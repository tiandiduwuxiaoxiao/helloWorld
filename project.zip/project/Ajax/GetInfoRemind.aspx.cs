﻿using System;
using System.Text;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using hugegis.DBUtility;
using BootStrapControls;

public partial class Ajax_GetInfoRemind : System.Web.UI.Page
{
    string result = string.Empty;
    public DataTable dt_new = null;
    public DataTable dt_overtime = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            GetData();
            
        }
        catch (System.Exception ex)
        {
            result = "<div>后台获取数据异常</div>";
            Loger.Error("获取工单提醒==>GetInfoRemind==>", ex);
        }
        try
        {
            result = GetMessageUL();
        }
        catch (System.Exception ex)
        {
            //只显示最基础的功能
            Loger.Error("获取工单提醒==>GetInfoRemind==>", ex);
        }
        Response.Write(result);
    }

    /// <summary>
    /// 获取新工单，获取超时工单
    /// </summary>
    public void GetData()
    {


        GetAllNew();

        GetAllOverTime();
    }


    /// <summary>
    /// 获取所有选项下工单总数（用于新工单提醒）
    /// </summary>
    /// <returns></returns>
    protected string GetAllNew()
    {
        
        List<UI_Menu> list1 = TempCache.UI_MenuList;
        List<UI_Menu> list2 = TempCache.UI_MenuList_Show;
        //Dictionary<string, string> dc = new Dictionary<string, string>();
        int shuliangcha =0;
        try
        {
            //差
            int cha =0;
            if (list1 != null && list2 != null)
            {
                //dr_cnt表示需要展示的最大数量
                int dr_cnt = 0;
                for (int i = 0; i < list1.Count; i++)
                {

                    List<UI_MenuItem> m1 = list1[i].MenuItemList;
                    List<UI_MenuItem> m2 = list2[i].MenuItemList;
                    for (int j = 0; j < m1.Count; j++)
                    {

                        UI_MenuItem item1 = m1[j];
                         UI_MenuItem item2 = null;
                         for (int ii = 0; ii < m2.Count; ii++)
                         {

                             if (m2[j].STATE == item1.STATE)
                             {
                                 item2 = m2[j];
                                 break;
                             }

                         }
                         if (int.Parse(item1.IsCreate) > 0 && item2 !=null)
                        {
                            if (int.Parse(item1.COUNT) > int.Parse(item2.COUNT))
                            {
                                cha = int.Parse(item1.COUNT) - int.Parse(item2.COUNT);
                                shuliangcha += cha;
                                //sql语句和数量
                                //dc.Add(item1.SQLCOUNT, cha.ToString());

                                string sqlcount = item1.SQLCOUNT;
                                string sql = @"SELECT ID, (CASE PRIORITY WHEN '2小时' THEN 1 ELSE 0 END) URGENCY_ORDER, (SELECT (CASE WHEN COUNT(*)>0 THEN 1 ELSE 0 END) FROM TRACK_MEDIA A WHERE A.EVENTRECORDID=B.ID) PHOTO, CUSTOMSERVICEID,INFONUM,ACCEPTTIME,SOLVETIME_PLAN,ACCEPTSTATION,REPORTTYPE,REPORTCONTENT,HAPPENADDR,ACCEPTREMARK FROM V_MAIN_TOKENLAST B WHERE 1=1 " + sqlcount + " order by ACCEPTTIME desc ";
                                dt_new = new DataTable();
                                dt_new.Columns.Add("ID");
                                dt_new.Columns.Add("CUSTOMSERVICEID");
                                dt_new.Columns.Add("ACCEPTTIME");
                                dt_new.Columns.Add("ACCEPTSTATION");
                                DataSet ds = new OracleDataBase().GetDataSet(sql);
                                if (ds != null && ds.Tables[0].Rows.Count>0)
                                {
                                    for (int k = 0; k < ds.Tables[0].Rows.Count && k < cha; k++)
                                    {

                                        DataRow dr_current = ds.Tables[0].Rows[k];

                                        DataRow dr = dt_new.NewRow();
                                        dr["ID"] = dr_current["ID"];
                                        dr["CUSTOMSERVICEID"] = dr_current["CUSTOMSERVICEID"];
                                        dr["ACCEPTTIME"] = dr_current["ACCEPTTIME"];
                                        dr["ACCEPTSTATION"] = dr_current["ACCEPTSTATION"];
                                        dt_new.Rows.Add(dr);

                                        dr_cnt++;
                                    }
                                }
                            }
                        }
                    }//for j
                }//for i


            }

        }
        catch(System.Exception ex)
        {
            Loger.Error("GetInfoRemind->GetAllOrderNumber->", ex);
        }

        
        return "";
    }

    protected void GetAllOverTime()
    {
        string sql1 = string.Empty;
        try
        {
            //获取新工单语句,包含3个字段，站点，工单号
            sql1 = @"
     select t.ID,t.CUSTOMSERVICEID,t.ACCEPTSTATION,t.handlingtime,t.remindtime,
     round((sysdate-t.handlingtime)*24) as OVERTIME_HOUR  from V_MAIN_TIMEOUT t
     order by t.ACCEPTSTATION,t.customserviceid,t.remindtime";

            DataSet ds = new OracleDataBase().GetDataSet(sql1);
            if (ds != null)
            {
                dt_overtime = ds.Tables[0];
            }
        }
        catch (System.Exception ex)
        {
            Loger.Error("获取超时工单语句出错->" + sql1, ex);
        }
    }

    private string GetMessageUL()
    {
        StringBuilder sb = new StringBuilder();
        //新工单提醒
        string s_new = GetNewOrderDropdown();
        sb.AppendLine(s_new);
        //超时工单提醒
        string s_overtime = GetOverTimeOrderDropdown();
        sb.AppendLine(s_overtime);

       
        return sb.ToString();
    }

    /// <summary>
    /// 新工单提醒
    /// </summary>
    /// <returns></returns>
    private string GetNewOrderDropdown()
    {
        NewMsgDropDown nmdd = new NewMsgDropDown();

        nmdd.IconClassName = "fa fa-envelope";
        nmdd.HeadName = "新工单";
        nmdd.HeadIconClassName = "fa fa-envelope";
        nmdd.FooterName = "查看更多...";
        nmdd.showFooter = true;
        nmdd.Footer_HREF = "javascript:alert('还没好！')";
        nmdd.MaxShowCount = 3;
        nmdd.NewMsgList = new List<NewMsgLi>();
        int cnt = 0;

        //NewMsgLi li1 = new NewMsgLi();
        //li1.Label = "label label-info";
        //li1.IconClassName = "fa fa-info";

        //li1.span_From = "廊坊分公司";
        //li1.span_Message = "160721152445";
        //li1.span_Message_Prophase = "新开单号：";
        //string js_string = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
        //li1.HREF = string.Format(js_string, li1.span_Message);

        //nmdd.NewMsgList.Add(li1);
        //int solid = DateTime.Now.Millisecond;
        //Random rd = new Random(solid);
        //cnt = rd.Next(10);

        //for (int i = 0; i < cnt; i++)
        //{
        //    NewMsgLi li_rd = new NewMsgLi();
        //    li_rd.Label = "label label-info";
        //    li_rd.IconClassName = "fa fa-info";
        //    li_rd.span_Message_Prophase = "新开单号：";

        //    li_rd.span_From = "廊坊分公司";
        //    li_rd.span_Message = "102" + rd.Next(1000).ToString();
        //    string js_string1 = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
        //    li_rd.HREF = string.Format(js_string1, li_rd.span_Message);
        //    nmdd.NewMsgList.Add(li_rd);
        //}
        if (dt_new != null && dt_new.Rows.Count > 0)
        {
            cnt = dt_new.Rows.Count;
            for (int i = 0; i < dt_new.Rows.Count; i++)
            {
                DataRow dr = dt_new.Rows[i];
                NewMsgLi li = new NewMsgLi();
                li.Label = "label label-info";
                li.IconClassName = "fa fa-info";
                li.span_Message_Prophase = "新开单号：";


                li.span_From = dr["ACCEPTSTATION"].ToString();
                li.span_Message = dr["CUSTOMSERVICEID"].ToString();

                string js_string = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
                li.HREF = string.Format(js_string, li.span_Message);
                nmdd.NewMsgList.Add(li);
            }

        }

        if (cnt<= nmdd.MaxShowCount)
        {
            nmdd.showFooter = false;
        }

        string s = nmdd.GetHtmlText();
        return s;
    }

    /// <summary>
    /// 超时工单提醒
    /// </summary>
    /// <returns></returns>
    private string GetOverTimeOrderDropdown()
    {

        OverTimeDropDown otdd = new OverTimeDropDown();
        
        otdd.IconClassName = "fa fa-bell";
        otdd.HeadName = "超时提醒";
        otdd.FooterName = "查看更多...";
        otdd.showFooter = true;
        otdd.Footer_HREF = "javascript:alert('还没好！！！')";
        otdd.MaxShowCount = 5;
        otdd.NewMsgList = new List<NewMsgLi>();


        int cnt = 0;

        //OverTimeLi li1 = new OverTimeLi();

        //li1.Label = "label label-warning";
        //li1.IconClassName = "fa fa-exclamation-triangle";
        //li1.span_Message_Prophase = "超时单号：";


        //li1.span_From = "廊坊分公司";
        //li1.span_Message = "160721133303";
        //int overtime = 9;
        //li1.span_OverTime = string.Format("超时{0}小时", overtime);
        //string js_string = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
        //li1.HREF = string.Format(js_string, li1.span_Message);
        //otdd.NewMsgList.Add(li1);

        //int solid = DateTime.Now.Second;

        //Random rd = new Random(solid);
        //cnt = rd.Next(10);
        //for (int i = 0; i < cnt; i++)
        //{
        //    OverTimeLi li_rd = new OverTimeLi();
        //    li_rd.Label = "label label-warning";
        //    li_rd.IconClassName = "fa fa-exclamation-triangle";
        //    li_rd.span_Message_Prophase = "超时单号：";


        //    li_rd.span_From = "廊坊分公司";
        //    li_rd.span_Message = "102" + rd.Next(1000).ToString();
        //    int overtime1 = rd.Next(72);
        //    li_rd.span_OverTime = string.Format("超时{0}小时", overtime1);
        //    string js_string1 = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
        //    li_rd.HREF = string.Format(js_string1, li_rd.span_Message);
        //    otdd.NewMsgList.Add(li_rd);
        //}

        if (dt_overtime != null && dt_overtime.Rows.Count > 0)
        {
            cnt = dt_overtime.Rows.Count;
            for (int i = 0; i < dt_overtime.Rows.Count; i++)
            {
                DataRow dr = dt_overtime.Rows[i];
                OverTimeLi li = new OverTimeLi();
                li.Label = "label label-warning";
                li.IconClassName = "fa fa-exclamation-triangle";
                li.span_Message_Prophase = "超时单号：";


                li.span_From = dr["ACCEPTSTATION"].ToString();
                li.span_Message = dr["CUSTOMSERVICEID"].ToString();
                int overtime = int.Parse(dr["OVERTIME_HOUR"].ToString());
                li.span_OverTime = string.Format("超时{0}小时", overtime);
                string js_string = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
                li.HREF = string.Format(js_string, li.span_Message);
                otdd.NewMsgList.Add(li);
            }

        }
        if (cnt <= otdd.MaxShowCount)
        {
            otdd.showFooter = false;
        }

        //string deptName = "廊坊分公司";
        //if (dt_overtime != null && dt_overtime.Rows.Count > 0)
        //{
        //    for (int i = 0; i < dt_overtime.Rows.Count; i++)
        //    {
        //        DataRow dr = dt_overtime.Rows[i];
        //        OverTimeLi li_rd = new OverTimeLi();
        //        li_rd.Label = "label label-warning";
        //        li_rd.IconClassName = "fa fa-exclamation-triangle";
        //        li_rd.span_Message_Prophase = "超时单号：";


        //        li_rd.span_From = dr["ACCEPTSTATION"].ToString();
        //        li_rd.span_Message = dr["CUSTOMERSERVICEID"].ToString();
        //        int overtime = int.Parse(dr["TONUMBER"].ToString());
        //        li_rd.span_OverTime = string.Format("超时{0}小时", overtime);
        //        string js_string1 = "javascript:window.open ('orderDetail.aspx?ID=' + {0},'_blank');";
        //        li_rd.HREF = string.Format(js_string1, li_rd.span_Message);
        //        otdd.NewMsgList.Add(li_rd);
        //    }
        //    if (cnt <= otdd.MaxShowCount)
        //    {
        //        otdd.showFooter = false;
        //    }
        //}


        string s = otdd.GetHtmlText();
        return s;
    }


    
}