﻿using System;
using System.Text;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Data.OracleClient;
using hugegis.DBUtility;

public partial class Ajax_GetPDAList : System.Web.UI.Page
{

    ProcessInfo processinfo = new ProcessInfo();
    string result = string.Empty;
    string MAIN_ID =  string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] title = { "操作", "人员", "在线状态", "站点", "电话","当前任务数" };
        MAIN_ID = Request["ID"].ToString();
        string sql = string.Empty;

        sql="select * from tz_main where 1=1";
        StringBuilder sb = new StringBuilder();

        sb.Append("<thead>");
        sb.Append("<tr>");
        for (int i = 0; i < title.Length; i++)
        {
            sb.Append("<th>");
            sb.Append(title[i]);
            sb.Append("</th>");
        }
        sb.Append("</tr>");
        sb.Append("</thead>");

        OracleConnection conn = Global.getOracleConnection(Decrypt.PropDBConn);
        try
        {
            string sql1 = string.Format("select * from v_author_user_res_view_paidan where id='{0}'", MAIN_ID);
            string uid = Request["uid"];//派遣人
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = conn;
            cmd.CommandText = sql1;
            Loger.Error("distributePDA.bindPDA_UserInfoByStation()==>" + sql1);
            OracleDataAdapter ada = new OracleDataAdapter(cmd);
            DataTable dt = new DataTable();
            ada.Fill(dt);
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dt.Rows[i];
                    sb.Append("<tr>");
                    sb.Append("<td>");
                    //派遣设备
                    string equipName = dr["EQUIPNAME"].ToString();
                    //string deptName = dr["depname"].ToString();
                    //string s1 = string.Format("<a onclick='SetPDA(this,{0},{1},{2})'>派遣</a>", deptName, equipName, MAIN_ID);
                    string s1 = string.Format("<a onclick='SetPDA(this,\"{0}\")' href=\"javascript:\">派遣</a>", equipName);
                    sb.Append(s1);
                    sb.Append("</td>");
                    sb.Append("<td>");
                    sb.Append(dr["realname"].ToString());
                    sb.Append("</td>");
                    sb.Append("<td>");
                    if (dr["ISZX"].ToString() == "离线")
                    {
                        sb.Append("<span class=\"label label-warning label-sm\">" + dr["ISZX"].ToString() + "</span>");
                    }
                    else
                    {
                        sb.Append("<span class=\"label label-success label-sm\">" + dr["ISZX"].ToString() + "</span>");
                    }
                    
                    sb.Append("</td>");
                    sb.Append("<td>");
                    sb.Append(dr["depname"].ToString());
                    sb.Append("</td>");
                    sb.Append("<td>");
                    sb.Append(dr["TEL"].ToString());
                    sb.Append("</td>");
                    sb.Append("<td>");
                    s1 = string.IsNullOrEmpty( dr["pcount"].ToString())?"0":dr["pcount"].ToString().ToString();
                    sb.Append(s1);
                    sb.Append("</td>");
                    sb.Append("</tr>");
                }
            }
           
            //this.GridView3.DataSource = dt;
            //this.GridView3.DataBind();
        }
        catch (Exception ex)
        {
            Loger.Error("getPDAList.aspx=====》bindPDA_UserInfoByStation", ex);
        }
        finally
        {
            conn.Close();
        }
        result = sb.ToString();
        Response.Write(result);
    }


}