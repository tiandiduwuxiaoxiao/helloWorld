﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class Ajax_GetChartData : System.Web.UI.Page
{

    public string title_text = "Ajax获取数据";

    public string[] types = { "bar", "line", "pie" };



    public string[] xAxis_data = { "周一", "周二", "周三", "周四", "周五", "周六", "周日"};

    public string legent_data = "温度";

    public string series_name = "温度";

    public string series_type = "bar";

    public string[] series_data = { "1", "2", "3", "4", "5", "6", "7"};

        //考虑到图表的category是字符串数组 这里定义一个string的List
    List<string> categoryList = new List<string>();

    //考虑到Echarts图表需要设置legend内的data数组为series的name集合这里需要定义一个legend数组
    List<string> legendList = new List<string>();

    //考虑到图表的series数据为一个对象数组 这里额外定义一个series的类
    List<Series> seriesList = new List<Series>();



    public string pointCount;



    public void GeteChartOption()
    {
        int _pointCount;
        //如果数据非整型 默认给予10个数据
        if (!int.TryParse(pointCount, out  _pointCount))
        {
            _pointCount = 10;
        }

        //设置legend数组
        legendList.Add("Series 1"); //这里的名称必须和series的每一组series的name保持一致

        //定义一个Series对象
        Series seriesObj = new Series();
        seriesObj.id = 1;
        seriesObj.name = "Series 1";
        seriesObj.type = "line"; //线性图呈现
        seriesObj.type = this.types[drawType];
        seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错

        //设置数据
        for (int i = 1; i <= 7; i++)
        {
            //加入category刻度数组
            categoryList.Add(xAxis_data[i-1]);

            //加入数据值series序列数组 这里提供为了效果只提供一组series数据好了                
            seriesObj.data.Add(i); //数据依次递增
        }
        //将sereis对象压入sereis数组列表内
        seriesList.Add(seriesObj);

        //最后调用相关函数将List转换为Json
        //因为我们需要返回category和series、legend多个对象 这里我们自己在new一个新的对象来封装这两个对象
        //var newObj = new
        //{
        //    title ="样例标题",
        //    category = categoryList,
        //    series = seriesList,
        //    legend = legendList
        //};
        EChartOption newOption = new EChartOption();
        newOption.Title = title_text;
        newOption.Category = categoryList;
        newOption.Series = seriesList;
        newOption.Legend = legendList;



        //Response返回新对象的json数据
        string jsonString = "";
        jsonString = Json.JsonSerializerBySingleData<EChartOption>(newOption);
        Response.Write(jsonString);
        Response.End();
    }

    private int drawType = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["TYPE"] != null)
        {
            drawType = Convert.ToInt32(Request["TYPE"]);
        }

        GeteChartOption();
    }
}

