﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OracleClient;
using System.Data;
using System.Collections;
using System.IO;
using System.Text;

public partial class Ajax_GetReport : System.Web.UI.Page
{
    public string uid = "";
    public string PROC_REPORTNAME = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];

        if (Request["flag"] == "loadCondtionHtml") loadCondtionHtml();//获取查询条件
        else if (Request["flag"] == "loadTableColumn") loadTableColumn();//表格列
        else if (Request["flag"] == "doQuery") doQuery();//查询
        else if (Request["flag"] == "doExport") doExport();//导出
    }

    /// <summary>
    /// 获取表格列
    /// </summary>
    private void loadTableColumn()
    {
        StringBuilder sb = new StringBuilder();
        Hashtable searchHashtable = InitCache.xwbm_sjzd;
        string rtid = Request["rtID"];//ID
        string procName = GetProcName(rtid);//查询配置的存储过程名称
        ArrayList seaList = (ArrayList)searchHashtable[procName.ToUpper()];
        sb.Append("[");
        int index = 0;
        foreach (var dc in seaList)
        {
            DictionaryContent item = (DictionaryContent)dc;
            if (item.fieldName == "ID" || item.fieldName == "URGENCY_ORDER" || item.fieldName == "PHOTO")
                sb.Append("{ \"mData\": \"" + item.fieldName + "\", \"sTitle\" : \"" + item.fieldAliasName + "\", \"sClass\": \"center\", \"bVisible\": false }");
            else
            {
                if (!string.IsNullOrWhiteSpace(item.listlength))
                {
                    sb.Append("{ \"mData\": \"" + item.fieldName + "\", \"sTitle\" : \"" + item.fieldAliasName +
                              "\",\"sWidth\": \"" + item.listlength + "px\"}");
                }
                else
                {
                    if (Convert.ToInt32(item.fieldLength) >= 200)
                    {
                        sb.Append("{ \"mData\": \"" + item.fieldName + "\", \"sTitle\" : \"" + item.fieldAliasName +
                                  "\" ,\"sWidth\": \"260px\"}");
                    }
                    else
                    {
                        sb.Append("{ \"mData\": \"" + item.fieldName + "\", \"sTitle\" : \"" + item.fieldAliasName + "\",\"sWidth\": \"170px\"}");
                    }
                }
                sb.Append(",");
            }
        }
        sb.Remove(sb.Length - 1, 1);
        sb.Append("] ");

        Response.Write(sb.ToString());
        Response.End();
    }

    /// <summary>
    /// 导出
    /// </summary>
    private void doExport()
    {
        string rtid = Request["rtID"];//ID
        string sqlFilter = Request["sqlFilter"];//Sql查询条件
        string iSortCol = Request["iSortCol_0"] ?? "";

        string sSortDir = Request["sSortDir_0"] ?? "";
        string mDataProp = Request["mDataProp_" + iSortCol] ?? "";
        string iDisplayStart = Request["iDisplayStart"];
        string iDisplayLength = Request["iDisplayLength"];
        string mType = "export";
        int iStart = 0;
        if (string.IsNullOrEmpty(iDisplayStart))
            iStart = 0;
        else
            iStart = Convert.ToInt32(iDisplayStart);
        int pageSize = 10;
        if (string.IsNullOrEmpty(iDisplayLength))
            pageSize = 10;
        else
            pageSize = Convert.ToInt32(iDisplayLength);
        int indexPage = iStart / pageSize;
        int totalRecord = 0;
        string count = "0";

        string procName = GetProcName(rtid);//查询配置的存储过程名称
        DataTable dt = GetDataTable(sqlFilter, procName, sSortDir, mDataProp, iStart, pageSize, mType, ref count);//获取数据

        Hashtable searchHashtable = InitCache.xwbm_sjzd;
        ArrayList dList = new ArrayList();
        ArrayList seaList = null;
        string _html = string.Empty;
        seaList = (ArrayList)searchHashtable[procName.ToUpper()];
        for (int i = 0; i < seaList.Count; i++)
        {

            DictionaryContent dc = (DictionaryContent)seaList[i];
            if (!dc.style.Contains("40"))
            {
                continue;
            }
            dList.Add(dc);
        }
        List<string> itList = new List<string>();
        for (int i = 0; i < dt.Columns.Count; i++)
        {
            int t = 0;
            foreach (DictionaryContent item in dList)
            {
                if (dt.Columns[i].ColumnName.ToUpper() == item.fieldName.ToUpper())
                {
                    dt.Columns[i].ColumnName = item.fieldAliasName;
                    t++;
                }
            }
            if (t == 0)
            {
                itList.Add(dt.Columns[i].ColumnName);
            }
            t = 0;
        }
        if (itList.Count > 0)
        {
            foreach (string item in itList)
            {
                dt.Columns.Remove(item);
            }
        }
        DataSet ds = new DataSet();
        ds.Tables.Add(dt);
        ds.AcceptChanges();
        ExcelExport.CommExportExcel(ds, null, "报表导出");

    }


    /// <summary>
    /// 类别统计
    /// </summary>
    public void loadCondtionHtml()
    {
        string rtid = Request["rtID"];//ID
        string procName = GetProcName(rtid);//查询配置的存储过程名称
        string tablename = Request["tablename"];
        if (!string.IsNullOrWhiteSpace(tablename))
        {
            procName = tablename;
        }
        string search = GetSearchInfo(procName);//通过存储过程名称获取搜索条件

        Response.Write(search);
        Response.End();
    }
    public void doQuery()
    {
        string rtid = Request["rtID"];//ID
        string sqlFilter = Request["sqlFilter"];//Sql查询条件
        string iSortCol = Request["iSortCol_0"];

        string sSortDir = Request["sSortDir_0"] ?? "";
        string mDataProp = Request["mDataProp_" + iSortCol] ?? "";
        string iDisplayStart = Request["iDisplayStart"];
        string iDisplayLength = Request["iDisplayLength"];
        string sEcho = Request["sEcho"] ?? "";
        string mType = "search";
        int iStart = 0;
        if (string.IsNullOrEmpty(iDisplayStart))
            iStart = 0;
        else
            iStart = Convert.ToInt32(iDisplayStart);
        int pageSize = 10;
        if (string.IsNullOrEmpty(iDisplayLength))
            pageSize = 10;
        else
            pageSize = Convert.ToInt32(iDisplayLength);
        int indexPage = iStart / pageSize;
        int totalRecord = 0;

        string procName = GetProcName(rtid);//查询配置的存储过程名称
        string reports = GetReport(sqlFilter, procName, sSortDir, mDataProp, iStart, pageSize, mType, sEcho);
        Response.Write(reports);
        Response.End();
    }
    /// <summary>
    /// 拼接html
    /// </summary>
    /// <param name="dt">结果集</param>
    /// <param name="PROC_NAME">存储过程名称</param>
    public string GetReportHTML(DataTable dt, string PROC_NAME)
    {

        Hashtable searchHashtable = InitCache.xwbm_sjzd;
        ArrayList dList = new ArrayList();
        ArrayList seaList = null;
        string _html = string.Empty;
        seaList = (ArrayList)searchHashtable[PROC_NAME.ToUpper()];
        if (seaList != null)
        {
            _html += "<div class=\"row\">";
            _html += "<div class=\"col-md-12\">";
            _html += "<div class=\"panel panel-default\">";
            _html += "<div class=\"panel-body\">";
            _html += "<table class=\"table table-striped table-bordered table-hover\" Id=\"tableReport\">";
            _html += "<thead>";
            _html += "<tr>";
            for (int i = 0; i < seaList.Count; i++)
            {
                DictionaryContent dc = (DictionaryContent)seaList[i];
                _html += "<th><i class=\"fa\"></i> " + dc.fieldAliasName + "</th>";
            }
            _html += "</tr>";
            _html += "</thead>";
            _html += "<tbody>";
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                _html += "<tr>";
                for (int j = 0; j < seaList.Count; j++)
                {
                    DictionaryContent dc = (DictionaryContent)seaList[j];
                    if (dt.Columns.Contains(dc.fieldName))
                    {
                        _html += "<td>" + dt.Rows[i][dc.fieldName] + "</td>";
                    }
                    else
                    {
                        _html += "<td></td>";
                    }
                }
                _html += "</tr>";
            }
            _html += "</tbody>";
            _html += "</table>";
            _html += "</div>";
            _html += "</div>";
            _html += "</div>";
            _html += "</div>";
        }
        return _html;
    }
    /// <summary>
    /// 获取搜索条件
    /// </summary>
    /// <param name="PROC_NAME">存储过程名称<param>
    public string GetSearchInfo(string PROC_NAME)
    {
        OracleDataBase odb = new OracleDataBase();
        string SearchHtml = "";
        int cnt = 1;
        try
        {
            string sql = "select * from v_dict t where t.tablename='" + PROC_NAME.ToUpper() + "' and t.validity='0'";
            DataTable Search = odb.GetDataSet(sql).Tables[0];

            foreach (DataRow item in Search.Rows)
            {
                string inputStr = string.Empty;
               
                if (Convert.ToInt32(item["SEARCH"]) == 1)
                {
                    if (cnt % 4 == 1)
                    {
                        SearchHtml += "<div class='row' style='margin:0px'>";
                    }

                    string fieldname = item["fieldname"] == null ? "" : item["fieldname"].ToString().ToUpper();
                    string Fielddisname = item["Fielddisname"] == null ? "" : item["Fielddisname"].ToString();
                    inputStr = "<div  class=\"col-xs-3\"><label>" + Fielddisname + ":</label><input runat=\"server\" class=\"form-control\" value=\"\" placeholder=\"" + Fielddisname + "\" name=\"" + fieldname + "\" type=\"text\" id=\"" + fieldname + "\" /></div>";
                    #region 时间
                    if (Convert.ToString(item["fieldstyle"]).Contains("50"))
                    {
                       
                        inputStr = "<div class=\"col-xs-3\"><label>开始" + Fielddisname + ":</label><input runat=\"server\" class=\"form-control layer-date\" placeholder=\"" + Fielddisname + "\" onclick=\"laydate({istime: true, format: 'YYYY-MM-DD hh:mm:ss'})\" value=\"\" name=\"BEG_" + fieldname + "\" type=\"text\" id=\"BEG_" + fieldname + "\"/></div>";
                        inputStr = inputStr + "<div class=\"col-xs-3\"><label>结束" + Fielddisname + ":</label><input runat=\"server\" class=\"form-control layer-date\" placeholder=\"" + Fielddisname + "\" onclick=\"laydate({istime: true, format: 'YYYY-MM-DD hh:mm:ss'})\" value=\"\" name=\"END_" + fieldname + "\" type=\"text\" id=\"END_" + fieldname + "\"  /></div>";
                    }
                    #endregion
                    #region 下拉框
                    if (Convert.ToString(item["mappingcode"]).Equals("1"))
                    {
                        string MAPPSQL = item["MAPPSQL"] == null ? "" : item["MAPPSQL"].ToString();
                        string validrules = item["validrules"] == null ? "" : item["validrules"].ToString().ToUpper();
                        string SUBFIELD = item["SUBFIELD"] == null ? "" : item["SUBFIELD"].ToString().ToUpper();
                        if (!string.IsNullOrEmpty(MAPPSQL))
                        {
                            DataTable dt = odb.GetDataSet(MAPPSQL).Tables[0];
                            inputStr = "<div class=\"col-xs-3\">  <div class=\"form-group\"><label>" + Fielddisname + ":</label><select class=\"form-control\"  placeholder=\"" + Fielddisname + "\"  size=\"1\" name=\"" + fieldname + "\" id=\"" + fieldname + "\"><option value=\"\">==请选择==</option>";
                            
                            if (!string.IsNullOrEmpty(SUBFIELD))
                            {
                                inputStr = "<div class=\"col-xs-3\"><div class=\"form-group\"><label>" + Fielddisname + ":</label><select class=\"form-control\"  onchange=\"selectChange(this)\"  placeholder=\"" + Fielddisname + "\" fielddata=\"" + SUBFIELD + "\" size=\"1\" name=\"" + fieldname + "\" id=\"" + fieldname + "\"><option value=\"\">==请选择==</option>";
                            }
                          
                            for (int j = 0; j < dt.Rows.Count; j++)
                            {
                                string temp = "<option wordscode=\"" + dt.Rows[j]["wordscode"] + "\" value=\"" + dt.Rows[j]["wordscontent"].ToString() + "\">" + dt.Rows[j]["wordscontent"].ToString() + "</option>";
                                inputStr += temp;
                            }
                            inputStr += "<asp:HiddenField ID=\"" + fieldname + "s\" runat=\"server\" />";
                            inputStr += "</select></div></div> ";
                           
                        }
                    }
                    #endregion
                    SearchHtml += inputStr;
                    if (cnt % 4 == 0)
                    {
                        SearchHtml += "</div>";
                    }
                    if (Convert.ToString(item["fieldstyle"]).Contains("50"))
                    {
                        cnt++;
                    }
                    cnt++;
                }

            }
            if (cnt%4 != 0)
            {
                SearchHtml +=
                    "<div id=\"div_ss\" class=\"col-xs-3\" style=\"padding-top:24px\"> <a class=\"js_update btn btn-primary\" href=\"javascript:doSearch()\" ><i class='fa fa-search'>搜索</i></a></div>";
                SearchHtml += "</div>";
            }
            else
            {
                SearchHtml +=
                   "<div class='row' style='margin:0px'><div id=\"div_ss\" class=\"col-xs-3\" style=\"padding-top:24px\"> <a class=\"js_update btn btn-primary\" href=\"javascript:doSearch()\" ><i class='fa fa-search'>搜索</i></a></div></div>";
            }

        }
        catch (Exception ex)
        {
            Loger.Error("GetSearchInfo===>" + ex);
        }
        finally
        {
            odb.Close();
        }
        return SearchHtml;
    }
    /// <summary>
    /// 获取存储过程名称
    /// </summary>
    /// <param name="_rid">ID</param>
    public string GetProcName(string _rid)
    {
        OracleDataBase odb = new OracleDataBase();
        string procName = "";
        try
        {
            string sql = string.Format(@" SELECT PROCENAME  FROM PZ_REPORT M WHERE 1=1 and ISVISIBLE='{0}' and ID='{1}'  order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), _rid);
            procName = odb.GetScalarInfo(sql);
        }
        catch (Exception ex)
        {
            Loger.Error("GetProcName===>" + ex);
        }
        finally
        {
            odb.Close();
        }
        return procName;
    }

    /// <summary>
    /// 查询报表
    /// </summary>
    /// <param name="sqlFilter">sql拼接条件</param>
    /// <param name="procName"></param>
    /// <param name="sSortDir">desc/asc</param>
    /// <param name="mDataProp">排序字段</param>
    /// <param name="iStart">起始记录</param>
    /// <param name="pageSize">每页多少条</param>
    public string GetReport(string sqlFilter, string procName, string sSortDir, string mDataProp, int iStart, int pageSize, string mType, string sEcho)
    {
        string _html = "";
        try
        {
            string count = "0";
            DataTable dt = GetDataTable(sqlFilter, procName, sSortDir, mDataProp, iStart, pageSize, mType, ref count);
            //_html=GetReportHTML(dt, procName);
            _html = GetReportTable(dt, sEcho, count);
        }
        catch (Exception ex)
        {
            Loger.Error("GetReport===>" + ex);
        }
        return _html;
    }
    /// <summary>
    /// DataTable拼接
    /// </summary>
    /// <param name="dt">结果集</param>
    private string GetReportTable(DataTable dt, string sEcho, string totalRecord)
    {
        string result = Json.ToJson(dt);
        StringBuilder jsonStr = new StringBuilder();
        jsonStr.Append("{\"sEcho\":" + sEcho + ",");
        jsonStr.Append("\"iTotalRecords\":" + totalRecord + ",");
        jsonStr.Append("\"iTotalDisplayRecords\":" + totalRecord + ",");
        jsonStr.Append("\"aaData\":" + result + "}");
        return jsonStr.ToString();
    }


    /// <summary>
    /// 获取查询DataTable
    /// </summary>
    /// <param name="sqlFilter"></param>
    /// <param name="procName"></param>
    /// <returns></returns>
    public DataTable GetDataTable(string sqlFilter, string procName, string sSortDir, string mDataProp, int iStart, int pageSize, string mType, ref string count)
    {
        List<OracleParameter> list = new List<OracleParameter>();
        OracleDataBase odb = new OracleDataBase();
        odb.Open();

        OracleParameter op = new OracleParameter("sqlFilter", OracleType.VarChar);
        op.Direction = ParameterDirection.Input;
        op.Value = sqlFilter;
        list.Add(op);

        OracleParameter opsSortDir = new OracleParameter("sSortDir", OracleType.VarChar);
        opsSortDir.Direction = ParameterDirection.Input;
        opsSortDir.Value = sSortDir;
        list.Add(opsSortDir);

        OracleParameter opmDataProp = new OracleParameter("mDataProp", OracleType.VarChar);
        opmDataProp.Direction = ParameterDirection.Input;
        opmDataProp.Value = mDataProp;
        list.Add(opmDataProp);

        OracleParameter opiStart = new OracleParameter("iStart", OracleType.VarChar);
        opiStart.Direction = ParameterDirection.Input;
        opiStart.Value = iStart;
        list.Add(opiStart);

        OracleParameter oppageSize = new OracleParameter("pageSize", OracleType.VarChar);
        oppageSize.Direction = ParameterDirection.Input;
        oppageSize.Value = pageSize;
        list.Add(oppageSize);

        OracleParameter opmType = new OracleParameter("mType", OracleType.VarChar);
        opmType.Direction = ParameterDirection.Input;
        opmType.Value = mType;
        list.Add(opmType);

        OracleParameter opOutcount = new OracleParameter("p_count", OracleType.VarChar, 50);
        opOutcount.Direction = ParameterDirection.Output;
        list.Add(opOutcount);

        OracleParameter opOut = new OracleParameter("p_cursor", OracleType.Cursor);
        opOut.Direction = ParameterDirection.Output;
        list.Add(opOut);


        count = "0";
        DataTable dt = odb.getPro(procName, list, ref count);
        return dt;
    }
}