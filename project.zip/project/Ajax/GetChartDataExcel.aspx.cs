﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ajax_GetChartDataExcel : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
      ExportEchartData exportEchart = new ExportEchartData();
     string flag=Convert.ToString(Request["flag"]);
     if (!string.IsNullOrWhiteSpace(flag))
     {
         string num = Convert.ToString(Request["num"]);
         string type = Convert.ToString(Request["type"]);
         switch (flag)
         {
             case "loadLineChars": exportEchart.loadLineChars(num, type); break;
             default:
                 break;
         }
     }
    
    }
}