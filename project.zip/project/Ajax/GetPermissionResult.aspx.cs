using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;

public partial class Ajax_GetPermissionResult : System.Web.UI.Page
{
    private MyAuth.authServices.WSPermissionResult permissionResult = null;
    private string source = "1";
    private string userDEPNAME = "";
    private string realName = "";
    private string orderid = "";
    public string uid = String.Empty;
    DataTable dt;
    Dictionary<string, bool> _dicAccpt = new Dictionary<string, bool>();

    #region Page_load加载
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];
        permissionResult = Global.getPermission(uid);
        userDEPNAME = Global.GetDepname(uid);
        realName = permissionResult.user.realName;
        string _PermissionBtnhtml = string.Empty;
        string _leftbtnMenuhtml = string.Empty;
        orderid = Request["ID"];
        string strISHXSql = "select * from tz_main where id = '" + orderid + "'";
        OracleDataBase dao = new OracleDataBase();
        dt = dao.GetDataSet(strISHXSql).Tables[0];
        string Acceptstation = string.Empty;
        string ShAcceptstation = string.Empty;
        if (dt.Rows.Count > 0)
        {
            Acceptstation = Convert.ToString(dt.Rows[0]["Acceptstation"]);
            ShAcceptstation = Convert.ToString(dt.Rows[0]["ShAcceptstation"]);
        }
        _dicAccpt = CompAcceptstation(Acceptstation, ShAcceptstation);
        bool _manyOrderfalg = Request["manyOrderId"].Split('|').Count() > 2 ? true : false;
        _PermissionBtnhtml = getInit(_manyOrderfalg, dt);
        string json = "{\"PermissionBtn\": \"" + _PermissionBtnhtml + "\"}";
        Response.Write(json);
    }
    #endregion

    #region List-Top上面的功能按钮
    public string getInit(bool manyOrderfalg, DataTable ds)
    {
        string _html = string.Empty;
        try
        {
            string radom = Guid.NewGuid().ToString();

            if (Global.isHaveAuth(permissionResult, "use", "短信发送"))
            {
                _html += "<a href='javascript:sendOrder();'><i class='fa fa-comment-o'></i>&nbsp;发送短信&nbsp;|</a>";
            }

            if (ds.Rows.Count > 0)
            {
                string tokenName = ("'" + Convert.ToString(ds.Rows[0]["TokenName"]) + "'").ToString();
                string fId = Convert.ToString(ds.Rows[0]["FID"]);
                string isxjsh = Convert.ToString(ds.Rows[0]["isxjsh"]);
                string issecret = Convert.ToString(ds.Rows[0]["issecret"]);


                #region 拆分工单or 后续跟进单 or 内部子工单
                if (string.IsNullOrEmpty(fId) && issecret != "1")
                {
                    if (Global.isHaveAuth(permissionResult, "use", "拆分工单") && tokenName == ConfigurationManager.AppSettings["Z_Not_Send"].ToString() && _dicAccpt["ACCP"] == true)
                    {
                        _html += "<a href=\\\"javascript:splitOrder('" + userDEPNAME + "','" + realName + "');\\\"><i class='fa fa-files-o'></i>&nbsp;拆分工单&nbsp;|</a>";
                    }
                    if (Global.isHaveAuth(permissionResult, "use", "后续跟进单") && tokenName == ConfigurationManager.AppSettings["Z_Yet_Close"].ToString())
                    {
                        _html += "<a href=\\\"javascript:followOrder('" + userDEPNAME + "','" + realName + "');\\\"><i class='fa fa-paste'></i>&nbsp;后续跟进单&nbsp;|</a>";
                    }
                    if (Global.isHaveAuth(permissionResult, "use", "内部子工单"))
                    {
                        _html += "<a href=\\\"javascript:internalOrder('" + userDEPNAME + "','" + realName + "');\\\"><i class='fa fa-columns'></i>&nbsp;内部子工单&nbsp;|</a>";
                    }
                }
                #endregion

                if (!manyOrderfalg)
                {
                    #region  受理战点
                    if (tokenName == ConfigurationManager.AppSettings["Z_Not_Send"].ToString() && issecret == "0" && _dicAccpt["ACCP"] == true)
                    {
                        if (isxjsh == "1")
                        {

                            if (Global.isHaveAuth(permissionResult, "use", "工单删除"))
                            {
                                _html += " <a href=\\\"javascript:DeleteOrder('" + Convert.ToString(ds.Rows[0]["ID"]) +
                                         "');\\\"><i class='fa fa-trash-o'></i>&nbsp;工单删除&nbsp;|</a>";
                            }
                            if (Global.isHaveAuth(permissionResult, "use", "终端延期"))
                            {
                                _html += "<a href=\\\"javascript:Skip('O_check_TrackOrder.aspx');\\\"><i class='fa fa-clock-o'></i>&nbsp;直接延期&nbsp;|</a>";
                            }
                            if (Global.isHaveAuth(permissionResult, "use", "直接退单"))
                            {
                                if (source != "2")
                                {
                                    _html += "<a href=\\\"javascript:returnOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-clock-o'></i>&nbsp;直接退单&nbsp;|</a>";
                                }
                            }
                        }
                    }
                    #endregion

                    if (tokenName == ConfigurationManager.AppSettings["Z_Not_DEL"].ToString() && Global.isHaveAuth(permissionResult, "use", "取消工单删除") && isxjsh != "0" && _dicAccpt["ACCP"] == true)
                    {
                        _html += "<a href=\\\"javascript:CanleDeleteOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "');\\\"><i class='fa fa-clock-o'></i>&nbsp;恢复工单&nbsp;|</a>";
                    }
                    if (tokenName != ConfigurationManager.AppSettings["Z_Not_Send"].ToString() && Global.isHaveAuth(permissionResult, "use", "工单重置") && isxjsh != "0" && _dicAccpt["ACCP"] == true)
                    {
                        _html += "<a href=\\\"javascript:resetOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-clock-o'></i>&nbsp;工单重置&nbsp;|</a>";
                    }
                    if (Global.isHaveAuth(permissionResult, "use", "工单打印") && issecret == "0")
                    {
                        _html += "<a href=\\\"javascript:PrintExcle('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "');\\\"><i class='fa fa-print'></i>&nbsp;工单打印&nbsp;|</a>";
                    }
                    if (tokenName != ConfigurationManager.AppSettings["Z_Yet_Close"].ToString() && Global.isHaveAuth(permissionResult, "use", "工单催办") && isxjsh != "0")
                    {
                        _html += "<a href=\\\"javascript:Skip('CuibanOrder.aspx');\\\"><i class='fa fa-bell-o'></i>&nbsp;工单催办&nbsp;|</a>";
                    }
                    if ((tokenName == ConfigurationManager.AppSettings["Z_Apply_Close"].ToString() || tokenName == ConfigurationManager.AppSettings["Z_Yet_Close"].ToString()) && isxjsh != "0" && (_dicAccpt["ACCP"] == true || _dicAccpt["SHACCP"]))
                    {
                        if (Global.isHaveAuth(permissionResult, "use", "添加材料"))
                        {
                            _html += "<a href='javascript:addCaiLiaoInfo();'><i class='fa fa-bell-o'></i>&nbsp;添加材料&nbsp;|</a>";
                        }
                    }
                    #region "重复"
                    if (tokenName == ConfigurationManager.AppSettings["Z_Not_Send"].ToString() && isxjsh != "0" && issecret == "0" && _dicAccpt["ACCP"] == true)
                    {
                        if (Global.isHaveAuth(permissionResult, "use", "标识重复"))
                        {
                            _html += "<a href=\\\"javascript:Skip('RepeatOrder.aspx');\\\"><i class='fa fa-retweet'></i>&nbsp;重复工单&nbsp;|</a>";
                        }
                    }
                    if (issecret == "1")
                    {
                        if (Global.isHaveAuth(permissionResult, "use", "取消标识重复") && _dicAccpt["ACCP"] == true)
                        {
                            _html += "<a href=\\\"javascript:CancelRepeatOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-retweet'></i>&nbsp;取消重复&nbsp;|</a>";
                        }
                    }
                    #endregion
                }


                #region 办事处终端接单
                if (tokenName == ConfigurationManager.AppSettings["Z_Not_Send"].ToString() && issecret != "1" && _dicAccpt["ACCP"] == true)
                {
                    if (Global.isHaveAuth(permissionResult, "use", "工单编辑") && manyOrderfalg != true)
                    {
                        _html += "<a href=\\\"javascript:Skip('EditOrder.aspx');\\\"><i class='fa fa-pencil-square-o'></i>&nbsp;工单编辑&nbsp;|</a>";
                    }
                    if (isxjsh == "1" && manyOrderfalg != true)
                    {
                        if (Global.isHaveAuth(permissionResult, "use", "接口派单"))
                        {
                            _html += "<a href=\\\"javascript:directToOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-twitter'></i>&nbsp;接口派单&nbsp;|</a>";
                        }

                        if (Global.isHaveAuth(permissionResult, "use", "派遣手机"))
                        {
                            _html += "<a href=\\\"javascript:Skip('distributePDAModel.aspx');\\\"><i class='fa fa-mobile-phone'></i>&nbsp;派遣手机&nbsp;|</a>";
                        }

                        if (Global.isHaveAuth(permissionResult, "use", "派遣站点"))
                        {
                            _html += "<a href=\\\"javascript:ZZOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-sitemap'></i>&nbsp;派遣站点&nbsp;|</a>";
                        }
                        if (Global.isHaveAuth(permissionResult, "use", "自销单"))
                        {
                            _html += "<a href=\\\"javascript:directClosingOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-mail-reply-all'></i>&nbsp;自销单&nbsp;|</a>";
                        }
                        if (Global.isHaveAuth(permissionResult, "use", "申请销单"))
                        {
                            _html += "<a href=\\\"javascript:Skip('PcOrderXD.aspx');\\\"><i class='fa fa-file-text-o'></i>&nbsp;申请销单&nbsp;|</a>";
                        }

                    }
                    else if (isxjsh == "1" && manyOrderfalg == true)
                    {
                        if (Global.isHaveAuth(permissionResult, "use", "一键销单"))
                        {
                            _html += "<a href=\\\"javascript:closingMoreOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-outdent'></i>&nbsp;一键销单&nbsp;|</a>";
                        }
                    }
                    else if (isxjsh == "0" && manyOrderfalg != true)
                    {
                        if (Global.isHaveAuth(permissionResult, "use", "巡检审核"))
                        {
                            _html += "<a href=\\\"javascript:XJToOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-share-square-o'></i>&nbsp;巡检审核&nbsp;|</a>";
                        }
                    }
                }
                #endregion
                #region 办事处终端销单审核
                else if (tokenName.Equals(ConfigurationManager.AppSettings["Z_Apply_Close"].ToString()) && manyOrderfalg != true && _dicAccpt["SHACCP"] == true)
                {

                    if (Global.isHaveAuth(permissionResult, "use", "办事处审核销单"))
                    {
                        _html += "<a href=\\\"javascript:checkOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-check-square-o'></i>&nbsp;审核销单&nbsp;|</a>";
                    }
                    if (Global.isHaveAuth(permissionResult, "use", "接口审核销单"))
                    {
                        _html += "<a href=\\\"javascript:checkJkOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-check-square-o'></i>&nbsp;审核销单&nbsp;|</a>";
                    }
                }
                #endregion
                #region "延期审核"
                if (tokenName.Equals(ConfigurationManager.AppSettings["Z_Apply_Delay"].ToString()) && manyOrderfalg != true && _dicAccpt["SHACCP"] == true)
                {

                    if (Global.isHaveAuth(permissionResult, "use", "办事处审核延期"))
                    {
                        _html += "<a href=\\\"javascript:checkOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-check-square-o'></i>&nbsp;审核延期&nbsp;|</a>";
                    }
                }
                #endregion
                #region "退单审核"
                if (tokenName.Equals(ConfigurationManager.AppSettings["Z_Apply_Exit"].ToString()) && manyOrderfalg != true && _dicAccpt["SHACCP"] == true)
                {
                    if (Global.isHaveAuth(permissionResult, "use", "办事处审核退单"))
                    {
                        _html += "<a href=\\\"javascript:checkOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-check-square-o'></i>&nbsp;审核退单&nbsp;|</a>";
                    }
                }

                #endregion
            }
            if (manyOrderfalg != true)
            {
                _html += "<a href=\\\"javascript:traceBackOrder('" + Convert.ToString(ds.Rows[0]["ID"]) + "','" + Convert.ToString(ds.Rows[0]["customserviceid"]) + "','" + uid + "');\\\"><i class='fa fa-sort-amount-asc'></i>&nbsp;任务追溯&nbsp;|</a>";
            }
            _html += "  <a href=\\\"javascript:showPhoto();\\\"><i class='fa fa-picture-o'></i>&nbsp;图片</a>";
        }
        catch (Exception ex)
        {
            Loger.Error("GetPermissionResult.aspx===>getInit:" + ex);
        }
        return _html;
    }
    #endregion



    #region  返回当前人是否在受理站点及审核站点中
    public Dictionary<string, bool> CompAcceptstation(string Acceptstation, string ShAcceptstation)
    {
        Dictionary<string, bool> dic = new Dictionary<string, bool>();
        dic.Add("ACCP", false);
        dic.Add("SHACCP", false);
        var res = permissionResult.permissions.Where(it => it.resourceCategoryName == "现维受理站点");
        foreach (var item in res)
        {
            if (Acceptstation == item.resourceName)
            {
                dic["ACCP"] = true;
            }
        }
        var ress = permissionResult.permissions.Where(it => it.resourceCategoryName == "审核站点");
        foreach (var item in ress)
        {
            if (ShAcceptstation == item.resourceName)
            {
                dic["SHACCP"] = true;
            }
        }
        return dic;
    }
    #endregion

}