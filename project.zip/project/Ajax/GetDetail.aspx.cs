﻿using System;
using System.Text;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using hugegis.DBUtility;
using Maticsoft.DBUtility;
using BootStrapControls;



public partial class Ajax_GetDetail : System.Web.UI.Page
{
    public string MAIN_ID = string.Empty;
    string result = "工单数据有误！";
    public Hashtable HT = new Hashtable();
    public Hashtable HT_Status = new Hashtable();
    public Hashtable HT_FIELDNAME = new Hashtable();//取出S_dict表的FIELDNAME
    public string orderState = "";
    public string ReturnType = "0";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["ID"] != null)
        {
            try
            {
                MAIN_ID = Request["ID"];
                //写入html
                GetData();
                SetData();
                //BtsBox box_orderdetail = new BtsBox();
                //box_orderdetail.BoxClass = "box border blue";
                //box_orderdetail.BtsBoxTitle.TitleHead.IconClass = "fa fa-bars";
                //box_orderdetail.BtsBoxTitle.TitleHead.Text = "工单详情";
                //AWithIcon ai1 = new AWithIcon();
                //ai1.AHREF = "javascript:showPhoto();";
                //ai1.IClass = "fa fa-picture-o";
                //ai1.IString = "&nbsp;图片";

                //box_orderdetail.BtsBoxTitle.TitleTools.Tools.Add(ai1);
                //Tab页模式
                int mili = DateTime.Now.Millisecond;
                Random rd = new Random(mili);
                int rdnum = rd.Next(100);
                BtsTabbable bt = new BtsTabbable();
                bt.TabIdName = "tab" + rdnum.ToString();
                //string[] icons = { "fa fa-reorder ", "fa fa-mobile-phone", "fa fa-gavel", "fa fa-bolt", "fa fa-file-text", "fa fa-bolt", "fa fa-file-text" };
                int listcnt = 0;
                foreach (string de in sumallList)
                {
                    PZ_TAB tab = HT_Status[de] as PZ_TAB;
                    if (tab == null)
                        continue;
                    int h = Convert.ToInt32(tab.FIELDGROUP);
                    string type = tab.TABTYPE;
                    //标题
                    BtsLi li = new BtsLi();
                    li.AI.AHREF = "#tab" + rdnum.ToString() + "_" + listcnt.ToString();
                    li.AI.IClass = tab.TICON;//icons[listcnt];
                    li.AI.IString = tab.TCNNAME;
                    li.AI.DataToggle = "tab";
                    bt.BtsLiList.Add(li);
                    string body_primary = "暂无数据";
                    if (BodyTextList != null && BodyTextList.Count > listcnt)
                    {
                        body_primary = BodyTextList[listcnt];
                    }
                    bt.TabContentList.Add(body_primary);
                    listcnt++;
                }
               // box_orderdetail.BtsBoxBody.BodyContent = bt.GetHtmlText();
                result = bt.GetHtmlText();
            }
            catch (System.Exception ex)
            {
                Loger.Error("追溯历史==>GetHis==>", ex);
            }
        }
        Response.Write(result);
    }



    public int sum = 3;
    public int nor;
    public int sumall;
    public ArrayList sumallList = new ArrayList();
    public int sumallMax;
    public void GetData()
    {
        bool isXX = false;
        //判断是否传入工单编号
        if (!string.IsNullOrEmpty(MAIN_ID))
        {
            string id = MAIN_ID;
            orderState = orderState != "" ? orderState : getOrderState(id).ToString();
            if (Request["MAINID"] != null)
            {
                string orderMainID = Request["MAINID"].ToString();
                orderState = "0";

                HT = Global.getDetailById(orderMainID, "v_tz_main");//根据ID得到详细信息 
            }
            else
            {

                HT = Global.getDetailById(id, "v_tz_main");//根据ID得到详细信息
            }
        }
        string where = " and ISDETAIL='1'";
        string rtID = "6F95974193A14C7F9F6437337EF9DB04";
        //获取角色菜单表RTID
        //string rtID = Request.QueryString["RTID"] == null ? "" : Request.QueryString["RTID"];
        //解决通过任务检索时，获取不到rtID导致看不到工单的详细信息,暂时解决方法
        //rtID = string.IsNullOrEmpty(rtID) ? System.Configuration.ConfigurationManager.AppSettings["SelectRtID"].ToString() : rtID;
        //获取显示组字段
        HT_Status = Global.GetTabs();
        sumallList = new ArrayList(HT_Status.Keys);
        sumallList.Sort();
        sumall = HT_Status != null && HT_Status.Count > 0 ? HT_Status.Count : 0;
        sumallMax = 7;//Convert.ToInt32(HT_Status_two[sumall - 1]) + 1;
        //获取组对应字段
        HT_FIELDNAME = Global.GetFieldNames(where, rtID);
        nor = HT_FIELDNAME != null && HT_FIELDNAME.Count > 0 ? HT_FIELDNAME.Count : 0;
    }

    List<string> BodyTextList = new List<string>();
    public void SetData()
    {

        foreach (string de in sumallList)
        {
            PZ_TAB tab = HT_Status[de] as PZ_TAB;
            if (tab == null)
                continue;
            int h = Convert.ToInt32(tab.FIELDGROUP);
            string type = tab.TABTYPE;
            //字段显示开始
            StringBuilder bodyText = new StringBuilder();
            if (type == "1")
            {
                bodyText.Append("<table border=\"0\" id=\"table1\" cellspacing=\"0\" cellpadding=\"3\" style=\"margin-top: 0px;padding-top: 0px; width: 100%;\" class=\"my-table table\">\n<tr>\n");
                int huanghang = 1;
                int valuesum = h;
                int decide = 0;
                //循环取出字段的数据
                for (int i = 0; i <= nor-1; i++)
                {
                    S_DICT dict = HT_FIELDNAME[i] as S_DICT;
                    if (dict == null)
                        continue;
                    //判断是否是这个top下的字段
                    if (dict.TID == tab.TID)
                    {
                        decide = 1;
                        int length = string.IsNullOrEmpty(dict.LENGTH) ? 0 : Convert.ToInt32(dict.LENGTH);
                        if (length >= 500)
                            //    bodyText.Append("<td  class=\"td_text table-border\" style=\"background-color: #FFF0F5;\">" + dict.FIELDDISNAME + "</td>\n");
                            //else
                            //    bodyText.Append("<td  class=\"td_text table-border\" style=\"background-color: #FFF0F5;\">" + dict.FIELDDISNAME + "</td>\n");
                            bodyText.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + dict.FIELDDISNAME + "</td>\n");
                        else
                            bodyText.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + dict.FIELDDISNAME + "</td>\n");
                        //取出对应于HT中的字段名 ，取值
                        string temp_value = "";
                        temp_value = Convert.ToString(HT[dict.FIELDNAME]);
                        string fontcolor = "Orange";
                        if (length >= 500)
                        {
                            if (i == nor)
                            {
                                bodyText.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n</tr>\n");
                            }
                            else
                            {
                                bodyText.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n</tr>\n<tr>\n");
                            }
                        }
                        else
                        {

                            bodyText.Append("<td class=\"td_value table-border\" style=\"width: 190px;color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>");
                        }
                        if (huanghang % sum == 0 && length < 500)
                        {
                            bodyText.Append("</tr>\n<tr>\n");
                        }
                        huanghang += 1;
                    }
                }


                bodyText.Append("</tr>\n</table>\n");
            }
            else//列表显示
            {
                bodyText.Append("<table border=\"0\" id=\"table1\" cellspacing=\"0\" cellpadding=\"3\" style=\"margin-top: 0px;padding-top: 0px; width: 100%;\" class=\"my-table table\">\n<tr>\n");
                int valuesum = h;
                int decide = 0;
                string taborder = string.IsNullOrEmpty(tab.TABORDER) ? "" : " order by " + tab.TABORDER;
                string fields = "";
                //循环取出字段的数据
                for (int i = 1; i <= nor; i++)
                {
                    S_DICT dict = HT_FIELDNAME[i] as S_DICT;
                    if (dict == null)
                        continue;
                    //判断是否是这个top下的字段
                    if (dict.TID == tab.TID)
                    {
                        decide = 1;
                        fields += dict.FIELDNAME + ",";
                        if (dict.STYLE.Contains("40"))
                        {
                            bodyText.Append("<td  align=\"center\" style=\"color:black\">" + dict.FIELDDISNAME + "</td>\n");
                        }
                        
                    }
                }
                if (type == "3")
                {
                    bodyText.Append("<td  align=\"center\" style=\"color:black\">操作</td>\n");
                }
                bodyText.Append("</tr>\n" + GetTableHTML(tab.TABNAME, tab.TABMAINID, MAIN_ID, taborder, fields, type) + "</table>\n");
            }
            BodyTextList.Add(bodyText.ToString());
        }

    }
    public string GetTableHTML(string tablename, string tabmainid, string main_id, string fiedorder, string fields)
    {
        string html = "";
        try
        {
            string fieldname = fields;
            if (fieldname.Length > 0)
                fieldname = fieldname.Substring(0, fieldname.Length - 1);
            if (fieldname.Length > 0)
            {
                string sql = "select " + fieldname + " from " + tablename + " t " + " where " + tabmainid + "='" + main_id + "' " + fiedorder;
                DataSet ds = DbHelperOra.Query(sql);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    string[] fieldList = fieldname.Split(',');
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        html += "<tr>\n";
                        string fontcolor = "Orange";
                        foreach (string fieldstr in fieldList)
                        {
                            html += string.Format("<td align=\"center\" style=\"color:" + fontcolor + " \">{0}</td>\n", row[fieldstr].ToString());
                        }
                        html += "</tr>\n";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTableHTML==>", ex);
        }
        return html;
    }

    /// <summary>
    /// 拼接列表时判断是否需要操作列
    /// </summary>
    /// <param name="tablename"></param>
    /// <param name="tabmainid"></param>
    /// <param name="main_id"></param>
    /// <param name="fiedorder"></param>
    /// <param name="fields"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    public string GetTableHTML(string tablename, string tabmainid, string main_id, string fiedorder, string fields, string type)
    {
        string html = "";
        try
        {
            string fieldname = fields;
            if (fieldname.Length > 0)
                fieldname = fieldname.Substring(0, fieldname.Length - 1);
            if (fieldname.Length > 0)
            {
                string sql = "select " + fieldname + " from " + tablename + " t " + " where " + tabmainid + "='" + main_id + "' " + fiedorder;
                DataSet ds = DbHelperOra.Query(sql);
                sql = "select t.tabname,d.fieldname from pz_tab t join s_dict d on t.fieldgroup = d.fieldgroup where d.style like '%40%' and t.tabname='" + tablename.ToUpper() + "'";
                DataSet dsSet = DbHelperOra.Query(sql);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    string[] fieldList = fieldname.Split(',');
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        html += "<tr>\n";
                        string fontcolor = "Orange";
                        foreach (string fieldstr in fieldList)
                        {
                            foreach (DataRow drRow in dsSet.Tables[0].Rows)
                            {
                                if (fieldstr.ToUpper() == drRow["fieldname"].ToString().ToUpper())
                                {
                                    html += string.Format("<td align=\"center\" style=\"color:" + fontcolor + " \">{0}</td>\n", row[fieldstr].ToString());
                                }
                            }
                        }
                        //此处仅针对附件信息后期可考虑在数据库中配置
                        if (type == "3")
                        {
                            string Filepath = ConfigurationManager.AppSettings["MediaPath"]; //本地图片访问路径
                            string FilepathXj = ConfigurationManager.AppSettings["filepathXJ"];//巡检地址
                            string path=string.Empty;
                             path = Filepath+ "/" +
                                         row["FILEPATH"].ToString() + "/" + row["FILENAME"].ToString();
                            string typeXJ =Convert.ToString(row["type"]);
                            if (typeXJ == "2")
                            {
                                path = FilepathXj + "/" +
                                       row["FILEPATH"].ToString() + "/" + row["FILENAME"].ToString();
                            }
                            html += string.Format("<td align=\"center\" style=\"color:" + fontcolor + " \"><a href=\"javascript:void(0)\" onclick=\"javascript:window.open('{0}');\">下载</a></td>\n", path);
                        }
                        html += "</tr>\n";

                    }
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTableHTML==>", ex);
        }
        return html;
    }

    public int getOrderState(string id)
    {
        int result = 1;
        string tokenname = Global.GetTokenname(id);
        string ARRIVALTIME = Global.GetArrivalTime(id);
        string Not_Send = ConfigurationManager.AppSettings["Z_Not_Send"].ToString();
        string Yet_Send = ConfigurationManager.AppSettings["Z_Yet_Send"].ToString();
        string Z_LOOK_SEND = ConfigurationManager.AppSettings["Z_LOOK_SEND"].ToString();
        string Apply_Delay = ConfigurationManager.AppSettings["Z_Apply_Delay"].ToString();
        string Yet_Delay = ConfigurationManager.AppSettings["G_Yet_Delay"].ToString();
        string Apply_Close = ConfigurationManager.AppSettings["Z_Apply_Close"].ToString();
        string Yet_Close = ConfigurationManager.AppSettings["Z_Yet_Close"].ToString();
        string Apply_Exit = ConfigurationManager.AppSettings["Z_Apply_Exit"].ToString();
        string Yet_Exit = ConfigurationManager.AppSettings["G_Apply_Exit"].ToString();
        string repeat = ConfigurationManager.AppSettings["Z_repeat"].ToString();
        string Apply_License = ConfigurationManager.AppSettings["G_Apply_License"].ToString();
        string Yet_License = ConfigurationManager.AppSettings["G_Yet_License"].ToString();
        string track = ConfigurationManager.AppSettings["G_track"].ToString();
        if (Not_Send.Contains(tokenname))
        {
            result = 1;
        }
        else if (Yet_Send.Contains(tokenname))
        {
            result = 9;
        }
        else if (Z_LOOK_SEND.Contains(tokenname))
        {
            result = 9;
        }
        else if (Apply_Delay.Contains(tokenname))
        {
            result = 2;
        }

        else if (Yet_Delay.Contains(tokenname))
        {
            result = 5;
        }
        else if (Apply_Exit.Contains(tokenname))
        {
            result = 4;
        }
        else if (Yet_Exit.Contains(tokenname))
        {
            result = 7;
        }
        else if (Apply_Close.Contains(tokenname))
        {
            result = 3;
        }
        else if (Yet_Close.Contains(tokenname))
        {
            result = 6;
        }
        else if (repeat.Contains(tokenname))
        {
            result = 8;
        }
        else if (track.Contains(tokenname))
        {
            result = 10;
        }
        else if (Apply_License.Contains(tokenname))
        {
            result = 11;
        }
        else if (Yet_License.Contains(tokenname))
        {
            result = 12;
        }
        if (ARRIVALTIME != "" && Z_LOOK_SEND.Contains(tokenname))
        {
            result = 13;
        }

        return result;
    }

}