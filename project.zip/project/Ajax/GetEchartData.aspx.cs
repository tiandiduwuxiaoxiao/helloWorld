﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using Maticsoft.DBUtility;
using System.Web.Services;

public partial class Ajax_GetEchartData : System.Web.UI.Page
{
    public string title_text = "";//默认标题
    public string[] types = { "bar", "line", "pie" };//支持的图表类型
    public string series_type = "line";//默认图表类型
    public string[] xAxis_data = { };//X轴
    public string uid = "";
    List<string> categoryList = new List<string>();
    List<string> legendList = new List<string>();
    List<Series> seriesList = new List<Series>();
    Hashtable hash = new Hashtable();
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];
        if (Request["flag"] == "loadLineChars") loadLineChars();//开单数统计
        else if (Request["flag"] == "loadStationChart") loadStationChart();//站点数统计
        else if (Request["flag"] == "loadFaultChart") loadFaultChart();//类别统计
        else if (Request["flag"] == "loadFaultChartFs") loadFaultChartFs();//佛山类别统计
        else if (Request["flag"] == "loadFaultReporittypeChart") loadFaultReporittypeChart();
        else if (Request["flag"] == "loadOnLineTimeChars") loadOnLineTimeChars();//在线人数统计
        else if (Request["flag"] == "loadWorkOrderAndPicCountChars") loadWorkOrderAndPicCountChars();//工单数和拍照数统计
        else if (Request["flag"] == "loadNetWorkTrafficChars") loadNetWorkTrafficChars();//使用流量统计
        else if (Request["flag"] == "loadOnLineOrVisitsChars") loadOnLineOrVisitsChars();//平均在线时长、平均访问次数统计
        else if (Request["flag"] == "loadOccurreasonChart") loadOccurreasonChart();
        else if (Request["flag"] == "loadOccurreasonChartTable") loadOccurreasonChartTable();
        else if (Request["flag"] == "loadStationPChart") loadStationPChart();//片区处理工单数量
        else if (Request["flag"] == "loadOrderChart") loadOrderChart();//总工单数，完结数，及时数
        else if (Request["flag"] == "loadUSETIMELineChars") loadUSETIMELineChars();//维修用时
      
    }

    /// <summary>
    /// 总工单数，完结数，及时数统计
    /// </summary>
    private void loadOrderChart()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            title_text = "本月工单数统计";
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月总工单数/完结数/及时数统计";
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年总工单数/完结数/及时数统计";
            dateFormat = "YYYY";
            condtionSql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text = "总工单数/完结数/及时数统计";
            dateFormat = "yyyy-mm-dd";
            condtionSql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        //数据获取
        string sql = @"select statustype,to_char(accepttime,'" + dateFormat + @"') accepttime ,count(*) as sum from v_tj_orders m where 1=1  and ISXJSH='1'";
        sql += condtionSql;
        sql += " group by statustype,to_char(accepttime,'" + dateFormat + "') order by statustype,accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["statustype"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
        //图例
        legendList.Add("总数");
        legendList.Add("完结");
        legendList.Add("及时");
        
        //x轴
        computationTime(num, type);

        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //一个线的对象
            Series seriesObj = new Series();
            seriesObj.id = i;
            seriesObj.name = legName;
            seriesObj.type = "line"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错
         
            MarkPoint mp = new MarkPoint();
            List<data> ldaMp = new List<data>();
            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                seriesObj.data.Add(tmpValue);
                if (tmpValue!=0)
                {
                    data daMp = new data();
                    daMp.name = categoryList[j];
                    daMp.value = tmpValue;
                    daMp.xAxis = j;
                    daMp.yAxis = tmpValue;
                    ldaMp.Add(daMp);
                }
            }
            if (ldaMp.Count>0)
            {
                mp.data = ldaMp;
                seriesObj.markPoint = mp;
            }
            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
   
    /// <summary>
    /// 开单数统计
    /// </summary>
    public void loadLineChars()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day"){
            title_text = "本月开单数统计";
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month"){
            title_text = "最近" + num + "月开单数统计";
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年开单数统计";
            dateFormat = "YYYY";
            condtionSql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length>=1)
            {
                 startTime = time[0];
            }
            if (time.Length >= 2)
            {
                 EndTime = time[1];
            }
            title_text = "开单数统计";
            dateFormat = "yyyy-mm-dd";
            condtionSql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        //数据获取
        string sql = "select acceptstation,to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum from tz_main where 1=1  and ISXJSH='1'";
        sql += condtionSql;
        sql += " group by acceptstation,to_char(accepttime,'" + dateFormat + "') order by acceptstation,accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["acceptstation"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
        //图例
        ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid);
        for (int i = 0; i < list.Count; i++)
        {
            legendList.Add(list[i].ToString());
        }
        //x轴
        computationTime(num, type);

        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //一个线的对象
            Series seriesObj = new Series();
            seriesObj.id = i;
            seriesObj.name = legName;
            seriesObj.type = "line"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错
            MarkPoint mp = new MarkPoint();
            List<data> ldaMp = new List<data>();
            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                seriesObj.data.Add(tmpValue);
                if (tmpValue != 0)
                {
                    data daMp = new data();
                    daMp.name = categoryList[j];
                    daMp.value = tmpValue;
                    daMp.xAxis = j;
                    daMp.yAxis = tmpValue;
                    ldaMp.Add(daMp);
                }
            }
            if (ldaMp.Count > 0)
            {
                mp.data = ldaMp;
                seriesObj.markPoint = mp;
            }
            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 站点数统计
    /// </summary>
    public void loadStationChart()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year

        //数据获取
        string sql = "select acceptstation as key,count(*) as sum from tz_main where 1=1  and ISXJSH='1' ";
        if (type == "day"){
            title_text = "本月站点统计";
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }  
        else if (type == "month"){
            title_text = "最近" + num + "月站点统计";
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year") {
            title_text = "最近" + num + "年站点统计";
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text = "站点统计";
            sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        sql += "  group by acceptstation";

        //图例
        ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid);
        Hashtable tmpHash=new Hashtable();
        for (int i = 0; i < list.Count; i++)
        {
            string val=list[i].ToString();
            legendList.Add(val);
            tmpHash.Add(val, val);
        }

        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (tmpHash.Contains(Convert.ToString(dt.Rows[i]["key"])))
                {
                    Series seriesObj = new Series();
                    seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                    seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                    seriesList.Add(seriesObj);
               }
            }
        }

      
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 片区统计
    /// </summary>
    public void loadStationPChart()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year

        //数据获取
        string sql = "select DEPNAME as key,count(*) as sum from v_pStation_orderinfo where 1=1  and ISXJSH='1' ";
        if (type == "day")
        {
            title_text = "本月片区工单统计";
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月片区工单统计";
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年片区工单统计";
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text = "片区工单统计";
            sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        sql += "  group by DEPNAME";

        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                    Series seriesObj = new Series();
                    seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                    seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                    seriesList.Add(seriesObj);
            }
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 实际类别统计
    /// </summary>
    public void loadFaultChart()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        try
        {
            string num = Request["num"];//天数
            string type = Request["type"];//日期类型  day,month,year
            string fault_parentType = Request["parent"];
            string TypeName = Request["TypeName"];
            string PianStation = Request["PianStation"];
            //数据获取
            string sql = "select parentType as key,count(*) sum  from v_tz_main_clinfo t left join v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype where 1=1  and parentType is not null ";
            if (fault_parentType == "parent") { sql = "select parentType as key,count(*) sum  from v_tz_main_clinfo t left join v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype where 1=1  and parentType is not null "; }
            else if (fault_parentType == "reporttype") { sql = "select t.SJCLLX as key, count(*) sum from v_tz_main_clinfo t left join  v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype  where 1=1  and parentType is not null "; }
            else if (fault_parentType == "reportcontent") { sql = "select SJCLNR as key,count(*) as sum from v_tz_main_clinfo where 1=1 and ISXJSH='1'  "; }
            if (type == "day")
            {
                title_text = "本月类别统计";
                sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
            }
            else if (type == "month")
            {
                title_text = "最近" + num + "月类别统计";
                sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
            }
            else if (type == "year")
            {
                title_text = "最近" + num + "年类别统计";
                sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
            }
            else if (type == "time")
            {
                string[] time = num.Split('|');
                if (time.Length >= 1)
                {
                    startTime = time[0];
                }
                if (time.Length >= 2)
                {
                    EndTime = time[1];
                }
                if (!string.IsNullOrWhiteSpace(EndTime) && !string.IsNullOrWhiteSpace(startTime))
                {
                    title_text = "类别统计";
                    sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
                }
            }
            if (!string.IsNullOrWhiteSpace(PianStation))
            {
                sql += string.Format(" and PianStation='{0}'", PianStation);
            }
            if (fault_parentType == "parent") { sql += "  group by parentType"; }
            else if (fault_parentType == "reporttype") { sql += string.Format(" and parentType='{0}'  group by t.SJCLLX", TypeName); }
            else if (fault_parentType == "reportcontent") { sql += string.Format("  and SJCLLX='{0}'    group by SJCLNR ", TypeName); }
            else sql += "  group by parentType";
            DataSet ds = DbHelperOra.Query(sql);
            if (ds != null && ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    //加图例数据
                    legendList.Add(Convert.ToString(dt.Rows[i]["key"]));
                    Series seriesObj = new Series();
                    seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                    seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                    seriesList.Add(seriesObj);
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GetEchartData==loadFaultChart==>" + ex);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 佛山类别统计
    /// </summary>
    public void loadFaultChartFs()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        try
        {
            string num = Request["num"];//天数
            string type = Request["type"];//日期类型  day,month,year
            string fault_parentType = Request["parent"];
            string TypeName = Request["TypeName"];
            string PianStation = Request["PianStation"];
            //数据获取
            string sql = "select parentType as key,count(*) sum  from v_tz_main_clinfo t left join v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype where 1=1  and parentType is not null ";
            if (fault_parentType == "parent") { sql = "select parentType as key,count(*) sum  from v_tz_main_clinfo t left join v_PZ_REPORTTYPE r on t.SJCLLX = r.parentType where 1=1  and parentType is not null "; }
            else if (fault_parentType == "reporttype") { sql = "select t.SJCLNR as key, count(*) sum from v_tz_main_clinfo t left join  v_PZ_REPORTTYPE r on t.SJCLNR = r.reporttype  where 1=1  and parentType is not null "; }
            else if (fault_parentType == "reportcontent") { sql = "select reporttpye1 as key,count(*) as sum from v_tz_main_clinfo where 1=1 and ISXJSH='1'  "; }
            if (type == "day")
            {
                title_text = "本月类别统计";
                sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
            }
            else if (type == "month")
            {
                title_text = "最近" + num + "月类别统计";
                sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
            }
            else if (type == "year")
            {
                title_text = "最近" + num + "年类别统计";
                sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
            }
            else if (type == "time")
            {
                string[] time = num.Split('|');
                if (time.Length >= 1)
                {
                    startTime = time[0];
                }
                if (time.Length >= 2)
                {
                    EndTime = time[1];
                }
                if (!string.IsNullOrWhiteSpace(EndTime) && !string.IsNullOrWhiteSpace(startTime))
                {
                    title_text = "类别统计";
                    sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
                }
            }
            if (!string.IsNullOrWhiteSpace(PianStation))
            {
                sql += string.Format(" and PianStation='{0}'", PianStation);
            }
            if (fault_parentType == "parent") { sql += "  group by parentType"; }
            else if (fault_parentType == "reporttype") { sql += string.Format(" and parentType='{0}'  group by t.SJCLNR", TypeName); }
            else if (fault_parentType == "reportcontent") { sql += string.Format("  and SJCLNR='{0}'    group by reporttpye1 ", TypeName); }
            else sql += "  group by parentType";
            DataSet ds = DbHelperOra.Query(sql);
            if (ds != null && ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    //加图例数据
                    legendList.Add(Convert.ToString(dt.Rows[i]["key"]));
                    Series seriesObj = new Series();
                    seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                    seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                    seriesList.Add(seriesObj);
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GetEchartData==loadFaultChart==>" + ex);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 类别统计
    /// </summary>
    public void loadFaultReporittypeChart()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        string fault_parentType = Request["parent"];
        string TypeName = Request["TypeName"];
        //数据获取
        string sql = "select parentType as key,count(*) sum  from tz_main t left join v_PZ_REPORTTYPE r on t.reporttype = r.reporttype where 1=1  and parentType is not null ";
        if (fault_parentType == "parent") { sql = "select parentType as key,count(*) sum  from tz_main t left join v_PZ_REPORTTYPE r on t.reporttype = r.reporttype where 1=1  and parentType is not null "; }
        else if (fault_parentType == "reporttype") { sql = "select t.reporttype as key, count(*) sum from tz_main t left join  v_PZ_REPORTTYPE r on t.reporttype = r.reporttype  where 1=1  and parentType is not null "; }
        else if (fault_parentType == "reportcontent") { sql = "select reportcontent as key,count(*) as sum from tz_main where 1=1 and ISXJSH='1'  "; }
        if (type == "day")
        {
            title_text = "本月类别统计";
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月类别统计";
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年类别统计";
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            if (!string.IsNullOrWhiteSpace(EndTime)&&!string.IsNullOrWhiteSpace(startTime))
            {
                title_text = "类别统计";
                sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
            }
        }
        if (fault_parentType == "parent") { sql += "  group by parentType"; }
        else if (fault_parentType == "reporttype") { sql += string.Format(" and parentType='{0}'  group by t.REPORTTYPE", TypeName); }
        else if (fault_parentType == "reportcontent") { sql += string.Format("  and REPORTTYPE='{0}'    group by reportcontent ", TypeName); }
        else  sql += "  group by parentType";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //加图例数据
                legendList.Add(Convert.ToString(dt.Rows[i]["key"]));
                Series seriesObj = new Series();
                seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                seriesList.Add(seriesObj);
            }
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 在线人数统计
    /// </summary>
    public void loadOnLineTimeChars()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();

        //参数获取
        string num = Request["num"];//天数或类型
        string type = Request["type"];//日期类型  day,hours
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")//按天统计
        {
            legendList.Add("本月在线人数"); //图例
            title_text = "本月在线人数";
            dateFormat = "YYYY-MM-DD";
            condtionSql = " and to_char(rq, 'yyyy-mm-dd') > to_char(sysdate - " + num + ", 'yyyy-mm-dd')";
            computationTime(num, type);
        }
        else if (type == "hours")//按小时
        {
            if (num == "today")//当天 
            {
                legendList.Add("当天在线人数"); //图例
                title_text = "当天在线人数";
                condtionSql = " and to_char(rq,'YYYY-MM-DD')= to_char(sysdate, 'yyyy-mm-dd')";
            }
            else if (num == "yesterday")//昨天
            {
                legendList.Add("昨天在线人数"); //图例
                title_text = "昨天在线人数";
                condtionSql = " and to_char(rq,'YYYY-MM-DD')= to_char(sysdate - 1, 'yyyy-mm-dd')";
            }
            dateFormat = "hh24";

            //x轴
            computationTime(num, type);
           
        }
        
        //数据获取
        string sql = " select to_char(rq,'" + dateFormat + "') rq ,count(*) as sum from t_logginginfo_bs ,(select max(rq) maxrq,username uname from t_logginginfo_bs  where type = '登录'  group by to_char(rq,'YYYY-MM-DD'),username order by maxrq desc) b where rq=b.maxrq and username=b.uname ";
        sql += condtionSql;
        sql += "group by to_char(rq,'" + dateFormat + "') order by rq";

        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["rq"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
     

        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //一个线的对象
            Series seriesObj = new Series();
            seriesObj.id = i;
            seriesObj.name = legName;
            seriesObj.type = "bar"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错

            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[categoryList[j]]);
                seriesObj.data.Add(tmpValue);
            }

            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 平均在线时长、平均访问次数统计
    /// </summary>
    public void loadOnLineOrVisitsChars()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();

        //参数获取
        string num = Request["num"];//天数或类型
        string type = Request["type"];//日期类型  day,hours
        string chartType = Request["chartType"];//平均在线时长  or  平均访问次数
        string chartTitle ="";
        string dateFormat = "";
        string condtionSql = "";

        if(Convert.ToString(Request["chartType"])=="0")
        {
            chartTitle="平均在线时长";
            legendList.Add("平均在线时长");
        }else
        {
            chartTitle = "平均访问次数";
            legendList.Add("平均访问次数");
        }
      
        if (type == "day")
        {
            title_text = "本月" + chartTitle + "统计";
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(rq, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月" + chartTitle + "统计";
            dateFormat = "YYYY-MM";
            condtionSql += " and rq between add_months(sysdate,-" + num + ") and sysdate";
        }

        //x轴
        computationTime(num, type);

        
        //数据获取
        string sql = " select to_char(rq,'" + dateFormat + "') rq ,count(*) as sum from t_logginginfo_bs ,(select max(rq) maxrq,username uname from t_logginginfo_bs  where type = '登录'  group by to_char(rq,'YYYY-MM-DD'),username order by maxrq desc) b where rq=b.maxrq and username=b.uname ";
        sql += condtionSql;
        sql += " group by to_char(rq,'" + dateFormat + "') order by rq";

        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["rq"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
     

        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //一个线的对象
            Series seriesObj = new Series();
            seriesObj.id = i;
            seriesObj.name = legName;
            seriesObj.type = "line"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错

            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[categoryList[j]]);
                seriesObj.data.Add(tmpValue);
            }

            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 工单数和拍照数统计
    /// </summary>
    public void loadWorkOrderAndPicCountChars()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();

        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            title_text = "本月工单数与拍照数对比";
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月工单数与拍照数对比";
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        //数据获取
        string sql = "select to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum,sum(piccount) piccount from (select b.*,(select count(*) from track_media where mediatype is null and eventrecordid=b.id) as piccount from  tz_main b) where 1=1 ";
        sql += condtionSql;
        sql += " group by to_char(accepttime,'" + dateFormat + "') order by accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = "工单数" + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
                string key1 = "拍照数" + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value1 = Convert.ToString(dt.Rows[i]["piccount"]);
                hash.Add(key1, value1);
            }
        }
        //图例
        legendList.Add("工单数");
        legendList.Add("拍照数");

        //x轴
        computationTime(num, type);

        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //一个线的对象
            Series seriesObj = new Series();
            seriesObj.id = i;
            seriesObj.name = legName;
            seriesObj.type = "bar"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错

            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                seriesObj.data.Add(tmpValue);
            }

            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 使用流量(GB)统计
    /// </summary>
    public void loadNetWorkTrafficChars()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();

        //参数获取
        string num = Request["num"];//天数
        string type =  Request["type"];//日期类型  day,month,year
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            title_text = "本月平均使用流量GB";
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月平均使用流量GB";
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }

        //数据获取
        string sql = "select acceptstation,to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum from tz_main where 1=1 ";
        sql += condtionSql;
        sql += " group by acceptstation,to_char(accepttime,'" + dateFormat + "') order by acceptstation,accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["acceptstation"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
        //图例
        ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid);
        for (int i = 0; i < list.Count; i++)
        {
            legendList.Add(list[i].ToString());
        }
        //x轴
        computationTime(num, type);

        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //一个线的对象
            Series seriesObj = new Series();
            seriesObj.id = i;
            seriesObj.name = legName;
            seriesObj.type = "line"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错

            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                seriesObj.data.Add(tmpValue);
            }

            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);
        }

        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 发生原因管统计
    /// </summary>
    public void loadOccurreasonChart()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        string PianStation = Request["PianStation"]; 
        //数据获取
        string sql = "select Occurreason as key,count(*) as sum from v_tz_main_clinfo c,tz_main t where t.id=c.id and t.ISXJSH='1'  and Occurreason is not null    ";
        if (type == "day")
        {
            title_text = "近"+num+"天发生原因统计";
            sql += " and to_char(t.accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月发生原因统计";
            sql += " and t.accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年发生原因统计";
            sql += " and to_char(t.accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            if (!string.IsNullOrWhiteSpace(EndTime) && !string.IsNullOrWhiteSpace(startTime))
            {
                title_text = "发生原因统计";
                sql += " and t.accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
            }
            if (!string.IsNullOrEmpty(PianStation))
            {
                  sql +=string.Format(" and PianStation ='{0}'",PianStation);
            }
        }
        sql += "  group by Occurreason ";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                //加图例数据
                legendList.Add(Convert.ToString(dt.Rows[i]["key"]));

                Series seriesObj = new Series();
                seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                seriesList.Add(seriesObj);
            }
        }


        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    //时段统计
    public void loadOccurreasonChartTable() {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        //数据获取
        string sql = "select sum(B1+B2+b3+B4) as sum,SCORE_GP  as key from ( select * from v_tj_accepttime where 1=1 ";
        if (type == "day")
        {
            title_text = "本月时段统计";
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月时段统计";
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年时段统计";
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text ="时段统计";
            sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        sql += "  ) group  by SCORE_GP";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                //加图例数据
                legendList.Add(Convert.ToString(dt.Rows[i]["key"]));

                Series seriesObj = new Series();
                seriesObj.name = Convert.ToString(dt.Rows[i]["key"]);
                seriesObj.value = Convert.ToString(dt.Rows[i]["sum"]);
                seriesList.Add(seriesObj);
            }
        }

        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 维修用时
    /// </summary>
    public void loadUSETIMELineChars()
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string num = Request["num"];//天数
        string type = Request["type"];//日期类型  day,month,year
        string dateFormat = "";
        string condtionSql = "";
        try
        {
            if (type == "day")
            {
                title_text = "工单维修用时统计";
                dateFormat = "YYYY-MM-DD";
                condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
            }
            else if (type == "month")
            {
                title_text = "最近" + num + "月工单维修用时统计";
                dateFormat = "YYYY-MM";
                condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
            }
            else if (type == "year")
            {
                title_text = "最近" + num + "年工单维修用时统计";
                dateFormat = "YYYY";
                condtionSql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
            }
            else if (type == "time")
            {
                string[] time = num.Split('|');
                if (time.Length >= 1)
                {
                    startTime = time[0];
                }
                if (time.Length >= 2)
                {
                    EndTime = time[1];
                }
                title_text = "工单维修用时统计";
                dateFormat = "yyyy-mm-dd";
                condtionSql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
            }
            //数据获取
            string sql = "select useType,to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum from v_usetimetype where 1=1  and ISXJSH='1'";
            sql += condtionSql;
            sql += " group by useType,to_char(accepttime,'" + dateFormat + "') order by useType,accepttime";
            DataSet ds = DbHelperOra.Query(sql);
            if (ds != null && ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string key = Convert.ToString(dt.Rows[i]["useType"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                    string value = Convert.ToString(dt.Rows[i]["sum"]);
                    hash.Add(key, value);
                }
            }
            string sqlstr = "select s.wordscontent from words  s where s.belongcode='059' order by s.wordscode asc ";
            DataSet dss = DbHelperOra.Query(sqlstr);
            //图例
            if (dss.Tables.Count > 0)
            {
                foreach (DataRow item in dss.Tables[0].Rows)
                {
                    legendList.Add(item["wordscontent"].ToString());
                }
            }

            //x轴
            computationTime(num, type);

            //图表赋值
            for (int i = 0; i < legendList.Count(); i++)
            {
                string legName = legendList[i];
                //一个线的对象
                Series seriesObj = new Series();
                seriesObj.id = i;
                seriesObj.name = legName;
                seriesObj.type = "line"; //线性图呈现
                seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错
                MarkPoint mp = new MarkPoint();
                List<data> ldaMp = new List<data>();
                //设置数据
                for (int j = 0; j < categoryList.Count(); j++)
                {
                    int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                    seriesObj.data.Add(tmpValue);
                    //气泡显示
                    if (tmpValue != 0)
                    {
                        data daMp = new data();
                        daMp.name = categoryList[j];
                        daMp.value = tmpValue;
                        daMp.xAxis = j;
                        daMp.yAxis = tmpValue;
                        ldaMp.Add(daMp);
                    }
                }
                if (ldaMp.Count > 0)
                {
                    mp.data = ldaMp;
                    seriesObj.markPoint = mp;
                }
                //将sereis对象压入sereis数组列表内
                seriesList.Add(seriesObj);
            }
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GetEchartData==loadUSETIMELineChars==>" + ex);
        }
        //封装图表
        Response.Write(setEChartOptionToJson());
        Response.End();
    }
    /// <summary>
    /// 封装实体类转换为JSON
    /// </summary>
    /// <returns></returns>
    public string setEChartOptionToJson()
    {
        //封装图表
        EChartOption newOption = new EChartOption();
        newOption.Title = title_text;
        newOption.Category = categoryList;
        newOption.Series = seriesList;
        newOption.Legend = legendList;

        //Response返回新对象的json数据
        string jsonString = "";
        jsonString = Json.JsonSerializerBySingleData<EChartOption>(newOption);
        return jsonString;
    }
    /// <summary>
    /// 时间数组
    /// </summary>
    /// <param name="num">减去的数量</param>
    /// <param name="type">时间类型，day=按天，month=按月,year=按年</param>
    /// <returns></returns>
    public void computationTime(string num, string type)
    {
        string[] time = num.Split('|');
        DateTime startTime = DateTime.Now;
        DateTime EndTime = DateTime.Now;
       
        if (time.Length >= 2)
        {
            startTime=Convert.ToDateTime(time[0]);
            EndTime = Convert.ToDateTime(time[1]);
            TimeSpan ts1 = new TimeSpan(startTime.Ticks);
            TimeSpan ts2 = new TimeSpan(EndTime.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            num = ts.Days.ToString();
        }
        categoryList.Clear();
        if (num.ToLower() == "today" || num.ToLower() == "yesterday")//今天，昨天
        {
            for (int i = 0; i < 24; i++)
            {
                categoryList.Add(i <= 9 ? "0" + Convert.ToString(i) : Convert.ToString(i));
            }
        }
        else
        {
            for (int i = Convert.ToInt32(num) - 1; i >= 0; i--)
            {
                if (type == "day")
                {
                    categoryList.Add(DateTime.Today.AddDays(Convert.ToInt32("-" + i)).ToString("yyyy-MM-dd"));
                }
                else if (type == "month")
                {
                    categoryList.Add(DateTime.Today.AddMonths(Convert.ToInt32("-" + i)).ToString("yyyy-MM"));
                }
                else if (type == "year")
                {
                    categoryList.Add(DateTime.Today.AddYears(Convert.ToInt32("-" + i)).ToString("yyyy"));
                }
                if (type == "time")
                {
                    categoryList.Add(DateTime.Today.AddDays(Convert.ToInt32("-" + i)).ToString("yyyy-MM-dd"));
                }
            }
        }
        //if (num.ToLower() == "lastmonth")
        //{
        //    DateTime dt = new DateTime().AddMonths(-1);
        //    int days = DateTime.DaysInMonth(dt.Year,dt.Month);
        //    for (int i = 0; i < days; i++)
        //    {
        //        string tmpDay = i <= 9 ? "0" + Convert.ToString(i) : Convert.ToString(i);
        //        categoryList.Add(dt.Year + "-" + dt.Month + "-" + tmpDay);
        //    }
        //}
       
    }
}
