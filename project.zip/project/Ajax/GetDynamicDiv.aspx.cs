using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BootStrapControls;
using OrderFunction;
using System.Data;
using System.Collections;
using Maticsoft.DBUtility;
using System.Configuration;
public partial class Ajax_GetDynamicDiv : System.Web.UI.Page
{
    private void GetOrderFunctions()
    {
        List<string> list1 = new List<string>();
        list1.Add("自开单");
        list1.Add("工单详情");
        list1.Add("任务追溯");
        list1.Add("工单重置");
        list1.Add("工单编辑");
        list1.Add("派遣手机");
        list1.Add("申请销单");
        list1.Add("直接退单");
        list1.Add("销单审核");
        list1.Add("延期审核");
        list1.Add("退单审核");
        list1.Add("工单转站");
        list1.Add("一键销单");
        OrderFunctions = list1.ToArray();
    }
    public string[] OrderFunctions;

    //请求的功能名称
    public string FunctionName = string.Empty;
    //请求的表名
    public string TableName = string.Empty;
    public string MAIN_ID = string.Empty;
    private string str_params = string.Empty;
    private string str_innerhtml = string.Empty;
    public string result = string.Empty;
    public string uid = "";
    public string userDEPNAME = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        uid = Request["uid"];
        userDEPNAME = Global.GetDepname(uid);
        try
        {
            //获取工单功能名称
            GetOrderFunctions();
            if (!string.IsNullOrEmpty(Request["FNAME"]))
            {
                FunctionName = Request["FNAME"].ToString();
            }
            if (!string.IsNullOrEmpty(Request["TableName"]))
            {
                TableName = Request["TableName"].ToString();
            }
            if (Request["ID"] != null)
            {
                MAIN_ID = Request["ID"].ToString();
            }
            //获取动态页面    
            GetDynamicHtml(FunctionName);
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax==>GetDynamicDiv==>", ex);
        }

        //AWithIcon ai = new AWithIcon();
        //ai.AHREF = "javascript:alert(1)";
        //ai.IClass = "fa fa-flag-o";
        //BtsBox b = new BtsBox();
        //b.BtsBoxTitle.TitleHead.IconClass = "fa fa-table";
        //b.BtsBoxTitle.TitleHead.Text = "测试窗口";
        //b.BtsBoxTitle.ShowTitleTools = true;
        //b.BtsBoxTitle.TitleTools.Tools.Add(ai);
        //result = b.GetHtmlText();
        //显示页面跟参数
        DynamicParam dp = new DynamicParam();
        dp.InnerHtml = str_innerhtml;
        dp.StrParams = str_params;

        //Response返回新对象的json数据
        result = Json.JsonSerializerBySingleData<DynamicParam>(dp);
        Response.Write(result);
        Response.End();
    }

    /// <summar>y
    /// 获取动态页面
    /// </summary>
    /// <param name="functionName"></param>
    public void GetDynamicHtml(string functionName)
    {
        switch (FunctionName)
        {
            case "zkd":
                //自开单
                GetAddOrderHtml();
                break;
            case "gdbj":
                //工单编辑
                GetUpdateOrderHtml();
                break;
            case "jkpdxx":
                //接口派单工单信息
                GetdirectToOrderInfoHtml();
                break;
            case "wfjPage": GetNotFJPage(); break;
            case "getDetail":
                //接口派单工单信息
                GeOrderInfoHtml();
                break;
            case "getJkDetail":
                //接口审核工单信息
                GetOrderInfoHtml();
                break;
            case "jkpq":
                //接口派遣
                GetdirectToOrderHtml();
                break;
            case "gdxx":
                //工单编辑的工单信息
                GetOrderInfo();
                break;
            case "dtzs":
                //工单信息在地图上展示
                GetOrderMapInfo();
                break;
            case "commonadd":
                //通用页面新增
                GetCommonAddHtml("CommonAdd");
                break;
            case "commonedit":
                //通用页面修改
                GetCommonEditHtml("CommonEdit");
                break;
            case "commonbind":
                //通用页面修改信息
                GetCommonInfo();
                break;
            default:
                Get404Html();
                break;
        }
    }
    /// <summary>
    /// 接口审核工单信息
    /// </summary>
    private void GetOrderInfoHtml()
    {
        Page_Template page = new Page_Template(this.TableName, uid, userDEPNAME);
        //页面htmltext
        this.str_innerhtml = page.GetNoEditHtmlTextDetail(MAIN_ID,this.TableName);
        //sql拼接参数
        this.str_params = page.SQL_String;
    }
    /// <summary>
    /// 通用页面修改信息
    /// </summary>
    private void GetCommonInfo()
    {
        string id = Request["ID"];
        string Sql = "select * from " + TableName + " where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        DataTable dt = odb.GetDataSet(Sql).Tables[0];
        Sql = "select T.Fielddisname,t.fieldname,mappingcode,SUBFIELD from v_dict t where t.tablename='" + TableName + "' and fieldstyle like '%40%' AND T.validity='0'";
        DataTable dField = odb.GetDataSet(Sql).Tables[0];
        this.str_innerhtml = Json.ToJson(dt, "TZ_MAIN");
        this.str_params = Json.ToJson(dField, "V_DICT");
    }
    /// <summary>
    /// 通用页面修改
    /// </summary>
    private void GetCommonEditHtml(string type)
    {
        CommonPageFunction page = new CommonPageFunction(uid, userDEPNAME);
        this.str_innerhtml = page.GetHtmlText(TableName, type);
        //sql字段拼接字符串
        this.str_params = page.INSERTORDERSQL;
    }
    /// <summary>
    /// 通用页面新增
    /// </summary>
    private void GetCommonAddHtml(string type)
    {
        CommonPageFunction page = new CommonPageFunction(uid, userDEPNAME);
        this.str_innerhtml = page.GetHtmlText(TableName,type);
        //sql字段拼接字符串
        this.str_params = page.INSERTORDERSQL;
    }
    /// <summary>
    /// 自开单
    /// </summary>
    public void GetAddOrderHtml()
    {
        Page_AddOrder page = new Page_AddOrder(uid, userDEPNAME,this.TableName);
        this.str_innerhtml = page.GetHtmlText();
        //sql字段拼接字符串
        this.str_params = page.INSERTORDERSQL;
    }
    /// <summary>
    /// 工单信息修改页面
    /// </summary>
    public void GetUpdateOrderHtml()
    {
        Page_Template page = new Page_Template(this.TableName, uid, userDEPNAME);
        //页面htmltext
        this.str_innerhtml = page.GetHtmlText();
        //sql拼接参数
        this.str_params = page.SQL_String;
    }
    /// <summary>
    /// 接口派遣
    /// </summary>
    public void GetdirectToOrderHtml()
    {
        Page_Template page = new Page_Template(this.TableName, uid, userDEPNAME);
        page.mainid = MAIN_ID;
        //页面htmltext
        this.str_innerhtml = page.GetHtmlText();
        //sql拼接参数
        this.str_params = page.SQL_String;
    }
    /// <summary>
    /// 无附件页面调用
    /// </summary>
    public void GetNotFJPage() {
        Page_AnnexTemplate page = new Page_AnnexTemplate(this.TableName, uid, userDEPNAME);
        //页面htmltext
        this.str_innerhtml = page.GetHtmlText();
        //sql拼接参数
        this.str_params = page.SQL_String;
    }
    /// <summary>
    /// 获取工单信息
    /// </summary>
    public void GeOrderInfoHtml()
    {
        Page_Template page = new Page_Template(this.TableName, uid, userDEPNAME);
        //页面htmltext
        this.str_innerhtml = page.GetNoEditHtmlTextDetail(MAIN_ID);
        //sql拼接参数
        this.str_params = page.SQL_String;
    }
    /// <summary>
    /// 接口派遣-工单信息
    /// </summary>
    public void GetdirectToOrderInfoHtml()
    {

        Page_Template page = new Page_Template(this.TableName, uid, userDEPNAME);
        //页面htmltext
        this.str_innerhtml = page.GetNoEditHtmlText();
        //sql拼接参数
        this.str_params = page.SQL_String;
    }
    /// <summary>
    /// 获取工单信息
    /// </summary>
    public void GetOrderInfo()
    {
        string Sql = "select * from  V_" + TableName + " where  id='" + MAIN_ID + "'";
        OracleDataBase odb = new OracleDataBase();
        DataTable dt = odb.GetDataSet(Sql).Tables[0];
        Sql ="select T.Fielddisname,t.fieldname,mappingcode,SUBFIELD from v_dict t where t.tablename='" + TableName.ToUpper() + "' and fieldstyle like '%40%' AND T.validity='0'  order by t.fieldorder";
        DataTable dField = odb.GetDataSet(Sql).Tables[0];
        this.str_innerhtml = Json.ToJson(dt, "TZ_MAIN");
        this.str_params = Json.ToJson(dField, "V_DICT");
    }

    /// <summary>
    /// 工单地图
    /// </summary>
    public void GetOrderMapInfo()
    {
        string ids = Request["ID"];

        string Sql = "select * from  " + TableName + " where id in(" + ids + ")";
        OracleDataBase odb = new OracleDataBase();
        DataTable dt = odb.GetDataSet(Sql).Tables[0];

        Sql = "select T.Fielddisname,t.fieldname from v_dict t where t.tablename='TZ_MAIN_UPDATE' and fieldstyle like '%40%' AND T.validity='0'";
        DataTable dField = odb.GetDataSet(Sql).Tables[0];
        Sql = string.Format("select FILEPATH||'/'||FILENAME as dPath,t.steptype  from track_media  t where t.mediatype is null and t.eventrecordid={0}", ids);
        DataTable dPath = odb.GetDataSet(Sql).Tables[0];
       if(dt.Rows.Count>0)
       {
           string jsonStr = "";
           for (int j = 0; j < dt.Rows.Count; j++)
           {
               string mainId = Convert.ToString(dt.Rows[j]["ID"]);
               string[] xys = GetPriorityXY(mainId).Split(',');
               
               if (xys.Length > 1)
               {
                   string strs = "";
                   for (int i = 0; i < dField.Rows.Count; i++)
                   {
                       string disName = Convert.ToString(dField.Rows[i]["FIELDDISNAME"]);
                       string fieldName = Convert.ToString(dField.Rows[i]["FIELDNAME"]);
                       string fieldValue = Convert.ToString(dt.Rows[j][fieldName]);
                       strs += "\"" + disName + "\":\"" + fieldValue + "\",";
                   }
                   strs += "\"X\":" + xys[0] + ",\"Y\":\"" + xys[1] + "\"";
                   string _sPathsTitle = string.Empty;
                   for (int i = 0; i < dPath.Rows.Count; i++)
                   {
                       string sPath = Convert.ToString(dPath.Rows[i]["dPath"]);
                       string sTitle = Convert.ToString(dPath.Rows[i]["steptype"]);
                       _sPathsTitle += "{\"href\":\"" + ConfigurationManager.AppSettings["filepath"] + sPath + "\",\"title\":\"" + sTitle + "\"},";
                   }
                   _sPathsTitle = _sPathsTitle.TrimEnd(',');
                   strs  += ",\"picList\":[" +_sPathsTitle+ "]";
                   jsonStr += jsonStr.Length>0?",{" + strs + "}":"{" + strs + "}";
               }
           }
         
           if (jsonStr.Length > 0) jsonStr = "[" + jsonStr + "]";
           //Loger.Error(jsonStr);
           this.str_params = jsonStr;  
       }
       else
       {
           this.str_params = "";
       } 

    }
    public string GetPriorityXY(string mainId)
    {
        string xys = "";
        //坐标优先规则---【多媒体坐标 > 人员轨迹坐标 > 地址模糊匹配坐标】
        string sql = "select b.*,";
        sql += "(select x from track_media a where a.eventrecordid=b.id and x is not null and mediatype is null and rownum=1) MEDIAX,";
        sql += "(select y from track_media a where a.eventrecordid=b.id and x is not null and mediatype is null and rownum=1) MEDIAY,";
        sql += "(select x from trackpos a where a.tid=b.PDAID and rownum=1) PDAX,";
        sql += "(select y from trackpos a where a.tid=b.PDAID and rownum=1) PDAY ";
        sql += "from V_MAIN_TOKENLAST b  where id='" + mainId + "'";

        DataSet ds = DbHelperOra.Query(sql);
        List<MapOption> list = new List<MapOption>();
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string addressX = Convert.ToString(dt.Rows[i]["TARGETX"]);//地址模糊匹配坐标
                string addressY = Convert.ToString(dt.Rows[i]["TARGETY"]);
                string pdaX = Convert.ToString(dt.Rows[i]["PDAX"]);//人员轨迹坐标
                string pdaY = Convert.ToString(dt.Rows[i]["PDAY"]);
                string mediaX = Convert.ToString(dt.Rows[i]["MEDIAX"]);//多媒体坐标
                string mediaY = Convert.ToString(dt.Rows[i]["MEDIAY"]);
                if (!string.IsNullOrEmpty(mediaX)) xys = mediaX + "," + mediaY;
                else if (!string.IsNullOrEmpty(pdaX)) xys = pdaX + "," + pdaY;
                else if (!string.IsNullOrEmpty(addressX)) xys = addressX + "," + addressY;
            }
        }
        return xys;
    }
    /// <summary>
    /// 404页面
    /// </summary>
    public void Get404Html()
    {
        BtsPage404 page_404 = new BtsPage404();
        page_404.Remark = "对不起，您的页面走丢了";
        page_404.BackUrl = "javascript:showTableDiv();";

        this.str_innerhtml = page_404.GetHtmlText();
    }

}