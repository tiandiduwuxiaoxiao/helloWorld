﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ajax_InsertRepatOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["CUSTOMSERVICEID"] != null && Request["MIAN_ID"] != null)
        {
            if (Request["type"]=="1")
            {
                insertRepeatOrder();
            }
            else if (Request["type"] == "2")
            {
                CancelRepeatOrder();
            }
        }

    }
    /// <summary>
    ///置重复
    /// </summary>
    private void insertRepeatOrder()
    {
        OracleDataBase odb = new OracleDataBase();
        //获取主单ID
        string ISSECRET_MAIN_ID = Global.getOrderId(Request["CUSTOMSERVICEID"].ToString());
        if (ISSECRET_MAIN_ID != null && !ISSECRET_MAIN_ID.Equals(""))
        {
            string sql = string.Format("update tz_main set ISSECRET_MAIN_ID='{0}', ISSECRET='1' where ID='{1}'", ISSECRET_MAIN_ID, Request["MIAN_ID"].ToString());
            Loger.Error("Ajax_InsertRepatOrder.aspx==>" + sql);
            if (odb.InsertOrUpdate(sql) > 0)
            {
                Response.Write("true");
            }
        }
    }

    private void CancelRepeatOrder()
    {
        try
        {
            OracleDataBase odb = new OracleDataBase();
            if (Request["MIAN_ID"] != null && Request["MIAN_ID"].ToString() != "")
            {
                string sql = string.Format("update tz_main set ISSECRET_MAIN_ID='{0}', ISSECRET='0' where ID='{1}'", "", Request["MIAN_ID"]);
                Loger.Error("Ajax_InsertRepatOrder.aspx==>" + sql);
                if (odb.InsertOrUpdate(sql) > 0)
                {
                    Response.Write("true");
                }
            }
        }
        catch (Exception)
        {
            
            throw;
        }
        
    }
}