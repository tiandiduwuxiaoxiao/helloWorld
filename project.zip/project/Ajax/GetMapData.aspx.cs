﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Maticsoft.DBUtility;
using System.Collections;
using System.Configuration;

public partial class Ajax_GetMapData : System.Web.UI.Page
{
    public string Z_Not_Send = ConfigurationManager.AppSettings["Z_Not_Send"].ToString();
    public string Z_Apply_Close = ConfigurationManager.AppSettings["Z_Apply_Close"].ToString();
    public string Z_Apply_Exit = ConfigurationManager.AppSettings["Z_Apply_Exit"].ToString();
    public string Z_Apply_Delay = ConfigurationManager.AppSettings["Z_Apply_Delay"].ToString();
    public string uid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];

        if (Request["flag"] == "setRecentOrderToMap") setRecentOrderToMap();//近期工单地图显示
    }
     /// <summary>
    /// 近期工单地图显示
    /// </summary>
    public void setRecentOrderToMap()
    {
        string type = Request["type"];

        ArrayList list1 = PublicFunction.GetAcceptstationInfoForDIsp(uid);
        string shoulizhandian = PublicFunction.ConvertArrayListToString(list1);

        //坐标优先规则---【多媒体坐标 > 人员轨迹坐标 > 地址模糊匹配坐标】
        string sql = "select b.*,";
        sql += "(select x from track_media a where a.eventrecordid=b.id and rownum=1) MEDIAX,";
        sql += "(select y from track_media a where a.eventrecordid=b.id and rownum=1) MEDIAY,";
        sql += "(select x from trackpos a where a.tid=b.PDAID and rownum=1) PDAX,";
        sql += "(select y from trackpos a where a.tid=b.PDAID and rownum=1) PDAY ";
        sql += "from V_MAIN_TOKENLAST b  where  b.ACCEPTSTATION in(" + shoulizhandian + ") ";

        if (type == "1") sql += "and tokenname=" + Z_Not_Send;
        else if (type == "2") sql += "and tokenname=" + Z_Apply_Close;
        else if (type == "3") sql += "and tokenname=" + Z_Apply_Exit;
        else if (type == "4") sql += "and tokenname=" + Z_Apply_Delay;

  
        DataSet ds = DbHelperOra.Query(sql);
        List<MapOption> list = new List<MapOption>();
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
          
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string addressX = Convert.ToString(dt.Rows[i]["TARGETX"]);//地址模糊匹配坐标
                string addressY = Convert.ToString(dt.Rows[i]["TARGETY"]);
                string pdaX = Convert.ToString(dt.Rows[i]["PDAX"]);//人员轨迹坐标
                string pdaY = Convert.ToString(dt.Rows[i]["PDAY"]);
                string mediaX = Convert.ToString(dt.Rows[i]["MEDIAX"]);//多媒体坐标
                string mediaY = Convert.ToString(dt.Rows[i]["MEDIAY"]);
                MapOption option = new MapOption();

                if (!string.IsNullOrEmpty(mediaX))
                {
                    option.X = mediaX;
                    option.Y = mediaY;
                }
                else if (!string.IsNullOrEmpty(pdaX))
                {
                    option.X = pdaX;
                    option.Y = pdaY;
                }
                else if (!string.IsNullOrEmpty(addressX))
                {
                    option.X = addressX;
                    option.Y = addressY;
                }
                else
                {
                    continue;
                }
                option.NAME = Convert.ToString(dt.Rows[i]["ACCEPTTIME"]);
                list.Add(option);
            }
        }

        string jsonString = Json.JsonSerializerBySingleData(list);
        Response.Write(jsonString);
        Response.End();
    }
}