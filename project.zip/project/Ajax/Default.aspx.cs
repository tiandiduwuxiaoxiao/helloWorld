﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Configuration;
using System.Data.OracleClient;
using hugegis.DBUtility;
using System.Data;
using System.Collections;

public partial class Ajax_Default : System.Web.UI.Page
{
    #region 页面加载API
    public string p_ZDJD = ConfigurationManager.AppSettings["Z_Not_Send"].ToString();
    public string uid = String.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];
        switch (Request["defaultType"])
        {
            case "开单": AddOrder(); break;
            case "修改": UpdateOrder(); break;
            case "直接销单": DirectOrder(); break;
            case "PC销单": PCServerClick(); break;
            case "PC批量销单": PCMoreServerClick(); break;
            case "工单审核": OrderCheck(); break;
            case "直接退单": Direct_Back_Order(); break;
            case "直接延期": Direct_Yanqi_Order(); break;
            case "CommonAdd": btn_CommonOK_Click("add"); break;
            case "CommonEdit": btn_CommonOK_Click("edit"); break;
            case "巡检转现维审核": XJToXWSH(); break;
            case "转站":SiteToSite(); break;
            case "工单催办": CuiBanOrder(); break;
            case "工单删除": OrderDelete(); break;
            case "取消工单删除": CanleOrderDelete(); break;
            case "接口审核": JkshClick();break;
            case "材料添加": addCailiaoInfo(); break;
            default:
                break;
        }
    }
    #endregion
   
    #region 通用页面存储
    /// <summary>
    /// 通用页面存储
    /// </summary>
    protected void btn_CommonOK_Click(string type)
    {
        OracleDataBase database = new OracleDataBase();
        try
        {
            string gugid = System.Guid.NewGuid().ToString("N");
            #region 业务处理
            string sql_values = Request["hidSqlString"];
            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(sql_values))
            {
                StringBuilder sbfieldname = new StringBuilder();
                StringBuilder sbvalues = new StringBuilder();
                string[] VALUES = sql_values.Split(',');
                #region 取值
                foreach (string value in VALUES)
                {
                    if (string.IsNullOrWhiteSpace(value))
                        continue;
                    string[] ss = value.Split('|');
                    string s_FieldName = ss[0];//字段名
                    string s_FieldType = ss[1];//字段类型
                    string s_IsNull = ss[2];//是否为空
                    string s_Nullable = ss[3];//是否可空
                    if (s_FieldType.Contains("51") || s_FieldType.Contains("52"))
                    {
                        sbfieldname.AppendFormat(" {0},{1},{2},", s_FieldName, s_FieldName + "BEGIN", s_FieldName + "END");
                        if (Request.Form[s_FieldName] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}',", s_FieldName, Request.Form[s_FieldName].ToString());
                        }

                        if (Request.Form[s_FieldName + "BEGIN"] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "BEGIN", Request.Form[s_FieldName + "BEGIN"].ToString());
                        }
                        if (Request.Form[s_FieldName + "END"] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "END", Request.Form[s_FieldName + "END"].ToString());
                        }
                    }
                    else if (s_FieldType.Contains("50"))
                    {
                        sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_FieldName, Request.Form[s_FieldName].ToString());
                    }
                    else
                    {
                        if (s_FieldName != "ID")
                        {
                            sbfieldname.AppendFormat(" {0},", s_FieldName);
                            if (Request.Form[s_FieldName] != null)
                            {
                                sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, Request.Form[s_FieldName].ToString());
                            }
                        }
                        else
                        {
                            sbfieldname.AppendFormat(" {0},", s_FieldName);
                        }
                    }
                }
                #endregion
                string s_table_name = Request["table"];
                string s_fields = sbfieldname.ToString();
                string username = uid;
                s_fields = s_fields.Substring(0, s_fields.Length - 1);
                #region  注销的代码
                //string s_values = sbvalues.ToString();
                //s_values = s_values.Substring(0, s_values.Length - 1);
                //sb.AppendFormat("INSERT INTO {0} ({1}) VALUES ({2})", s_table_name, s_fields, s_values);
                //string s_insertsql = sb.ToString();
                #endregion
                string upstr = "";
                if (type == "add")
                {
                    sb.AppendFormat("INSERT INTO " + s_table_name + " (ID,createby,createdate) VALUES ('{0}' , '{1}',sysdate)", gugid, username);
                    if (database.InsertOrUpdate(sb.ToString()) == 0)
                    {
                        Response.Write("false");
                    }
                }
                if (type == "edit")
                {
                    gugid = Request.Form["OrderhId"].ToString();
                    upstr = "editby='" + username + "',editdate=sysdate,";
                }
                string s_updatesql = sb2.ToString();
                s_updatesql = s_updatesql.Substring(0, s_updatesql.Length - 1);
                s_updatesql = string.Format(" UPDATE {0} SET {3} {1}   WHERE ID = '{2}'", s_table_name, s_updatesql, gugid, upstr);
                if (s_updatesql.Length > 0)
                {
                    if (database.InsertOrUpdate(s_updatesql) > 0)
                    {
                        Response.Write("true");
                    }
                    else
                    {
                        Response.Write("false");
                    }
                }
            }
            else
            {
                //执行失败
                Response.Write("false");
            }
            #endregion
        }
        catch (Exception ex)
        {
            //执行失败
            Response.Write("false");
            Loger.Error("Default.aspx.cs==>>btn_CommonOK_Click()====》: ", ex);
        }
        finally { database.Close(); }

    }
    #endregion

    #region  自开开单
    /// <summary>
    /// 开单
    /// </summary>
    protected void AddOrder()
    {
        OracleDataBase database = new OracleDataBase();
        try
        {
            string gugid = System.Guid.NewGuid().ToString();
            string fid = Request["hidFidString"];//主工单ID
            string isselesend = Request["hidIsSelfSendString"];//来源标识(0：热线，1：内部子工单，2：拆分工单，3：后续跟进单)
            if (string.IsNullOrWhiteSpace(isselesend)) isselesend = "4";//0：热线
            Loger.Info("AddOrder===>isselesend:" + isselesend);
            #region
            string insertvalues = Request["hidSqlString"];
            //string insertvalues = ViewState["INSERTORDERSQL"] as string;
            string happendAddr = "";//地址
            if (string.IsNullOrWhiteSpace(Request.Form["OrderhId"]))
            {
                return;
            }
            StringBuilder sb = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(insertvalues))
            {
                gugid = Request.Form["OrderhId"].ToString();
                StringBuilder sbfieldname = new StringBuilder();
                StringBuilder sbvalues = new StringBuilder();
                string[] VALUES = insertvalues.Split('∑');
                foreach (string value in VALUES)
                {
                    if (string.IsNullOrWhiteSpace(value))
                        continue;
                    string[] ss = value.Split('|');
                    string s_1 = ss[1];
                    string s_f = ss[0];
                    string s_v = Request.Form[ss[0]];
                    string s_q = ss[3];
                    if (Request.Form[ss[0]] == null && !ss[0].Equals("AGREEDTIME")) continue;
                    if (s_f.Equals("HAPPENADDR")) happendAddr = s_v;
                    //拼值
                    if (ss[1].Contains("50"))
                    {
                        sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                    }
                    else if (ss[1].Contains("40"))
                    {
                        if (ss[0] != "ID")
                        {
                            if (ss[0] == "AGREEDTIME")
                            {
                                string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
                                string EndAGREEDTIME = Request.Form[ss[0] + "END"];
                                string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
                                sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
                            }
                            else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]) && !string.IsNullOrWhiteSpace(s_q))
                            {
                                string WORDSCONTENT = Request.Form[ss[0]];
                                sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                            }
                            else
                            {
                                sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                            }
                        }
                    }
                    //拼字段
                    if (ss[1].Contains("51"))
                    {
                        if (ss[0] == "AGREEDTIME")
                        {
                            sbfieldname.AppendFormat(" {0},{1},{2},", ss[0], ss[0] + "BEGIN", ss[0] + "END");
                        }
                        else
                        {
                            sbfieldname.AppendFormat(" {0},", ss[0]);
                        }
                    }
                    else
                    {
                        if (ss[0] != "ID")
                            sbfieldname.AppendFormat(" {0},", ss[0]);
                    }
                }
                sb.AppendFormat("INSERT INTO TZ_MAIN (ID,FID,TOKENNAME, ISSELFSEND,{4}) VALUES ('{0}' , '{1}',{2},{3},{5})", gugid, fid, p_ZDJD, isselesend, sbfieldname.ToString().Substring(0, sbfieldname.ToString().Length - 1), sbvalues.ToString().Substring(0, sbvalues.ToString().Length - 1));
                string s_insertsql = sb.ToString();
                Loger.Info("AddOrder===>s_insertsql:" + s_insertsql);
                if (sb.ToString().Length > 0 && database.InsertOrUpdate(s_insertsql) > 0 && (!string.IsNullOrWhiteSpace(Request.Form["ACCEPTSTATION1"]) || !string.IsNullOrWhiteSpace(Request.Form["ACCEPTSTATION"])))
                {
                    string xyFilter = "";
                    //XY录入时取XY定位，否则使用地址定位
                    if (!string.IsNullOrWhiteSpace(Request["TARGETX"]) || !string.IsNullOrWhiteSpace(Request["TARGETY"]))
                    {
                        xyFilter = ",TARGETX=" + Request["TARGETX"] + ",TARGETY=" + Request["TARGETY"];
                    }
                    else
                    {
                        string[] xys = Convert.ToString(PublicFunction.GetLocation("TZ_DMKU", happendAddr)).Split(',');
                        if (xys.Length > 1)
                        {
                            xyFilter = ",TARGETX=" + xys[0] + ",TARGETY=" + xys[1];
                        }
                    }
                    string Acceptstation = string.IsNullOrWhiteSpace(Request.Form["ACCEPTSTATION"]) ? Request.Form["ACCEPTSTATION1"].ToString() : Request.Form["ACCEPTSTATION"].ToString();
                    Loger.Info("AddOrder===>ACCEPTSTATION:" + Request.Form["ACCEPTSTATION"]);
                    string ISACCEPTSTATION = !string.IsNullOrWhiteSpace(Request.Form["ACCEPTSTATION"]) ? "ACCEPTSTATION" : "ACCEPTSTATION1";
                    string sql = string.Format(" UPDATE TZ_MAIN SET INFONUM = CUSTOMSERVICEID, MISSIONBH = CUSTOMSERVICEID, SENDSTATION = " + ISACCEPTSTATION + ",SHACCEPTSTATION =" + ISACCEPTSTATION + ",ACCEPTSTATION=" + ISACCEPTSTATION + ", SENDPEOPLE = nvl(ACCEPTPEOPLE,SENDPEOPLE),{1} {2} WHERE ID = '{0}'", gugid, GetExeCutive(gugid), xyFilter);
                    database.InsertOrUpdate(sql);
                    string deppid = database.GetScalarInfo("select pid from AUTHOR_DEPARTMENT where depname = '" + Acceptstation + "'");
                    if (!string.IsNullOrWhiteSpace(deppid))
                    {
                        sql = "insert into STATIONPAIDANHIS (DEPPID, HISORDER, HISSTATION, HISDATE, MAIN_ID) values ('" + deppid + "', '1', '" + Acceptstation + "', sysdate, '" + gugid + "')";
                        database.InsertOrUpdate(sql);
                    }
                    sql = string.Format("insert into tz_tokenlog(main_id,tokenname,cuser,type) values ('{0}',{1},'{2}','1')", gugid, p_ZDJD, uid);
                    string cuser = uid;
                    string tokeName = p_ZDJD;
                    if (database.InsertOrUpdate(sql) > 0)
                    {
                        Response.Write("true");
                    }
                }
            }
            else
            {
                Response.Write("false");
            }
            #endregion
        }
        catch (Exception ex)
        {
            Response.Write("false");
            Loger.Error("addOrder.aspx====》: ", ex);
        }
        finally { database.Close(); }

    }
    #endregion

    #region 工单编辑\接口派单
    /// <summary>
    /// 工单编辑
    /// </summary>
    protected void UpdateOrder()
    {
        OracleDataBase database = new OracleDataBase();
        try
        {
            string gugid = System.Guid.NewGuid().ToString();
            #region 业务处理
            string sql_values = Request["hidSqlString"];
            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();
            string happendAddr = "";//地址
            if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]))
            {
                return;
            }
            //查询timestamp标志，防止页面过期或并发
            string timestampsql = "select timestamp from tz_main where id='" + Request.Form["OrderhId"] + "'";
            string timestampnew = database.GetScalarInfo(timestampsql);
            string timestampold = Request["hdtimestamp"];
            if (timestampnew != timestampold)
            {
                Loger.Error("页面已过期");
                Response.Write("false");
                return;
            }
            if (!string.IsNullOrWhiteSpace(sql_values))
            {
                gugid = Request.Form["OrderhId"].ToString();
                StringBuilder sbfieldname = new StringBuilder();
                StringBuilder sbvalues = new StringBuilder();
                string[] VALUES = sql_values.Split('∑');
                #region 取值
                foreach (string value in VALUES)
                {
                    if (string.IsNullOrWhiteSpace(value))
                        continue;
                    string[] ss = value.Split('|');
                    string s_FieldName = ss[0];//字段名
                    string s_FieldType = ss[1];//字段类型
                    string s_IsNull = ss[2];//是否为空
                    string s_Nullable = ss[3];//是否可空
                    if (s_FieldName.Equals("HAPPENADDR")) happendAddr = Request[s_FieldName];
                    if (s_FieldType.Contains("51") || s_FieldType.Contains("52"))
                    {
                        sbfieldname.AppendFormat(" {0},{1},{2},", s_FieldName, s_FieldName + "BEGIN", s_FieldName + "END");
                        if (Request.Form[s_FieldName] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}',", s_FieldName, Request.Form[s_FieldName].ToString());
                        }
                        else if (s_FieldName == "AGREEDTIME")
                        {
                            string BegAGREEDTIME = Request.Form[s_FieldName + "BEGIN"];
                            string EndAGREEDTIME = Request.Form[s_FieldName + "END"];
                            string AGREEDTIME = DateTime.Parse(Request.Form[s_FieldName + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_FieldName + "END"]).ToString("HH:ss");
                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, AGREEDTIME);
                        }
                        if (Request.Form[s_FieldName + "BEGIN"] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "BEGIN", Request.Form[s_FieldName + "BEGIN"].ToString());
                        }
                        if (Request.Form[s_FieldName + "END"] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "END", Request.Form[s_FieldName + "END"].ToString());
                        }
                    }
                    else if (s_FieldType.Contains("50"))
                    {
                        sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_FieldName, Request.Form[s_FieldName].ToString());
                    }
                    else
                    {
                        if (s_FieldName != "ID")
                        {
                            sbfieldname.AppendFormat(" {0},", s_FieldName);
                            if (s_FieldName.ToUpper() == "TOKENNAME")
                            {
                                string temp = p_ZDJD;
                                sb2.AppendFormat(" {0} = {1} ,", s_FieldName, temp);
                            }
                            else if (Request.Form[s_FieldName] != null)
                            {
                                sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, Request.Form[s_FieldName].ToString());
                            }
                        }
                        else
                        {
                            sbfieldname.AppendFormat(" {0},", s_FieldName);
                        }
                    }
                }
                #endregion
                string s_table_name = "TZ_MAIN";
                string s_fields = sbfieldname.ToString();
                #region 审核站点、受理站点
                if (Request["ACCEPTSTATION"] == null)
                {
                    sb2.AppendFormat("ACCEPTSTATION='{0}',", Request["ACCEPTSTATION1"]);
                    sb2.AppendFormat("SHACCEPTSTATION='{0}',", Request["ACCEPTSTATION1"]);
                }
                else
                {
                    sb2.AppendFormat("SHACCEPTSTATION='{0}',", Request["ACCEPTSTATION"]);
                }
                #endregion
                s_fields = s_fields.Substring(0, s_fields.Length - 1);
                string s_updatesql = sb2.ToString();
                s_updatesql = s_updatesql.Substring(0, s_updatesql.Length - 1);

                s_updatesql = string.Format(" UPDATE {0} SET {1}  WHERE ID = '{2}'", s_table_name, s_updatesql, gugid);
                if (s_updatesql.Length > 0)
                {
                    if (database.InsertOrUpdate(s_updatesql) > 0)
                    {
                        string xyFilter = "";
                        string[] xys = Convert.ToString(PublicFunction.GetLocation("TZ_DMKU", happendAddr)).Split(',');
                        if (xys.Length > 1)
                        {
                            xyFilter = ",TARGETX=" + xys[0] + ",TARGETY=" + xys[1];
                        }
                        string sql = string.Format("UPDATE TZ_MAIN SET SENDPEOPLE = ACCEPTPEOPLE,timestamp=sysdate,{1} {2} WHERE ID = '{0}'", gugid, GetExeCutive(gugid), xyFilter);
                        database.InsertOrUpdate(sql);
                        if (!string.IsNullOrWhiteSpace(Request.Form["ACCEPTSTATION1"]) && !string.IsNullOrWhiteSpace(Request.Form["ACCEPTSTATION"]))
                        {
                            string ACCEPTSTATION = Request.Form["ACCEPTSTATION1"];
                            string sendacceptstation = Request.Form["ACCEPTSTATION"];
                            string deppid = database.GetScalarInfo("select pid from AUTHOR_DEPARTMENT where depname = '" + sendacceptstation + "'");
                            if (!string.IsNullOrWhiteSpace(deppid))
                            {
                                string type = "1";
                                database.ExeProcedure("pd_stationsh", ACCEPTSTATION ?? "", sendacceptstation ?? "", gugid, type);
                                sql = string.Format("select (HISORDER+1) as HISORDER from  STATIONPAIDANHIS where main_id='{0}' and HISSTATION<>'{1}' ", gugid, sendacceptstation);
                               string hiStr=database.GetScalarInfo(sql);
                               if (!string.IsNullOrWhiteSpace(hiStr))
                               {
                                   int HISORDER = Convert.ToInt32(database.GetScalarInfo(sql));
                                   sql = "insert into STATIONPAIDANHIS (DEPPID, HISORDER, HISSTATION, HISDATE, MAIN_ID) values ('" + deppid + "', '" + HISORDER + "', '" + sendacceptstation + "', sysdate, '" + gugid + "')";
                                   database.InsertOrUpdate(sql);
                               }
                               string  CUSTOMSERVICEID=   Global.getCUSTOMSERVICEID(Request.Form["OrderhId"]);
                                string sql_u = @"insert into TZ_ZHUANZHANHIS(id,main_id,num,sendtime,SENDREMARK,ACCEPTSTATION,SENDSTATION,SENDPEOPLE,STATUS) 
                                    values(sys_guid(),'" + Request.Form["OrderhId"] + "','" + CUSTOMSERVICEID + "',sysdate,'接口派遣','" + ACCEPTSTATION + "','" + sendacceptstation + "','" + uid + "','0') ";
                                database.InsertOrUpdate(sql_u);
                            }
                        }
                        Response.Write("true");
                    }
                }
            }
            else
            {
                //执行失败
                Response.Write("false");
            }
            #endregion
        }
        catch (Exception ex)
        {
            //执行失败
            Response.Write("false");
            Loger.Error("Default.aspx.cs==>>btn_OK1_Click()====》: ", ex);
        }
        finally { database.Close(); }
    }
    #endregion

    #region 直接销单无需审核
    protected void DirectOrder()
    {
        try
        {
            string sql = string.Empty;
            OracleDataBase odb = new OracleDataBase();
            string sql_values = Request["hidSqlString"];
            List<string> dic = new List<string>();
            if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]) || Request["TableName"] == null)
            {
                return;
            }
            if (!string.IsNullOrWhiteSpace(sql_values))
            {
                string TableName = Request["TableName"].ToString();
                string gugid = Request.Form["OrderhId"].ToString();
                string T_sql = string.Format("select distinct updtaetable from v_dict where tablename ='{0}'   and fieldstyle like '%40%'  ", TableName);
                DataSet ds = odb.GetDataSet(T_sql);
                #region
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        StringBuilder sbfieldname = new StringBuilder();
                        StringBuilder sbvalues = new StringBuilder();
                        StringBuilder sb = new StringBuilder();
                        StringBuilder sb2 = new StringBuilder();
                        if (string.IsNullOrWhiteSpace(Convert.ToString(item["updtaetable"]))) continue;
                        string[] VALUES = sql_values.Split('∑');
                        #region 取值
                        sbfieldname.AppendFormat("MAIN_ID,");
                        sbvalues.AppendFormat("'{0}',", gugid);
                        foreach (string value in VALUES)
                        {
                            if (string.IsNullOrWhiteSpace(value))
                                continue;
                            string[] ss = value.Split('|');
                            string s_FieldName = ss[0];//字段名
                            string s_FieldType = ss[1];//字段类型
                            string s_IsNull = ss[2];//是否为空
                            string s_Nullable = ss[3];//是否可空
                            string mapSql = ss[4];//修改的表
                            string updtaetable = ss[5];//修改的表
                            if (updtaetable != Convert.ToString(item["updtaetable"]))
                                continue;
                            //拼值
                            if (ss[1].Contains("50"))
                            {
                                sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                            }
                            else if (ss[1].Contains("40"))
                            {
                                if (ss[0] != "ID")
                                {
                                    if (ss[0] == "AGREEDTIME")
                                    {
                                        string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
                                        string EndAGREEDTIME = Request.Form[ss[0] + "END"];
                                        string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
                                        sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
                                    }
                                    else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]))
                                    {
                                        string WORDSCONTENT = Request.Form[ss[0]];
                                        sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                                    }
                                    else
                                    {
                                        sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                                    }
                                }
                            }

                            if (s_FieldType.Contains("51") || s_FieldType.Contains("52"))
                            {
                                sbfieldname.AppendFormat(" {0},{1},{2},", s_FieldName, s_FieldName + "BEGIN", s_FieldName + "END");
                                if (Request.Form[s_FieldName] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}',", s_FieldName, Request.Form[s_FieldName].ToString());
                                }
                                else if (s_FieldName == "AGREEDTIME")
                                {
                                    string BegAGREEDTIME = Request.Form[s_FieldName + "BEGIN"];
                                    string EndAGREEDTIME = Request.Form[s_FieldName + "END"];
                                    string AGREEDTIME = DateTime.Parse(Request.Form[s_FieldName + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_FieldName + "END"]).ToString("HH:ss");
                                    sb2.AppendFormat(" {0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss') ,", s_FieldName, AGREEDTIME);
                                }
                                if (Request.Form[s_FieldName + "BEGIN"] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "BEGIN", Request.Form[s_FieldName + "BEGIN"].ToString());
                                }
                                if (Request.Form[s_FieldName + "END"] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "END", Request.Form[s_FieldName + "END"].ToString());
                                }
                            }
                            else if (s_FieldType.Contains("50"))
                            {
                                sbfieldname.AppendFormat(" {0},", s_FieldName);
                                sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_FieldName, Request.Form[s_FieldName].ToString());
                            }
                            else
                            {
                                if (s_FieldName != "ID")
                                {
                                    sbfieldname.AppendFormat(" {0},", s_FieldName);
                                    if (s_FieldName.ToUpper() == "TOKENNAME")
                                    {
                                        string temp = p_ZDJD;
                                        sb2.AppendFormat(" {0} = {1} ,", s_FieldName, temp);
                                    }
                                    else if (Request.Form[s_FieldName] != null)
                                    {
                                        sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, Request.Form[s_FieldName].ToString());
                                    }
                                }
                                else
                                {
                                    sbfieldname.AppendFormat(" {0},", s_FieldName);
                                }
                            }
                        }
                        string s_updatesql = sb2.ToString();
                        sql = "select count(*) count from " + Convert.ToString(item["updtaetable"]) + " where main_id='" + gugid + "'";
                        if (Convert.ToInt32(odb.GetScalarInfo(sql)) > 0)
                        {
                            s_updatesql = s_updatesql.Substring(0, s_updatesql.Length - 1);
                            s_updatesql = string.Format(" UPDATE {0} SET {1}  WHERE MAIN_ID = '{2}'", Convert.ToString(item["updtaetable"]), s_updatesql, gugid);
                        }
                        else
                        {
                            s_updatesql = string.Format("insert into {0}  ({1}) VALUES ({2})", Convert.ToString(item["updtaetable"]), sbfieldname.ToString().Substring(0, sbfieldname.ToString().Length - 1), sbvalues.ToString().Substring(0, sbvalues.ToString().Length - 1));
                        }
                        dic.Add(Convert.ToString(s_updatesql));
                        #endregion
                    }
                }
                if (dic.Count > 0)
                {
                    if (odb.SetExecuteTranSql(dic))
                    {
                        #region 更新为销单完成状态, update by @juno
                        string Z_Yet_Close = ConfigurationManager.AppSettings["Z_Yet_Close"].ToString();
                        sql = " update tz_main set STATUS='1' ,pdaid=''  where id='" + gugid + "'";
                        odb.InsertOrUpdate(sql);
                        string cuser = uid;
                        #region 业务处理
                        if (Global.DoProcess(gugid, Z_Yet_Close, cuser))
                        {
                            #region "4工单回收，凡是销单的，一律从手机上进行工单删除 2015年2月2日14:12:38 add"
                            string sql1 = string.Format(" insert into huishou_his (pdaid, main_id, tdyy) (select pdaid, main_id, '手机端无法正常销单，平台段来销单' from tz_paidanhis where main_id = '{0}')", gugid);
                            odb.InsertOrUpdate(sql1);
                            Loger.Error("平台段销单执附加回收sql==>" + sql1);
                            OracleCommand UpdateCommand = new OracleCommand();
                            OracleConnection myConnection = null;
                            OracleTransaction myTran = null;
                            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
                            myConnection.Open();
                            UpdateCommand.Connection = myConnection;
                            myTran = myConnection.BeginTransaction();
                            UpdateCommand.Transaction = myTran;
                            bool flag = Global.SHCL(gugid, "1", "2", uid, UpdateCommand);
                            myTran.Commit();
                            #endregion
                            Response.Write("true");
                        }
                        #endregion
                        #endregion
                    }
                }
                #endregion
            }
            else
            {
                Response.Write("false");
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    #endregion

    #region PC销单(需要审核）
    /// <summary>
    /// PC销单(需要审核)
    /// </summary>
    protected void PCServerClick()
    {
        string cuser = uid;
        OracleDataBase odb = new OracleDataBase();
        bool falg = false;
        try
        {
            string sql_values = Request["hidSqlString"];
            List<string> dic = new List<string>();
            if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]) || Request["TableName"] == null)
            {
                return;
            }
            if (!string.IsNullOrWhiteSpace(sql_values))
            {
                string TableName = Request["TableName"].ToString();
                string gugid = Request.Form["OrderhId"].ToString();
                string T_sql = string.Format("select distinct updtaetable from v_dict where tablename ='{0}'   and fieldstyle like '%40%'  ", TableName);
                DataSet ds = odb.GetDataSet(T_sql);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        StringBuilder sbfieldname = new StringBuilder();
                        StringBuilder sbvalues = new StringBuilder();
                        StringBuilder sb = new StringBuilder();
                        StringBuilder sb2 = new StringBuilder();
                        Dictionary<string, string> treeDic = new Dictionary<string, string>();
                        if (string.IsNullOrWhiteSpace(Convert.ToString(item["updtaetable"]))) continue;
                        string[] VALUES = sql_values.Split('∑');
                        #region 取值
                        sbfieldname.AppendFormat("MAIN_ID,");
                        sbvalues.AppendFormat("'{0}',", gugid);
                        foreach (string value in VALUES)
                        {
                            if (string.IsNullOrWhiteSpace(value))
                                continue;
                            string[] ss = value.Split('|');
                            string s_FieldName = ss[0];//字段名
                            string s_FieldType = ss[1];//字段类型
                            string s_IsNull = ss[2];//是否为空
                            string s_Nullable = ss[3];//是否可空
                            string mapSql = ss[4];//修改的表
                            string mappingcode = ss[6];//类型
                            string updtaetable = ss[5];//修改的表
                            if (updtaetable != Convert.ToString(item["updtaetable"]))
                                continue;
                            //拼值
                            if (ss[1].Contains("50"))
                            {
                                sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                            }
                            else if (ss[1].Contains("40"))
                            {
                                if (ss[0] != "ID")
                                {
                                    if (ss[0] == "AGREEDTIME")
                                    {
                                        string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
                                        string EndAGREEDTIME = Request.Form[ss[0] + "END"];
                                        string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
                                        sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
                                    }
                                    else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]))
                                    {
                                        string WORDSCONTENT = Request.Form[ss[0]];
                                        sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                                    }
                                    else
                                    {
                                        sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                                    }
                                }
                            }

                            if (s_FieldType.Contains("51") || s_FieldType.Contains("52"))
                            {
                                sbfieldname.AppendFormat(" {0},{1},{2},", s_FieldName, s_FieldName + "BEGIN", s_FieldName + "END");
                                if (Request.Form[s_FieldName] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}',", s_FieldName, Request.Form[s_FieldName].ToString());
                                }
                                else if (s_FieldName == "AGREEDTIME")
                                {
                                    string BegAGREEDTIME = Request.Form[s_FieldName + "BEGIN"];
                                    string EndAGREEDTIME = Request.Form[s_FieldName + "END"];
                                    string AGREEDTIME = DateTime.Parse(Request.Form[s_FieldName + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_FieldName + "END"]).ToString("HH:ss");
                                    sb2.AppendFormat(" {0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss') ,", s_FieldName, AGREEDTIME);
                                }
                                if (Request.Form[s_FieldName + "BEGIN"] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "BEGIN", Request.Form[s_FieldName + "BEGIN"].ToString());
                                }
                                if (Request.Form[s_FieldName + "END"] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "END", Request.Form[s_FieldName + "END"].ToString());
                                }
                            }
                            else if (s_FieldType.Contains("50"))
                            {
                                sbfieldname.AppendFormat(" {0},", s_FieldName);
                                sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_FieldName, Request.Form[s_FieldName].ToString());
                            }
                            else
                            {
                                if (s_FieldName != "ID")
                                {
                                    sbfieldname.AppendFormat(" {0},", s_FieldName);
                                    if (s_FieldName.ToUpper() == "TOKENNAME")
                                    {
                                        string temp = p_ZDJD;
                                        sb2.AppendFormat(" {0} = {1} ,", s_FieldName, temp);
                                    }
                                    else if (Request.Form[s_FieldName] != null)
                                    {
                                        sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, Request.Form[s_FieldName].ToString());
                                    }
                                }
                                else
                                {
                                    sbfieldname.AppendFormat(" {0},", s_FieldName);
                                }
                            }
                            //如果为tree选择的需要将值存储在tz_tree中
                            if (mappingcode == "4")
                            {
                                treeDic.Add(s_FieldName, Request.Form[s_FieldName + "_tree"]);
                            }
                        }
                        #endregion
                        string s_updatesql = sb2.ToString();
                        string sql = "select count(*) count from " + Convert.ToString(item["updtaetable"]) + " where main_id='" + gugid + "'";
                        if (Convert.ToInt32(odb.GetScalarInfo(sql)) > 0)
                        {
                            s_updatesql = s_updatesql.Substring(0, s_updatesql.Length - 1);
                            s_updatesql = string.Format(" UPDATE {0} SET {1}  WHERE MAIN_ID = '{2}'", Convert.ToString(item["updtaetable"]), s_updatesql, gugid);
                        }
                        else
                        {
                            s_updatesql = string.Format("insert into {0}  ({1}) VALUES ({2})", Convert.ToString(item["updtaetable"]), sbfieldname.ToString().Substring(0, sbfieldname.ToString().Length - 1), sbvalues.ToString().Substring(0, sbvalues.ToString().Length - 1));
                        }
                        if (treeDic.Count > 0)
                        {
                            foreach (KeyValuePair<string, string> itemdic in treeDic)
                            {
                                sql = "select count(*) count from TZ_TREE where SOURCEID='" + gugid + "' and  FIELDNAME = '" + itemdic.Key + "'";
                                if (Convert.ToInt32(odb.GetScalarInfo(sql)) > 0)
                                {
                                    string sqlupdate = "update TZ_TREE set VALUE = '" + itemdic.Value +
                                                       "',EDITBY='" + cuser + "' where SOURCEID='" + gugid + "' and  FIELDNAME = '" +
                                                       itemdic.Key + "'";
                                    dic.Add(sqlupdate);
                                }
                                else
                                {
                                    string sqlupdate = "insert into TZ_TREE (SOURCEID,VALUE,FIELDNAME,CREATEBY,EDITBY) values ('" + gugid + "','" + itemdic.Value + "','" + itemdic.Key + "','" + cuser + "','" + cuser + "')";
                                    dic.Add(sqlupdate);
                                }
                            }
                           
                        }
                        dic.Add(Convert.ToString(s_updatesql));
                    }
                }
                #region 业务处理
                if (dic.Count > 0)
                {
                    if (odb.SetExecuteTranSql(dic))
                    {
                        falg = PCServerDoProcess(odb, gugid);
                    }
                }
                #endregion
            }
        }
        catch (Exception ex)
        {
            Loger.Error("PC端销单PCServerClick==>" + ex);
        }
        if (falg)
        {
            Response.Write("true");
        }
        else
        {
            Response.Write("false");
        }

    }
    #endregion

    #region PC批量销单(需要审核) 
    /// <summary>
    /// PC批量销单(需要审核)
    /// </summary>
    protected void PCMoreServerClick()
    {
        OracleDataBase odb = new OracleDataBase();
        Dictionary<string, string> dic = new Dictionary<string, string>();
        List<string> listtab = new List<string>();
        bool falg = false;
        try
        {
            string sql_values = Request["hidSqlString"];
            if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]) || Request["TableName"] == null)
            {
                return;
            }
            if (!string.IsNullOrWhiteSpace(sql_values))
            {
                string TableName = Request["TableName"].ToString();
                string gugid = Request.Form["OrderhId"].ToString();
                string T_sql = string.Format("select distinct updtaetable from v_dict where tablename ='{0}'   and fieldstyle like '%40%'  ", TableName);
                DataSet ds = odb.GetDataSet(T_sql);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        StringBuilder sbfieldname = new StringBuilder();
                        StringBuilder sbvalues = new StringBuilder();
                        StringBuilder sb = new StringBuilder();
                        StringBuilder sb2 = new StringBuilder();
                        if (string.IsNullOrWhiteSpace(Convert.ToString(item["updtaetable"]))) continue;
                        string[] VALUES = sql_values.Split('∑');
                        #region 取值
                        foreach (string value in VALUES)
                        {
                            if (string.IsNullOrWhiteSpace(value))
                                continue;
                            string[] ss = value.Split('|');
                            string s_FieldName = ss[0];//字段名
                            string s_FieldType = ss[1];//字段类型
                            string s_IsNull = ss[2];//是否为空
                            string s_Nullable = ss[3];//是否可空
                            string mapSql = ss[4];//修改的表
                            string updtaetable = ss[5];//修改的表
                            if (updtaetable != Convert.ToString(item["updtaetable"]))
                                continue;
                            //拼值
                            if (ss[1].Contains("50"))
                            {
                                sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                            }
                            else if (ss[1].Contains("40"))
                            {
                                if (ss[0] != "ID")
                                {
                                    if (ss[0] == "AGREEDTIME")
                                    {
                                        string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
                                        string EndAGREEDTIME = Request.Form[ss[0] + "END"];
                                        string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
                                        sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
                                    }
                                    else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]))
                                    {
                                        string WORDSCONTENT = Request.Form[ss[0]];
                                        sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                                    }
                                    else
                                    {
                                        sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                                    }
                                }
                            }
                            if (s_FieldType.Contains("51") || s_FieldType.Contains("52"))
                            {
                                sbfieldname.AppendFormat(" {0},{1},{2},", s_FieldName, s_FieldName + "BEGIN", s_FieldName + "END");
                                if (Request.Form[s_FieldName] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}',", s_FieldName, Request.Form[s_FieldName].ToString());
                                }
                                else if (s_FieldName == "AGREEDTIME")
                                {
                                    string BegAGREEDTIME = Request.Form[s_FieldName + "BEGIN"];
                                    string EndAGREEDTIME = Request.Form[s_FieldName + "END"];
                                    string AGREEDTIME = DateTime.Parse(Request.Form[s_FieldName + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_FieldName + "END"]).ToString("HH:ss");
                                    sb2.AppendFormat(" {0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss') ,", s_FieldName, AGREEDTIME);
                                }
                                if (Request.Form[s_FieldName + "BEGIN"] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "BEGIN", Request.Form[s_FieldName + "BEGIN"].ToString());
                                }
                                if (Request.Form[s_FieldName + "END"] != null)
                                {
                                    sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "END", Request.Form[s_FieldName + "END"].ToString());
                                }
                            }
                            else if (s_FieldType.Contains("50"))
                            {
                                sbfieldname.AppendFormat(" {0},", s_FieldName);
                                sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_FieldName, Request.Form[s_FieldName].ToString());
                            }
                            else
                            {
                                if (s_FieldName != "ID")
                                {
                                    sbfieldname.AppendFormat(" {0},", s_FieldName);
                                    if (s_FieldName.ToUpper() == "TOKENNAME")
                                    {
                                        string temp = p_ZDJD;
                                        sb2.AppendFormat(" {0} = {1} ,", s_FieldName, temp);
                                    }
                                    else if (Request.Form[s_FieldName] != null)
                                    {
                                        sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, Request.Form[s_FieldName].ToString());
                                    }
                                }
                                else
                                {
                                    sbfieldname.AppendFormat(" {0},", s_FieldName);
                                }
                            }
                        }
                        #endregion
                        string s_updatesql = sb2.ToString();
                        s_updatesql = s_updatesql.Substring(0, s_updatesql.Length - 1);
                        dic.Add(Convert.ToString(item["updtaetable"]) + "_update", s_updatesql);
                        string fieldname = sbfieldname.ToString() + "MAIN_ID,";
                        string values = sbvalues.ToString() + "'[[∑##∑]]',";
                        string sql = string.Format("insert into {0}  ({1}) VALUES ({2})", Convert.ToString(item["updtaetable"]), fieldname.ToString().Substring(0, fieldname.ToString().Length - 1), values.Substring(0, values.Length - 1));
                        dic.Add(Convert.ToString(item["updtaetable"]) + "_insert", sql);
                        listtab.Add(Convert.ToString(item["updtaetable"]));
                    }
                }
                #region 业务处理
                List<string> list = new List<string>();
                string[] gugids = gugid.Split('|');
                if (gugids.Length > 0)
                {
                    foreach (string str in gugids)
                    {
                        if (string.IsNullOrWhiteSpace(str))
                            continue;
                        for (int i = 0; i < listtab.Count; i++)
                        {
                            string sql = "select count(*) count from " + listtab[i] + " where main_id='" + str + "'";
                            if (Convert.ToInt32(odb.GetScalarInfo(sql)) > 0)
                            {
                                sql = dic[listtab[i] + "_update"];
                                if (!string.IsNullOrEmpty(sql))
                                {
                                    sql = string.Format(" UPDATE {0} SET {1}  WHERE MAIN_ID = '{2}'", listtab[i], sql, str);
                                }
                            }
                            else
                            {
                                sql = dic[listtab[i] + "_insert"];
                                if (!string.IsNullOrEmpty(sql))
                                {
                                    sql = sql.Replace("[[∑##∑]]", str);
                                }
                            }
                            list.Add(sql);
                        }
                        if (odb.SetExecuteTranSql(list))
                        {
                            falg = PCServerDoProcess(odb, str);
                        }
                       
                    }
                }

                #endregion


            }
        }
        catch (Exception ex)
        {
            Loger.Error("PC端销单PCServerClick==>" + ex);
        }
        if (falg)
        {
            Response.Write("true");
        }
        else
        {
            Response.Write("false");
        }

    }
   #endregion

    #region 销单需要审核的处理流程
    public bool PCServerDoProcess(OracleDataBase odb, string gugid)
    {
        bool falg = false;
        OracleCommand UpdateCommand = new OracleCommand();
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        try
        {
            string cuser = uid;
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
           string   sql = " update tz_main set  pdaid=''   where id='" + gugid + "'";
            odb.InsertOrUpdate(sql);
            #region 工单回收,凡是销单的,一律从手机上进行工单删除 2015年2月2日14:12:38 add
            string sql1 = string.Format(" insert into huishou_his (pdaid, main_id, tdyy) (select pdaid, main_id, '手机端无法正常销单，平台段来销单' from tz_paidanhis where main_id = '{0}')", gugid);
            odb.InsertOrUpdate(sql1);
            #endregion
            Loger.Error("平台段销单执附加回收sql==>" + sql1);
            #region 数据处理业务
            myConnection.Open();
            UpdateCommand.Connection = myConnection;
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            bool flag = false;
            bool ISZS = ConfigurationManager.AppSettings["ISZS"] == null ? true :Convert.ToBoolean(ConfigurationManager.AppSettings["ISZS"]);
            if (ISZS)
            {
                flag = Global.SHCL(gugid, "1", "2", uid, UpdateCommand);
            }
            myTran.Commit();
            myConnection.Close();
            if (flag)
            {
                string Z_Yet_Close = ConfigurationManager.AppSettings["Z_Yet_Close"].ToString();
                Global.DoProcess(gugid, Z_Yet_Close, cuser);
                List<OracleParameter> list = new List<OracleParameter>();
                OracleParameter paramter = new OracleParameter("V_Id", OracleType.VarChar, 20);
                paramter.Direction = ParameterDirection.Input;
                paramter.Value = MAIN_ID;
                list.Add(paramter);
                odb.ExeProcedure("proc_repeatorderxd", list);
            }
            else
            {
                string Z_Apply_Close = ConfigurationManager.AppSettings["Z_Apply_Close"].ToString();
                Global.DoProcess(gugid, Z_Apply_Close, cuser);
            }
            #endregion
            falg = true;
        }
        catch (Exception ex)
        {
            myTran.Rollback();
            Loger.Error("PCServerDoProcess==>" + ex);
        }
        return falg;
    }
    #endregion

    #region 直接销单后台也增加验证，如果处理类别、处理内容、发生原因、解决措施、等红色必填项未填，则必须填写才能销单。
    /// <summary>
    /// 验证是否为空 2015年1月16日13:28:03 add
    /// 直接销单后台也增加验证，如果处理类别、处理内容、发生原因、解决措施、等红色必填项未填，则必须填写才能销单。
    /// </summary>
    /// <returns></returns>
    private bool ValidateIsEmpty()
    {
        bool result = true;
        if (string.IsNullOrWhiteSpace(Request["ARRIVALTIMEID"]) || string.IsNullOrWhiteSpace(Request["EXECUTIVETIMEID"]) || string.IsNullOrWhiteSpace(Request["WCSJ"]) || string.IsNullOrWhiteSpace(Request["CLNR"]) || string.IsNullOrWhiteSpace(Request["FSYY"]) || string.IsNullOrWhiteSpace(Request["JJCS"]) || string.IsNullOrWhiteSpace(Request["CLJG"]) || string.IsNullOrWhiteSpace(Request["CLGC"]) || string.IsNullOrWhiteSpace(Request["KJ"]))
            result = false;

        return result;
    }
    #endregion 

    #region  处理时限/截止时间
    protected string GetExeCutive(string id)
    {
        string COMETIME_PLAN = Global.GetComeTime(id).ToString("G");
        string SOLVETIME_PLAN = Global.GetHandingTime(id).ToString("G");
        if (COMETIME_PLAN.StartsWith("0001"))
            COMETIME_PLAN = "";
        if (SOLVETIME_PLAN.StartsWith("0001"))
            SOLVETIME_PLAN = "";
        return string.Format(@" COMETIME_PLAN= to_date('{0}','yyyy-MM-dd HH24:mi:ss'),  
SOLVETIME_PLAN= to_date('{1}','yyyy-MM-dd HH24:mi:ss') ", COMETIME_PLAN, SOLVETIME_PLAN);
    }
    #endregion 

    #region 接口审核
    /// <summary>
    /// 接口审核
    /// </summary>
    private void JkshClick()
    {
        MAIN_ID = Request["OrderhId"];
        OracleDataBase odb = new OracleDataBase();
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        string sql = "";
        try
        {
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            string Remark = "";
            string sqdx = "";
            string sqdxvalue = "";
            string CHECKER = uid;
            string STATE = Request["isaccept"];//审核状态
            string JKBM = Request["txtclbm"];
            string jksj = Request["txtfksj"];
            string fkyj = Request["txtfkyj"];
            #region 接口审核录入信息存储
            //1、内部子工单   2、拆分工单
            sql = string.Format("select  count(*) from tz_main t where fid='{0}' and isselfsend in ('1','2')  and tokenname<>'结束' ",MAIN_ID);
            int Fcount=Convert.ToInt32(odb.GetScalarInfo(sql));
            if (Fcount >0) {
                Response.Write("1-1");
                return;
            }
            sql= "select count(*) from tz_main_clinfo where main_id='" + MAIN_ID + "'";
            string res = odb.GetScalarInfo(sql);
            if (Convert.ToInt32(res) > 0)
            {
                sql = "update tz_main_clinfo set JKBM='" + JKBM + "',JKFKSJ=to_date('" + jksj + "','yyyy-mm-dd hh24:mi:ss'),JKFKYJ='" + fkyj +
                      "' where main_id='" + MAIN_ID + "'";
            }
            UpdateCommand.CommandText = sql;
            UpdateCommand.ExecuteNonQuery();
            #endregion
            
            #region 1.销单审核历史
            string newguid = Guid.NewGuid().ToString().Replace('-', ' ');//id
            string CUSTOMSERVICEID = Global.getMISSIONBH(MAIN_ID);//工作单流水号
            string CHECKERVIEW = Remark;//审核意见
            string STATUS = "0";//握手状态
            DateTime SENDDATE = DateTime.Now;

            string pSQL = "insert into TZ_XD_SH (id,CUSTOMSERVICEID,STATE,CHECKERVIEW,CHECKER,SENDDATE,STATUS,MAIN_ID) values('" + newguid + "','" + CUSTOMSERVICEID + "','" + STATE + "','" + CHECKERVIEW + "','" + CHECKER + "',to_date('" + SENDDATE + "','yyyy-mm-dd HH24:MI:SS'),'" + STATUS + "','" + MAIN_ID + "')";
            UpdateCommand.CommandText = pSQL;
            UpdateCommand.ExecuteNonQuery();
            #endregion
            
            #region  2.销单处理信息
            if (STATE == "1")
            {
                DateTime WRITEOFFTIME = DateTime.Now;
                string xdSjhiddenstr = Request["xdSjhidden"];
                if (!string.IsNullOrWhiteSpace(xdSjhiddenstr))
                {
                    WRITEOFFTIME = DateTime.Parse(xdSjhiddenstr);
                }
                string sql333 = "select pdaid from tz_main where id='" + MAIN_ID + "'";
                string pdaid = odb.GetScalarInfo(sql333);
                // string EXECUTIVEDEPARTMENT = Session["userDEPNAME"] != null ? Session["userDEPNAME"].ToString() : "管网技术科";
                string depName = Global.GetDepname(uid);
                string EXECUTIVEDEPARTMENT = !string.IsNullOrWhiteSpace(pdaid) ? Global.getPdaDepName(pdaid) : !string.IsNullOrWhiteSpace(depName)?depName : "抢修中心";//处理部门  这里的处理部门
                string EXECUTIVEPEOPLE = Global.getPdaName(pdaid);//处理PDA
                string EXECUTIVELOGON = uid != "" ? uid : "admin";
                string gotime = Global.getSendtime(MAIN_ID, "sendtime", "tz_paidanhis");//出发时间
                string FINISHPEOPLE = EXECUTIVELOGON;//完成操作员
                string update_main = @"update TZ_MAIN_CLINFO set gotime=to_date('" + gotime + "','yyyy-mm-dd HH24:MI:SS'),FINISHPEOPLE='" + FINISHPEOPLE + "',SATISFACTION='满意',EXECUTIVEDEPARTMENT='" + EXECUTIVEDEPARTMENT + "',WRITEOFFTIME=to_date('" + WRITEOFFTIME + "','yyyy-mm-dd HH24:MI:SS'), EXECUTIVEPEOPLE='" + EXECUTIVEPEOPLE + "',EXECUTIVELOGON='" + EXECUTIVELOGON + "'  where main_id='" + MAIN_ID + "'";
                UpdateCommand.CommandText = update_main;
                UpdateCommand.ExecuteNonQuery();
            }
            bool flag = Global.SHCL(MAIN_ID, STATE, "2", uid == "" ? "admin" : uid, UpdateCommand);
            #endregion

            #region 3.执行处理
            if (flag)
            {
                #region  5.流程处理部分
                string updatesql = string.Empty;
                string tokenname;
                string Z_Apply_Close = System.Configuration.ConfigurationManager.AppSettings["Z_Apply_Close"].ToString().Split(',')[0].ToString();
                string Z_Yet_Close = System.Configuration.ConfigurationManager.AppSettings["Z_Yet_Close"].ToString().Split(',')[0].ToString();
                string Z_LOOK_SEND = System.Configuration.ConfigurationManager.AppSettings["Z_LOOK_SEND"].ToString().Split(',')[0].ToString();
                pSQL = string.Format(" select  tokenname,sendtime from tz_tokenlog t where t.main_id='{0}'  order by sendtime  desc", MAIN_ID);
                DataTable dt = odb.GetDataSet(pSQL).Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (Z_Apply_Close.Contains(dt.Rows[i]["tokenname"].ToString()))
                    {
                        if (dt.Rows.Count > i + 1)
                        {
                            Z_LOOK_SEND = "'" + Convert.ToString(dt.Rows[i + 1]["tokenname"]) + "'";
                            break;
                        }
                        break;
                    }
                }
                if (STATE == "1")
                {
                    tokenname = Z_Yet_Close;
                }
                else
                {
                    tokenname = Z_LOOK_SEND;
                }
                #endregion
                #region 驱动节点
                if (Global.DoProcess(MAIN_ID, tokenname, CHECKER, UpdateCommand))
                {

                    //List<OracleParameter> list = new List<OracleParameter>();
                    if (STATE == "1")
                    {
                        UpdateCommand.CommandText = "proc_repeatorderxd";
                        UpdateCommand.CommandType = CommandType.StoredProcedure;
                        //根据存储过程的参数个数及类型生成参数对象
                        OracleParameter p1 = new OracleParameter("V_Id", OracleType.VarChar, 20);
                        //设置参数的输入输出类型,默认为输入
                        p1.Direction = ParameterDirection.Input;
                        //对输入参数定义初值,输出参数不必赋值.
                        p1.Value = MAIN_ID;
                        //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
                        UpdateCommand.Parameters.Add(p1);
                        //执行,把结果集填入datatable中
                        UpdateCommand.ExecuteNonQuery();

                    }
                    myTran.Commit();
                    Response.Write("true");
                }
                else
                {
                    myTran.Rollback();//流程没有执行成功，回滚业务数据
                    Response.Write("false");
                    Loger.Error("接口审核 B_check_CloseOrder==》流程执行失败！");
                }
                #endregion
            }
            else
            {
                myTran.Commit();

                Response.Write("true");
            }
            #endregion
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("接口审核 B_check_CloseOrder==》异常！", ex);
        }
        finally
        {
            myConnection.Close();
        }
    }
    #endregion

    #region 工单审核
    string MAIN_ID = "";
    string checkType = "";
    protected void OrderCheck()
    {
        try
        {
            string insertvalues = Request["hidSqlString"];
            checkType = Request["checkType"];
            MAIN_ID = Request["MAIN_ID"];
            string STATE = string.Empty;//审核状态
            StringBuilder sbfieldname = new StringBuilder();
            StringBuilder sbvalues = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(insertvalues))
            {
                string state = string.Empty;//1、通过，2、不通过
                string[] VALUES = insertvalues.Split('∑');
                #region 数据
                foreach (string value in VALUES)
                {
                    if (string.IsNullOrWhiteSpace(value))
                        continue;
                    string[] ss = value.Split('|');
                    string s_1 = ss[1];
                    string s_f = ss[0];
                    string s_v = Request.Form[ss[0]];
                    string s_q = ss[3];
                    if (Request.Form[ss[0]] == null && !ss[0].Equals("AGREEDTIME")) continue;
                    #region 拼值
                    if (ss[1].Contains("50"))
                    {
                        sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                    }
                    else if (ss[1].Contains("40"))
                    {
                        if (ss[0] != "ID")
                        {
                          if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]) && !string.IsNullOrWhiteSpace(s_q))
                            {
                                if (ss[0].ToUpper() == "RADIOCHECK")
	                                {
                                        STATE = Request.Form[ss[0]];
	                                }
                            }
                            if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]) && !string.IsNullOrWhiteSpace(s_q))
                            {
                                string WORDSCONTENT = Request.Form[ss[0]];
                                sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                            }
                            else
                            {
                                sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                            }
                        }
                    }
                    #endregion
                    #region 拼字段
                    if (ss[1].Contains("51"))
                    {
                        if (ss[0] == "AGREEDTIME")
                        {
                            sbfieldname.AppendFormat(" {0},{1},{2},", ss[0], ss[0] + "BEGIN", ss[0] + "END");
                        }
                        else
                        {
                            sbfieldname.AppendFormat(" {0},", ss[0]);
                        }
                    }
                    else
                    {
                           if (ss[0].ToUpper() == "RADIOCHECK" && checkType == "2")
                            {
                                sbfieldname.AppendFormat("STATES,");
                            }
                           else if(ss[0].ToUpper() == "RADIOCHECK")
                           {
                                sbfieldname.AppendFormat("STATE,");
                           }
                            else
                            {
                                sbfieldname.AppendFormat(" {0},", ss[0]);
                            }
                    }
                    #endregion
                }
                #endregion
                if (!string.IsNullOrWhiteSpace(sbvalues.ToString()) && !string.IsNullOrWhiteSpace(sbfieldname.ToString()))
                {
                    string values = sbvalues.ToString().TrimEnd(',') ;
                    string fields = sbfieldname.ToString().TrimEnd(',');
                    if (checkType == "1")
                    {
                        XD_SH(values, fields, STATE);
                    }
                    else if (checkType == "2")
                    {
                        YQ_SH(values, fields, STATE);
                    }
                    else if (checkType == "3")
                    {
                        TD_SH(values, fields, STATE);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("btn_OK_Click===>ex:" + ex);
        }

    }
    /// <summary>
    /// 销单审核
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void XD_SH(string values, string fieldname, string STATE)
    {
        OracleDataBase odb = new OracleDataBase();
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        try
        {
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            string Remark = "";
            string sqdx = "";
            string sqdxvalue = "";
            string CHECKER = uid;
            #region 0.0 获取数据
            //foreach (var item in _dic)
            //{
            //    if (Convert.ToString(item.Value.Split('|')[0]) == "3")
            //    {
            //        if (item.Value.Split('|')[1] == "01201" || item.Value.Split('|')[1] == "通过")
            //        {
            //            STATE = "1";
            //        }
            //        else
            //        {
            //            STATE = "2";
            //        }
            //    }
            //    else if (item.Key.ToUpper() == "SQDX")
            //    {
            //        sqdx = item.Value.Split('|')[1];
            //        sqdxvalue = Request["SQDX_tree"];
            //    }
            //    else
            //    {
            //        Remark += item.Value.Split('|')[1];
            //    }
            //}
            #endregion

            #region 1.销单审核历史
            string newguid = Guid.NewGuid().ToString().Replace('-', ' ');//id
            string CUSTOMSERVICEID = Global.getMISSIONBH(MAIN_ID);//工作单流水号
            string CHECKERVIEW = Remark;//审核意见
            string STATUS = "0";//握手状态
            DateTime SENDDATE = DateTime.Now;
           
            string pSQL = "insert into TZ_XD_SH (id,CUSTOMSERVICEID,CHECKER,SENDDATE,STATUS,MAIN_ID,{0}) values('" + newguid + "','" + CUSTOMSERVICEID + "','" + CHECKER + "',to_date('" + SENDDATE + "','yyyy-mm-dd HH24:MI:SS'),'" + STATUS + "','" + MAIN_ID + "',{1})";
             pSQL = string.Format(pSQL, fieldname, values);
            UpdateCommand.CommandText = pSQL;
            UpdateCommand.ExecuteNonQuery();
            #endregion

            #region 存储诉求定性数据

            if (!string.IsNullOrWhiteSpace(sqdx))
            {
                string sqdxSql = "update TZ_MAIN_CLINFO set SQDX = '" + sqdx + "'";
                UpdateCommand.CommandText = sqdxSql;
                UpdateCommand.ExecuteNonQuery();
                sqdxSql = "select count(*) count from TZ_TREE where SOURCEID='" + MAIN_ID + "' and  FIELDNAME = 'SQDX'";
                if (Convert.ToInt32(odb.GetScalarInfo(sqdxSql)) > 0)
                {
                    string sqlupdate = "update TZ_TREE set VALUE = '" + sqdxvalue +
                                       "',EDITBY='" + CHECKER + "' where SOURCEID='" + MAIN_ID + "' and  FIELDNAME = 'SQDX'";
                    UpdateCommand.CommandText = sqlupdate;
                    UpdateCommand.ExecuteNonQuery();
                  
                }
                else
                {
                    string sqlupdate = "insert into TZ_TREE (SOURCEID,VALUE,FIELDNAME,CREATEBY,EDITBY) values ('" + MAIN_ID + "','" + sqdxvalue + "','SQDX','" + CHECKER + "','" + CHECKER + "')";
                    UpdateCommand.CommandText = sqlupdate;
                    UpdateCommand.ExecuteNonQuery();
                }
            }
            #endregion

            #region  2.销单处理信息
            if (STATE == "1")
            {
                DateTime WRITEOFFTIME = DateTime.Now;
                string xdSjhiddenstr = Request["xdSjhidden"];
                if (!string.IsNullOrWhiteSpace(xdSjhiddenstr))
                {
                    WRITEOFFTIME = DateTime.Parse(xdSjhiddenstr);
                }
                string sql333 = "select pdaid from tz_main where id='" + MAIN_ID + "'";
                string pdaid = odb.GetScalarInfo(sql333);
                string depname = Global.GetDepname(uid);
                string EXECUTIVEDEPARTMENT = !string.IsNullOrWhiteSpace(pdaid) ? Global.getPdaDepName(pdaid) : !string.IsNullOrWhiteSpace(depname) ? depname : "抢修中心";//处理部门  这里的处理部门
                string EXECUTIVEPEOPLE = Global.getPdaName(pdaid);//处理PDA
                string EXECUTIVELOGON = uid;
                string gotime = Global.getSendtime(MAIN_ID, "sendtime", "tz_paidanhis");//出发时间
                string FINISHPEOPLE = EXECUTIVELOGON;//完成操作员
                string update_main = @"update TZ_MAIN_CLINFO set gotime=to_date('" + gotime + "','yyyy-mm-dd HH24:MI:SS'),FINISHPEOPLE=nvl('" + FINISHPEOPLE + "',EXECUTIVEPEOPLE),SATISFACTION='满意',EXECUTIVEDEPARTMENT=nvl('" + EXECUTIVEDEPARTMENT + "',EXECUTIVEDEPARTMENT),WRITEOFFTIME=to_date('" + WRITEOFFTIME + "','yyyy-mm-dd HH24:MI:SS'), EXECUTIVEPEOPLE=nvl('" + EXECUTIVEPEOPLE + "',EXECUTIVEPEOPLE),EXECUTIVELOGON='" + EXECUTIVELOGON + "'  where main_id='" + MAIN_ID + "'";
                UpdateCommand.CommandText = update_main;
                UpdateCommand.ExecuteNonQuery();
            }
            bool flag = Global.SHCL(MAIN_ID, STATE, "2", uid, UpdateCommand);
            #endregion

            #region 节点名
            string updatesql = string.Empty;
            string tokenname;
            string Z_Apply_Close = System.Configuration.ConfigurationManager.AppSettings["Z_Apply_Close"].ToString().Split(',')[0].ToString();
            string Z_Yet_Close = System.Configuration.ConfigurationManager.AppSettings["Z_Yet_Close"].ToString().Split(',')[0].ToString();
            string Z_LOOK_SEND = System.Configuration.ConfigurationManager.AppSettings["Z_LOOK_SEND"].ToString().Split(',')[0].ToString();
            pSQL = string.Format(" select  tokenname,sendtime from tz_tokenlog t where t.main_id='{0}'  order by sendtime  desc", MAIN_ID);
            DataTable dt = odb.GetDataSet(pSQL).Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Z_Apply_Close.Contains(dt.Rows[i]["tokenname"].ToString()))
                {
                    if (dt.Rows.Count > i + 1)
                    {
                        Z_LOOK_SEND = "'" + Convert.ToString(dt.Rows[i + 1]["tokenname"]) + "'";
                        break;
                    }
                    break;
                }
            }
            #endregion

            #region 3.执行处理
            if (flag)
            {
                #region  5.流程处理部分
                if (STATE == "1")
                {
                    tokenname = Z_Yet_Close;
                }
                else
                {
                    tokenname = Z_LOOK_SEND;
                }
                #endregion
                #region 驱动节点
                if (Global.DoProcess(MAIN_ID, tokenname, CHECKER, UpdateCommand))
                {
                    if (STATE == "1")
                    {
                        UpdateCommand.CommandText = "proc_repeatorderxd";
                        UpdateCommand.CommandType = CommandType.StoredProcedure;
                        //根据存储过程的参数个数及类型生成参数对象
                        OracleParameter p1 = new OracleParameter("V_Id", OracleType.VarChar, 20);
                        //设置参数的输入输出类型,默认为输入
                        p1.Direction = ParameterDirection.Input;
                        //对输入参数定义初值,输出参数不必赋值.
                        p1.Value = MAIN_ID;
                        //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
                        UpdateCommand.Parameters.Add(p1);
                        //执行,把结果集填入datatable中
                        UpdateCommand.ExecuteNonQuery();
                    }
                    myTran.Commit();
                    Response.Write("true");
                }
                else
                {
                    myTran.Rollback();//流程没有执行成功，回滚业务数据
                    Response.Write("false");
                    Loger.Error("办事处销单 B_check_CloseOrder==》流程执行失败！");
                }
                #endregion
            }
            else
            {
                bool ISXDNT= Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["ISXDNT"]);
                #region 直接回到原来位置
                if (STATE == "2" && ISXDNT)
                {
                    UpdateCommand.CommandText = "PROC_ISXDNT";
                    UpdateCommand.CommandType = CommandType.StoredProcedure;
                    //根据存储过程的参数个数及类型生成参数对象
                    OracleParameter p1 = new OracleParameter("v_id", OracleType.VarChar, 50);
                    OracleParameter p2 = new OracleParameter("v_tokenname", OracleType.VarChar, 50);
                    //设置参数的输入输出类型,默认为输入
                    p1.Direction = ParameterDirection.Input;
                    //对输入参数定义初值,输出参数不必赋值.
                    p1.Value = MAIN_ID;
                    p2.Direction = ParameterDirection.Input;
                    p2.Value = Z_LOOK_SEND.Trim('\'');
                    //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
                    UpdateCommand.Parameters.Add(p1);
                    UpdateCommand.Parameters.Add(p2);
                    //执行,把结果集填入datatable中
                    UpdateCommand.ExecuteNonQuery();
                }
                myTran.Commit();
                Response.Write("true");
            }
            #endregion
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("办事处销单 B_check_CloseOrder==》异常！", ex);
        }
        finally
        {
            myConnection.Close();
        }

     #endregion
    }

    /// <summary>
    /// 退单审核
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void TD_SH(string values, string fieldname, string STATE)
    {
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;

        string tmpSql = string.Format("select ACCEPTSTATION,REPORTCONTENT,REPORTTYPE from tz_main where ID='{0}'", MAIN_ID);
        OracleDataBase odb = new OracleDataBase("0");
        try
        {
            Hashtable mainHt = odb.getDBHT(tmpSql);

            string Remark = "";
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            #region 1. 退单审核历史
            string CHECKER = uid;//审核人
            string CHECKERVIEW = Remark;//审核意见
            DateTime CHECKTIME = DateTime.Now;
            string newguid = Guid.NewGuid().ToString().Replace('-', ' ');//id
            string TZ_TUIDA_ID = "";
            string sqlyanqiid = "select id from(select * from tz_tuidanhis t where main_id='" + MAIN_ID + "'  order by t.sendtime desc) where rownum=1";
            UpdateCommand.CommandText = sqlyanqiid;
            TZ_TUIDA_ID = Convert.ToString(UpdateCommand.ExecuteScalar());

            string CUSTOMSERVICEID = Global.getMISSIONBH(MAIN_ID);//工作单流水号
            string STATUS = "0";//握手状态
            string pSQL = "insert into TZ_TD_SH (id,CUSTOMSERVICEID,CHECKER,CHECKTIME,STATUS,MAIN_ID,TZ_TUIDA_ID,{0}) values('" + newguid + "','" + CUSTOMSERVICEID + "','" + CHECKER + "',to_date('" + CHECKTIME + "','yyyy-mm-dd HH24:MI:SS'),'" + STATUS + "','" + MAIN_ID + "','" + TZ_TUIDA_ID + "',{1})";
            pSQL = string.Format(pSQL, fieldname, values);
            UpdateCommand.CommandText = pSQL;
            UpdateCommand.ExecuteNonQuery();
            #endregion
            #region 2. 退单审核处理
            bool flag = Global.SHCL(MAIN_ID, STATE, "1", uid, UpdateCommand);
            #endregion
            #region 3.流程处理部分
            if (flag)
            {
                string tokenname = "";
                //by 20160320 @juno 
                if (System.Configuration.ConfigurationManager.AppSettings["Z_Not_Send"].ToString() != "")
                {
                    string Z_Not_Send = System.Configuration.ConfigurationManager.AppSettings["Z_Not_Send"].ToString().Split(',')[0].ToString();
                    string Z_LOOK_SEND = System.Configuration.ConfigurationManager.AppSettings["Z_LOOK_SEND"].ToString().Split(',')[0].ToString();
                    if (STATE == "1")
                    {
                        //通过返回》办事处终端接单
                        //tokenname = "update tz_main set tokenName=" + Z_Not_Send + " where id='" + MAIN_ID + "'";
                        tokenname = Z_Not_Send;
                    }
                    else
                    {   //不通过返回》现场维修人员浏览工单
                        //updatesql = "update tz_main set tokenName=" + Z_LOOK_SEND + " where id='" + MAIN_ID + "'";
                        tokenname = Z_LOOK_SEND;
                    }
                    if (Global.DoProcess(MAIN_ID, tokenname, CHECKER, UpdateCommand))
                    {
                        myTran.Commit();
                        Response.Write("true");
                        string status = Global.getStatus(MAIN_ID);
                        if (status != "4")//对pda而言4为申请退单，但是对办事处终端而言，本次退单已经完成了。
                        {
                            Loger.Error(" 办事处退单 B_check_BackOrder==》获取派单页面开始！");
                        }
                    }
                    else
                    {
                        myTran.Commit();
                        Response.Write("true");
                    }
                }
                else
                {
                    myTran.Rollback();
                    Response.Write("false");
                    Loger.Error("办事处退单 B_check_BackOrder==》流程执行失败！");
                }
            }
            else
            {
                myTran.Commit();
                string status = Global.getStatus(MAIN_ID);
                if (status != "4")//对pda而言4为申请退单，但是对办事处终端而言，本次退单已经完成了。
                {
                    Response.Write("true");
                    Loger.Error(" 办事处退单 B_check_BackOrder==》获取派单页面开始！");
                }
                else
                {
                    Response.Write("true");
                }
            }
        }
            #endregion
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("办事处退单 B_check_BackOrder==》异常：", ex);
        }
        finally
        {
            odb.Close();
            myConnection.Close();

        }
    }

    /// <summary>
    /// 延期审核
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void YQ_SH(string values, string fieldname, string STATE)
    {
        OracleDataBase odb = new OracleDataBase();
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        try
        {
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            string STATUS = "0";//握手状态
            //获取延期记录 ID
            string TZ_YANQIHIS_ID = "";
            string sqlyanqiid = "select id from (select * from tz_yanqihis t where main_id='" + MAIN_ID + "'  order by t.sendtime desc) where rownum=1";
            DataSet dsTZ_YANQIHIS_ID = odb.GetDataSet(sqlyanqiid);
            if (dsTZ_YANQIHIS_ID.Tables[0].Rows.Count > 0)
            {
                TZ_YANQIHIS_ID = dsTZ_YANQIHIS_ID.Tables[0].Rows[0]["id"].ToString();
            }
            #region 判断是否通过
            if (STATE == "1")
            {
                //  STATUS = "0";//状态改为0，待握手状态 
                string DELAYRESULT = ""; 
                if (string.IsNullOrWhiteSpace(DELAYRESULT) || DELAYRESULT == "请选择")
                {
                    DELAYRESULT = "完成";
                }
                string update = "select sendtime  from (select sendtime from tz_yanqihis  where main_id='" + MAIN_ID + "' order by sendtime desc ) where rownum=1";
                string sql = "update tz_yanqihis set DELAYRESULT='" + DELAYRESULT + "'  where main_id='" + MAIN_ID + "' and sendtime = (" + update + ")";
                UpdateCommand.CommandText = sql;
                UpdateCommand.ExecuteNonQuery();
                string updatetz_main = "update tz_main set STATUS='7'  where id='" + MAIN_ID + "'";
                UpdateCommand.CommandText = updatetz_main;
                Loger.Error("updatetz_main==>" + updatetz_main);
                UpdateCommand.ExecuteNonQuery();
                string sqlyan = "select FINISHTIMEINPLAN from TZ_YANQIHIS where MAIN_ID='" + MAIN_ID + "' order by SENDTIME desc";
                DataSet ds = odb.GetDataSet(sqlyan);//FINISHTIMEINPLAN
                DateTime FINISHTIMEINPLAN = DateTime.Now;
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    FINISHTIMEINPLAN = DateTime.Parse(ds.Tables[0].Rows[0][0].ToString());
                }
                UpdateCommand.CommandText = "update tz_main set SOLVETIME_PLAN=to_date('" + FINISHTIMEINPLAN + "','yyyy-mm-dd HH24:MI:SS') where id='" + MAIN_ID + "'";
                UpdateCommand.ExecuteNonQuery();
            }
            #endregion
            #region 延期审核历史
            string newguid = Guid.NewGuid().ToString();//id
            string CUSTOMSERVICEID = Global.getMISSIONBH(MAIN_ID);//工作单流水号
            DateTime CHECKTIME = DateTime.Now;//审核时间
            string CHECKER = uid;//审核人
            //STATES = "2";//不通过
            string pSQL = "insert into tz_yq_sh (id,CUSTOMSERVICEID,CHECKER,CHECKTIME,STATUS,MAIN_ID,TZ_YANQIHIS_ID,OCCURREASON,RESOLVENT,{0}) values('" + newguid + "','" + CUSTOMSERVICEID + "','" + CHECKER + "',to_date('" + CHECKTIME + "','yyyy-mm-dd HH24:MI:SS'),'" + STATUS + "','" + MAIN_ID + "','" + TZ_YANQIHIS_ID + "','" + Request["FSYY"] + "','" + Request["JJCS"] + "',{1})";
            pSQL = string.Format(pSQL, fieldname,values);
            UpdateCommand.CommandText = pSQL;
            UpdateCommand.ExecuteNonQuery();

            #endregion
            //所有审核人员审核完后才能进入流程(下一步)
            bool flag = Global.SHCL(MAIN_ID, STATE, "3", uid, UpdateCommand);
            Loger.Error("B_check_TrackOrder" + flag);
            #region 流程处理部分
            if (flag)
            {
                #region 节点名
                string updatesql = string.Empty;
                string tokenname;
                string Z_Apply_Delay = System.Configuration.ConfigurationManager.AppSettings["Z_Apply_Delay"].ToString().Split(',')[0].ToString();
                string Z_LOOK_SEND = System.Configuration.ConfigurationManager.AppSettings["Z_LOOK_SEND"].ToString().Split(',')[0].ToString();
                pSQL = string.Format(" select  tokenname,sendtime from tz_tokenlog t where t.main_id='{0}'  order by sendtime  desc", MAIN_ID);
                DataTable dt = odb.GetDataSet(pSQL).Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (Z_Apply_Delay.Contains(dt.Rows[i]["tokenname"].ToString()))
                    {
                        if (dt.Rows.Count > i + 1)
                        {
                            Z_LOOK_SEND = "'" + Convert.ToString(dt.Rows[i + 1]["tokenname"]) + "'";
                            break;
                        }
                        break;
                    }
                }
                tokenname = Z_LOOK_SEND;
                #endregion
                if (Global.DoProcess(MAIN_ID, tokenname, CHECKER, UpdateCommand))
                {
                    myTran.Commit();
                    Response.Write("true");
                }
                else
                {
                    myTran.Rollback();
                    Response.Write("false");
                    Loger.Error("办事处延期 B_check_TrackOrder==》流程执行失败！");
                }
            }
            else
            {
                myTran.Commit();
                Response.Write("true");
            }
            #endregion
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("办事处延期 B_check_TrackOrder==》异常！", ex);
        }
        finally
        {
            myConnection.Close();
        }
    }
    #endregion

    #region 直接退单
    /// <summary>
    /// 直接退单
    /// </summary>
    protected void Direct_Back_Order()
    {
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        try
        {
            Decrypt decrypt = new Decrypt();
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;
            if (Request["OrderhId"] != null)
            {
                MAIN_ID = Request["OrderhId"];
            }
            string id = Guid.NewGuid().ToString();
            string num = Global.getMISSIONBH(MAIN_ID);
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            #region 2.转站变更历史
            string DESTSTATION = Request["ddlsite"];//目的站点
            string SOURCESTATION = Global.getSourceStation(MAIN_ID);//原站点
            string CHECKTIME = DateTime.Now.ToString("G");//转站时间
            string PRINCIPAL = uid;
            string CANCELREASON = "直接退单";
            string s_tdkj = Request["ddlCALIBRE"];
            if (Request["ddlReason"] == "其它" && !string.IsNullOrWhiteSpace(Request["txtOtherReason"]))
            {
                CANCELREASON = Request["txtOtherReason"];
            }
            else
            {
                CANCELREASON = Request["ddlReason"];
            }
            string pdaid = uid;
            string type = "3";
            string sql_u = @"insert into tz_tuidanhis(id,main_id,num,sendtime,CANCELREASON,SOURCESTATION,DESTSTATION,PRINCIPAL,type,pdaid, S_TDKJ) 
                                    values('" + id + "','" + MAIN_ID + "','" + num + "',sysdate,'" + CANCELREASON + "','" + SOURCESTATION + "','" + DESTSTATION + "','" + PRINCIPAL + "','" + type + "','" + pdaid + "', '" + s_tdkj + "') ";
            UpdateCommand.CommandText = sql_u;
            UpdateCommand.ExecuteNonQuery();
            sql_u = "update stationpaidanhis set  status=0  where main_id='" + MAIN_ID + "'  and  HISSTATION='" + SOURCESTATION + "'";
            UpdateCommand.CommandText = sql_u;
            UpdateCommand.ExecuteNonQuery();

            string u_tz_main = "update tz_main set ACCEPTSTATION='" + DESTSTATION + "'  where id='" + MAIN_ID + "'";
            UpdateCommand.CommandText = u_tz_main;
            UpdateCommand.ExecuteNonQuery();
            #endregion
            myTran.Commit();
            Response.Write("true");
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("派遣到站点 distributeSite==》异常！", ex);
        }
        finally
        {
            myConnection.Close();
        }
    }
    #endregion

    #region  直接延期
    public void Direct_Yanqi_Order() {
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        string uid = String.Empty;
        try
        {
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;

            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;

            #region 1. 延期审核历史
            string id = Guid.NewGuid().ToString();
            MAIN_ID = Request["OrderhId"];
            uid = Request["uid"];
            string num = Global.getCUSTOMSERVICEID(MAIN_ID);
            string delayreason = Request["GZYY"];
            string delayplan = Request["texggbz"];//备注
            string sendtime = DateTime.Now.ToString("G");
            string delayresult = "";//跟踪结果
            string finishtimeinplan = Request["texgzjh"];//计划完成时间
            string padid = string.IsNullOrWhiteSpace(uid) ? "平台端" : uid;
            string sendtotime = DateTime.Now.ToString("G");
            string pSQL = string.Format(@"insert into tz_yanqihis  (id, main_id, num, delayreason, delayplan, sendtime, finishtimeinplan,  pdaid, sendtotime,delayresult) values ('{0}', '{1}', '{2}', '{3}','{4}',to_date('{5}','yyyy-MM-dd HH24:mi:ss'), '{6}','{7}', to_date('{8}','yyyy-MM-dd HH24:mi:ss'),'{9}')", id, MAIN_ID, num, delayreason, delayplan, sendtime, finishtimeinplan, padid, sendtotime, delayresult);
            UpdateCommand.CommandText = pSQL;
            UpdateCommand.ExecuteNonQuery();
            #endregion
              string Z_Apply_Delay=ConfigurationManager.AppSettings["Z_Apply_Delay"];
            #region 1.流程处理部分
            if (Global.DoProcess(MAIN_ID, Z_Apply_Delay, uid))
            {
                myTran.Commit();
                Response.Write("true");
            }
            else
            {
                myTran.Rollback();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "sta32js", "<script>swal('执行失败!');hide();</script>");
                Loger.Error("办事处直接跟踪==》流程执行失败！");
            }
            #endregion
         
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("办事处直接跟踪==》异常：", ex);
        }
        finally
        {
       
            myConnection.Close();
        }
    }
    #endregion

    #region 巡检转现维审核
    /// <summary>
    /// 巡检转现维审核
    /// </summary>
    protected void XJToXWSH()
    {
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        try
        {
            Decrypt decrypt = new Decrypt();
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;
            string remark = Request["REMARK"];
            MAIN_ID = Request["MAIN_ID"];
            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            if (!string.IsNullOrWhiteSpace(MAIN_ID))
            {
                #region
                string pdaid = uid;
                string sql_u = @"insert into tz_xjtoxwhis(main_id,remark,createpeople) 
                                    values('" + MAIN_ID + "','" + remark + "','" + pdaid + "') ";
                UpdateCommand.CommandText = sql_u;
                UpdateCommand.ExecuteNonQuery();


                string u_tz_main = "update tz_main set isxjsh='1'  where id='" + MAIN_ID + "'";
                UpdateCommand.CommandText = u_tz_main;
                UpdateCommand.ExecuteNonQuery();

                #endregion
                myTran.Commit();
                Response.Write("true");
            }
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("派遣到站点 distributeSite==》异常！", ex);
        }
        finally
        {
            myConnection.Close();
        }
    }
    #endregion

    #region 转站
    /// <summary>
    /// 转站
    /// </summary>
    protected void SiteToSite()
    {
        OracleDataBase odb = new OracleDataBase();
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        try
        {
            if (Request["OrderhId"] != null)
            {
                MAIN_ID = Request["OrderhId"];
            }
            else
            {
                Response.Write("false");
                return;
            }
            //查询timestamp标志，防止页面过期或并发
            string timestampsql = "select timestamp from tz_main where id='"+MAIN_ID+"'";
            string timestampnew = odb.GetScalarInfo(timestampsql);
            string timestampold = Request["hdtimestamp"];
            if (timestampnew != timestampold)
            {
                Response.Write("false");
                return;
            }

            string SOURCESTATION = Global.getSourceStation(MAIN_ID);//原站点
            myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
            myConnection.Open();
            OracleCommand UpdateCommand = new OracleCommand();
            UpdateCommand.Connection = myConnection;

            myTran = myConnection.BeginTransaction();
            UpdateCommand.Transaction = myTran;
            #region 2.转站变更历史
            string id = Guid.NewGuid().ToString();
            string num = Global.getMISSIONBH(MAIN_ID);
            string DESTSTATION = Request["ddlsite"];//目的站点
           
            string CHECKTIME = DateTime.Now.ToString("G");//转站时间
            string PRINCIPAL = uid;

            string CANCELREASON = "派遣站点";
            string type = "0";
            string sql_u = @"insert into TZ_ZHUANZHANHIS(id,main_id,num,sendtime,SENDREMARK,ACCEPTSTATION,SENDSTATION,SENDPEOPLE,STATUS) 
                                    values('" + id + "','" + MAIN_ID + "','" + num + "',sysdate,'" + CANCELREASON + "','" + SOURCESTATION + "','" + DESTSTATION + "','" + PRINCIPAL + "','" + type + "') ";
            UpdateCommand.CommandText = sql_u;
            UpdateCommand.ExecuteNonQuery();
            string deppid = odb.GetScalarInfo("select pid from AUTHOR_DEPARTMENT where depname = '" + DESTSTATION + "'");
            if (!string.IsNullOrEmpty(deppid))
            {
                sql_u=string.Format("select max(HISORDER) from  STATIONPAIDANHIS where main_Id='{0}'",MAIN_ID);
                string HISORDER = odb.GetScalarInfo(sql_u);
               HISORDER= string.IsNullOrWhiteSpace(HISORDER) ? "1" : (Int32.Parse(HISORDER) + 1).ToString();
               sql_u = string.Format("select count(*) from  STATIONPAIDANHIS where main_Id='{0}' and HISSTATION='{1}'", MAIN_ID, DESTSTATION);
               int index_falg =Convert.ToInt32(odb.GetScalarInfo(sql_u));
               if (index_falg<=0)
               {
                   sql_u = "insert into STATIONPAIDANHIS (DEPPID, HISORDER, HISSTATION, HISDATE, MAIN_ID) values ('" + deppid + "', '" + HISORDER + "', '" + DESTSTATION + "', sysdate, '" + MAIN_ID + "')";
                   UpdateCommand.CommandText = sql_u;
                   UpdateCommand.ExecuteNonQuery();
               }
            }
            string u_tz_main = "update tz_main set ACCEPTSTATION='" + DESTSTATION + "' ,SHACCEPTSTATION='" + DESTSTATION + "',timestamp=sysdate    where id='" + MAIN_ID + "'";
            UpdateCommand.CommandText = u_tz_main;
            UpdateCommand.ExecuteNonQuery();
            string stationtype = "1";
            SetData(UpdateCommand, MAIN_ID, SOURCESTATION, DESTSTATION, stationtype);
            #endregion
            myTran.Commit();
            Response.Write("true");
        }
        catch (Exception ex)
        {
            if (myTran.Connection != null)
            {
                myTran.Rollback();
            }
            Response.Write("false");
            Loger.Error("派遣到站点 distributeSite==》异常！", ex);
        }
        finally
        {
            myConnection.Close();
        }
    }
    #endregion

    #region 工单催办
    /// <summary>
    /// 工单催办
    /// </summary>
    public void CuiBanOrder() {
        OracleDataBase odb = new OracleDataBase();
        string sql_values = Request["hidSqlString"];
            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();
            string happendAddr = "";//地址
            if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]))
            {
                return;
            }
            if (!string.IsNullOrWhiteSpace(sql_values))
            {
                string gugid = Request.Form["OrderhId"].ToString();
                string cuiban_id = System.Guid.NewGuid().ToString();
                string TableNAME = Request.Form["TableName"].ToString();
                StringBuilder sbfieldname = new StringBuilder();
                StringBuilder sbvalues = new StringBuilder();
                string[] VALUES = sql_values.Split('∑');

                #region 获取值
                foreach (string value in VALUES)
                {
                    if (string.IsNullOrWhiteSpace(value))
                        continue;
                    string[] ss = value.Split('|');
                    string s_1 = ss[1];//字段名
                    string s_f = ss[0];//字段类型
                    string s_v = Request.Form[ss[0]];//字段值
                    string s_q = ss[3];//字段sql
                    #region 拼值
                    if (ss[1].Contains("50"))
                    {
                        sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                    }
                    else if (ss[1].Contains("40"))
                    {
                        if (ss[0] != "ID")
                        {
                            if (ss[0] == "AGREEDTIME")
                            {
                                string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
                                string EndAGREEDTIME = Request.Form[ss[0] + "END"];
                                string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
                                sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
                            }
                            else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]) && !string.IsNullOrWhiteSpace(s_q))
                            {
                                string WORDSCONTENT = Request.Form[ss[0]];
                                sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                            }
                            else
                            {
                                sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                            }
                        }
                    }
                    #endregion
                    #region 取值
                    if (s_f.Equals("HAPPENADDR")) happendAddr = Request[s_f];
                    if (s_1.Contains("51") || s_1.Contains("52"))
                    {
                        sbfieldname.AppendFormat(" {0},{1},{2},", s_f, s_f + "BEGIN", s_f + "END");
                        if (Request.Form[s_f] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}',", s_f, Request.Form[s_f].ToString());
                        }
                        else if (s_f == "AGREEDTIME")
                        {
                            string BegAGREEDTIME = Request.Form[s_f + "BEGIN"];
                            string EndAGREEDTIME = Request.Form[s_f + "END"];
                            string AGREEDTIME = DateTime.Parse(Request.Form[s_f + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_f + "END"]).ToString("HH:ss");
                            sb2.AppendFormat(" {0} = '{1}' ,", s_f, AGREEDTIME);
                        }
                        if (Request.Form[s_f + "BEGIN"] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}' ,", s_f + "BEGIN", Request.Form[s_f + "BEGIN"].ToString());
                        }
                        if (Request.Form[s_f + "END"] != null)
                        {
                            sb2.AppendFormat(" {0} = '{1}' ,", s_f + "END", Request.Form[s_f + "END"].ToString());
                        }
                    }
                    else if (s_1.Contains("50"))
                    {
                        sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_f, Request.Form[s_f].ToString());
                    }
                    else
                    {
                        if (s_f != "ID")
                        {
                            sbfieldname.AppendFormat(" {0},", s_f);
                            if (s_f.ToUpper() == "TOKENNAME")
                            {
                                string temp = p_ZDJD;
                                sb2.AppendFormat(" {0} = {1} ,", s_f, temp);
                            }
                            else if (Request.Form[s_f] != null)
                            {
                                sb2.AppendFormat(" {0} = '{1}' ,", s_f, Request.Form[s_f].ToString());
                            }
                        }
                        else
                        {
                            sbfieldname.AppendFormat(" {0},", s_f);
                        }
                    }
                    #endregion
                }
                #endregion

                string sql = string.Format(" insert into tz_main_cuiban (ID,main_id)values('{0}','{1}')", cuiban_id,gugid);
                odb.InsertOrUpdate(sql);
                sb2.AppendFormat(" REMINDPEOPLE= '{0}',", uid);
                sql = string.Format("UPDATE {0} SET {1}  WHERE id = '{2}'", TableNAME, sb2.ToString().TrimEnd(','), cuiban_id);
                if (odb.InsertOrUpdate(sql) > 0)
                {
                    Response.Write("true");
                }
            }
    }
    #endregion

    #region 执行存储过程，判断特殊逻辑
    /// <summary>
    /// 执行存储过程，判断特殊逻辑
    /// </summary>
    /// <param name="UpdateCommand"></param>
    /// <param name="mainid"></param>
    /// <param name="sourcestation"></param>
    /// <returns></returns>
    public void SetData(OracleCommand UpdateCommand, string mainid, string sourcestation, string sendstation, string type)
    {
        //需要执行跳站的存储过程
        UpdateCommand.CommandText = "PD_STATIONSH";
        UpdateCommand.CommandType = CommandType.StoredProcedure;
        //根据存储过程的参数个数及类型生成参数对象
        OracleParameter p1 = new OracleParameter("V_ACCEPTSTATION", OracleType.VarChar, 400);
        OracleParameter p2 = new OracleParameter("V_SENDSTATION", OracleType.VarChar, 4000);
        OracleParameter p3 = new OracleParameter("V_main_id", OracleType.VarChar, 4000);
        OracleParameter p4 = new OracleParameter("v_type", OracleType.VarChar, 4000);
        //设置参数的输入输出类型,默认为输入
        p1.Direction = ParameterDirection.Input;
        p2.Direction = ParameterDirection.Input;
        p3.Direction = ParameterDirection.Input;
        p4.Direction = ParameterDirection.Input;
        //对输入参数定义初值,输出参数不必赋值.
        p1.Value = sourcestation;
        p2.Value = sendstation;
        p3.Value = mainid;
        p4.Value = type;
        //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
        UpdateCommand.Parameters.Add(p1);
        UpdateCommand.Parameters.Add(p2);
        UpdateCommand.Parameters.Add(p3);
        UpdateCommand.Parameters.Add(p4);
        //执行,把结果集填入datatable中
        UpdateCommand.ExecuteNonQuery();
    }
    #endregion

    #region 工单删除
    public void OrderDelete(){
        try
        {
            string Z_Not_DEL = ConfigurationManager.AppSettings["Z_Not_DEL"].ToString();
            OracleDataBase odb = new OracleDataBase();
            string main_id = Request["OrderhId"];
            string insert_sql = string.Format("insert into orderDelete (cuser,Main_Id,ISDEL) values('{0}','{1}','1')", uid, main_id);
            string update_sql = string.Format("update  tz_main set  tokenname={1}  where id='{0}'", main_id,Z_Not_DEL);
            List<string> _list=new List<string>();
            _list.Add(insert_sql);
            _list.Add(update_sql);
            if (odb.SetExecuteTranSql(_list))
            {
                Response.Write("true");
            }
            else
            {
                Response.Write("false");
            }
        }
        catch (Exception ex)
        {
            Loger.Error("OrderDelete工单删除:" + ex);
            Response.Write("false");
        }
}
    #endregion 

    #region 工单删除恢复
    public void CanleOrderDelete()
    {
        try
        {
            string Z_Not_Send= ConfigurationManager.AppSettings["Z_Not_Send"].ToString();
            OracleDataBase odb = new OracleDataBase();
            string main_id = Request["OrderhId"];
            string sql_q = string.Format("select max(deltime)  as deltime from orderDelete where main_id='{0}' and ISDEL='1'", main_id);
            DateTime del = Convert.ToDateTime(odb.GetScalarobj(sql_q) );
            if (del.AddDays(2).CompareTo(DateTime.Now)>0)
            {
                string insert_sql = string.Format("insert into orderDelete (cuser,Main_Id,ISDEL) values('{0}','{1}','2')", uid, main_id);
                string update_sql = string.Format("update  tz_main set tokenname={1}  where id='{0}'", main_id, Z_Not_Send);
                List<string> _list = new List<string>();
                _list.Add(insert_sql);
                _list.Add(update_sql);
                if (odb.SetExecuteTranSql(_list))
                {
                    Response.Write("true");
                }
                else
                {
                    Response.Write("false");
                }
            }
            else
            {
                Response.Write("false");
            }
           
        }
        catch (Exception ex)
        {
            Loger.Error("OrderDelete工单删除:" + ex);
            Response.Write("false");
        }
    }
    #endregion 

    #region 添加材料
     public void addCailiaoInfo(){
            try 
            {
                string id = Request["OrderhId"];
                if (string.IsNullOrWhiteSpace(id))
                {
                    Response.Write("false");
                    Loger.Info("addCailiaoInfo===>Main_id为空！");
                    return;
                }
                string name=Request["Name"];
                string num=Request["num"];
                string specification=Request["specification"];
                string unit=Request["unit"];
                string sql = string.Format(@"INSERT INTO EQUIPMENT_MATERIAL_USED (ID,NAME,SPECIFICATION,UNIT,QUANTITY,MAINID,STYLE,CREATER) VALUES
                                                        (sys_guid(),'{0}','{1}','{2}','{3}','{4}','1','{5}')", name, specification, unit, num, id,uid);
                OracleDataBase odb = new OracleDataBase();
                if (odb.InsertOrUpdate(sql)>0) {
                    Response.Write("true");
                }
            }
            catch (Exception ex)
            {
                Response.Write("false");
                Loger.Info("addCailiaoInfo===>处理异常:" + ex);
            }
     }
    #endregion

    #region 退单备注（注销的代码）
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    //protected void directOrder_bak()
    //{
    //    try
    //    {
    //        OracleDataBase odb = new OracleDataBase();
    //        string idstr = Request.Form["OrderhId"];
    //        if (!string.IsNullOrWhiteSpace(idstr))
    //        {
    //            string sql_values = Request["hidSqlString"];
    //            StringBuilder sb = new StringBuilder();
    //            StringBuilder sb2 = new StringBuilder();
    //            if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]) || Request["TableName"] == null)
    //            {
    //                return;
    //            }
    //            if (!string.IsNullOrWhiteSpace(sql_values))
    //            {
    //                string TableName = Request["TableName"].ToString();
    //                string gugid = Request.Form["OrderhId"].ToString();
    //                StringBuilder sbfieldname = new StringBuilder();
    //                StringBuilder sbvalues = new StringBuilder();
    //                string[] VALUES = sql_values.Split('∑');
    //                #region 取值
    //                sbfieldname.AppendFormat("MAIN_ID,");
    //                sbvalues.AppendFormat("'{0}',", gugid);
    //                foreach (string value in VALUES)
    //                {
    //                    if (string.IsNullOrWhiteSpace(value))
    //                        continue;
    //                    string[] ss = value.Split('|');
    //                    string s_FieldName = ss[0];//字段名
    //                    string s_FieldType = ss[1];//字段类型
    //                    string s_IsNull = ss[2];//是否为空
    //                    string s_Nullable = ss[3];//是否可空
    //                    //拼值
    //                    if (ss[1].Contains("50"))
    //                    {
    //                        sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
    //                    }
    //                    else if (ss[1].Contains("40"))
    //                    {
    //                        if (ss[0] != "ID")
    //                        {
    //                            if (ss[0] == "AGREEDTIME")
    //                            {
    //                                string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
    //                                string EndAGREEDTIME = Request.Form[ss[0] + "END"];
    //                                string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
    //                                sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
    //                            }
    //                            else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]))
    //                            {
    //                                string WORDSCONTENT = Request.Form[ss[0]];
    //                                sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
    //                            }
    //                            else
    //                            {
    //                                sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
    //                            }
    //                        }
    //                    }

    //                    if (s_FieldType.Contains("51") || s_FieldType.Contains("52"))
    //                    {
    //                        sbfieldname.AppendFormat(" {0},{1},{2},", s_FieldName, s_FieldName + "BEGIN", s_FieldName + "END");
    //                        if (Request.Form[s_FieldName] != null)
    //                        {
    //                            sb2.AppendFormat(" {0} = '{1}',", s_FieldName, Request.Form[s_FieldName].ToString());
    //                        }
    //                        else if (s_FieldName == "AGREEDTIME")
    //                        {
    //                            string BegAGREEDTIME = Request.Form[s_FieldName + "BEGIN"];
    //                            string EndAGREEDTIME = Request.Form[s_FieldName + "END"];
    //                            string AGREEDTIME = DateTime.Parse(Request.Form[s_FieldName + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_FieldName + "END"]).ToString("HH:ss");
    //                            sb2.AppendFormat(" {0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss') ,", s_FieldName, AGREEDTIME);
    //                        }
    //                        if (Request.Form[s_FieldName + "BEGIN"] != null)
    //                        {
    //                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "BEGIN", Request.Form[s_FieldName + "BEGIN"].ToString());
    //                        }
    //                        if (Request.Form[s_FieldName + "END"] != null)
    //                        {
    //                            sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName + "END", Request.Form[s_FieldName + "END"].ToString());
    //                        }
    //                    }
    //                    else if (s_FieldType.Contains("50"))
    //                    {
    //                        sbfieldname.AppendFormat(" {0},", s_FieldName);
    //                        sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_FieldName, Request.Form[s_FieldName].ToString());
    //                    }
    //                    else
    //                    {
    //                        if (s_FieldName != "ID")
    //                        {
    //                            sbfieldname.AppendFormat(" {0},", s_FieldName);
    //                            if (s_FieldName.ToUpper() == "TOKENNAME")
    //                            {
    //                                string temp = p_ZDJD;
    //                                sb2.AppendFormat(" {0} = {1} ,", s_FieldName, temp);
    //                            }
    //                            else if (Request.Form[s_FieldName] != null)
    //                            {
    //                                sb2.AppendFormat(" {0} = '{1}' ,", s_FieldName, Request.Form[s_FieldName].ToString());
    //                            }
    //                        }
    //                        else
    //                        {
    //                            sbfieldname.AppendFormat(" {0},", s_FieldName);
    //                        }
    //                    }
    //                }
    //                #endregion
    //                #region 修改（新增）
    //                string sql = "select count(*) count from " + TableName + " where main_id='" + gugid + "'";
    //                if (Convert.ToInt32(odb.GetScalarInfo(sql)) > 0)
    //                {
    //                    string s_updatesql = sb2.ToString();
    //                    s_updatesql = s_updatesql.Substring(0, s_updatesql.Length - 1);
    //                    s_updatesql = string.Format(" UPDATE {0} SET {1}  WHERE MAIN_ID = '{2}'", TableName, s_updatesql, gugid);
    //                    odb.InsertOrUpdate(s_updatesql);
    //                    //更新为销单完成状态, update by @juno
    //                    odb.InsertOrUpdate(sql);
    //                }
    //                else
    //                {
    //                    sql = string.Format("insert into {0}  ({1}) VALUES ({2})", TableName, sbfieldname.ToString().Substring(0, sbfieldname.ToString().Length - 1), sbvalues.ToString().Substring(0, sbvalues.ToString().Length - 1));
    //                    odb.InsertOrUpdate(sql);
    //                }
    //                #endregion

    //                //更新为销单完成状态, update by @juno
    //                string Z_Yet_Close = ConfigurationManager.AppSettings["Z_Yet_Close"].ToString();
    //                sql = " update tz_main set STATUS='1'  where id='" + idstr + "'";
    //                odb.InsertOrUpdate(sql);
    //                string cuser = Session["uid"] == null ? "admin" : Session["uid"].ToString();
    //                #region 业务处理
    //                if (Global.DoProcess(idstr, Z_Yet_Close, cuser))
    //                {
    //                    #region "4工单回收，凡是销单的，一律从手机上进行工单删除 2015年2月2日14:12:38 add"
    //                    string sql1 = string.Format(" insert into huishou_his (pdaid, main_id, tdyy) (select pdaid, main_id, '手机端无法正常销单，平台段来销单' from tz_paidanhis where main_id = '{0}')", idstr);
    //                    odb.InsertOrUpdate(sql1);
    //                    Loger.Error("平台段销单执附加回收sql==>" + sql1);
    //                    OracleCommand UpdateCommand = new OracleCommand();
    //                    OracleConnection myConnection = null;
    //                    OracleTransaction myTran = null;
    //                    myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
    //                    myConnection.Open();
    //                    UpdateCommand.Connection = myConnection;
    //                    myTran = myConnection.BeginTransaction();
    //                    UpdateCommand.Transaction = myTran;
    //                    bool flag = Global.SHCL(idstr, "1", "2", Session["uid"] == null ? "admin" : Session["uid"].ToString(), UpdateCommand);
    //                    myTran.Commit();
    //                    #endregion
    //                    Response.Write("true");
    //                }
    //                #endregion
    //            }
    //        }
    //        else
    //        {
    //            Response.Write("false");
    //        }
    //    }
    //    catch (Exception)
    //    {
    //        throw;
    //    }
    //}
    #endregion

    #region 获取页面HttpResqusert值
     ///<summary>
     /// 获取HttpRequest值
     /// </summary>
     /// <returns></returns>
     public Dictionary<string, string> getRequsertValue()
     {
         Dictionary<string, string> dic = new Dictionary<string, string>();
         string sql_values = Request["hidSqlString"];
         StringBuilder sb = new StringBuilder();
         StringBuilder sb2 = new StringBuilder();
         string happendAddr = "";//地址
         if (Request.Form["OrderhId"] == null || string.IsNullOrWhiteSpace(Request.Form["OrderhId"]))
         {
             return dic;
         }

         if (!string.IsNullOrWhiteSpace(sql_values))
         {
             string gugid = Request.Form["OrderhId"].ToString();
             string TableNAME = Request.Form["TableName"].ToString();
             StringBuilder sbfieldname = new StringBuilder();
             StringBuilder sbvalues = new StringBuilder();
             string[] VALUES = sql_values.Split('∑');
             #region 取值
             foreach (string value in VALUES)
             {
                 if (string.IsNullOrWhiteSpace(value))
                     continue;
                 string[] ss = value.Split('|');
                 string s_1 = ss[1];//字段名
                 string s_f = ss[0];//字段类型
                 string s_v = Request.Form[ss[0]];//字段值
                 string s_q = ss[3];//字段sql
                 #region 拼值
                 if (ss[1].Contains("50"))
                 {
                     sbvalues.AppendFormat(" to_date('{0}','yyyy-MM-dd HH24:mi:ss'),", Request.Form[ss[0]]);
                 }
                 else if (ss[1].Contains("40"))
                 {
                     if (ss[0] != "ID")
                     {
                         if (ss[0] == "AGREEDTIME")
                         {
                             string BegAGREEDTIME = Request.Form[ss[0] + "BEGIN"];
                             string EndAGREEDTIME = Request.Form[ss[0] + "END"];
                             string AGREEDTIME = Request.Form[ss[0] + "BEGIN"].Substring(0, 10) + Request.Form[ss[0] + "END"].Substring(10, 6);
                             sbvalues.AppendFormat(" '{0}', '{1}', '{2}',", AGREEDTIME, BegAGREEDTIME, EndAGREEDTIME);
                         }
                         else if (!string.IsNullOrWhiteSpace(Request.Form[ss[0]]) && !string.IsNullOrWhiteSpace(s_q))
                         {
                             string WORDSCONTENT = Request.Form[ss[0]];
                             sbvalues.AppendFormat(" '{0}',", WORDSCONTENT);
                         }
                         else
                         {
                             sbvalues.AppendFormat(" '{0}',", Request.Form[ss[0]]);
                         }
                     }
                 }
                 #endregion

                 #region 取值
                 if (s_f.Equals("HAPPENADDR")) happendAddr = Request[s_f];
                 if (s_f.Contains("51") || s_1.Contains("52"))
                 {
                     sbfieldname.AppendFormat(" {0},{1},{2},", s_f, s_f + "BEGIN", s_f + "END");
                     if (Request.Form[s_f] != null)
                     {
                         sb2.AppendFormat(" {0} = '{1}',", s_f, Request.Form[s_f].ToString());
                     }
                     else if (s_f == "AGREEDTIME")
                     {
                         string BegAGREEDTIME = Request.Form[s_f + "BEGIN"];
                         string EndAGREEDTIME = Request.Form[s_f + "END"];
                         string AGREEDTIME = DateTime.Parse(Request.Form[s_f + "BEGIN"]).ToString("yyyy-MM-dd") + " " + DateTime.Parse(Request.Form[s_f + "END"]).ToString("HH:ss");
                         sb2.AppendFormat(" {0} = '{1}' ,", s_f, AGREEDTIME);
                     }
                     if (Request.Form[s_f + "BEGIN"] != null)
                     {
                         sb2.AppendFormat(" {0} = '{1}' ,", s_f + "BEGIN", Request.Form[s_f + "BEGIN"].ToString());
                     }
                     if (Request.Form[s_f + "END"] != null)
                     {
                         sb2.AppendFormat(" {0} = '{1}' ,", s_f + "END", Request.Form[s_f + "END"].ToString());
                     }
                 }
                 else if (s_1.Contains("50"))
                 {
                     sb2.AppendFormat("{0} = to_date('{1}','yyyy-MM-dd HH24:mi:ss'),", s_f, Request.Form[s_f].ToString());
                 }
                 else
                 {
                     if (s_f != "ID")
                     {
                         sbfieldname.AppendFormat(" {0},", s_f);
                         if (s_f.ToUpper() == "TOKENNAME")
                         {
                             string temp = p_ZDJD;
                             sb2.AppendFormat(" {0} = {1} ,", s_f, temp);
                         }
                         else if (Request.Form[s_f] != null)
                         {
                             sb2.AppendFormat(" {0} = '{1}' ,", s_f, Request.Form[s_f].ToString());
                         }
                     }
                     else
                     {
                         sbfieldname.AppendFormat(" {0},", s_f);
                     }
                 }
                 #endregion
             }
             #endregion
             dic.Add("add", sbfieldname.ToString().TrimEnd(','));
             dic.Add("addvalue", sbvalues.ToString().TrimEnd(','));
             dic.Add("update", sb2.ToString().TrimEnd(','));
             return dic;
         }
         else
         {
             return dic;
         }
     } 
     #endregion
}