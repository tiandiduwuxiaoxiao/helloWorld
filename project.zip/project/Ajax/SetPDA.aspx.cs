﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using hugegis.DBUtility;

public partial class Ajax_SetPDA : System.Web.UI.Page
{
    public string DEPTNAME = string.Empty;
    public string PDANAME = string.Empty;
    public string MAIN_ID = string.Empty;

    string driver = string.Empty;
    string Tel = string.Empty;
    string DrverRemark = string.Empty;
    string CarInfo = string.Empty;
    string Cartype = string.Empty;

    string result = "0";//1执行成功，0是执行不成功
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["pdaName"] != null && Request["ID"] != null)
        {
            try
            {
                DEPTNAME = Request["deptName"]??Server.UrlDecode(Request["deptName"]);
                PDANAME = Request["pdaName"];
                MAIN_ID = Request["ID"];
                driver = Request["driver"];
                Tel = Request["Tel"];
                DrverRemark = Request["Remark"];
                CarInfo = Request["CarInfo"];
                Cartype = Request["Cartype"];
                SetPDA();
            }
            catch (System.Exception ex)
            {
                Loger.Error("派遣手机==>SetPDA==>", ex);
            }
        }
        Response.Write(result);
    }

    private void SetPDA()
    {
        OracleConnection myConnection = null;
        OracleTransaction myTran = null;
        double distance = -1d;
        string xstr = "";
        string ystr = "";
        OracleDataBase odb = new OracleDataBase();
        string updatesql = "";
        string PDAID = PDANAME;
        if (string.IsNullOrEmpty(PDAID))
        {
            result = "0";
        }
        try
        {
            string tokenname = Global.GetTokenname(MAIN_ID);
            if (tokenname== "办事处终端接单")
            {
                //PDA编号
                myConnection = Global.getOracleConnection(Decrypt.PropDBConn);
                myConnection.Open();
                OracleCommand UpdateCommand = new OracleCommand();
                UpdateCommand.Connection = myConnection;
                myTran = myConnection.BeginTransaction();
                UpdateCommand.Transaction = myTran;
                //获取工单位置坐标，人员坐标，计算距离
                string PDAXstr = "";
                string PDAYstr = "";
                string PDAUser = "";
                string PDAloctime = "";
                string sql = string.Format("select targetx as  x, targety As y from tz_main t where t.id='{0}'", MAIN_ID);
                DataSet ds = odb.GetDataSet(sql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];
                    xstr = dr["X"].ToString();
                    ystr = dr["Y"].ToString();
                }
                //获取PDA位置，计算距离
                sql = string.Format("select t.RELATIONOBJ,t.x,t.y,t.loctime from author_equipment_view t where t.EQUIPNAME='{0}' order by t.loctime desc", PDAID);
                DataSet PDAds = odb.GetDataSet(sql);
                if (PDAds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = PDAds.Tables[0].Rows[0];
                    PDAXstr = dr["X"].ToString();
                    PDAYstr = dr["Y"].ToString();
                    PDAUser = dr["RELATIONOBJ"].ToString();
                    PDAloctime = dr["loctime"].ToString();
                    if (!string.IsNullOrEmpty(PDAXstr) && !string.IsNullOrEmpty(PDAYstr) && !string.IsNullOrEmpty(xstr) && !string.IsNullOrEmpty(ystr))
                    {
                        distance = Global.GetXYLength(double.Parse(PDAXstr), double.Parse(PDAYstr), double.Parse(xstr), double.Parse(ystr));
                    }
                }
                #region 1.派单历史
                string ID = System.Guid.NewGuid().ToString();
                string SENDPEOPLE = Session["uid"] == null ? "admin" : Session["uid"].ToString();//派遣人
                //DateTime SENDTIME = DateTime.Now;//派遣时间
                DateTime SENDTIME = DateTime.Now;//派遣时间
                string SENDREMARK = "派遣备注";//派遣备注
                string ZT = "1";//派单状态
                updatesql = "insert into TZ_PAIDANHIS(ID,MAIN_ID,SENDPEOPLE,SENDTIME,SENDREMARK,PDAID,ZT,X,y,LOCTIME,LOCLENGTH,PDAUSER,DRIVERNAME,DRIVERTEL,DRIVERREMARK,CARNUMBER,CARTYPE) values('" + ID + "','" + MAIN_ID + "','" + SENDPEOPLE + "',to_date('" + SENDTIME + "','yyyy-mm-dd HH24:MI:SS'),'" + SENDREMARK + "','" + PDAID + "','" + ZT + "','" + PDAXstr + "','" + PDAYstr + "',to_date('" + PDAloctime + "','yyyy-mm-dd HH24:MI:SS'),'" + distance + "','" + PDAUser + "','" + driver + "','" + Tel + "','" + DrverRemark + "','" + CarInfo + "','" + Cartype + "')";
                UpdateCommand.CommandText = updatesql;
                UpdateCommand.ExecuteNonQuery();
                #endregion

                #region 2. 维护tz_main流程状态 （-1 发送中）
                updatesql = "update tz_main set STATUS='-1' ,PDAID='" + PDAID + "'  where id='" + MAIN_ID + "'";
                UpdateCommand.CommandText = updatesql;
                UpdateCommand.ExecuteNonQuery();
                #endregion
                #region 20150401新增：如果抢修中心直接派单到PDA的，改变受理站点为派遣手机的所在管理所名称。
                bool isDoThisAction = Convert.ToBoolean(ConfigurationManager.AppSettings["isDoThisAction"]);
                string oldacceptstation = this.GetAcceptStation(odb, MAIN_ID);
                string stationName = this.getPadDept(odb, PDAID);
                if (isDoThisAction)
                {
                    bool isQxzx = this.isQXZX(odb, MAIN_ID);
                    if (isQxzx)
                    {
                        if (stationName != null && stationName != "")
                        {
                            updatesql = "update tz_main set acceptstation='" + stationName + "'  where id='" + MAIN_ID + "'";
                            UpdateCommand.CommandText = updatesql;
                            UpdateCommand.ExecuteNonQuery();
                            updatesql = "insert into ACCEPTSTATION_HIS(OLDACCEPTSTATION, NEWACCEPTSTATION, UPDATEPERSON, PDAID, MAID_ID, UPDATETIME) values ('" + oldacceptstation + "', '" + stationName + "', '" + SENDPEOPLE + "', '" + PDAID + "', '" + MAIN_ID + "', to_date('" + DateTime.Now + "','yyyy-mm-dd hh24-mi-ss'))";
                            UpdateCommand.CommandText = updatesql;
                            UpdateCommand.ExecuteNonQuery();
                        }
                    }
                }
                #endregion
                #region 3.流程处理
                //by 20160320 @juno 
                if (System.Configuration.ConfigurationManager.AppSettings["Z_Yet_Send"].ToString() != "")
                {
                    string Z_Yet_Send = System.Configuration.ConfigurationManager.AppSettings["Z_Yet_Send"].ToString().Split(',')[0].ToString();
                    updatesql = "update tz_main set tokenName=" + Z_Yet_Send + " where id='" + MAIN_ID + "'";
                    UpdateCommand.CommandText = updatesql;
                    if (UpdateCommand.ExecuteNonQuery() <= 0)
                    {
                        string sql1 = string.Format(@"select * from (
                                     select *  from author_department t start wITh t.id = '{0}' connect by prior id = pid)  
                                     start wITh id = '{1}' connect by prior pid = id", "", "");

                        myTran.Rollback();
                        result = "0";
                        Loger.Error("办事处派遣到维修人员 distributePDA==》流程执行失败！");
                    }
                    else
                    {
                        string stationtype = "2";
                        SetData(UpdateCommand, MAIN_ID, oldacceptstation, stationName, stationtype);
                        myTran.Commit();
                        result = "1";
                    }
                }
                else
                {
                    Loger.Error("办事处派遣到维修人员 distributePDA==》异常！Z_Yet_Send:配置异常");
                    result = "0";
                }
                #endregion
            }
            else
            {
                result = "0"; 
            }
        }
        catch (Exception ex)
        {
            if (myTran != null)
            {
                myTran.Rollback();
            }
            Loger.Error("办事处派遣到维修人员 distributePDA==》异常！updatesql:" + updatesql, ex);
            result = "0";
        }
        finally
        {
            myConnection.Close();
        }
    }

    /// <summary>
    /// 执行存储过程，判断特殊逻辑
    /// </summary>
    /// <param name="UpdateCommand"></param>
    /// <param name="mainid"></param>
    /// <param name="sourcestation"></param>
    /// <returns></returns>
    public void SetData(OracleCommand UpdateCommand, string mainid, string sourcestation, string sendstation, string type)
    {
        //需要执行跳站的存储过程
        UpdateCommand.CommandText = "PD_STATIONSH";
        UpdateCommand.CommandType = CommandType.StoredProcedure;
        //根据存储过程的参数个数及类型生成参数对象
        OracleParameter p1 = new OracleParameter("V_ACCEPTSTATION", OracleType.VarChar, 400);
        OracleParameter p2 = new OracleParameter("V_SENDSTATION", OracleType.VarChar, 4000);
        OracleParameter p3 = new OracleParameter("V_main_id", OracleType.VarChar, 4000);
        OracleParameter p4 = new OracleParameter("v_type", OracleType.VarChar, 4000);
        //设置参数的输入输出类型,默认为输入
        p1.Direction = ParameterDirection.Input;
        p2.Direction = ParameterDirection.Input;
        p3.Direction = ParameterDirection.Input;
        p4.Direction = ParameterDirection.Input;
        //对输入参数定义初值,输出参数不必赋值.
        p1.Value = sourcestation;
        p2.Value = sendstation;
        p3.Value = mainid;
        p4.Value = type;
        //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
        UpdateCommand.Parameters.Add(p1);
        UpdateCommand.Parameters.Add(p2);
        UpdateCommand.Parameters.Add(p3);
        UpdateCommand.Parameters.Add(p4);
        //执行,把结果集填入datatable中
        UpdateCommand.ExecuteNonQuery();
    }

    /// <summary>
    /// 20150401新增：如果抢修中心直接派单到PDA的，改变受理站点为派遣手机的所在管理所名称。此方法为判断是否为抢修中心
    /// </summary>
    /// <param name="MAIN_ID"></param>
    private bool isQXZX(OracleDataBase odb, string MAIN_ID)
    {
        string sql = "select acceptstation from tz_main where id='" + MAIN_ID + "'";
        DataSet ds = odb.GetDataSet(sql);
        bool isqxzx = false;
        if (ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            string stationname = Convert.ToString(dr["acceptstation"]);
            if (stationname == ConfigurationManager.AppSettings["qxzxName"])
            {
                isqxzx = true;
            }
        }
        return isqxzx;
    }

    /// <summary>
    /// 20150401新增：如果抢修中心直接派单到PDA的，改变受理站点为派遣手机的所在管理所名称。此方法为取得所在管理所名称。
    /// </summary>
    /// <param name="MAIN_ID"></param>
    private string getStationName(OracleDataBase odb, string pdaid)
    {
        string sql = "select equipname,depname,p_depname2,p_depname3,p_depname4 from author_equipment eq inner join " +
"(select t1.id,t1.depname,t2.depname as p_depname2,t3.depname as p_depname3,t4.depname as p_depname4 from author_department t1 " +
"left join author_department t2 on t1.pid=t2.id " +
"left join author_department t3 on t2.pid=t3.id " +
"left join author_department t4 on t3.pid=t4.id) t_dep " +
"on eq.depid=t_dep.id where equipname='" + pdaid + "'";
        DataSet ds = odb.GetDataSet(sql);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            string depname = Convert.ToString(dr["depname"]);
            string p_depname2 = Convert.ToString(dr["p_depname2"]);
            string p_depname3 = Convert.ToString(dr["p_depname3"]);
            string p_depname4 = Convert.ToString(dr["p_depname4"]);
            if (depname.IndexOf(ConfigurationManager.AppSettings["stationNameContain"]) != -1 && depname.Length > 5)
            {
                return depname;
            }
            if (p_depname2.IndexOf(ConfigurationManager.AppSettings["stationNameContain"]) != -1 && p_depname2.Length > 5)
            {
                return p_depname2;
            }
            if (p_depname3.IndexOf(ConfigurationManager.AppSettings["stationNameContain"]) != -1 && p_depname3.Length > 5)
            {
                return p_depname3;
            }
            if (p_depname4.IndexOf(ConfigurationManager.AppSettings["stationNameContain"]) != -1 && p_depname4.Length > 5)
            {
                return p_depname4;
            }
        }
        return "";
    }

    /// <summary>
    /// 获取受理站点
    /// </summary>
    /// <param name="odb"></param>
    /// <param name="mainid"></param>
    /// <returns></returns>
    private string GetAcceptStation(OracleDataBase odb, string mainid)
    {
        string sql = "select acceptstation from tz_main t where t.id='" + mainid + "'";
        DataSet ds = odb.GetDataSet(sql);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            return dr["acceptstation"].ToString();
        }
        return "";
    }

    private string getPadDept(OracleDataBase odb, string pdaid)
    {
        string sql = "select d.depname from author_equipment t,author_department d where t.depid=d.id and t.equipname='" + pdaid + "'";
        DataSet ds = odb.GetDataSet(sql);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            return dr["depname"].ToString();
        }
        return "";
    }

    private string GetLocationXy(string x, string y, string userName)
    {
        string result = "{\"label\":\"" + userName + "\",\"x\":" + x + ",\"y\":" + y + "}";
        return result;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="loctime"></param>
    /// <returns></returns>
    public string getLoctime(string loctime)
    {
        if (loctime != "")
        {
            //时限
            int sbsx = Convert.ToInt32(ConfigurationManager.AppSettings["Loctime"]);
            DateTime dt = DateTime.Parse(loctime);//Convert.ToDateTime(loctime); 
            DateTime dat1 = DateTime.Now;
            TimeSpan sydt = dt - dat1;
            int temp = Convert.ToInt32(sydt.TotalHours);
            if ((temp + sbsx) >= 0)
            {
                return "<font color='red'>在线</font>";
            }
            else
            {
                return "离线";
            }
        }
        return "离线";
    }


}