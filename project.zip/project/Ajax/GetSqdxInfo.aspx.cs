﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ajax_GetSqdxInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string sql = string.Empty;
        try
        {
            string MAIN_ID = Convert.ToString(Request["MAIN_ID"]);
            if (!string.IsNullOrWhiteSpace(MAIN_ID))
            {
                OracleDataBase odb = new OracleDataBase();
                sql = string.Format("SELECT SQDX FROM v_tz_main WHERE ID='{0}'", MAIN_ID);
                string Sqdx = odb.GetScalarInfo(sql);
                Response.Write(Sqdx);
            }
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GetSqdxInfo===>SQL:" + sql + "====>ex:" + ex);
        }
    }
}