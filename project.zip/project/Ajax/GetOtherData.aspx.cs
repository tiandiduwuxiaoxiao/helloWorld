﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using Maticsoft.DBUtility;
using System.Configuration;

public partial class Ajax_GetOtherData : System.Web.UI.Page
{
    public string uid = "";
    public string filepath = ConfigurationManager.AppSettings["filepath"].ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];
        if (Request["flag"] == "QueryImageList") QueryImageList();//照片展示
        else if (Request["flag"] == "CommonTableList") CommonTableList();//通用表格查询
        else if (Request["flag"] == "doExport") doExport();//导出Excel
    }
    /// <summary>
    /// 展示照片
    /// </summary>
    public void QueryImageList()
    {
        string orderId = Request["orderId"];
        ArrayList al = Global.getPicDetailById(orderId);
        //DataSet ds = DbHelperOra.Query(sql);
        List<ImageOption> list = new List<ImageOption>();
        string Filepath = ConfigurationManager.AppSettings["filepath"]; //本地图片访问路径
        string FilepathXj = ConfigurationManager.AppSettings["filepathXJ"];//巡检地址
        if (al.Count > 0)
        {
            for (int i = 0; i < al.Count; i++)
            {
                string OUTPUTPATHstr = Filepath;
                if (((string[])al[i])[5] == "2")
                {
                    OUTPUTPATHstr = FilepathXj;
                }
                string imgUrl = OUTPUTPATHstr + "/" + ((string[])al[i])[0];
                string name = string.IsNullOrWhiteSpace(((string[])al[i])[2]) ? ((string[])al[i])[6] : ((string[])al[i])[2];
                ImageOption option = new ImageOption();
                option.title = name + "--" + Convert.ToString(((string[])al[i])[3]);
                option.href = imgUrl;
                list.Add(option);
            }
        }
   
        string listStr = Json.JsonSerializerBySingleData(list);
   //     string jsonString = "{\"title\": \"照片信息展示\",\"id\": 0,\"start\": 0,\"data\":" + listStr + "}";
        string jsonString = listStr;
        Response.Write(jsonString);
        Response.End();
    }
    /// <summary>
    /// 通用表格查询
    /// </summary>
    public void CommonTableList()
    {
        string _html =CommontableString();
        Response.Write(_html);
        Response.End();
    }
    /// <summary>
    /// 导出Excel
    /// </summary>
    public void doExport() {
        string _html =CommontableString();
        string tile_text=Request["Title_text"];
        ExcelExport.CommExportExcel(_html, tile_text);
    }
   /// <summary>
   /// 
   /// </summary>
   /// <returns></returns>
    private string CommontableString()
    {
        string sql = string.Empty;
        try
        {
            string tableName = Request["tableName"];//需要在s_tabinfo、s_dict维护字典
            string sqlFilter = Request["sqlFilter"];//可扩展-Sql查询条件
            //表头数据
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = (ArrayList)searchHashtable[tableName.Trim().ToUpper()];
            //表格数据
            sql = "select *  from " + tableName + " where 1=1 ";
            if (!string.IsNullOrEmpty(sqlFilter)) sql += sqlFilter;
            DataSet ds = DbHelperOra.Query(sql);
            string _html = "";
            _html += "<div class=\"row\">";
            _html += "<div class=\"col-md-12\">";
            if (seaList != null && ds != null && ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    _html += "<table class=\"table table-striped table-bordered table-hover\" Id=\"commonTable\">";
                    _html += "<thead>";
                    _html += "<tr>";
                    for (int i = 0; i < seaList.Count; i++)
                    {
                        DictionaryContent dc = (DictionaryContent)seaList[i];
                        if (dc.fieldName == "ID")
                        {
                            _html += "<th style='display:none'><i class=\"fa\"></i> " + dc.fieldAliasName + "</th>";
                        }
                        else
                        {
                            _html += "<th><i class=\"fa\"></i> " + dc.fieldAliasName + "</th>";
                        }
                    }
                    _html += "</tr>";
                    _html += "</thead>";
                    _html += "<tbody>";
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        _html += "<tr onclick=\"OrderDetailCommonTableList('" + dt.Rows[i]["ID"] + "')\">";
                        for (int j = 0; j < seaList.Count; j++)
                        {
                            DictionaryContent dc = (DictionaryContent)seaList[j];
                            if (dt.Columns.Contains(dc.fieldName))
                            {
                                if (dc.fieldName == "ID")
                                {
                                    _html += "<td style='display:none'>" + dt.Rows[i][dc.fieldName] + "</td>";
                                }
                                else
                                {
                                    _html += "<td>" + dt.Rows[i][dc.fieldName] + "</td>";
                                }
                            }
                            else
                            {
                                _html += "<td></td>";
                            }
                        }
                        _html += "</tr>";
                    }
                    _html += "</tbody>";
                    _html += "</table>";
                }
                else
                {
                    _html += "<h4 class=\"modal-title\">查无数据信息</h4>";
                }
            }
            _html += "</div>";
            _html += "</div>";
            return _html;
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GetOtherData===>SQl==>" + sql+ "CommontableString:" + ex);
            return "";
        }
    }
}