﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Maticsoft.DBUtility;
using System.Collections;
using BootStrapControls;
using System.Text;
using System.Configuration;
using System.Net;

public partial class Ajax_PrintExcel : System.Web.UI.Page
{

    public string MAIN_ID = string.Empty;
    public string result = "工单数据有误！";
    public Hashtable HT = new Hashtable();
    public Hashtable HT_Status = new Hashtable();
    public Hashtable HT_FIELDNAME = new Hashtable();//取出S_dict表的FIELDNAME
    public string ReturnType = "0";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["ID"] != null)
        {
            try
            {
                MAIN_ID = Request["ID"];
                //写入html
                GetData();
                SetData();
                int mili = DateTime.Now.Millisecond;
                Random rd = new Random(mili);
                int rdnum = rd.Next(100);
                BtsTabbable bt = new BtsTabbable();
                bt.TabIdName = "tab" + rdnum.ToString();
                string[] icons = { "fa fa-reorder ", "fa fa-mobile-phone", "fa fa-gavel", "fa fa-bolt", "fa fa-file-text", "fa fa-bolt", "fa fa-file-text" };
                string body_primary = "暂无数据";
                int listcnt = 0;
                foreach (string de in sumallList)
                {
                    PZ_TAB tab = HT_Status[de] as PZ_TAB;
                    if (tab == null)
                        continue;
                    body_primary = "";
                    if (BodyTextList != null && BodyTextList.Count > listcnt)
                    {
                        body_primary += BodyTextList[listcnt];
                    }
                    bt.TabContentList.Add(body_primary);
                    listcnt++;
                }
                string Title = " <div class=\"box-title\" style=\"text-align: center;\"><h4><i class=\"fa fa-bars\"></i>工单打印</h4><input type=\"button\" id=\"PrintButton\" class=\"btn btn-primary\" onclick=\"btn_print()\" value=\"打印\"></div>";
                result = Title + bt.GetHtmlText();
                //PublicOperBean.ToExcelByHtml(result, "");
            }
            catch (System.Exception ex)
            {
                Loger.Error("追溯历史==>GetHis==>", ex);
            }
        }
    }



    public int sum = 3;
    public int nor;
    public int sumall;
    public ArrayList sumallList = new ArrayList();
    public int sumallMax;
    public void GetData()
    {
        bool isXX = false;
        //判断是否传入工单编号
        if (!string.IsNullOrEmpty(MAIN_ID))
        {
            string id = MAIN_ID;
            if (Request["MAINID"] != null)
            {
                string orderMainID = Request["MAINID"].ToString();
                HT = Global.getDetailById(orderMainID, "v_tz_main");//根据ID得到详细信息 
            }
            else
            {

                HT = Global.getDetailById(id, "v_tz_main");//根据ID得到详细信息
            }
        }
        string where = " and ISDETAIL='1'";
        string rtID = "6F95974193A14C7F9F6437337EF9DB04";
        //获取角色菜单表RTID
        //string rtID = Request.QueryString["RTID"] == null ? "" : Request.QueryString["RTID"];
        //解决通过任务检索时，获取不到rtID导致看不到工单的详细信息,暂时解决方法
        //rtID = string.IsNullOrEmpty(rtID) ? System.Configuration.ConfigurationManager.AppSettings["SelectRtID"].ToString() : rtID;
        //获取显示组字段
        HT_Status = Global.GetTabs();
        sumallList = new ArrayList(HT_Status.Keys);
        sumallList.Sort();
        sumall = HT_Status != null && HT_Status.Count > 0 ? HT_Status.Count : 0;
        sumallMax = 7;//Convert.ToInt32(HT_Status_two[sumall - 1]) + 1;
        //获取组对应字段
        HT_FIELDNAME = Global.GetFieldNames(where, rtID);
        nor = HT_FIELDNAME != null && HT_FIELDNAME.Count > 0 ? HT_FIELDNAME.Count : 0;

    }

    List<string> BodyTextList = new List<string>();
    public void SetData()
    {
        int column_count = 3;
        foreach (string de in sumallList)
        {
            PZ_TAB tab = HT_Status[de] as PZ_TAB;
            if (tab == null)
                continue;
            int h = Convert.ToInt32(tab.FIELDGROUP);
            string type = tab.TABTYPE;

            //字段显示开始
            StringBuilder bodyText = new StringBuilder();
            if (type == "1")
            {
                bodyText.Append("<table id=\"table1\" cellspacing=\"0\" cellpadding=\"3\" style=\"margin-top: 0px;padding-top: 0px; width: 100%;border-left: 1px black solid;border-top: 1px black solid;\" class=\"my-table table\">\n");
                bodyText.Append("<tr><td colspan='6' style=\"background-color: #A8C9DD;text-align:center;border-bottom: 1px black solid;border-right: 1px black solid;\"><b>" + tab.TCNNAME + "</b></td></tr>");
                int valuesum = h;
                int j = 0;
                int prelength = 0;
                //循环取出字段的数据
                for (int i = 1; i <= nor; i++)
                {
                    S_DICT dict = HT_FIELDNAME[i] as S_DICT;
                    if (dict == null)
                        continue;
                    //判断是否是这个top下的字段
                    if (dict.TID == tab.TID)
                    {
                        int Length = string.IsNullOrEmpty(dict.LENGTH) ? 0 : Convert.ToInt32(dict.LENGTH);
                        string temp_value = "";
                        string fontcolor = "black";
                        temp_value = Convert.ToString(HT[dict.FIELDNAME]);
                        
                        if (j % column_count == 0 && Length < 500)
                        {
                            bodyText.Append("<tr>");
                        }
                        if (Length >= 500)
                        {
                            if (j % 3 == 2 && prelength == 0)
                            {
                                bodyText.Append("<td style=\"background-color: #A8C9DD;border-bottom: 1px black solid;border-right: 1px black solid;\">&nbsp;</td><td style=\"border-bottom: 1px black solid;border-right: 1px black solid;\">&nbsp;</td>");
                            }
                            if (j % 3 == 1 && prelength == 0)
                            {
                                bodyText.Append("<td style=\"background-color: #A8C9DD;border-bottom: 1px black solid;border-right: 1px black solid;\">&nbsp;</td><td style=\"border-bottom: 1px black solid;border-right: 1px black solid;\">&nbsp;</td><td style=\"background-color: #A8C9DD;border-bottom: 1px black solid;border-right: 1px black solid;\">&nbsp;</td><td style=\"border-bottom: 1px black solid;border-right: 1px black solid;\">&nbsp;</td>");
                            }
                            bodyText.Append("</tr><tr>");
                            bodyText.Append("<td  class=\"td_text table-border\" style=\"background-color: #A8C9DD;color:black;width:190px;border-bottom: 1px black solid;border-right: 1px black solid;\">" + dict.FIELDDISNAME + "</td>\n");
                            bodyText.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + ";border-bottom: 1px black solid;border-right: 1px black solid;\">" + temp_value + "&nbsp;</td>\n");
                            prelength = 1;
                            j = j + 3;
                            bodyText.Append("</tr>");
                            //if (j % column_count == (column_count - 1))
                            //{
                            //}
                        }
                        else
                        {
                            prelength = 0;
                            bodyText.Append("<td class=\"td_text table-border\" style=\"background-color: #A8C9DD;color:black;width:190px;border-bottom: 1px black solid;border-right: 1px black solid;\">" + dict.FIELDDISNAME + "</td>\n");
                            bodyText.Append("<td class=\"td_value table-border\" style=\"color:" + fontcolor + ";width:23%;border-bottom: 1px black solid;border-right: 1px black solid;\">" + temp_value + "&nbsp;</td>\n");
                            if (j % column_count == (column_count - 1))
                            {
                                bodyText.Append("</tr>");
                            }
                            j++;
                        }
                    }
                }
                bodyText.Append("</table>\n");
                bodyText.Append("<br/>\n");
            }
            else//列表显示
            {
                
                bodyText.Append("<table id=\"table1\" cellspacing=\"0\" cellpadding=\"3\" style=\"margin-top: 0px;padding-top: 0px; width: 100%;border-left: 1px black solid;border-top: 1px black solid;\" class=\"my-table table\">\n<tr>\n");
                bodyText.Append("<tr><td colspan='6' style=\"background-color: #A8C9DD;text-align:center;border-bottom: 1px black solid;border-right: 1px black solid;\"><b>" + tab.TCNNAME + "</b></td></tr>");
                int valuesum = h;
                int decide = 0;
                string taborder = string.IsNullOrEmpty(tab.TABORDER) ? "" : " order by " + tab.TABORDER;
                string fields = "";
                //循环取出字段的数据
                for (int i = 1; i <= nor; i++)
                {
                    S_DICT dict = HT_FIELDNAME[i] as S_DICT;
                    if (dict == null)
                        continue;
                    //判断是否是这个top下的字段
                    if (dict.TID == tab.TID)
                    {
                        decide = 1;
                        fields += dict.FIELDNAME + ",";
                        if (dict.STYLE.Contains("40"))
                        {
                            bodyText.Append("<td  align=\"center\" style=\"background-color: #A8C9DD;color:black;border-bottom: 1px black solid;border-right: 1px black solid;\">" + dict.FIELDDISNAME + "</td>\n");
                        }
                    }
                }
                bodyText.Append("</tr>\n" + GetTableHTML(tab.TABNAME, tab.TABMAINID, MAIN_ID, taborder, fields, type) + "</table>\n");
                bodyText.Append("<br/>\n");
            }
            BodyTextList.Add(bodyText.ToString());
        }
    }
    public string GetTableHTML(string tablename, string tabmainid, string main_id, string fiedorder, string fields)
    {
        string html = "";
        try
        {
            string fieldname = fields;
            if (fieldname.Length > 0)
                fieldname = fieldname.Substring(0, fieldname.Length - 1);
            if (fieldname.Length > 0)
            {
                string sql = "select " + fieldname + " from " + tablename + " t " + " where " + tabmainid + "='" + main_id + "' " + fiedorder;
                DataSet ds = DbHelperOra.Query(sql);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    string[] fieldList = fieldname.Split(',');
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        html += "<tr>\n";
                        string fontcolor = "Orange";
                        foreach (string fieldstr in fieldList)
                        {
                            html+= string.Format("<td align=\"center\" style=\"color:" + fontcolor + " \">{0}</td>\n", row[fieldstr].ToString());
                        }
                        html += "</tr>\n";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTableHTML==>", ex);
        }
        return html;
    }

    /// <summary>
    /// 拼接列表时判断是否需要操作列
    /// </summary>
    /// <param name="tablename"></param>
    /// <param name="tabmainid"></param>
    /// <param name="main_id"></param>
    /// <param name="fiedorder"></param>
    /// <param name="fields"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    public string GetTableHTML(string tablename, string tabmainid, string main_id, string fiedorder, string fields, string type)
    {
        string html = "";
        try
        {
            string fieldname = fields;
            if (fieldname.Length > 0)
                fieldname = fieldname.Substring(0, fieldname.Length - 1);
            string[] length = fieldname.Split(',');
            int width = 100 / length.Length;
            if (fieldname.Length > 0)
            {
                string sql = "select " + fieldname + " from " + tablename + " t " + " where " + tabmainid + "='" + main_id + "' " + fiedorder;
                DataSet ds = DbHelperOra.Query(sql);
                sql = "select t.tabname,d.fieldname from pz_tab t join s_dict d on t.fieldgroup = d.fieldgroup where d.style like '%40%' and t.tabname='" + tablename.ToUpper() + "'";
                DataSet dsSet = DbHelperOra.Query(sql);
                html = "<tr></tr>";
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    html = "";
                    string[] fieldList = fieldname.Split(',');
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        html += "<tr>\n";
                        string fontcolor = "Orange";
                        foreach (string fieldstr in fieldList)
                        {
                            foreach (DataRow drRow in dsSet.Tables[0].Rows)
                            {
                                if (fieldstr.ToUpper() == drRow["fieldname"].ToString().ToUpper())
                                {
                                    html += string.Format("<td align=\"center\" style=\"width:" + width + "%;border-bottom: 1px black solid;border-right: 1px black solid;color:" + fontcolor + " \">{0}</td>\n", row[fieldstr].ToString());
                                }
                            }
                        }
                        //此处仅针对附件信息后期可考虑在数据库中配置
                        //if (type == "3")
                        //{
                        //    string path = ConfigurationManager.AppSettings["MediaPath"].Trim() + "/" +
                        //                  row["FILEPATH"].ToString() + "/" + row["FILENAME"].ToString();
                        //    html += string.Format("<td align=\"center\" style=\"width:" + width + "%;color:" + fontcolor + " \"><a href=\"javascript:void(0)\" onclick=\"javascript:window.open('{0}');\">下载</a></td>\n", path);


                        //}
                        html += "</tr>\n";

                    }
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTableHTML==>", ex);
        }
        return html;
    }

      #region web端下载
        /// <summary>
        /// http下载
        /// </summary>
        /// <param name="url">完整http下载</param>
        /// <param name="fileName">下载后的文件名称</param>
        /// <param name="Response"></param>
        /// <returns></returns>
        public static string HttpDownLoad(string url,string fileName, HttpResponse Response)
        {
            try
            {
                WebClient webClient = new WebClient();
                webClient.Credentials = CredentialCache.DefaultCredentials;
                //以数组的形式下载指定文件  
                byte[] byteData = webClient.DownloadData(url);
                string ContentType = "application/octet-stream ";
                Response.Clear();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
                Response.AddHeader("Content-Length", byteData.Length.ToString());
                Response.ContentType = ContentType;
                Response.Filter.Close();
                Response.OutputStream.Write(byteData, 0, byteData.Length);
                HttpContext.Current.ApplicationInstance.CompleteRequest();
                //Response.End();
                return "true";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        #endregion
}