﻿using System;
using System.Text;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;

public partial class Ajax_GetCheckHis : System.Web.UI.Page
{
    ProcessInfo processinfo = new ProcessInfo();
    string result = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] title = { "审核人", "审核状态", "审核日期", "审核意见" };
        string MAIN_ID = Request["ID"].ToString();
        string checkType = Request["TP"].ToString();
        string sql = string.Empty;
        switch (checkType)
        {
            case "销单审核":
                sql = "select (select nvl(realname,checker ) from author_user where cuser=checker)as checker, decode(state,2,'审核不通过',1,'审核通过') as STATESNAME,checkerview,senddate as CHECKTIME,state from tz_xd_sh where main_id='" + MAIN_ID + "' order by checktime desc";
                break;
            case "延期审核":
                sql = "select (select nvl(realname,checker ),decode(states,2,'审核不通过',1,'审核通过') as STATESNAME,SHYJ,checktime from tz_yq_sh where main_id='" + MAIN_ID + "' order by checktime desc";
                break;
            case "退单审核":
                sql = string.Format("select (select nvl(realname,checker ) from author_user where cuser=checker)as checker, decode(state,2,'审核不通过',1,'审核通过') as STATESNAME,checkerview,checktime,state from tz_td_sh where main_id='{0}' order by checktime desc", MAIN_ID);
                break;
            default:
                break;
        }

        StringBuilder sb = new StringBuilder();


        sb.Append("<thead>");
        sb.Append("<tr>");
        for (int i = 0; i < title.Length; i++)
        {
            sb.Append("<th>");
            sb.Append(title[i]);
            sb.Append("</th>");
        }
        sb.Append("</tr>");
        sb.Append("</thead>");
    
        try
        {
            OracleDataBase odb = new OracleDataBase();
            DataSet ds = odb.GetDataSet(sql);
            if (ds == null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {


                sb.Append("<tbody>");
                for (int j = 0; j < 4; j++)
                {
                    sb.Append("<tr>");
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        sb.Append("<td>");
                        string s = ds.Tables[0].Rows[i][j].ToString();
                        if (s.Length > 8)
                        {
                            sb.Append(s);
                        }
                        else
                        {
                            sb.Append(s.Substring(0,8));
                        }
                        sb.Append("</td>");

                    }
                    sb.Append("</tr>");
                }

                sb.Append("</tbody>");
            }
            else
            {
                sb.Append("<tr><td colspan=\"4\">暂无数据</td></tr>");
            }
        }
        catch (Exception ex)
        {
            Loger.Error("历史审核==>GetCheckHis==>", ex);
        }


        result = sb.ToString();
        Response.Write(result);
    }
}