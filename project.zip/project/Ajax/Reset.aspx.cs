﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Ajax_Reset : System.Web.UI.Page
{
    ProcessInfo processinfo = new ProcessInfo();
    protected void Page_Load(object sender, EventArgs e)
    {
        string result = "0";//1执行不成功，0是执行成功2已销单
        string uid = Request["uid"];
        if (Request.Form["ID"] != null)
        {
            string p_customserviceid = Request.Form["ID"];
            //OracleDataBase odb = new OracleDataBase();
            //string sql1 = "select t.id  from tz_main t where t.customserviceid='" + p_customserviceid + "'";
            //string p_id = odb.GetScalarInfo(sql1);
            //if (!string.IsNullOrEmpty(p_customserviceid))
            //{
                string ID = p_customserviceid;
                result = isReset(ID, uid) ? "1" : "2";
            //}


        }
        Response.Write(result);
    }


    //private bool isReset(string ID)
    //{
    //    string tokeName = Global.GetTokenname(ID);
    //    bool result = false;
    //    if (tokeName != "结束")//没有销单完成并且已派遣
    //    {
    //        try
    //        {
    //            WorkItemInfo workiteminfo = bpmHelp.getWorkItemsAllByOrderID(ID);
    //            processinfo.Prot = int.Parse(System.Configuration.ConfigurationManager.AppSettings["sProt"].ToString());
    //            processinfo.SIP = System.Configuration.ConfigurationManager.AppSettings["sIP"].ToString();
    //            processinfo.SPassword = "";
    //            processinfo.SProcessCode = System.Configuration.ConfigurationManager.AppSettings["sProt"].ToString();
    //            processinfo.SAccount = Session["uid"] != null ? Session["uid"].ToString() : "admin";
    //            processinfo.SProcessId = workiteminfo.SProcessId;
    //            processinfo.SRemark = "重置流程";
    //            processinfo.STransitionId = "";
    //            processinfo.SVersion = "";
    //            processinfo.SWorkItemId = workiteminfo.SWorkItemId;
    //            processinfo.SFormContent = "<MyField></MyField>";


    //            OracleDataBase dao = new OracleDataBase("0");
    //            string status = "-1";
    //            string sql = "update tz_main set status='" + status + "' where id='" + ID + "'";
    //            bpmHelp.Reset(processinfo, ID);
    //            dao.InsertOrUpdate(sql);
    //            //add 2014年12月25日10:10:12 HUISHOU_HIS

    //            string pdaids = "";//手机串号
    //            string pqid = "";//派遣ID
    //            string zt = "";//接收状态
    //            string dt = DateTime.Now.ToString();
    //            //获取手机串号
    //            sql = "select * from TZ_MAIN where id='" + ID + "' order by sendtime desc";

    //            DataSet dspdaid = dao.GetDataSet(sql);
    //            if (dspdaid.Tables[0].Rows.Count > 0)
    //            {
    //                pdaids = dspdaid.Tables[0].Rows[0]["PDAID"].ToString();
    //                string sql1 = "insert into huishou_his ( pdaid, main_id) values ('" + pdaids + "', '" + ID + "')";
    //                dao.InsertOrUpdate(sql1);
    //            }
    //            result = true;
    //        }
    //        catch (Exception ex)
    //        {
    //            Loger.Error("Ajax_Reset.isReset()==>ID==>" + ID, ex);
    //            result = false;
    //        }
    //    }
    //    return result;
    //}

    private bool isReset(string ID, string uid)
    {
        string tokeName = Global.GetTokenname(ID);
        bool result = false;
        // if (tokeName != "结束")//没有销单完成
        //if (!string.IsNullOrEmpty(tokeName))
        {
            try
            {
                
                OracleDataBase dao = new OracleDataBase("0");
                string sql2 = "select PDAID from TZ_MAIN where id='" + ID + "' order by sendtime desc";
                string pdaids = dao.GetScalarInfo(sql2);
                //string sql = "update tz_main set pdaid=null,  status='-1',taskid  ='" + log.TaskId + "' where id='" + ID + "'";
                string Z_Not_Send = ConfigurationManager.AppSettings["Z_Not_Send"].ToString();
                string sql = "update tz_main set pdaid=null,tokenname=" + Z_Not_Send + ",  status='-1' where id='" + ID + "'";
                dao.InsertOrUpdate(sql);
                Loger.Error("Ajax_Reset.isReset()=>+sql" + sql);
               
                string sql1 = "insert into huishou_his ( pdaid, main_id) values ('" + pdaids + "', '" + ID + "')";
                dao.InsertOrUpdate(sql1);
                sql = string.Format("insert into tz_tokenlog(main_id,tokenname,cuser,type) values ('{0}',{1},'{2}','1')", ID, Z_Not_Send, uid);
                dao.InsertOrUpdate(sql);
                Loger.Error("Ajax_Reset.isReset()=>+sql1" + sql1);
                
                #region "1.去退单审核表中更新所有握手状态 2015年2月4日10:26:16 howard add,从服务拷贝"

                string pLSql = "update TZ_TD_SH SET STATUS = 1 where STATUS=0 and  MAIN_ID='" + ID + "'";
                dao.InsertOrUpdate(pLSql);
                Loger.Error("Ajax_Reset.isReset()=>+pLSql" + pLSql);
                //修改派单历史表中数据，给终端派遣
                pLSql = "update TZ_PAIDANHIS SET ZT='0' where MAIN_ID='" + ID + "' and TAKEINTIME is null and status = 1";
                dao.InsertOrUpdate(pLSql);
                Loger.Error("Ajax_Reset.isReset()=>+pLSql2" + pLSql);
                #endregion
                result = true;
            }
            catch (Exception ex)
            {
                Loger.Error("Ajax_Reset.isReset()==>ID==>" + ID, ex);
                result = false;
            }
        }
        return result;
    }
}
