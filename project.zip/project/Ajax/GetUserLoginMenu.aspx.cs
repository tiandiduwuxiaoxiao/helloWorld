using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BootStrapControls;
using System.Configuration;
using System.Data;
using MyAuth.authServices;

public partial class Ajax_GetUserLoginMenu : System.Web.UI.Page
{
    public string result;
    public string userDEPNAME = "";
    public MyAuth.authServices.WSPermissionResult permissionResult = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            //用户账户功能列表
            //Loger.Info();
            string s_user = GetUserLognDropdown().Replace("\r\n", "");
            string s_basis = GetBasisDropdown().Replace("\r\n", "");
            string s_others = GetOthersDropdown().Replace("\r\n", "");
            //sb.AppendLine(json);
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("ul_user_menu", s_user);
            dic.Add("ul_Basis", s_basis);
            dic.Add("ul_others", s_others);
            result = string.Format("\"ul_user_menu\":\"{0}\",\"ul_Basis\":\"{1}\",\"ul_others\":\"{2}\"", s_user, s_basis, s_others);
            result = "{" + result + "}";
            userDEPNAME = Session["userDEPNAME"] == null ? "" : Session["userDEPNAME"].ToString();
        }
        catch (System.Exception ex)
        {
            Loger.Error("获取用户登录功能列表==>GetUserLoginMenu==>", ex);
        }
        Response.Write(result);
    }

    /// <summary>
    /// 获取根据数据库配置的链接
    /// </summary>
    /// <returns></returns>
    public string GetOthersDropdown()
    {
        string sql = String.Empty;
        string uid = Convert.ToString(Session["uid"]);
        string returnStr=String.Empty;
        try
        {
            permissionResult = (MyAuth.authServices.WSPermissionResult)Session["permissionResult"];
            OracleDataBase odb = new OracleDataBase();
            sql = "select * from pz_otherlinks order by orders";
            DataSet ds = odb.GetDataSet(sql);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    string pername = Convert.ToString(ds.Tables[0].Rows[i]["permission"]);
                    if (string.IsNullOrWhiteSpace(pername))
                    {
                        returnStr += String.Format("<li><a href='javascript:OpenOtherPage(|{0}|,|{1}|,|{2}|);'><i class='{3}'></i>{4}</a></li>",string.Format(Convert.ToString(ds.Tables[0].Rows[i]["url"]), uid),
                            Convert.ToString(ds.Tables[0].Rows[i]["type"]),
                            Convert.ToString(ds.Tables[0].Rows[i]["title"]), Convert.ToString(ds.Tables[0].Rows[i]["icon"]), Convert.ToString(ds.Tables[0].Rows[i]["title"]));
                    }
                    else
                    {
                        var per = permissionResult.permissions.Where(it => it.resourceCategoryName == "外链接");
                        IEnumerable<WSPermissionItem> wsPermissionItems = per as IList<WSPermissionItem> ?? per.ToList();
                        if (wsPermissionItems.Any() && wsPermissionItems.Any(it => it.resourceName == pername))
                        {
                            returnStr += String.Format("<li><a href='javascript:OpenOtherPage(|{0}|,|{1}|,|{2}|);'><i class='{3}'></i>{4}</a></li>", string.Format(Convert.ToString(ds.Tables[0].Rows[i]["url"]), uid),
                            Convert.ToString(ds.Tables[0].Rows[i]["type"]),
                            Convert.ToString(ds.Tables[0].Rows[i]["title"]), Convert.ToString(ds.Tables[0].Rows[i]["icon"]), Convert.ToString(ds.Tables[0].Rows[i]["title"]));
                   
                        }
                    }

                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GetUserLoginMenu=>GetOthersDropdown异常,sql=" + sql, ex);
        }

        return returnStr;
    }

    /// <summary>
    /// 用户登录
    /// </summary>
    /// <returns></returns>
    public string GetUserLognDropdown()
    {
        permissionResult = (MyAuth.authServices.WSPermissionResult)Session["permissionResult"];
        string user = permissionResult.user.realName;

        UserDropDown udd = new UserDropDown();
        //登录名
        udd.UserName = user;

        //注释
        //udd.Note = "USER LOGIN DROPDOWN";
        //头像url
        udd.UserImgUrl = "img/avatars/avatar.png";
        udd.menuList = new List<UserDropDownLi>();

        string UserManager = ConfigurationManager.AppSettings["UserManager"].ToString() + "?uid=" + permissionResult.user.loginName;

        UserDropDownLi li1 = new UserDropDownLi();
        li1.HREF = UserManager;
        li1.TARGET = "_blank";
        li1.iconClassName = "fa fa-cog";
        li1.MenuName = " 用户管理";
        udd.menuList.Add(li1);
        if (Global.isHaveAuth(permissionResult, "use", "修改密码"))
        {
            UserDropDownLi li2 = new UserDropDownLi();
            li2.HREF = "javascript:EditPassword();";
            li2.iconClassName = "fa fa-key";
            li2.MenuName = "修改密码";
            udd.menuList.Add(li2);
        }
        UserDropDownLi li5 = new UserDropDownLi();
        li5.HREF = "javascript:Fullscreen();";
        li5.iconClassName = "fa  fa-expand";
        li5.MenuName = " 全屏";
        udd.menuList.Add(li5);

        UserDropDownLi li6 = new UserDropDownLi();
        li6.HREF = "javascript:exitFullscreen();";
        li6.iconClassName = "fa  fa-compress";
        li6.MenuName = " 退出全屏";
        udd.menuList.Add(li6);

        UserDropDownLi li4 = new UserDropDownLi();
        li4.HREF = "login.aspx";
        li4.iconClassName = "fa fa-power-off";
        li4.MenuName = " 退出";
        udd.menuList.Add(li4);
        Loger.Info("GetUserLognDropdown=>end");
        return udd.GetHtmlText();
    }

    public string GetBasisDropdown()
    {
        permissionResult = (MyAuth.authServices.WSPermissionResult)Session["permissionResult"];
        string user = permissionResult.user.realName;

        BasisDropDown udd = new BasisDropDown();
        udd.menuList = new List<BasisDDropDownLi>();

        BasisDDropDownLi li = new BasisDDropDownLi();
        li.HREF = "javascript:backOrderList();";
        li.iconClassName = "fa fa-navicon";
        li.MenuName = " 工单列表";
        udd.menuList.Add(li);
        if (Global.isHaveAuth(permissionResult, "use", "统计图表"))
        {
            BasisDDropDownLi li0 = new BasisDDropDownLi();
            li0.HREF = "javascript:loadStatisticalChart();";
            li0.iconClassName = "fa fa-area-chart";
            li0.MenuName = " 统计图表";
            udd.menuList.Add(li0);
        }
        if (Global.isHaveAuth(permissionResult, "use", "统计报表"))
        {
            BasisDDropDownLi li1 = new BasisDDropDownLi();
            li1.HREF = "javascript:loadReportPage();";
            li1.iconClassName = "fa fa-flag-o";
            li1.MenuName = " 统计报表";
            udd.menuList.Add(li1);
        }
        if (Global.isHaveAuth(permissionResult, "use", "同步测压"))
        {
            BasisDDropDownLi li2 = new BasisDDropDownLi();
            li2.HREF = "javascript:loadCommonPage();";
            li2.iconClassName = "fa fa-flask";
            li2.MenuName = " 同步测压";
            udd.menuList.Add(li2);
        }
        BasisDDropDownLi li3 = new BasisDDropDownLi();
        li3.HREF = "javascript:SearchCommonPage();";
        li3.iconClassName = "fa fa-search";
        li3.MenuName = " 信息检索";
        udd.menuList.Add(li3);
        return udd.GetHtmlText();
    }
}