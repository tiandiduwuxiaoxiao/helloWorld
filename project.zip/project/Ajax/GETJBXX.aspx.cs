﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using Maticsoft.DBUtility;
using System.Collections;
using System.Text;
using BootStrapControls;
using OrderFunction;

public partial class Ajax_GETJBXX : System.Web.UI.Page
{
    public string MAIN_ID = string.Empty;
    public string TableInfo = string.Empty;
    string result = "";
    public Hashtable HT = new Hashtable();
    public Hashtable HT_Status = new Hashtable();
    public Hashtable HT_FIELDNAME = new Hashtable();//取出S_dict表的FIELDNAME
    public string orderState = "";
    public string ReturnType = "0";
    public string uid = "";
    public string userDEPNAME = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        uid = Request["uid"];
        bool isneedsqdx = true;
        userDEPNAME = Global.GetDepname(uid);
        if (Request["ID"] != null)
        {
            try
            {
                string checkType = Request["checkType"];//判断审核的类型（1、销单2、延期审核3、退单审核）
                MAIN_ID = Request["ID"];
                if (checkType == "1")
                {
                    TableInfo = ConfigurationManager.AppSettings["checkXdTable"];
                    //判断当前是否为第一步审核,若为第一步审核则需要填写诉求定性，其他不需要
                    isneedsqdx = CheckIsNeedSqdx(MAIN_ID);

                }
                else if (checkType == "2")
                {
                    TableInfo = ConfigurationManager.AppSettings["checkYqTable"];
                }
                else if (checkType == "3")
                {
                    TableInfo = ConfigurationManager.AppSettings["checkTdTable"];
                }
                //写入html
                GetData();
                SetData();

                //Tab页模式
                int mili = DateTime.Now.Millisecond;
                Random rd = new Random(mili);
                int rdnum = rd.Next(100);

                BtsTabbable bt = new BtsTabbable();

                bt.TabIdName = "tab" + rdnum.ToString();

                string[] icons = { "fa fa-reorder ", "fa fa-mobile-phone", "fa fa-gavel", "fa fa-bolt", "fa fa-file-text" };
                int listcnt = 0;
                foreach (string de in sumallList)
                {
                    PZ_TAB tab = HT_Status[de] as PZ_TAB;
                    if (tab == null)
                        continue;
                    #region title
                    BtsBox box_orderdetail = new BtsBox();
                    box_orderdetail.BoxClass = "box border blue col-lg-10 col-lg-offset-1";
                    box_orderdetail.BtsBoxTitle.TitleHead.IconClass = "fa fa-bars";
                    box_orderdetail.BtsBoxTitle.TitleHead.Text = tab.TCNNAME;
                    #endregion

                    string body_primary = "暂无数据";
                    if (BodyTextList != null && BodyTextList.Count > listcnt)
                    {
                        body_primary = BodyTextList[listcnt];
                    }
                    //bt.TabContentList.Add(body_primary);
                    box_orderdetail.BtsBoxBody.BodyContent = body_primary;
                    listcnt++;
                    result += "<div class='row'>";
                    result += box_orderdetail.GetHtmlText();
                    result += "</div>";
                }
                Hashtable searchHashtable = InitCache.xwbm_sjzd;
                ArrayList seaList = null;
                ArrayList dList = new ArrayList();
                if (searchHashtable != null && TableInfo.Split(';')[1] != null)
                {
                    seaList = (ArrayList)searchHashtable[TableInfo.Split(';')[1].ToUpper()];
                }
                FormList formList = new FormList(uid, userDEPNAME);
                StringBuilder upsql = new StringBuilder();
                string tablefields = String.Empty;
                for (int i = 0; i < seaList.Count; i++)
                {
                    DictionaryContent dc = (DictionaryContent)seaList[i];
                    tablefields = dc.fieldconfig;
                    FormControl fc = new FormControl();
                    fc.TableName = dc.tableName;
                    fc.FieldDisName = dc.fieldAliasName;
                    fc.FieldName = dc.fieldName;
                    fc.FieldType = dc.style;
                    fc.FIELDORDER = dc.colid;
                    fc.MAPINGCODE = dc.dm;
                    fc.MAPSQL = dc.mappsql;
                    fc.VALIDRULES = dc.validrules;
                    fc.SUBFIELD = dc.subfield;
                    fc.Type = dc.fieldType;
                    if (dc.fieldName.ToUpper()=="SQDX")
                    {
                        fc.isneedshow = isneedsqdx.ToString();
                    }
                    fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    formList.Add(fc);
                    upsql.AppendFormat("{0}∑", fc.FieldName + "|" + fc.FieldType + "|" + fc.IsNull + "|" + fc.MAPSQL);
                }
                //获取是否需要根据某些字段来控制字段显隐或者验证
                formList.Flist = GetConfigs(tablefields, MAIN_ID);
                result += formList.GetHtmlText();
              
                DynamicParam dp = new DynamicParam();
                dp.InnerHtml = result;
                dp.StrParams = upsql.ToString();
                //Response返回新对象的json数据
                result = Json.JsonSerializerBySingleData<DynamicParam>(dp);
            }


            catch (System.Exception ex)
            {
                Loger.Error("追溯历史==>GetHis==>", ex);
            }
        }

        Response.Write(result);
    }

    /// <summary>
    /// 判断当前是否为第一步审核,若为第一步审核则需要填写诉求定性，其他不需要
    /// </summary>
    /// <param name="MAIN_ID"></param>
    /// <returns></returns>
    private bool CheckIsNeedSqdx(string MAIN_ID)
    {
        string sql = "";
        bool flag = false;
        try
        {
            OracleDataBase odb = new OracleDataBase();
            sql = "select * from v_GetOrderSHStation where main_id='" + MAIN_ID + "'";
            DataSet ds = odb.GetDataSet(sql);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                if (Convert.ToString(ds.Tables[0].Rows[0]["hisstation"]) == userDEPNAME)
                {
                    flag = true;
                }
            }

        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GETJBXX=>CheckIsNeedSqdx异常,sql=" + sql, ex);
        }
        return flag;
    }

    /// <summary>
    /// 获取是否需要根据某些字段来控制字段显隐或者验证
    /// </summary>
    /// <param name="tablefields"></param>
    /// <param name="mainId"></param>
    /// <returns></returns>
    public List<FieldConfig> GetConfigs(string tablefields, string mainId)
    {
        List<FieldConfig> flist = new List<FieldConfig>();
        string sql = "";
        try
        {
            //获取是否需要根据某些字段来控制字段显隐或者验证
            if (!string.IsNullOrWhiteSpace(tablefields))
            {
                string[] fieldStrings = tablefields.Split(';');
                string sqlwhere = fieldStrings.Aggregate("", (current, item) => current + ("'" + item + "',"));
                sqlwhere = sqlwhere.TrimEnd(',');
                sql = "select * from PZ_FIELDCONFIG where id in (" + sqlwhere + ")";
                OracleDataBase odb = new OracleDataBase();
                DataSet ds = odb.GetDataSet(sql);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        //根据存储的sql获取字段值
                        sql = Convert.ToString(ds.Tables[0].Rows[i]["SQL"]) + " and " + Convert.ToString(ds.Tables[0].Rows[i]["SQLFIELD"]) + "='" + mainId + "'";
                        DataSet data = odb.GetDataSet(sql);
                        if (data != null && data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                        {
                            if (Convert.ToString(data.Tables[0].Rows[i]["title"]).ToUpper() == Convert.ToString(ds.Tables[0].Rows[i]["DEFAULTVALUE"]).ToUpper())
                            {
                                string[] fieldnames = Convert.ToString(ds.Tables[0].Rows[i]["FIELDS"]).Split(';');
                                foreach (string item in fieldnames)
                                {
                                    FieldConfig fc = new FieldConfig();
                                    fc.fieldname = item;
                                    fc.result = Convert.ToString(ds.Tables[0].Rows[i]["RESULTVALUE"]);
                                    fc.type = Convert.ToString(ds.Tables[0].Rows[i]["TYPE"]);
                                    flist.Add(fc);
                                }
                            }
                        }
                    }
                }

                // Session["fieldconfig"] = flist;
            }
        }
        catch (Exception ex)
        {
            Loger.Error("Ajax_GETJBXX=>GetConfigs异常,sql=" + sql, ex);
        }


        return flist;
    }

    public int sum = 3;
    public int nor;
    public int sumall;
    public ArrayList sumallList = new ArrayList();
    public int sumallMax;
    public void GetData()
    {
        try
        {
            //判断是否传入工单编号
            if (!string.IsNullOrEmpty(MAIN_ID))
            {
                string id = MAIN_ID;

                if (Request["MAINID"] != null)
                {
                    string orderMainID = Request["MAINID"].ToString();
                    orderState = "0";
                    HT = Global.getDetailById(orderMainID, TableInfo.Split(';')[0]);//根据ID得到详细信息 
                }
                else
                {
                    HT = Global.getDetailById(id, TableInfo.Split(';')[0]);//根据ID得到详细信息
                }
            }
            string where = string.Empty;
            string rtID = "6F95974193A14C7F9F6437337EF9DB04";
            //获取角色菜单表RTID
            //string rtID = Request.QueryString["RTID"] == null ? "" : Request.QueryString["RTID"];
            //解决通过任务检索时，获取不到rtID导致看不到工单的详细信息,暂时解决方法
            //rtID = string.IsNullOrEmpty(rtID) ? System.Configuration.ConfigurationManager.AppSettings["SelectRtID"].ToString() : rtID;
            //获取显示组字段
            HT_Status = Global.GetTabs("'" + TableInfo.Split(';')[0] + "'");
            sumallList = new ArrayList(HT_Status.Keys);
            sumallList.Sort();
            sumall = HT_Status != null && HT_Status.Count > 0 ? HT_Status.Count : 0;
            sumallMax = 7;//Convert.ToInt32(HT_Status_two[sumall - 1]) + 1;

            //获取组对应字段
            HT_FIELDNAME = Global.GetFieldNames(where, rtID);
            nor = HT_FIELDNAME != null && HT_FIELDNAME.Count > 0 ? HT_FIELDNAME.Count : 0;
        }
        catch (Exception ex)
        {
            Loger.Error(" GETJBXX.apx===》GetData()===log:" + ex);
        }
    }
    List<string> BodyTextList = new List<string>();

    public void SetData()
    {
        try
        {
            foreach (string de in sumallList)
            {
                PZ_TAB tab = HT_Status[de] as PZ_TAB;
                if (tab == null)
                    continue;
                int h = Convert.ToInt32(tab.FIELDGROUP);
                string type = tab.TABTYPE;

                //字段显示开始
                StringBuilder bodyText = new StringBuilder();
                if (type == "1")
                {
                    bodyText.Append("<table border=\"0\" id=\"table1\" cellspacing=\"0\" cellpadding=\"3\" style=\"margin-top: 0px;padding-top: 0px; width: 100%;\" class=\"my-table table\">\n<tr>\n");
                    int huanghang = 1;
                    int valuesum = h;
                    int decide = 0;
                    //循环取出字段的数据
                    for (int i = 1; i <= nor; i++)
                    {
                        S_DICT dict = HT_FIELDNAME[i] as S_DICT;
                        if (dict == null)
                            continue;
                        //判断是否是这个top下的字段
                        if (dict.TID == tab.TID)
                        {
                            decide = 1;
                            int length = string.IsNullOrEmpty(dict.LENGTH) ? 0 : Convert.ToInt32(dict.LENGTH);
                            if (length >= 500)
                                //    bodyText.Append("<td  class=\"td_text table-border\" style=\"background-color: #FFF0F5;\">" + dict.FIELDDISNAME + "</td>\n");
                                //else
                                //    bodyText.Append("<td  class=\"td_text table-border\" style=\"background-color: #FFF0F5;\">" + dict.FIELDDISNAME + "</td>\n");
                                bodyText.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + dict.FIELDDISNAME + "</td>\n");
                            else
                                bodyText.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + dict.FIELDDISNAME + "</td>\n");
                            //取出对应于HT中的字段名 ，取值
                            string temp_value = "";
                            temp_value = Convert.ToString(HT[dict.FIELDNAME]);
                            string fontcolor = "Orange";
                            if (length >= 500)
                            {
                                if (i == nor)
                                {
                                    bodyText.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n</tr>\n");
                                }
                                else
                                {
                                    bodyText.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n</tr>\n<tr>\n");
                                }
                            }
                            else
                            {

                                bodyText.Append("<td class=\"td_value table-border\" style=\"width: 170px;color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>");
                            }
                            if (huanghang % sum == 0 && length < 500)
                            {
                                bodyText.Append("</tr>\n<tr>\n");
                            }
                            huanghang += 1;
                        }
                    }


                    bodyText.Append("</tr>\n</table>\n");
                }
                else//列表显示
                {
                    bodyText.Append("<table border=\"0\" id=\"table1\" cellspacing=\"0\" cellpadding=\"3\" style=\"margin-top: 0px;padding-top: 0px; width: 100%;\" class=\"my-table table\">\n<tr>\n");
                    int valuesum = h;
                    int decide = 0;
                    string taborder = string.IsNullOrEmpty(tab.TABORDER) ? "" : " order by " + tab.TABORDER;
                    string fields = "";
                    //循环取出字段的数据
                    for (int i = 1; i <= nor; i++)
                    {
                        S_DICT dict = HT_FIELDNAME[i] as S_DICT;
                        if (dict == null)
                            continue;
                        //判断是否是这个top下的字段
                        if (dict.TID == tab.TID)
                        {
                            decide = 1;
                            fields += dict.FIELDNAME + ",";
                            bodyText.Append("<td  align=\"center\" style=\"color:black\">" + dict.FIELDDISNAME + "</td>\n");
                        }
                    }
                    bodyText.Append("</tr>\n" + GetTableHTML(tab.TABNAME, tab.TABMAINID, MAIN_ID, taborder, fields) + "</table>\n");
                }
                BodyTextList.Add(bodyText.ToString());
            }
        }
        catch (Exception ex)
        {
            Loger.Error(" GETJBXX.apx===》SetData()===log:" + ex);
        }
    }

    public string GetTableHTML(string tablename, string tabmainid, string main_id, string fiedorder, string fields)
    {
        string html = "";
        try
        {
            string fieldname = fields;
            if (fieldname.Length > 0)
                fieldname = fieldname.Substring(0, fieldname.Length - 1);
            if (fieldname.Length > 0)
            {
                string sql = "select " + fieldname + " from " + tablename + " t " + " where " + tabmainid + "='" + main_id + "' " + fiedorder;
                DataSet ds = DbHelperOra.Query(sql);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    string[] fieldList = fieldname.Split(',');
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        html += "<tr>\n";
                        string fontcolor = "Orange";
                        foreach (string fieldstr in fieldList)
                        {
                            html += string.Format("<td align=\"center\" style=\"color:" + fontcolor + " \">{0}</td>\n", row[fieldstr].ToString());
                        }
                        html += "</tr>\n";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTableHTML==>", ex);
        }
        return html;
    }
}