﻿using System;
using System.Text;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using hugegis.DBUtility;

public class MyImg
{
    public string Img_Url { get; set; }
    public string ID { get; set; }
    public string PicTime { get; set; }
    public string PicStation { get; set; }
}





public class TimeLineBindData
{
    /// <summary>
    /// 日期
    /// </summary>
    public string Date { get; set; }

    /// <summary>
    /// 时间
    /// </summary>
    public string Time { get; set; }

    /// <summary>
    /// 登录用户名
    /// </summary>
    public string UserName { get; set; }

    /// <summary>
    /// 备注
    /// </summary>
    public string Remark { get; set; }

    /// <summary>
    /// 事件名称
    /// </summary>
    public string EventName { get; set; }


    public MyImg[] Images = null;
}


public class TimeLineLi
{
    public TimeLineBindData dataItem = null;

    private string _divClassName = "bg-success";

    private string _divIconName = "icon-pencil";

    public string DivClassName
    {
        get
        {
            return _divClassName;
        }
        set
        {
            _divClassName = value;
        }
    }

    public string DivIconName
    {
        get
        {
            return _divIconName;
        }
        set
        {
            _divIconName = value;
        }
    }

    public string TimeLineClassName = "timeline-time";
    public int cnt = 0;
    public string GenerateHtml()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.AppendLine("<li>");
        sb.AppendLine(string.Format("<div class=\"{0}\">", this.TimeLineClassName));
        if (dataItem != null)
        {
            sb.AppendLine(string.Format("<strong>{0}</strong>{1}", dataItem.Date, dataItem.Time));
        }
        sb.AppendLine("</div>");

        sb.AppendLine(string.Format("<div class=\"timeline-icon\"><div class = \"{0}\"><i class = \"{1}\"></i></div></div>", this.DivClassName, this.DivIconName));

        sb.AppendLine("<div class=\"timeline-content\">");
        if (dataItem != null)
        {
            sb.AppendLine(string.Format("<h4><b>{0}</b></h4>", dataItem.EventName));
            sb.AppendLine(string.Format("<h5>操作人：<i class=\"fa fa-user\"></i> {0}</h5>", dataItem.UserName));
            if (!string.IsNullOrEmpty(dataItem.Remark))
            {
                sb.AppendLine(string.Format("<p>备注： {0}</p>", dataItem.Remark));
            }
            //sb.AppendLine(string.Format("<h4><button class=\"btn btn-default\" ><i class=\"fa fa-cog\"></i>地图定位</button></h4>"));
            //获取需要显示的图片
            //string tracephoto = ConfigurationManager.AppSettings["tracephoto"];
            //string[] tracephotos = tracephoto.Split(',');
            //foreach (string item in tracephotos)
            //{
            //    if (dataItem.EventName == item)
            //    {
            //        sb.Append(string.Format("<p>定位: </p><center><iframe id=\"map_traceiframe\" name=\"map_traceiframe\" src=\"{0}\" height=\"100%\" width=\"100%\" frameborder=\"0\"></iframe></center>", map_url));
            //    }
            //}
            if (dataItem.Images != null && dataItem.Images.Length > 0)
            {
                foreach (MyImg img in dataItem.Images)
                {
                    sb.Append(string.Format("<center><img src=\"{0}\"    style=\"height=400px;width:400px\"/></center>", img.Img_Url));
                }
            }
            string map_img_url = "img/earth.jpg";
            string map_url = ConfigurationManager.AppSettings["mapurl"];

            if (dataItem.EventName == "到场照片")
            {
                if (cnt == 1)
                {
                    sb.Append(string.Format("<center><iframe id=\"map_traceiframe\" name=\"map_traceiframe\" src=\"{0}\" height=\"100%\" width=\"100%\" frameborder=\"0\"></iframe></center>", map_url));
                }

            }

        }
        sb.AppendLine("</div>");
        sb.AppendLine("</li>");
        return sb.ToString();
    }
}


public partial class Ajax_GetTraceHis : System.Web.UI.Page
{
    public string MAIN_ID = string.Empty;
    string result = "工单数据有误！";
    DataTable dt = null;
    ArrayList picList = null;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["ID"] != null)
        {
            try
            {
                string MAIN_ID = Request.QueryString["ID"];
                OracleDataBase odb = new OracleDataBase();
                //string sql1 = "select t.id  from tz_main t where t.='" + p_customserviceid + "'";
                //string p_id = Request.QueryString["ID"];
                //MAIN_ID = p_id;
                //图片路径，时间等信息
                picList = Global.getPicDetailById(MAIN_ID);
                //工单历史
                dt = LoadListInfo(MAIN_ID, "");
                //写入html 0808
                //result = AddLi2(dt);
                result = AddTimeLineUL(dt);


            }
            catch (System.Exception ex)
            {
                Loger.Error("追溯历史==>GetTraceHis==>", ex);
            }
        }

        Response.Write(result);
    }

    string[] bgs = { "bg-primary ", "bg-warning", "bg-info", "bg-danger", "bg-success" };
    int bgscount = 0;
    protected string AddTimeLineUL(DataTable dt)
    {
        StringBuilder sb = new StringBuilder();
        int cnt = 0;
        if (dt != null && dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                TimeLineLi li = new TimeLineLi();
                li.dataItem = new TimeLineBindData();
                bgscount = bgscount % 5;
                li.DivClassName = bgs[bgscount++];

                string ev = dr["Event"].ToString();

                li.dataItem.EventName = ev.Replace("时间", "");

                li.dataItem.UserName = dr["Operator"].ToString();
                string datetime = dr["time"].ToString();
                int indexofblank = datetime.IndexOf(" ");
                string riqi = datetime.Substring(0, indexofblank);
                string shijian = datetime.Substring(indexofblank);
                li.dataItem.Date = riqi;
                li.dataItem.Time = shijian;
                li.dataItem.Remark = dr["Description"].ToString();

                string station = ev;//li.dataItem.Remark;
                ArrayList PicList = this.picList;
                if (PicList != null && PicList.Count > 0 && !string.IsNullOrEmpty(station))
                {
                    List<MyImg> list_img = new List<MyImg>();
                    for (int j = 0; j < PicList.Count; j++)
                    {
                        string[] array = ((string[])PicList[j]);
                        //[0,1,2,3]:url,id,description,time
                        if (array[2] == station)
                        {
                            MyImg im = new MyImg();
                            string Filepath = ConfigurationManager.AppSettings["filepath"]; //本地图片访问路径
                            im.Img_Url = Filepath + array[0];
                            im.ID = array[1];
                            im.PicStation = array[2];
                            im.PicTime = array[3];
                            list_img.Add(im);
                        }
                    }
                    if (list_img != null && list_img.Count > 0)
                    {
                        li.dataItem.Images = list_img.ToArray();
                    }

                }
                if (li.dataItem.EventName == "到场照片")
                {
                    cnt++;
                }
                li.cnt = cnt;
                string s = li.GenerateHtml();
                sb.Append(s);
                
            }
        }
        return sb.ToString();
    }








    public DataTable LoadListInfo(string INFONUM, string where)
    {
        string MAIN_ID = INFONUM;
        Decrypt decrypt = new Decrypt();
        StringBuilder sql = new StringBuilder();
        OracleDataBase odb = new OracleDataBase();
        DataSet ds = new DataSet();

        try
        {
            if (GetXCSB(INFONUM))
            {
                sql.Append(string.Format(@"select  '上报时间' Event, sbsj as time,pda as Operator,
 xcqk as Description from tz_xcqksb where main_id='{0}' union ", INFONUM));
            }
            sql.Append(string.Format(@"select * from v_trackhis where main_id='{0}'", MAIN_ID));
            ds = odb.GetDataSet(sql.ToString());
        }
        catch (Exception ex)
        {
            Loger.Error("GetTraceHis=>LoadListInfo异常,sql=" + sql.ToString(), ex);
        }


        return ds.Tables[0];

    }

    /// <summary>
    /// 判断派遣状态
    /// </summary>
    /// <param name="state"></param>
    /// <returns></returns>
    public string getstate(string state)
    {
        if (state != "")
        {
            if (state == "1")
            {
                return "发送中";
            }
            if (state == "2")
            {
                return "已查看";
            }
        }
        state = state.Length > 15 ? state.Remove(14) + "...." : state;
        return state;
    }

    private bool GetXCSB(string id)
    {
        string sql = string.Format("select count(id) from tz_xcqksb where main_id='{0}'", id);
        OracleDataBase odb = new OracleDataBase();
        return Convert.ToInt32(odb.GetScalarobj(sql)) > 0 ? true : false;
    }

    public string getmyname(string name)
    {
        string temp = "";
        if (name != "")
        {
            string sql = "select realname from author_user a,author_equipment b where a.cuser=b.relationobj and b.equipname='" + name + "'";
            OracleDataBase odb = new OracleDataBase("1");
            temp = odb.GetScalarInfo(sql);
            if (temp.Trim() == "")
            {
                sql = "select t.realname from author_user t where t.cuser='" + name + "'";
                temp = odb.GetScalarInfo(sql);
            }
        }
        return !string.IsNullOrEmpty(temp) ? temp : name;
    }


    /// <summary>
    /// 获取图片信息
    /// </summary>
    /// <param name="id">主表id</param>
    /// <returns>图片信息</returns>
    public string[] DownloadFileByBH(string id)
    {
        string[] returnstr = null;
        ArrayList al = Global.getPicDetailById(id);
        if (al.Count > 0)
        {
            string Filepath = ConfigurationManager.AppSettings["filepath"]; //本地图片访问路径
            string OUTPUTPATHstr = Filepath; //发布文件目录
            returnstr = new string[al.Count];
            string[] returnrecordstr = new string[al.Count];
            string[] showrecordstr = new string[al.Count];
            for (int i = 0; i < al.Count; i++)
            {
                returnstr[i] = OUTPUTPATHstr + "/" + ((string[])al[i])[0];// + ".jpg";
                returnrecordstr[i] = ((string[])al[i])[1];
                showrecordstr[i] = "状态：" + ((string[])al[i])[2] + " 拍摄时间：" + ((string[])al[i])[3];
            }
        }
        return returnstr;
    }

}