﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Ajax_GetCarDriverInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       string ID= HttpUtility.UrlDecode(Request["ID"].ToString());
       string type = Request["type"].ToString();
       switch (type)
       {
           case "driver": GetDriverInfo(ID);
               break;
           case "carInfo": GetCarInfo(ID); break;
           default:
               break;
       }
    }
    /// <summary>
    /// 获取司机的信息
    /// </summary>
    /// <param name="Id">ID</param>
    public void GetDriverInfo(string Id) {
        OracleDataBase odb = new OracleDataBase("1");
        try
        {
            string sql = string.Format("select * from author_driver where id='{0}'", Id);
            DataSet ds = odb.GetDataSet(sql);
            if (ds.Tables.Count > 0)
            {
                string json = Json.ToJson(ds.Tables[0]);
                Response.Write(json);
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetCarDriverInfo===GetDriverInfo==>ex:"+ex);
        }
        finally
        {
            odb.Close();
        }
  }
    /// <summary>
    /// 获取车辆信息
    /// </summary>
    /// <param name="Id"></param>
    public void GetCarInfo(string Id) {
        OracleDataBase odb = new OracleDataBase("1");
        try
        {
            string sql = string.Format("select * from  author_carinfo where id='{0}'", Id);
            DataSet ds = odb.GetDataSet(sql);
            if (ds.Tables.Count > 0)
            {
                string json = Json.ToJson(ds.Tables[0]);
                Response.Write(json);
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetCarDriverInfo===GetDriverInfo==>ex:" + ex);
        }
        finally
        {
            odb.Close();
        }
        
    }
}