﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Main 的摘要说明
/// </summary>
public class Main
{
	public Main()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public string id { get; set; }
    public string customserviceid { get; set; }
    public string tokenname { get; set; }
    public string ArrivalTime { get; set; }

}