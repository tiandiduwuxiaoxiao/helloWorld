﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using System.Data;

/// <summary>
///调用Oracle存储过程对表进行分页
/// </summary>
public class Pagination
{
    OracleConnection m_oracleConnection; //Oracle连接对象

    /// <summary>
    /// 构造函数,传入存储过程名称与连接对象
    /// </summary>
    /// <param name="procedureName">存储过程名称</param>
    /// <param name="orclConnection">初始化后连接字符串的Oracle连接对象</param>
    public Pagination(OracleConnection orclConnection)
    {
        m_oracleConnection = orclConnection;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="procedureName">存储过程名称</param>
    /// <param name="processState">流程状态</param>
    /// <param name="acceptstation">受理站点</param>
    /// <param name="filter">过滤条件 格式如下：and 字段名='字段值'</param>
    /// <param name="paeSize">每页记录数</param>
    /// <param name="indexNowPage">分页索引 从0开始</param>
    /// <param name="totalRows">总记录数</param>
    /// <returns>分页结果集</returns>
    public DataTable Paging(string procedureName, string processState, string acceptstation, string filter, string orderby, int paeSize, int indexNowPage, ref int totalRows)
    {
        try
        {
            //打开连接
            OpenOracleConnection();

            //定义OracleCommand对象,设置命令类型为存储过程
            OracleCommand pOracleCMD = new OracleCommand(procedureName, m_oracleConnection);
            pOracleCMD.CommandType = CommandType.StoredProcedure;

            //根据存储过程的参数个数及类型生成参数对象
            OracleParameter p1 = new OracleParameter("rowPageSize", OracleType.Number, 10);
            OracleParameter p2 = new OracleParameter("rowPageIndex", OracleType.Number, 10);
            OracleParameter p3 = new OracleParameter("totalRows", OracleType.Number, 10);
            OracleParameter p4 = new OracleParameter("P_processState", OracleType.VarChar, 1000);
            OracleParameter p5 = new OracleParameter("P_acceptstation", OracleType.VarChar, 4000);
            OracleParameter p6 = new OracleParameter("P_filter", OracleType.VarChar, 4000);
            OracleParameter p7 = new OracleParameter("v_orderby", OracleType.VarChar, 4000);
            OracleParameter p8 = new OracleParameter("p_cursor", OracleType.Cursor);

            //设置参数的输入输出类型,默认为输入
            p1.Direction = ParameterDirection.Input;
            p2.Direction = ParameterDirection.Input;
            p3.Direction = ParameterDirection.Output;
            p4.Direction = ParameterDirection.Input;
            p5.Direction = ParameterDirection.Input;
            p6.Direction = ParameterDirection.Input;
            p7.Direction = ParameterDirection.Input;
            p8.Direction = ParameterDirection.Output;

            //对输入参数定义初值,输出参数不必赋值.
            p1.Value = paeSize;
            p2.Value = indexNowPage;
            //   p3.Value = paeSize;
            p4.Value = processState;
            p5.Value = acceptstation;
            p6.Value = filter;
            p7.Value = orderby;
            //       p3.Value = tableName;

            //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
            pOracleCMD.Parameters.Add(p1);
            pOracleCMD.Parameters.Add(p2);
            pOracleCMD.Parameters.Add(p3);
            pOracleCMD.Parameters.Add(p4);
            pOracleCMD.Parameters.Add(p5);
            pOracleCMD.Parameters.Add(p6);
            pOracleCMD.Parameters.Add(p7);
            pOracleCMD.Parameters.Add(p8);
            //执行,把分页结果集填入datatable中
            OracleDataAdapter pOracleDataAdapter = new OracleDataAdapter(pOracleCMD);
            DataTable datatable = new System.Data.DataTable();

            pOracleDataAdapter.Fill(datatable);

            //在执行结束后,从存储过程输出参数中取得相应的值放入引用参数中以供程序调用
            totalRows = int.Parse(p3.Value.ToString());
            // totalPages = int.Parse(p5.Value.ToString());


            return datatable;
        }
        catch (Exception ex)
        {
            Loger.Error("Pagination.cs=======》错误异常：  ", ex);
            return null;
        }
        finally
        {
            //关闭连接
            CloseOracleConnection();

        }

    }

    /// <summary>
    /// 关闭连接
    /// </summary>
    private void CloseOracleConnection()
    {
        if (m_oracleConnection.State == ConnectionState.Open)
        {
            m_oracleConnection.Close();
        }
    }

    /// <summary>
    /// 打开连接
    /// </summary>
    private void OpenOracleConnection()
    {
        if (m_oracleConnection.State == ConnectionState.Closed)
        {
            m_oracleConnection.Open();
        }
    }

}

