using System.Collections.Generic;
using hugegis.DAL;
using hugegis.Model;

namespace hugegis.BLL
{
    public class BLL_MENUGNFIG
    {
        public readonly DAL_MENUGNFIG dal = new DAL_MENUGNFIG();

        #region

        /// <summary>
        ///     ��ȡ���������б�
        /// </summary>
        public List<Model_MENUGNFIG> GetList(string _pid)
        {
            return dal.GetList(_pid);
        }


        public List<Model_MENUGNFIG> GetListByAsiaName(string _pid)
        {
            return dal.GetListByAsiaName(_pid);
        }
        /// <summary>
        ///     �������ݿ����û�ȡ������Ŀ
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public int GetOrderNumber(string strSql)
        {
            return dal.GetOrderNumber(strSql);
        }

        /// <summary>
        ///     ��������ID ��ȡ �˵�����
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public string GetAsianameByID(string _id)
        {
            return dal.GetAsianameByID(_id);
        }
        /// <summary>
        ///     ��������ID ��ȡ �˵�����
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public string GetIdByAsianame(string _id)
        {
            return dal.GetIdByAsianame(_id);
        }

        #endregion
    }
}