﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Text;
using System.Data;
using System.Configuration;
using hugegis.DBUtility;
using Maticsoft.DBUtility;

/// <summary>
///BLL_List 的摘要说明
/// </summary>
public class BLL_List
{
    /// <summary>
    ///过滤接报信息
    /// </summary>
    /// <param name="drpDateJb">接报时间</param>
    /// <returns></returns>
    public static string getWhereTime(string drpDateJb)
    {
        string strWhereTime = string.Empty;
        if (drpDateJb == Globals.DATE_ONE)
        {
            strWhereTime =
                @" AND ACCEPTTIME >= to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 00:00:00'),'yyyy-MM-dd hh24:mi:ss')
                        and ACCEPTTIME <=to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 23:59:59'),'yyyy-MM-dd hh24:mi:ss') ";
        }
        else if (drpDateJb == Globals.DATE_THREE)
        {
            strWhereTime =
                @" AND ACCEPTTIME >= to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 00:00:00'),'yyyy-MM-dd hh24:mi:ss')-2
                                            and ACCEPTTIME <=to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 23:59:59'),'yyyy-MM-dd hh24:mi:ss') ";
        }
        else if (drpDateJb == Globals.DATE_FIVE)
        {
            strWhereTime =
                @" AND ACCEPTTIME >= to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 00:00:00'),'yyyy-MM-dd hh24:mi:ss')-4
                                            and ACCEPTTIME <=to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 23:59:59'),'yyyy-MM-dd hh24:mi:ss') ";
        }
        else if (drpDateJb == Globals.DATE_SEVEN)
        {
            strWhereTime =
                @" AND ACCEPTTIME >= to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 00:00:00'),'yyyy-MM-dd hh24:mi:ss')-6
                                            and ACCEPTTIME <=to_date((to_char(SYSDATE,'yyyy-MM-dd')||' 23:59:59'),'yyyy-MM-dd hh24:mi:ss') ";
        }
        return strWhereTime;
    }

    /// <summary>
    ///     根据配置ID 获取 菜单名称
    /// </summary>
    /// <param name="asiacode">asiacode</param>
    /// <returns></returns>
    public static string GetAsianameByID(string asiacode)
    {
        if (string.IsNullOrEmpty(asiacode)) return string.Empty;
        StringBuilder strSql = new StringBuilder(@"select asianame from PZ_MENUCONFIG ");
        strSql.AppendFormat(" where asiacode='{0}'", asiacode);
        strSql.Append(" order by sorted ");
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(strSql.ToString());
    }

    /// <summary>
    ///     获取查询条件
    /// </summary>
    /// <param name="sel"></param>
    /// <returns></returns>
    public static string getSel(string sel)
    {
        if (!string.IsNullOrEmpty(sel))
        {
            if (sel.IndexOf("'") > -1)
            {
                return String.Format(" and (customserviceid in ({0})  ) ", sel);
            }
            else
            {
                if (sel.Contains(","))
                {
                    return GetTagname(sel);
                }
                else
                {
                    return @" and (customserviceid like '%" + sel + "%' or infonum like '%" + sel + "%' or happenaddr like '%" + sel + "%' or tel like '%" + sel + "%' or mobile like '%" + sel + "%'  or CUSTOMID like '%" + sel + "%' ) ";
                }
            }
        }
        else
        {
            return " ";
        }
    }
    private static string GetTagname(string _tagname)
    {
        StringBuilder result = new StringBuilder(string.Empty);
        //   string _tagname = tex.Text.Trim().Replace("，", ",");
        if (_tagname.Contains(","))
        {
            string[] tagnames = _tagname.Split(',');
            if (tagnames.Length > 0)
            {
                result.Append(" AND ( ");
                for (int i = 0; i < tagnames.Length; i++)
                {
                    if (!string.IsNullOrEmpty(tagnames[i]))
                    {
                        if (i == 0)
                        {
                            result.Append(string.Format("(customserviceid = '{0}')", tagnames[i]));
                        }
                        else
                        {
                            result.Append(string.Format("OR (customserviceid = '{0}')", tagnames[i]));
                        }
                    }
                }
                result.Append("  ) ");
            }
        }
        else
        {
            if (!string.IsNullOrEmpty(_tagname))
            {
                result.Append(string.Format(" AND (customserviceid = '{0}')", _tagname));
            }
        }
        return result.ToString();
    }

    /// <summary>
    /// 拼接SQL语句，返回数据
    /// </summary>
    /// <param name="filter1">关联工单条件(内部子工单，拆分工单，后续跟进单等)</param>
    /// <param name="filter">过滤条件 格式如下：and 字段名='字段值'</param>
    /// <param name="paeSize">每页记录数</param>
    /// <param name="indexNowPage">分页索引 从0开始</param>
    /// <param name="totalRows">总记录数</param>
    /// <param name="rtID">角色左侧菜单表主键</param>
    /// <returns>分页结果集</returns>
    public static DataTable Paging(string filter1, string filter, string orderby, int paeSize, int indexNowPage,
                                         ref int totalRows, string rtID,string uid)
    {

        return RunProcedure(filter1,filter, orderby, paeSize, indexNowPage, ref totalRows, rtID, uid);
    
    }

    

    /// <summary>
    /// 拼接SQL语句，返回数据
    /// </summary>
    /// <param name="filter1">关联工单条件(内部子工单，拆分工单，后续跟进单等)</param>
    /// <param name="filter">过滤条件 格式如下：and 字段名='字段值'</param>
    /// <param name="paeSize">每页记录数</param>
    /// <param name="indexNowPage">分页索引 从0开始</param>
    /// <param name="totalRows">总记录数</param>
    /// <param name="rtID">角色左侧菜单表主键</param>
    /// <param name="rtID">角色左侧菜单表主键</param>
    /// <returns>分页结果集</returns>
    public static DataTable RunProcedure(string filter1, string filter, string orderby, int paeSize, int indexNowPage,
                                         ref int totalRows, string rtID,string uid="")
    {
        OracleDataBase odb = new OracleDataBase("0");
        //获取当前菜单下的所有字段信息，拼成一个数据库可查询的字段
        string sql = "";
        try
        {

            //获取当前菜单下所有配置的字段数据
            sql = string.Format(@" select * from pz_menuconfig WHERE id = '{0}' ", rtID);
            DataTable dtColumnName = odb.GetDataSet(sql).Tables[0];
            string strColumnName = string.Empty;
            if (dtColumnName.Rows.Count > 0)
                strColumnName = dtColumnName.Rows[0]["SQLLIST"].ToString();

            //起始页
            int startIndex = indexNowPage * paeSize;
            //结束页
            int endIndex = startIndex + paeSize;

            strColumnName = string.IsNullOrEmpty(strColumnName) ?  Convert.ToString (ConfigurationManager.AppSettings["Right_List"]) : strColumnName;
            //Convert.ToString (ConfigurationManager.AppSettings["Right_List"])
            strColumnName= string.Format(strColumnName, uid);
            if (!string.IsNullOrEmpty(filter1))//子工单需要全状态查询
            {
                strColumnName = strColumnName.Substring(0, strColumnName.ToUpper().LastIndexOf("V_MAIN_TOKENLAST", StringComparison.Ordinal));
                strColumnName += " V_MAIN_TOKENLAST B WHERE 1=1 ";
                strColumnName += filter1;
            }
            //strColumnName += filter1;
            //string stationsql = string.Format(" and ACCEPTSTATION in (select v.RESNAME as STATIONNAME  from author_user_all_resource v  where USERID='{0}' and RESCATALOG='{1}')", uid, ConfigurationManager.AppSettings["ShouliAcception"]);
            //filter += stationsql;

            string tempSql = string.Format("{0} {1} {2}", strColumnName, filter, orderby);


            //计算总记录条数
            sql = string.Format(@"SELECT COUNT(*) FROM  ({0})", tempSql);
            DataTable dtSumRows = odb.GetDataSet(sql).Tables[0];
            if (dtSumRows.Rows.Count > 0)
                totalRows = ConvertUtil.ToInt32(dtSumRows.Rows[0][0]);
            else
                totalRows = 0;

            //拼成语句
            sql = string.Format(@" SELECT * FROM (SELECT t.*,ROWNUM rn FROM ({0})t WHERE ROWNUM<={2}) WHERE rn>{1} ", tempSql, startIndex, endIndex);

            Loger.Error("BLL.cs==RunProcedure==>" + sql);
            return odb.GetDataSet(sql).Tables[0];
        }
        catch (Exception ex)
        {
            Loger.Error("连接字符串==========" + DbHelperOra.connectionString + "========执行sql:======" + sql + "=====执行DAL_WebPage中RunProcedure方法出错：" + ex);
            return new DataTable();
        }


    }
}