﻿using System;
using System.Collections.Generic;
using System.Web;

namespace hugegis.Model
{
    //左边菜单列表
    public class Model_PZ_MENUCONFIG
    {
        /// <summary>
        /// 主键编号
        /// </summary>		
        private string _id;
        public string ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// RTID
        /// </summary>		
        private string _rtid;
        public string RTID
        {
            get { return _rtid; }
            set { _rtid = value; }
        }
        /// <summary>
        /// 编码编号
        /// </summary>		
        private string _asiacode;
        public string ASIACODE
        {
            get { return _asiacode; }
            set { _asiacode = value; }
        }
        /// <summary>
        /// 编码名称
        /// </summary>		
        private string _asianame;
        public string ASIANAME
        {
            get { return _asianame; }
            set { _asianame = value; }
        }
        /// <summary>
        /// 父编号
        /// </summary>		
        private string _parentcode;
        public string PARENTCODE
        {
            get { return _parentcode; }
            set { _parentcode = value; }
        }
        /// <summary>
        /// 1,2,3 级别
        /// </summary>		
        private string _nodelevel;
        public string NODELEVEL
        {
            get { return _nodelevel; }
            set { _nodelevel = value; }
        }
        /// <summary>
        /// 排序
        /// </summary>		
        private int _sorted;
        public int SORTED
        {
            get { return _sorted; }
            set { _sorted = value; }
        }
        /// <summary>
        /// 照片目录
        /// </summary>		
        private string _picdic;
        public string PICDIC
        {
            get { return _picdic; }
            set { _picdic = value; }
        }
        /// <summary>
        /// 0，不启用 1，启用
        /// </summary>		
        private string _isvisible;
        public string ISVISIBLE
        {
            get { return _isvisible; }
            set { _isvisible = value; }
        }
        /// <summary>
        /// 0，不显示 1，显示
        /// </summary>		
        private string _tip;
        public string TIP
        {
            get { return _tip; }
            set { _tip = value; }
        }
        /// <summary>
        /// （是否根据流程节点动态创建菜单）0，不创建 1，创建
        /// </summary>		
        private string _iscreate;
        public string ISCREATE
        {
            get { return _iscreate; }
            set { _iscreate = value; }
        }
        /// <summary>
        /// 流程编号
        /// </summary>		
        private string _processid;
        public string PROCESSID
        {
            get { return _processid; }
            set { _processid = value; }
        }
        /// <summary>
        /// 流程节点名称
        /// </summary>		
        private string _processnodename;
        public string PROCESSNODENAME
        {
            get { return _processnodename; }
            set { _processnodename = value; }
        }
        /// <summary>
        /// 记录数
        /// </summary>		
        private string _sqlcount;
        public string SQLCOUNT
        {
            get { return _sqlcount; }
            set { _sqlcount = value; }
        }

    }
}
