﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///Mode_Report_Left 的摘要说明
/// </summary>
public class Mode_Report_Left
{
        /// <summary>
        /// 主键编号
        /// </summary>		
        private string _id;
        public string ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 编码名称
        /// </summary>		
        private string _asianame;
        public string ASIANAME
        {
            get { return _asianame; }
            set { _asianame = value; }
        }
        /// <summary>
        /// 父编号
        /// </summary>		
        private string _parentcode;
        public string PARENTCODE
        {
            get { return _parentcode; }
            set { _parentcode = value; }
        }
        /// <summary>
        /// 排序
        /// </summary>		
        private int _sorted;
        public int SORTED
        {
            get { return _sorted; }
            set { _sorted = value; }
        }
       
        /// <summary>
        /// 0，不启用 1，启用
        /// </summary>		
        private string _isvisible;
        public string ISVISIBLE
        {
            get { return _isvisible; }
            set { _isvisible = value; }
        }
        /// <summary>
        /// 0，不显示 1，显示
        /// </summary>		
        private string _tip;
        public string TIP
        {
            get { return _tip; }
            set { _tip = value; }
        }
      
        /// <summary>
        /// 流程节点名称
        /// </summary>		
        private string _PROCENAME;
        public string PROCENAME
        {
            get { return _PROCENAME; }
            set { _PROCENAME = value; }
        }
}