using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using System.Text;
using Maticsoft.DBUtility;
using hugegis.DBUtility;
using hugegis.Model;
using System;
using System.Data;
using System.Configuration;

//������������

namespace hugegis.DAL
{
    public class DAL_MENUGNFIG
    {
        OracleDataBase odb = new OracleDataBase("0");
        /// <summary>
        ///     �������ݿ����û�ȡ������Ŀ
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public int GetOrderNumber(string strSql)
        {
            if (!string.IsNullOrEmpty(strSql))
            {
                //Loger.Error("GetOrderNumber()==>" + strSql);
                return odb.GetRecordCount(strSql);
            }
            return 0;
        }

        /// <summary>
        ///     ��������ID ��ȡ �˵�����
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public string GetAsianameByID(string _id)
        {
            if (string.IsNullOrEmpty(_id)) return string.Empty;
            string result = "";
            StringBuilder strSql = new StringBuilder(@"select asianame from MENUGNFIG ");
            try
            {
                strSql.AppendFormat(" where id='{0}'", _id);
                strSql.Append(" order by sorted ");
                result = odb.GetScalarInfo(strSql.ToString());

            }
            catch (Exception ex)
            {
                Loger.Error("GetAsianameByID()==>strSql:" + strSql, ex);
            }

            return result;
        }

        /// <summary>
        /// �������ƻ�ȡID
        /// </summary>
        /// <param name="asiaName"></param>
        /// <returns></returns>
        public string GetIdByAsianame(string asiaName)
        {
            if (string.IsNullOrEmpty(asiaName)) return string.Empty;
            string result = "";
            StringBuilder strSql = new StringBuilder(@"select id from MENUGNFIG ");
            try
            {
                //2014��12��17��15:34:30 
                //string checkAdminLeftMenu = ConfigurationManager.AppSettings["checkAdminLeftMenu"].ToString();
                //if (!asiaName.Contains(checkAdminLeftMenu))
                //{
                    strSql.AppendFormat(" where asianame in(select depname from author_department where id='{0}' ) and rownum='1'", asiaName);
                //}
                //else
                //{
                //    strSql.AppendFormat(" where id='{0}'", ConfigurationManager.AppSettings["QiangXiuCenter"].ToString());
                //}
                strSql.Append(" order by sorted ");
                result = odb.GetScalarInfo(strSql.ToString());

            }
            catch (Exception ex)
            {
                Loger.Error("GetIdByAsianame()==>strSql:" + strSql, ex);
            }

            return result;
        }
        /// <summary>
        ///     ��ȡ���������б�
        /// </summary>
        public List<Model_MENUGNFIG> GetList(string _pid)
        {
            //menugnfig.isvisible='1'
            StringBuilder strSql = new StringBuilder(@"SELECT * FROM MENUGNFIG where isvisible='1' ");
            //  Loger.Error("ִ�е�GetList()");
            List<Model_MENUGNFIG> lst = new List<Model_MENUGNFIG>();
            try
            {
                //and  menugnfig.pid = '0'
                strSql.AppendFormat(" and  pid='{0}' ", _pid);
                strSql.Append(" order by sorted ");
                DataSet ds = odb.GetDataSet(strSql.ToString());
                lst = GetList(ds);
            }
            catch (System.Exception ex)
            {
                Loger.Error("GetList()==>strSql:" + strSql, ex);
            }
            return lst;
        }



        public List<Model_MENUGNFIG> GetListByAsiaName(string _pid)
        {
            //menugnfig.isvisible='1'
            StringBuilder strSql = new StringBuilder(@"SELECT * FROM MENUGNFIG where isvisible='1' ");
            //  Loger.Error("ִ�е�GetList()");
            List<Model_MENUGNFIG> lst = new List<Model_MENUGNFIG>();
            try
            {
                //and  menugnfig.pid = '0'
                strSql.AppendFormat(" and  ASIANAME='{0}' and rownum=1", _pid);
                strSql.Append(" order by sorted ");
                DataSet ds = odb.GetDataSet(strSql.ToString());
                lst = GetList(ds);
            }
            catch (System.Exception ex)
            {
                Loger.Error("GetList()==>strSql:" + strSql, ex);
            }
            return lst;
        }
        ///// <summary>
        /////     ��DbDataReader�õ����������б�
        ///// </summary>
        //private List<Model_MENUGNFIG> GetList(DbDataReader dr)
        //{
        //    List<Model_MENUGNFIG> lst = new List<Model_MENUGNFIG>();
        //    while (dr.Read())
        //    {
        //        lst.Add(GetModel(dr));
        //    }
        //    return lst;
        //}

        /// <summary>
        ///     ��DbDataReader�õ����������б�
        /// </summary>
        private List<Model_MENUGNFIG> GetList(DataSet ds)
        {
            Model_MENUGNFIG model_MENUGNFIG = null;
            List<Model_MENUGNFIG> lst = new List<Model_MENUGNFIG>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                model_MENUGNFIG = new Model_MENUGNFIG();
                PrepareModel(model_MENUGNFIG, ds.Tables[0].Rows[i]);
                lst.Add(model_MENUGNFIG);
            }
            return lst;
        }

        /// <summary>
        ///     ��һ�����ݵõ�һ��ʵ��
        /// </summary>
        private Model_MENUGNFIG GetModel(DbDataReader dr)
        {
            Model_MENUGNFIG model = new Model_MENUGNFIG();
            PrepareModel(model, dr);
            return model;
        }

        /// <summary>
        /// </summary>
        /// <param name="model"></param>
        /// <param name="dr"></param>
        private void PrepareModel(Model_MENUGNFIG model, DataRow dr)
        {
            model.Id = ConvertUtil.ToString(dr["id"]);
            model.Asianame = ConvertUtil.ToString(dr["Asianame"]);
            model.Pid = ConvertUtil.ToString(dr["Pid"]);
            model.Sorted = ConvertUtil.ToString(dr["Sorted"]);
            model.Sqlcount = ConvertUtil.ToString(dr["Sqlcount"]);
            model.Picdic = ConvertUtil.ToString(dr["Picdic"]);
            model.Nodelevel = ConvertUtil.ToString(dr["Nodelevel"]);
            model.Isvisible = ConvertUtil.ToString(dr["Isvisible"]);
            model.Iscreate = ConvertUtil.ToString(dr["Iscreate"]);
            model.Tip = ConvertUtil.ToString(dr["Tip"]);
            model.Isadd = ConvertUtil.ToString(dr["Isadd"]);
        }

        /// <summary>
        /// </summary>
        /// <param name="model"></param>
        /// <param name="dr"></param>
        private void PrepareModel(Model_MENUGNFIG model, DbDataReader dr)
        {
            model.Id = ConvertUtil.ToString(dr["id"]);
            model.Asianame = ConvertUtil.ToString(dr["Asianame"]);
            model.Pid = ConvertUtil.ToString(dr["Pid"]);
            model.Sorted = ConvertUtil.ToString(dr["Sorted"]);
            model.Sqlcount = ConvertUtil.ToString(dr["Sqlcount"]);
            model.Picdic = ConvertUtil.ToString(dr["Picdic"]);
            model.Nodelevel = ConvertUtil.ToString(dr["Nodelevel"]);
            model.Isvisible = ConvertUtil.ToString(dr["Isvisible"]);
            model.Iscreate = ConvertUtil.ToString(dr["Iscreate"]);
            model.Tip = ConvertUtil.ToString(dr["Tip"]);
            model.Isadd = ConvertUtil.ToString(dr["Isadd"]);
        }
    }
}