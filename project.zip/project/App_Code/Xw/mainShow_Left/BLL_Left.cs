using System.Collections.Generic;
using hugegis.Model;
using System.Text;
using System.Collections;

namespace hugegis.BLL.BLL_WebPage
{
    public class BLL_Left
    {
        public readonly BLL_MENUGNFIG bll = new BLL_MENUGNFIG();

        #region

        /// <summary>
        ///     ��ȡ���������б�
        /// </summary>
        public List<Model_MENUGNFIG> GetList(string _pid)
        {
            return bll.GetList(_pid);
        }


        public List<Model_MENUGNFIG> GetListByAsiaName(string asiaName)
        {
            return bll.GetListByAsiaName(asiaName);
        }

        /// <summary>
        ///     �������ݿ����û�ȡ������Ŀ
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public int GetOrderNumber(string strSql)
        {
            return bll.GetOrderNumber(strSql);
        }

        /// <summary>
        ///     ��������ID ��ȡ �˵�����
        /// </summary>
        /// <param name="_id"></param>
        /// <returns></returns>
        public string GetAsianameByID(string _id)
        {
            return bll.GetAsianameByID(_id);
        }
        /// <summary>
        ///  �������ò˵����� ��ȡ ID 
        /// </summary>
        /// <param name="asiaName"></param>
        /// <returns></returns>
        public string GetIdByAsianame(string asiaName)
        {
            return bll.GetIdByAsianame(asiaName.Trim());
        }
        /// <summary>
        /// ���ݽ�ɫ������Ϣ����ȡ��ǰ��ɫ�Ĳ˵�
        /// </summary>
        /// <param name="_uid">ϵͳ��¼��</param>
        /// <param name="_pid">��ǰ�ڵ��ţ�ParentCode��</param>
        /// <returns></returns>
        public List<Model_PZ_MENUCONFIG> GetList(string _uid, string _pid)
        {
            return DAL_AuthorGlobal.GetMenuCongif(_uid, _pid);
        }
        /// <summary>
        /// ��arraylist�ֵĵ�ֵ��� 'ֵ',��ʽ���ַ���
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public string ConvertArrayListToString(ArrayList list)
        {
            if (list == null || list.Count < 0) return string.Empty;
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < list.Count; i++)
            {
                if (i == list.Count - 1)
                {
                    result.Append(string.Format("'{0}'", list[i].ToString()));
                }
                else
                {
                    result.Append(string.Format("'{0}',", list[i].ToString()));
                }
            }
            return result.ToString();
        }
        #endregion
    }
}