﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
///SqlHelper 的摘要说明
/// </summary>
public class SqlHelper
{
    public SqlHelper()
    {
        //
        //TODO: 在此处添加构造函数逻辑
        //
    }

    public static readonly string connectionString = GetConnectionstring();// ConfigurationManager.ConnectionStrings["ZLSWXFWDB"].ConnectionString;
    // public static readonly string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

    //public static readonly string gws = ConfigurationManager.AppSettings["gws"];

    private static string GetConnectionstring()
    {
        bool ConStringEncrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]);
        string connstring = ConfigurationManager.ConnectionStrings["ZLSWXFWDB"].ConnectionString;
        if (ConStringEncrypt)
        {
            connstring = Global.Decode(connstring);
        }
        return connstring;
    }

    public static void AddDropDownListData(DropDownList drop)
    {
        string[] list = ConfigurationManager.AppSettings["gws"].Split(',');

        for (int i = 0; i < list.Length; i++)
        {
            drop.Items.Add(new ListItem(list[i].Replace("'", ""), list[i].Replace("'", "")));
        }
    }
    public static void AddDDListSteptype(DropDownList drop)
    {
        string[] list = ConfigurationManager.AppSettings["steptype"].Split(',');

        for (int i = 0; i < list.Length; i++)
        {
            drop.Items.Add(new ListItem(list[i].Replace("'", ""), list[i].Replace("'", "")));
        }
    }
    public static void AddDropDownListAll(DropDownList drop)
    {
        string[] list = ConfigurationManager.AppSettings["all"].Split(',');
        drop.Items.Add(new ListItem("--请选择--", "--请选择--"));
        for (int i = 0; i < list.Length; i++)
        {
            drop.Items.Add(new ListItem(list[i].Replace("'", ""), list[i].Replace("'", "")));
        }
    }

    public static void AddDropDownListDatas(DropDownList drop)
    {
        drop.Items.Clear();
        drop.Items.Add(new ListItem("管网技术科", "管网技术科"));
        AddDropDownListData(drop);

    }
}
