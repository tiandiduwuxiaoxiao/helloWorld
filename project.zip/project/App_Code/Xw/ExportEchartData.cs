﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using Maticsoft.DBUtility;
using System.Web.SessionState;
/// <summary>
///ExportEchartData 的摘要说明
/// </summary>
public class ExportEchartData : IRequiresSessionState
{

    public string uid = "";

    List<string> categoryList = new List<string>();

    List<string> legendList = new List<string>();

    List<Series> seriesList = new List<Series>();

    Hashtable hash = new Hashtable();

	public ExportEchartData()
	{
        if (HttpContext.Current.Session["uid"] != null) uid =Convert.ToString(HttpContext.Current.Session["uid"]);
	}

    /// <summary>
    ///  总工单数，完结数，及时数统计
    /// </summary>
    ///
    public void loadOrderChars(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();
        string title_text = "总工单数完结数及时数统计";
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            dateFormat = "YYYY";
            condtionSql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            dateFormat = "yyyy-mm-dd";
            condtionSql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        //数据获取
        string sql = @"select statustype,to_char(accepttime,'" + dateFormat + @"') accepttime ,count(*) as sum from (select t.*,'总数' statustype from tz_main t
                        union all
                        select t.*,'完结' statustype from tz_main t where t.tokenname='结束'
                        union all
                        select t.*,'及时' statustype from tz_main t join tz_main_clinfo c on t.id = c.main_id where c.CLINTIME='及时') m where 1=1  and ISXJSH='1'";
        sql += condtionSql;
        sql += " group by statustype,to_char(accepttime,'" + dateFormat + "') order by statustype,accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["statustype"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }

        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("日期", typeof(string));  //为datatable添加一些列

        //图例
        legendList.Add("总数");
        legendList.Add("完结");
        legendList.Add("及时");
        dtable.Columns.Add("总数");
        dtable.Columns.Add("完结");
        dtable.Columns.Add("及时");
        //x轴
        computationTime(num, type);
        //设置数据
        for (int j = 0; j < categoryList.Count(); j++)
        {
            DataRow dr = dtable.NewRow();
            dr["日期"] = Convert.ToString(categoryList[j]);
            for (int i = 0; i < legendList.Count(); i++)
            {
                string legName = legendList[i];
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                dr[legName] = tmpValue;
            }
            dtable.Rows.Add(dr);
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, title_text);
    }

    /// <summary>
    /// 开单数统计
    /// </summary>
    ///
    public void loadLineChars(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();
        string title_text = "开单数统计";
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //参数获取
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            dateFormat = "YYYY";
            condtionSql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            dateFormat = "yyyy-mm-dd";
            condtionSql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }

        //数据获取
        string sql = "select acceptstation,to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum from tz_main where 1=1 ";
        sql += condtionSql;
        sql += " group by acceptstation,to_char(accepttime,'" + dateFormat + "') order by acceptstation,accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["acceptstation"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }

        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("日期", typeof(string));  //为datatable添加一些列

        //图例
        ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid);
        for (int i = 0; i < list.Count; i++)
        {
            legendList.Add(list[i].ToString());
            dtable.Columns.Add(list[i].ToString(), typeof(string));  //为datatable添加一些列
        }
        //x轴
        computationTime(num, type);
        //设置数据
        for (int j = 0; j < categoryList.Count(); j++)
        {
            DataRow dr =dtable.NewRow();
            dr["日期"] =Convert.ToString(categoryList[j]);
            for (int i = 0; i < legendList.Count(); i++)
            {
                string legName = legendList[i];
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                dr[legName] = tmpValue;
            }
            dtable.Rows.Add(dr);  
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, title_text);
    }
    /// <summary>
    /// 站点数统计
    /// </summary>
    public void loadStationChart(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        string title_text = string.Empty;
        //数据获取
        string sql = "select acceptstation as key,count(*) as sum from tz_main where 1=1  and ISXJSH='1' ";
        if (type == "day")
        {
            title_text = "本月站点统计";
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月站点统计";
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年站点统计";
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text = "站点统计";
            sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        sql += "  group by acceptstation";
        DataSet ds = DbHelperOra.Query(sql);

        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("区域", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("数量", typeof(string));  //为datatable添加一些列
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dRow = dtable.NewRow();
                dRow["区域"] = Convert.ToString(dt.Rows[i]["key"]);
                dRow["数量"] = Convert.ToString(dt.Rows[i]["sum"]);
                dtable.Rows.Add(dRow);  
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "站点数统计");
    }

    /// <summary>
    /// 维修用时
    /// </summary>
    public void loadUSETIMELineChars(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        string title_text = string.Empty;
        string dateFormat = string.Empty;
        string condtionSql = string.Empty;
        if (type == "day")
        {
            title_text = "工单维修用时统计";
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月工单维修用时统计";
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年工单维修用时统计";
            dateFormat = "YYYY";
            condtionSql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text = "工单维修用时统计";
            dateFormat = "yyyy-mm-dd";
            condtionSql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        string sql = "select useType ,to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum from v_usetimetype where 1=1  and ISXJSH='1'";
        sql += condtionSql;
        sql += " group by useType,to_char(accepttime,'" + dateFormat + "') order by useType,accepttime";
        DataSet ds = DbHelperOra.Query(sql);

        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("时段", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("时间", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("数量", typeof(string));  //为datatable添加一些列
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dRow = dtable.NewRow();
                dRow["时段"] = Convert.ToString(dt.Rows[i]["useType"]);
                dRow["时间"] = Convert.ToString(dt.Rows[i]["accepttime"]);
                dRow["数量"] = Convert.ToString(dt.Rows[i]["sum"]);
                dtable.Rows.Add(dRow);
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "工单维修用时统计");
    }
    /// <summary>
    /// 实际类别统计
    /// </summary>
    public void loadFaultChart(string num, string type, string fault_parentType, string TypeName, string PianStation)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        hash.Clear();
        //数据获取
        string sql = "select parentType as key,count(*) sum  from v_tz_main_clinfo t left join v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype where 1=1  and parentType is not null ";
        if (fault_parentType == "parent") { sql = "select parentType as key,count(*) sum  from v_tz_main_clinfo t left join v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype where 1=1  and parentType is not null "; }
        else if (fault_parentType == "reporttype") { sql = "select t.SJCLLX as key, count(*) sum from v_tz_main_clinfo t left join  v_PZ_REPORTTYPE r on t.SJCLLX = r.reporttype  where 1=1  and parentType is not null "; }
        else if (fault_parentType == "reportcontent") { sql = "select SJCLNR as key,count(*) as sum from v_tz_main_clinfo where 1=1 and ISXJSH='1'  "; }
        if (type == "day")
        {
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            if (!string.IsNullOrWhiteSpace(EndTime) && !string.IsNullOrWhiteSpace(startTime))
            {
                sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
            }
        }
        if (!string.IsNullOrWhiteSpace(PianStation))
        {
            sql += string.Format(" and PianStation='{0}'", PianStation);
        }

        if (fault_parentType == "parent") { sql += "  group by parentType"; }
        else if (fault_parentType == "reporttype") { sql += string.Format(" and parentType='{0}'  group by t.SJCLLX", TypeName); }
        else if (fault_parentType == "reportcontent") { sql += string.Format("  and SJCLLX='{0}'    group by SJCLNR ", TypeName); }
        else sql += "  group by parentType";
        DataSet ds = DbHelperOra.Query(sql);
        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("类别", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("数量", typeof(string));  //为datatable添加一些列
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dRow = dtable.NewRow();
                dRow["类别"] = Convert.ToString(dt.Rows[i]["key"]);
                dRow["数量"] = Convert.ToString(dt.Rows[i]["sum"]);
                dtable.Rows.Add(dRow);
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "类别统计");

    }
    /// <summary>
    /// 反映类别统计
    /// </summary>
    public void loadFaultReporittypeChart(string num, string type, string fault_parentType, string TypeName)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        hash.Clear();
        //数据获取
        string sql = "select parentType as key,count(*) sum  from tz_main t left join v_PZ_REPORTTYPE r on t.reporttype = r.reporttype where 1=1  and parentType is not null ";
        if (fault_parentType == "parent") { sql = "select parentType as key,count(*) sum  from tz_main t left join v_PZ_REPORTTYPE r on t.reporttype = r.reporttype where 1=1  and parentType is not null "; }
        else if (fault_parentType == "reporttype") { sql = "select t.reporttype as key, count(*) sum from tz_main t left join  v_PZ_REPORTTYPE r on t.reporttype = r.reporttype  where 1=1  and parentType is not null "; }
        else if (fault_parentType == "reportcontent") { sql = "select reportcontent as key,count(*) as sum from tz_main where 1=1 and ISXJSH='1'  "; }
        if (type == "day")
        {
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            if (!string.IsNullOrWhiteSpace(EndTime) && !string.IsNullOrWhiteSpace(startTime))
            {
                sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
            }
        }
        if (fault_parentType == "parent") { sql += "  group by parentType"; }
        else if (fault_parentType == "reporttype") { sql += string.Format(" and parentType='{0}'  group by t.REPORTTYPE", TypeName); }
        else if (fault_parentType == "reportcontent") { sql += string.Format("  and REPORTTYPE='{0}'    group by reportcontent ", TypeName); }
        else sql += "  group by parentType";
        DataSet ds = DbHelperOra.Query(sql);
        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("类别", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("数量", typeof(string));  //为datatable添加一些列
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dRow = dtable.NewRow();
                dRow["类别"] = Convert.ToString(dt.Rows[i]["key"]);
                dRow["数量"] = Convert.ToString(dt.Rows[i]["sum"]);
                dtable.Rows.Add(dRow);
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "类别统计");

    }
    /// <summary>
    /// 在线人数统计
    /// </summary>
    public void loadOnLineTimeChars(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();

        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")//按天统计
        {
            legendList.Add("最近" + num + "天在线人数"); //图例
            dateFormat = "YYYY-MM-DD";
            condtionSql = " and to_char(rq, 'yyyy-mm-dd') > to_char(sysdate - " + num + ", 'yyyy-mm-dd')";
            computationTime(num, type);
        }
        else if (type == "hours")//按小时
        {
            if (num == "today")//当天 
            {
                legendList.Add("当天在线人数"); //图例
                condtionSql = " and to_char(rq,'YYYY-MM-DD')= to_char(sysdate, 'yyyy-mm-dd')";
            }
            else if (num == "yesterday")//昨天
            {
                legendList.Add("昨天在线人数"); //图例
                condtionSql = " and to_char(rq,'YYYY-MM-DD')= to_char(sysdate - 1, 'yyyy-mm-dd')";
            }
            dateFormat = "hh24";

            //x轴
            computationTime(num, type);

        }

        //数据获取
        string sql = " select to_char(rq,'" + dateFormat + "') rq ,count(*) as sum from t_logginginfo_bs ,(select max(rq) maxrq,username uname from t_logginginfo_bs  where type = '登录'  group by to_char(rq,'YYYY-MM-DD'),username order by maxrq desc) b where rq=b.maxrq and username=b.uname ";
        sql += condtionSql;
        sql += "group by to_char(rq,'" + dateFormat + "') order by rq";

        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["rq"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("日期", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("在线人数", typeof(string));  //为datatable添加一些列
        //图表赋值
        for (int i = 0; i < legendList.Count(); i++)
        {
            string legName = legendList[i];
            //设置数据
            for (int j = 0; j < categoryList.Count(); j++)
            {
                int tmpValue = Convert.ToInt32(hash[categoryList[j]]);
                DataRow dRow = dtable.NewRow();
                dRow["日期"] = Convert.ToString(categoryList[j]);
                dRow["在线人数"] = Convert.ToString(tmpValue);
                dtable.Rows.Add(dRow);
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "在线人数统计");
    }

    /// <summary>
    /// 平均在线时长、平均访问次数统计
    /// </summary>
    public void loadOnLineOrVisitsChars(string num, string type,string chartType)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();

        string dateFormat = "";
        string condtionSql = "";
        string cTitle ="";
   
        if(chartType=="0")
        {
            cTitle="平均在线时长";
        }else
        {
            cTitle = "平均访问次数";
        }

        if (type == "day")
        {
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(rq, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            dateFormat = "YYYY-MM";
            condtionSql += " and rq between add_months(sysdate,-" + num + ") and sysdate";
        }

        //x轴
        computationTime(num, type);


        //数据获取
        string sql = " select to_char(rq,'" + dateFormat + "') rq ,count(*) as sum from t_logginginfo_bs ,(select max(rq) maxrq,username uname from t_logginginfo_bs  where type = '登录'  group by to_char(rq,'YYYY-MM-DD'),username order by maxrq desc) b where rq=b.maxrq and username=b.uname ";
        sql += condtionSql;
        sql += " group by to_char(rq,'" + dateFormat + "') order by rq";

        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["rq"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }
        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("日期", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add(cTitle, typeof(string));  //为datatable添加一些列
        //设置数据
        for (int j = 0; j < categoryList.Count(); j++)
        {
            int tmpValue = Convert.ToInt32(hash[categoryList[j]]);
            DataRow dRow = dtable.NewRow();
            dRow["日期"] = Convert.ToString(categoryList[j]);
            dRow[cTitle] = Convert.ToString(tmpValue);
            dtable.Rows.Add(dRow);
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, cTitle);
    }

    /// <summary>
    /// 工单数和拍照数统计
    /// </summary>
    public void loadWorkOrderAndPicCountChars(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();

        //参数获取
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        //数据获取
        string sql = "select to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum,sum(piccount) piccount from (select b.*,(select count(*) from track_media where mediatype is null and eventrecordid=b.id) as piccount from  tz_main b) where 1=1 ";
        sql += condtionSql;
        sql += " group by to_char(accepttime,'" + dateFormat + "') order by accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = "工单数" + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
                string key1 = "拍照数" + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value1 = Convert.ToString(dt.Rows[i]["piccount"]);
                hash.Add(key1, value1);
            }
        }
     
        //x轴
        computationTime(num, type);

        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("日期", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("工单数", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("拍照数", typeof(string));  //为datatable添加一些列

        //图表赋值
        //设置数据
        for (int j = 0; j < categoryList.Count(); j++)
        {

            int tmpValue1 = Convert.ToInt32(hash["工单数" + categoryList[j]]);
            int tmpValue2 = Convert.ToInt32(hash["拍照数" + categoryList[j]]);

            DataRow dr = dtable.NewRow();
            dr["日期"] = Convert.ToString(categoryList[j]);
            dr["工单数"] = tmpValue1;
            dr["拍照数"] = tmpValue2;
            dtable.Rows.Add(dr);
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "工单数和拍照数统计");
  
    }

    /// <summary>
    /// 使用流量(GB)统计
    /// </summary>
    public void loadNetWorkTrafficChars(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        hash.Clear();

        //参数获取
        string dateFormat = "";
        string condtionSql = "";
        if (type == "day")
        {
            dateFormat = "YYYY-MM-DD";
            condtionSql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            dateFormat = "YYYY-MM";
            condtionSql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }

        //数据获取
        string sql = "select acceptstation,to_char(accepttime,'" + dateFormat + "') accepttime ,count(*) as sum from tz_main where 1=1 ";
        sql += condtionSql;
        sql += " group by acceptstation,to_char(accepttime,'" + dateFormat + "') order by acceptstation,accepttime";
        DataSet ds = DbHelperOra.Query(sql);
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string key = Convert.ToString(dt.Rows[i]["acceptstation"]) + Convert.ToString(dt.Rows[i]["accepttime"]);
                string value = Convert.ToString(dt.Rows[i]["sum"]);
                hash.Add(key, value);
            }
        }

        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("日期", typeof(string));  //为datatable添加一些列

        //图例
        ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid);
        for (int i = 0; i < list.Count; i++)
        {
            legendList.Add(list[i].ToString());
            dtable.Columns.Add(list[i].ToString(), typeof(string));  //为datatable添加一些列
        }
        //x轴
        computationTime(num, type);

        //设置数据
        for (int j = 0; j < categoryList.Count(); j++)
        {
            DataRow dr = dtable.NewRow();
            dr["日期"] = Convert.ToString(categoryList[j]);
            for (int i = 0; i < legendList.Count(); i++)
            {
                string legName = legendList[i];
                int tmpValue = Convert.ToInt32(hash[legName + categoryList[j]]);
                dr[legName] = tmpValue;
            }
            dtable.Rows.Add(dr);
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, "使用流量统计");

    }

    /// <summary>
    /// 时间数组
    /// </summary>
    /// <param name="num">减去的数量</param>
    /// <param name="type">时间类型，day=按天，month=按月,year=按年</param>
    /// <returns></returns>
    public void computationTime(string num, string type)
    {
        categoryList.Clear();
        string[] time = num.Split('|');
        DateTime startTime = DateTime.Now;
        DateTime EndTime = DateTime.Now;

        if (time.Length >= 2)
        {
            startTime = Convert.ToDateTime(time[0]);
            EndTime = Convert.ToDateTime(time[1]);
            TimeSpan ts1 = new TimeSpan(startTime.Ticks);
            TimeSpan ts2 = new TimeSpan(EndTime.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            num = ts.Days.ToString();
        }
        categoryList.Clear();
        if (num.ToLower() == "today" || num.ToLower() == "yesterday")//今天，昨天
        {
            for (int i = 0; i < 24; i++)
            {
                categoryList.Add(i <= 9 ? "0" + Convert.ToString(i) : Convert.ToString(i));
            }
        }
        else
        {
            for (int i = Convert.ToInt32(num) - 1; i >= 0; i--)
            {
                if (type == "day")
                {
                    categoryList.Add(DateTime.Today.AddDays(Convert.ToInt32("-" + i)).ToString("yyyy-MM-dd"));
                }
                else if (type == "month")
                {
                    categoryList.Add(DateTime.Today.AddMonths(Convert.ToInt32("-" + i)).ToString("yyyy-MM"));
                }
                else if (type == "year")
                {
                    categoryList.Add(DateTime.Today.AddYears(Convert.ToInt32("-" + i)).ToString("yyyy"));
                }
                if (type == "time")
                {
                    categoryList.Add(DateTime.Today.AddDays(Convert.ToInt32("-" + i)).ToString("yyyy-MM-dd"));
                }
            }
        }
        //if (num.ToLower() == "lastmonth")
        //{
        //    DateTime dt = new DateTime().AddMonths(-1);
        //    int days = DateTime.DaysInMonth(dt.Year,dt.Month);
        //    for (int i = 0; i < days; i++)
        //    {
        //        string tmpDay = i <= 9 ? "0" + Convert.ToString(i) : Convert.ToString(i);
        //        categoryList.Add(dt.Year + "-" + dt.Month + "-" + tmpDay);
        //    }
        //}
    }
    
    public void btn_OccurreasonChartTable_Click(string num, string type)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        string title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //数据获取
        string sql = "select sum(B1+B2+b3+B4) as sum,SCORE_GP  as key from ( select * from v_tj_accepttime where 1=1 ";
        if (type == "day")
        {
            title_text = "本月时段统计";
            sql += " and to_char(accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "最近" + num + "月时段统计";
            sql += " and accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "最近" + num + "年时段统计";
            sql += " and to_char(accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            title_text = "工单时段统计";
            sql += " and accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
        }
        sql += "  ) group  by SCORE_GP";
       
        DataSet ds = DbHelperOra.Query(sql);
        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("时间段", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("数量", typeof(string));  //为datatable添加一些列
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dRow = dtable.NewRow();
                dRow["时间段"] = Convert.ToString(dt.Rows[i]["key"]);
                dRow["数量"] = Convert.ToString(dt.Rows[i]["sum"]);
                dtable.Rows.Add(dRow);
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, title_text);
    }
    public  void loadOccurreasonChart(string num, string type, string PianStation)
    {
        //清空资源
        categoryList.Clear();
        seriesList.Clear();
        legendList.Clear();
        string title_text = "";
        hash.Clear();
        string startTime = string.Empty;
        string EndTime = string.Empty;
        //数据获取
        string sql = "select Occurreason as key,count(*) as sum from v_tz_main_clinfo c,tz_main t where t.id=c.id and t.ISXJSH='1'  and Occurreason is not null    ";
        if (type == "day")
        {
            title_text = "发生原因统计";
            sql += " and to_char(t.accepttime, 'yyyy-mm-dd') between to_char(sysdate - " + num + ", 'yyyy-mm-dd') and to_char(sysdate, 'yyyy-mm-dd')";
        }
        else if (type == "month")
        {
            title_text = "发生原因统计";
            sql += " and t.accepttime between add_months(sysdate,-" + num + ") and sysdate";
        }
        else if (type == "year")
        {
            title_text = "发生原因统计";
            sql += " and to_char(t.accepttime, 'yyyy') between to_char(sysdate, 'YYYY')-" + num + " and to_char(sysdate, 'yyyy') ";
        }
        else if (type == "time")
        {
            string[] time = num.Split('|');
            if (time.Length >= 1)
            {
                startTime = time[0];
            }
            if (time.Length >= 2)
            {
                EndTime = time[1];
            }
            if (!string.IsNullOrWhiteSpace(EndTime) && !string.IsNullOrWhiteSpace(startTime))
            {
                title_text = "发生原因统计";
                sql += " and t.accepttime  between to_date('" + startTime + "', 'yyyy-mm-dd') and to_date('" + EndTime + "', 'yyyy-mm-dd') ";
            }
            if (!string.IsNullOrEmpty(PianStation))
            {
                sql += string.Format(" and PianStation ='{0}'", PianStation);
            }
        }
        sql += "  group by Occurreason ";
        DataSet ds = DbHelperOra.Query(sql);
        DataTable dtable = new DataTable("MyDT");  //实例一个空datatable
        dtable.Columns.Add("发生原因", typeof(string));  //为datatable添加一些列
        dtable.Columns.Add("数量", typeof(string));  //为datatable添加一些列
        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dRow = dtable.NewRow();
                dRow["发生原因"] = Convert.ToString(dt.Rows[i]["key"]);
                dRow["数量"] = Convert.ToString(dt.Rows[i]["sum"]);
                dtable.Rows.Add(dRow);
            }
        }
        DataSet dSet = new DataSet();//创建数据集
        dSet.Tables.Add(dtable);
        ExcelExport.CommExportExcel(dSet, null, title_text);

    }
}