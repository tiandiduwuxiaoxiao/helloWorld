﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Device.DB;
using Device.Model;

namespace Device.DAO
{
    /// <summary>
    /// DeviceTypeDAO 的摘要说明：关于设备类别管理业务处理类
    /// </summary>
    public class DeviceTypeDAO
    {
        private string errMessage;  /*保存业务处理错误信息*/
        public string getErrMessage() { return this.errMessage; }
        public DeviceTypeDAO() { this.errMessage = ""; }

        /*查询所有的设备类别信息*/
        public static DataSet QueryAllDeviceType()
        {
            string sqlString = "select * from t_device_type";
            OracleDataBase db = new OracleDataBase();
            return db.GetDataSet(sqlString);
        }

        /*根据类别编号得到类别名称*/
        public static string GetTypeNameById(int typeId)
        {
            string typeName = "";
            string queryString = "select typeName from t_device_type where typeId=" + typeId;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceTypeDs = db.GetDataSet(queryString);
            if (deviceTypeDs.Tables[0].Rows.Count > 0)
            {
                DataRow dr = deviceTypeDs.Tables[0].Rows[0];
                typeName = dr["typeName"].ToString();
            }

            return typeName;
        }

        /*更新某个设备类别*/
        public bool UpdateDeviceType(int typeId, string typeName)
        {
            string queryString = "select * from t_device_type where typeName='" + typeName + "' and typeId <>" + typeId;
            OracleDataBase db = new OracleDataBase();
            DataSet ds = db.GetDataSet(queryString);
            if (ds.Tables[0].Rows.Count > 0)
            {
                this.errMessage = "改类别已经存在!";
                return false;
            }
            string updateString = "update t_device_type set typeName='" + typeName + "' where typeId=" + typeId;
            if (db.InsertOrUpdate(updateString) < 0)
            {
                this.errMessage = "更新失败!";
                return false;
            }
            return true;
        }

        /*删除某个设备类别*/
        public bool DeleteDeviceType(int typeId)
        {
            string queryString = "select * from t_device_backup where typeId=" + typeId;
            OracleDataBase db = new OracleDataBase();
            DataSet ds = db.GetDataSet(queryString);
            if (ds.Tables[0].Rows.Count > 0)
            {
                this.errMessage = "备用备件中还存在本类别的设备!不能删除!";
                return false;
            }
            queryString = "select * from t_device_using where typeId=" + typeId;
            ds = db.GetDataSet(queryString);
            if (ds.Tables[0].Rows.Count > 0)
            {
                this.errMessage = "在用设备中还存在本类别的设备!不能删除!";
                return false;
            }
            queryString = "select * from t_device_useless where typeId=" + typeId;
            ds = db.GetDataSet(queryString);
            if (ds.Tables[0].Rows.Count > 0)
            {
                this.errMessage = "报废设备中还存在本类别的设备!不能删除!";
                return false;
            }

            string deleteString = "delete from t_device_type where typeId=" + typeId;
            if (db.InsertOrUpdate(deleteString) < 0)
            {
                this.errMessage = "删除类别失败！";
                return false;
            }

            return true;
        }

        /*添加设备类别信息*/
        public bool AddDeviceType(string typeName)
        {
            string queryString = "select * from t_device_type where typeName=" + SqlString.GetQuotedString(typeName);
            OracleDataBase db = new OracleDataBase();
            DataSet ds = db.GetDataSet(queryString);
            if (ds.Tables[0].Rows.Count > 0)
            {
                this.errMessage = "改类别名称已经存在！";
                return false;
            }
            string insertString = "insert into t_device_type (typeName) values ('" + typeName + "')";
            if (db.InsertOrUpdate(insertString) < 0)
            {
                this.errMessage = "添加类别失败!";
                return false;
            }

            return true;
        }
    }

}
