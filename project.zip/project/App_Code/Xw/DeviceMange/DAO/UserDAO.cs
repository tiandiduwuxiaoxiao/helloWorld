﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Device.Model;
using Device.DB;

namespace Device.DAO
{
    /// <summary>
    /// UserInfoDAO 的摘要说明:关于用户信息处理的逻辑层
    /// </summary>
    public class UserDAO
    {
        private string errMessage;  /*存储业务处理错误信息*/
        public string getErrMessage() { return this.errMessage; }
        public UserDAO(){this.errMessage = String.Empty;}
        
        
        //判断用户的登陆管理权限
        public bool checkLogin(UserModel userModel)
        {
            string queryString;
            bool hasUser, isPasswordRight;

            //首先在数据库中查询该管理帐号是否存在
            queryString = "select * from t_user where username = " + SqlString.GetQuotedString(userModel.getUsername());
            OracleDataBase db = new OracleDataBase();
            hasUser = db.GetRecord(queryString);
            if (false == hasUser)
            {
                errMessage = "对不起，用户名不存在!";
                return false;
            }

            //再查询数据库该管理帐号的密码是否正确
            queryString = "select * from t_user where username = " + SqlString.GetQuotedString(userModel.getUsername());
            queryString = queryString + " and password = " + SqlString.GetQuotedString(userModel.getPassword());
            isPasswordRight = db.GetRecord(queryString);
            if (false == isPasswordRight)
            {
                errMessage = "对不起，用户密码错误!";
                return false;
            }

            return true;
        }

        
        //修改登陆密码
        public bool ChangePassword(UserModel userModel)
        {
            string updateString = "update t_user set password=" + SqlString.GetQuotedString(userModel.getPassword());
            updateString += " where username=" + SqlString.GetQuotedString(userModel.getUsername());

            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(updateString) < 0)
                return false;
            return true;
        }

        /*加入新的用户信息*/
        public bool AddUserInfo(UserModel userModel)
        {
            string queryString = "select count(*) from t_user where username=" + SqlString.GetQuotedString(userModel.getUsername());
            OracleDataBase db = new OracleDataBase();
            if (db.GetRecordCount(queryString) > 0)
            {
                this.errMessage = "该用户名已经存在!";
                return false;
            }
            string insertString = "insert into t_user (username,password) values (";
            insertString += SqlString.GetQuotedString(userModel.getUsername()) + ",";
            insertString += SqlString.GetQuotedString(userModel.getPassword()) + ")";
            if (db.InsertOrUpdate(insertString) < 0)
            {
                this.errMessage = "添加用户信息时发生了错误！";
                return false;
            }
            return true;
        }

        /*删除某个用户记录*/
        public bool DelUserInfo(string username)
        {
            string deleteString = "delete from t_user where username=" + SqlString.GetQuotedString(username);
            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(deleteString) < 0)
            {
                this.errMessage = "删除用户发生了错误！";
                return false;
            }
            return true;
        }

    }

}

