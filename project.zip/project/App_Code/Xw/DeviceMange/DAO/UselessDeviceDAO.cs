﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Device.DB;
using Device.Model;

namespace Device.DAO
{
    /// <summary>
    /// UselessDeviceDAO 的摘要说明：关于报废设备管理的业务处理类
    /// </summary>
    public class UselessDeviceDAO
    {
        private string errMessage;
        public string getErrMessage() { return this.errMessage; }
        public UselessDeviceDAO() { this.errMessage = ""; }

        /*登记报废设备信息*/
        public static bool AddUselessDevice(UselessDeviceModel uselessDevice)
        {
            string insertString = "insert into t_device_useless (typeId,deviceName,deviceModel,deviceFrom,deviceCount,AUTHOR,AUTHORDATE,USEPLACE) values (";
            insertString += uselessDevice.getTypeId() + ",";
            insertString += SqlString.GetQuotedString(uselessDevice.getDeviceName()) + ",";
            insertString += SqlString.GetQuotedString(uselessDevice.getDeviceModel()) + ",";
            insertString += SqlString.GetQuotedString(uselessDevice.getDeviceFrom()) + ",";
            insertString += uselessDevice.getDeviceCount() + ",";
            insertString +=  SqlString.GetQuotedString(uselessDevice.Author) + ",";
            insertString +="sysdate,";
            insertString += SqlString.GetQuotedString(uselessDevice.UsePlace) + ")";

            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(insertString) > 0)
                return true;
            return false;
           
        }

        /*更新报废设备信息*/
        public static bool UpdateUselessDevice(UselessDeviceModel uselessDevice)
        {
            string updateString = "update t_device_useless set typeId=";
            updateString += uselessDevice.getTypeId() + ",deviceName=";
            updateString += SqlString.GetQuotedString(uselessDevice.getDeviceName()) + ",deviceModel=";
            updateString += SqlString.GetQuotedString(uselessDevice.getDeviceModel()) + ",deviceFrom=";
            updateString += SqlString.GetQuotedString(uselessDevice.getDeviceFrom()) + ",deviceCount=";
            updateString += uselessDevice.getDeviceCount() + ",UPDATEDATE=sysdate,UPDATECOUNT=UPDATECOUNT+1,UPDATEAUTHOR='" + uselessDevice.Author + "',USEPLACE='" + uselessDevice.UsePlace+ "' where id=" + uselessDevice.getId();

            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(updateString) > 0)
                return true;
            return true;
        }

        /*删除报废设备信息*/
        public static bool DeleteUselessDevice(int id)
        {
            string deleteString = "delete from t_device_useless where id=" + id;
            OracleDataBase db = new OracleDataBase();
            return db.InsertOrUpdate(deleteString)>0?true:false;
        }

        /*根据记录编号查询本条设备记录的设备类型*/
        public static string GetDeviceTypeName(int id)
        {
            string queryString = "select typeId from t_device_useless where id=" + id;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceDs = db.GetDataSet(queryString);
            int typeId = 0;
            if (deviceDs.Tables[0].Rows.Count > 0)
            {
                DataRow dr = deviceDs.Tables[0].Rows[0];
                typeId = Convert.ToInt32(dr["typeId"]);
            }

            return DeviceTypeDAO.GetTypeNameById(typeId);

        }

        /*根据设备名称和设备类别查询信息*/
        public static DataSet QueryDeviceInfo(string deviceName, int typeId)
        {
            string queryString = "select * from t_device_useless where 1=1";
            if (deviceName != "")
                queryString += " and deviceName like '%" + deviceName + "%'";
            if (typeId != 0)
                queryString += " and typeId=" + typeId;
            OracleDataBase db = new OracleDataBase();
            return db.GetDataSet(queryString);
        }

        /*取得某个报废设备信息*/
        public static UselessDeviceModel GetUselessDevice(int id)
        {
            UselessDeviceModel uselessDevice = null;
            string queryString = "select * from t_device_useless where id=" + id;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceDs = db.GetDataSet(queryString);
            if (deviceDs.Tables[0].Rows.Count > 0)
            {
                uselessDevice = new UselessDeviceModel();
                DataRow dr = deviceDs.Tables[0].Rows[0];
                uselessDevice.setTypeId(Convert.ToInt32(dr["typeId"]));
                uselessDevice.setDeviceName(dr["deviceName"].ToString());
                uselessDevice.setDeviceModel(dr["deviceModel"].ToString());
                uselessDevice.setDeviceFrom(dr["deviceFrom"].ToString());
                uselessDevice.setDeviceCount(Convert.ToInt32(dr["deviceCount"]));
                uselessDevice.UsePlace = dr["USEPLACE"].ToString();
            }
            return uselessDevice;
        }
    }

}
