﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Device.Model;
using Device.DB;

namespace Device.DAO
{
    /// <summary>
    /// BackupDeviceDAO 的摘要说明：关于备用备件的业务处理类
    /// </summary>
    public class BackupDeviceDAO
    {
        private string errMessage; /*保存业务处理时的错误信息*/
        public string getErrMessage() { return this.errMessage; }
        public BackupDeviceDAO()
        {
            this.errMessage = "";
        }

        /*登记备用备件信息*/
        public static bool AddBackupDevice(BackupDeviceModel backupDevice)
        {
            string sqlString = "insert into t_device_backup (typeId,deviceName,deviceModel,price,deviceFrom,manufacturer,inDate,outDate,stockCount,inOperator,outOperator,USEPLACE,AUTHOR,AUTHORDATE) values (";
            sqlString += backupDevice.getTypeId() + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getDeviceName()) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getDeviceModel()) + ",";
            sqlString += backupDevice.getPrice() + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getDeviceFrom()) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getManufacturer()) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getInDate()) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getOutDate()) + ",";
            sqlString += backupDevice.getStockCount() + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getInOperator()) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.getOutOperator()) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.UsePlace) + ",";
            sqlString += SqlString.GetQuotedString(backupDevice.Author) + ",";
            sqlString += "sysdate)";

            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(sqlString) < 0)
                return false;
            return true;
        }

        /*更新备用备件信息*/
        public static bool UpdateDeviceModel(BackupDeviceModel backupDevice)
        {
            string updateSql = "update t_device_backup set ";
            updateSql += "typeId=" + backupDevice.getTypeId() + ",";
            updateSql += "deviceName=" + SqlString.GetQuotedString(backupDevice.getDeviceName()) + ",";
            updateSql += "deviceModel=" + SqlString.GetQuotedString(backupDevice.getDeviceModel()) + ",";
            updateSql += "price=" + backupDevice.getPrice() + ",";
            updateSql += "deviceFrom=" + SqlString.GetQuotedString(backupDevice.getDeviceFrom()) + ",";
            updateSql += "manufacturer=" + SqlString.GetQuotedString(backupDevice.getManufacturer()) + ",";
            updateSql += "inDate=" + SqlString.GetQuotedString(backupDevice.getInDate()) + ",";
            updateSql += "outDate=" + SqlString.GetQuotedString(backupDevice.getOutDate()) + ",";
            updateSql += "stockCount=" + backupDevice.getStockCount() + ",";
            updateSql += "inOperator=" + SqlString.GetQuotedString(backupDevice.getInOperator()) + ",";
            updateSql += "USEPLACE=" + SqlString.GetQuotedString(backupDevice.UsePlace) + ",";
            updateSql += "UPDATEDATE=sysdate,";
            updateSql += "UPDATECOUNT=UPDATECOUNT+1,";
            updateSql += "UPDATEAUTHOR=" + SqlString.GetQuotedString(backupDevice.Author) + ",";
            updateSql += "outOperator=" + SqlString.GetQuotedString(backupDevice.getOutOperator());
            updateSql += " where id=" + backupDevice.getId();

            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(updateSql) < 0)
                return false;
            return true;
        }

        /*删除某个备用设备信息*/
        public static bool DeleteDevice(int id)
        {
            string deleteString = "delete from t_device_backup where id=" + id;
            OracleDataBase db = new OracleDataBase();
            return db.InsertOrUpdate(deleteString) > 0 ? true : false;
        }

        /*取得某个备用设备信息*/
        public static BackupDeviceModel GetBackupDevice(int id)
        {
            BackupDeviceModel backupDevice = null;
            string queryString = "select * from t_device_backup where id=" + id;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceDs = db.GetDataSet(queryString);
            if (deviceDs.Tables[0].Rows.Count > 0)
            {
                backupDevice = new BackupDeviceModel();
                DataRow dr = deviceDs.Tables[0].Rows[0];
                backupDevice.setTypeId(Convert.ToInt32(dr["typeId"]));
                backupDevice.setDeviceName(dr["deviceName"].ToString());
                backupDevice.setDeviceModel(dr["deviceModel"].ToString());
                backupDevice.setPrice(Convert.ToSingle(dr["price"]));
                backupDevice.setDeviceFrom(dr["deviceFrom"].ToString());
                backupDevice.setManufacturer(dr["manufacturer"].ToString());
                backupDevice.setInDate(dr["inDate"].ToString());
                backupDevice.setOutDate(dr["outDate"].ToString());
                backupDevice.setStockCount(Convert.ToInt32(dr["stockCount"]));
                backupDevice.setInOperator(dr["inOperator"].ToString());
                backupDevice.setOutOperator(dr["outOperator"].ToString());
                backupDevice.UsePlace = dr["USEPLACE"].ToString();
            }
            return backupDevice;
        }

        /*根据设备名称和设备类别查询信息*/
        public static DataSet QueryDeviceInfo(string deviceName, int typeId)
        {
            string queryString = "select * from t_device_backup where 1=1";
            if (deviceName != "")
                queryString += " and deviceName like '%" + deviceName + "%'";
            if (typeId != 0)
                queryString += " and typeId=" + typeId;
            OracleDataBase db = new OracleDataBase();
            return db.GetDataSet(queryString);
        }

        /*根据记录编号查询本条设备记录的设备类型*/
        public static string  GetDeviceTypeName(int id)
        {
            string queryString = "select typeId from t_device_backup where id=" + id;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceDs = db.GetDataSet(queryString);
            int typeId = 0;
            if (deviceDs.Tables[0].Rows.Count > 0)
            {
                DataRow dr = deviceDs.Tables[0].Rows[0];
                typeId = Convert.ToInt32(dr["typeId"]);
            }

            return DeviceTypeDAO.GetTypeNameById(typeId);

        }

    }

}
