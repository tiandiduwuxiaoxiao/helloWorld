﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Collections;
using Device.Model;
using Device.DB;

namespace Device.DAO
{
    /// <summary>
    /// UsingDeviceDAO 的摘要说明：关于在用设备信息管理的业务处理类
    /// </summary>
    public class UsingDeviceDAO
    {
        private string errMessage;  /*保存业务处理错误信息*/
        public string getErrMessage() { return this.errMessage; }
        public UsingDeviceDAO() { this.errMessage = ""; }

        /*添加在用设备信息*/
        public static bool AddUsingDevice(UsingDeviceModel usingDevice)
        {
            string insertString = "insert into t_device_using (typeId,deviceName,deviceModel,deviceFrom,manufacturer,useDate,deviceLife,usePlace,deviceCount,deviceState,AUTHOR,AUTHORDATE) values (";
            insertString += usingDevice.getTypeId() + ",";
            insertString += SqlString.GetQuotedString(usingDevice.getDeviceName()) + ",";
            insertString += SqlString.GetQuotedString(usingDevice.getDeviceModel()) + ",";
            insertString += SqlString.GetQuotedString(usingDevice.getDeviceFrom()) + ",";
            insertString += SqlString.GetQuotedString(usingDevice.getManufacturer()) + ",";
            insertString += "to_date('"+usingDevice.getUseDate().ToString() + "','yyyy-mm-dd HH24:MI:SS'),";
            insertString += usingDevice.getDeviceLife() + ",";
            insertString += SqlString.GetQuotedString(usingDevice.getUsePlace()) + ",";
            insertString += usingDevice.getDeviceCount() + ",";
           
            insertString += SqlString.GetQuotedString(usingDevice.getDeviceState()) + ",";
            insertString += SqlString.GetQuotedString(usingDevice.Author) + ",";
            insertString += "sysdate)";
            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(insertString) < 0)
                return false;
            return true;
        }

        /*更新在用设备信息*/
        public static bool UpdateUsingDevice(UsingDeviceModel usingDevice)
        {
            string updateString = "update t_device_using set typeId=";
            updateString += usingDevice.getTypeId() + ",deviceName=";
            updateString += SqlString.GetQuotedString(usingDevice.getDeviceName()) + ",deviceModel=";
            updateString += SqlString.GetQuotedString(usingDevice.getDeviceModel()) + ",deviceFrom=";
            updateString += SqlString.GetQuotedString(usingDevice.getDeviceFrom()) + ",manufacturer=";
            updateString += SqlString.GetQuotedString(usingDevice.getManufacturer()) + ",useDate=to_date('";
            updateString += usingDevice.getUseDate().ToString() + "','yyyy-mm-dd HH24:MI:SS'),deviceLife=";
            updateString += usingDevice.getDeviceLife() + ",usePlace=";
            updateString += SqlString.GetQuotedString(usingDevice.getUsePlace()) + ",deviceCount=";
            updateString += usingDevice.getDeviceCount() + ",deviceState=";
            updateString += SqlString.GetQuotedString(usingDevice.getDeviceState());
            updateString += ",UPDATEAUTHOR=" + SqlString.GetQuotedString(usingDevice.Author) + ",UPDATEDATE=sysdate,UPDATECOUNT=UPDATECOUNT+1";
          
            updateString += " where id=" + usingDevice.getId();

            OracleDataBase db = new OracleDataBase();
            if (db.InsertOrUpdate(updateString) < 0)
                return false;
            return true;
        }

        /*删除在用设备信息*/
        public static bool DeleteUsingDevice(int id)
        {
            string deleteString = "delete from t_device_using where id=" + id;
            OracleDataBase db = new OracleDataBase();
            return db.InsertOrUpdate(deleteString) > 0 ? true : false;
        }

        /*根据设备名称和设备类别和使用地点查询信息*/
        public static DataSet QueryDeviceInfo(string deviceName, int typeId,string usePlace)
        {
            string queryString = "select * from t_device_using where 1=1";
            if (deviceName != "")
                queryString += " and deviceName like '%" + deviceName + "%'";
            if (typeId != 0)
                queryString += " and typeId=" + typeId;
            if (usePlace != "")
                queryString += " and usePlace='" + usePlace + "'";
            OracleDataBase db = new OracleDataBase();
            return db.GetDataSet(queryString);
        }

        /*根据记录编号查询本条设备记录的设备类型*/
        public static string GetDeviceTypeName(int id)
        {
            string queryString = "select typeId from t_device_using where id=" + id;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceDs = db.GetDataSet(queryString);
            int typeId = 0;
            if (deviceDs.Tables[0].Rows.Count > 0)
            {
                DataRow dr = deviceDs.Tables[0].Rows[0];
                typeId = Convert.ToInt32(dr["typeId"]);
            }

            return DeviceTypeDAO.GetTypeNameById(typeId);

        }

        /*取得某个在用设备信息*/
        public static UsingDeviceModel GetUsingDevice(int id)
        {
            UsingDeviceModel usingDevice = null;
            string queryString = "select * from t_device_using where id=" + id;
            OracleDataBase db = new OracleDataBase();
            DataSet deviceDs = db.GetDataSet(queryString);
            if (deviceDs.Tables[0].Rows.Count > 0)
            {
                usingDevice = new UsingDeviceModel();
                DataRow dr = deviceDs.Tables[0].Rows[0];
                usingDevice.setTypeId(Convert.ToInt32(dr["typeId"]));
                usingDevice.setDeviceName(dr["deviceName"].ToString());
                usingDevice.setDeviceModel(dr["deviceModel"].ToString());
                usingDevice.setDeviceFrom(dr["deviceFrom"].ToString());
                usingDevice.setManufacturer(dr["manufacturer"].ToString());
                usingDevice.setUseDate(Convert.ToDateTime(dr["useDate"]));
                usingDevice.setDeviceLife(Convert.ToInt32(dr["deviceLife"]));
                usingDevice.setUsePlace(dr["usePlace"].ToString());
                usingDevice.setDeviceCount(Convert.ToInt32(dr["deviceCount"]));
                usingDevice.setDeviceState(dr["deviceState"].ToString());

            }
            return usingDevice;
        }

        /*找出库存报警的设备*/
        public static ArrayList GetStockWarningDevices()
        {
            ArrayList devices = new ArrayList();
            string queryString = "select * from t_device_using";
            OracleDataBase db = new OracleDataBase();
            DataSet usingDeviceDs = db.GetDataSet(queryString);
            for (int i = 0; i < usingDeviceDs.Tables[0].Rows.Count; i++)
            {
                DataRow dr = usingDeviceDs.Tables[0].Rows[i];
                /*设备名称*/
                string deviceName = dr["deviceName"].ToString();
                /*使用开始时间*/
                DateTime useDate = Convert.ToDateTime(dr["useDate"]);
                /*使用寿命*/
                int deviceLife = Convert.ToInt32(dr["deviceLife"]);
                /*当前时间*/
                DateTime nowDate = DateTime.Now;
                /*计算已经使用的天数*/
                TimeSpan ts = nowDate - useDate;
                int haveUsedDays = Convert.ToInt32(ts.TotalDays);
                /*计算剩余可以使用的天数*/
                int leftDays = deviceLife - haveUsedDays;
                if (leftDays < Constant.WARNING_DAYS)
                {
                    /*如果在用设备寿命即将到期，查询备用备件中该设备是否存在*/
                    queryString = "select * from t_device_backup where deviceName=" + SqlString.GetQuotedString(deviceName);
                    DataSet backupDeviceDs = db.GetDataSet(queryString);
                    if (backupDeviceDs.Tables[0].Rows.Count == 0)
                    {
                        /*如果备用设备不存在，则将该设备名称加入到库存报警信息中*/
                        devices.Add(deviceName);
                    }
                }
            }

            return devices;
        }
    }
}