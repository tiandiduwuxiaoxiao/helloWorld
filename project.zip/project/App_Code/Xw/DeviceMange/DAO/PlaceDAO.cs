﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Device.DB;

namespace Device.DAO
{
    /// <summary>
    /// PlaceDAO 的摘要说明:使用地点的处理
    /// </summary>
    public class PlaceDAO
    {
        public static DataSet QueryAllPlace()
        {
            string queryString = "select placeName from t_place";
            OracleDataBase db = new OracleDataBase();
            return db.GetDataSet(queryString);
        }
    }

}
