﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Device.Model
{
    /// <summary>
    /// UselessDeviceModel 的摘要说明:映射数据库中的报废设备信息表
    /// </summary>
    public class UselessDeviceModel
    {
        /*
        CREATE TABLE [dbo].t_device_useless(
	        [id] [int] IDENTITY(1,1) NOT NULL,                              //记录编号
	        [typeId] [int] NULL,                                            //设备类别编号
	        [deviceName] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //设备名称
	        [deviceModel] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,    //设备型号
	        [deviceFrom] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //设备来源
	        [deviceCount] [int] NULL,                                       //数量
            CONSTRAINT [PK_t_device_useless] PRIMARY KEY CLUSTERED 
            (
	            [id] ASC
            )WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
        ) ON [PRIMARY]
        */
        private int id;
        private int typeId;
        private string deviceName;
        private string deviceModel;
        private string deviceFrom;
        private int deviceCount;
        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        public void setTypeId(int typeId) { this.typeId = typeId; }
        public int getTypeId() { return this.typeId; }
        public void setDeviceName(string deviceName) { this.deviceName = deviceName; }
        public string getDeviceName() { return this.deviceName; }
        public void setDeviceModel(string deviceModel) { this.deviceModel = deviceModel; }
        public string getDeviceModel() { return this.deviceModel; }
        public void setDeviceFrom(string deviceFrom) { this.deviceFrom = deviceFrom; }
        public string getDeviceFrom() { return this.deviceFrom; }
        public void setDeviceCount(int deviceCount) { this.deviceCount = deviceCount; }
        public int getDeviceCount() { return this.deviceCount; }

        public string UsePlace;
        public string Author;

        public UselessDeviceModel()
        {
        }
    }

}
