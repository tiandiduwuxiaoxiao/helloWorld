﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Device.Model
{
    /// <summary>
    /// DeviceTypeModel 的摘要说明:映射数据库中的设备类别信息表
    /// </summary>
    public class DeviceTypeModel
    {
        /*
        CREATE TABLE [dbo].t_device_type(
            [typeId] [int] IDENTITY(1,1) NOT NULL,                      //类别编号
            [typeName] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,   //类别名称
            CONSTRAINT [PK_t_device_type] PRIMARY KEY CLUSTERED 
            (
                [typeId] ASC
            )WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
        ) ON [PRIMARY]
        */
        private int typeId;
        private string typeName;
        public void setTypeId(int typeId) { this.typeId = typeId; }
        public int getTypeId() { return this.typeId; }
        public void setTypeName(string typeName) { this.typeName = typeName; }
        public string getTypeName() { return this.typeName; }
        public DeviceTypeModel()
        { 
        }
    }

}
