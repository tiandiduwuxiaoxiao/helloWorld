﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Device.Model
{
    /// <summary>
    /// BackupDeviceModel 的摘要说明:关系映射数据库中备用设备信息表
    /// </summary>
    public class BackupDeviceModel
    {
        /*
        CREATE TABLE [dbo].t_device_backup(
            [id] [int] IDENTITY(1,1) NOT NULL,                              //记录编号
            [typeId] [int] NULL,                                            //设备类别编号
            [deviceName] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //设备名称
            [deviceModel] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,    //设备型号
            [price] [float] NULL,                                           //设备价格
            [deviceFrom] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //设备来源
            [manufacturer] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,   //生产厂家
            [inDate] [varchar](50) COLLATE Chinese_PRC_CI_AS NOT NULL,      //入库时间
            [outDate] [varchar](50) COLLATE Chinese_PRC_CI_AS NOT NULL,     //出库时间
            [stockCount] [int] NULL,                                        //库存数量
            [inOperator] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //入库人
            [outOperator] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,    //出库人
            CONSTRAINT [PK_t_device_backup] PRIMARY KEY CLUSTERED 
            (
                [id] ASC
                )WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
            ) ON [PRIMARY]
        */

        private int id;
        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        private int typeId;
        public void setTypeId(int typeId) { this.typeId = typeId; }
        public int getTypeId() { return this.typeId; }
        private string deviceName;
        public void setDeviceName(string deviceName) { this.deviceName = deviceName; }
        public string getDeviceName() { return this.deviceName; }
        private string deviceModel;
        public void setDeviceModel(string deviceModel) { this.deviceModel = deviceModel; }
        public string getDeviceModel() { return this.deviceModel; }
        private float price;
        public void setPrice(float price) { this.price = price; }
        public float getPrice() { return this.price; }
        private string deviceFrom;
        public void setDeviceFrom(string deviceFrom) { this.deviceFrom = deviceFrom; }
        public string getDeviceFrom() { return this.deviceFrom; }
        private string manufacturer;
        public void setManufacturer(string manufacturer) { this.manufacturer = manufacturer; }
        public string getManufacturer() { return this.manufacturer; }
        private string inDate;
        public void setInDate(string inDate) { this.inDate = inDate; }
        public string getInDate() { return this.inDate; }
        private string outDate;
        public void setOutDate(string outDate) { this.outDate = outDate; }
        public string getOutDate() { return this.outDate; }
        private int stockCount;
        public void setStockCount(int stockCount) { this.stockCount = stockCount; }
        public int getStockCount() { return this.stockCount; }
        private string inOperator;
        public void setInOperator(string inOperator) { this.inOperator = inOperator; }
        public string getInOperator() { return this.inOperator; }
        private string outOperator;
        public void setOutOperator(string outOperator) { this.outOperator = outOperator; }
        public string getOutOperator() { return this.outOperator; }

        public string UsePlace;


        public string Author;
       


        public BackupDeviceModel()
        { 
        }
    }

}
