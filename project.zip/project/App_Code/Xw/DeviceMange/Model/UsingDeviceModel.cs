﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Device.Model
{
    /// <summary>
    /// UsingDeviceModel 的摘要说明:映射数据库中的在用设备信息表
    /// </summary>
    public class UsingDeviceModel
    {
        /*
        CREATE TABLE [dbo].t_device_using(
            [id] [int] IDENTITY(1,1) NOT NULL,                              //记录编号                            
            [typeId] [int] NULL,                                            //设备类别编号
            [deviceName] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //设备名称
            [deviceModel] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,    //设备型号
            [deviceFrom] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,     //设备来源
            [manufacturer] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,   //生产厂家
            [useDate] [datetime] NULL,                                      //使用日期
            [deviceLife] [int] NULL,                                        //设备寿命
            [usePlace] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,       //使用地点
            [deviceCount] [int] NULL,                                       //数量
            [deviceState] [nvarchar](50) COLLATE Chinese_PRC_CI_AS NULL,    //状态
            CONSTRAINT [PK_t_device_using] PRIMARY KEY CLUSTERED 
            (
                [id] ASC
            )WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
        ) ON [PRIMARY]
        */
        private int id;
        public void setId(int id) { this.id = id; }
        public int getId() { return this.id; }
        private int typeId;
        public void setTypeId(int typeId) { this.typeId = typeId; }
        public int getTypeId() { return this.typeId; }
        private string deviceName;
        public void setDeviceName(string deviceName) { this.deviceName = deviceName; }
        public string getDeviceName() { return this.deviceName; }
        private string deviceModel;
        public void setDeviceModel(string deviceModel) { this.deviceModel = deviceModel; }
        public string getDeviceModel() { return this.deviceModel; }
        private string deviceFrom;
        public void setDeviceFrom(string deviceFrom) { this.deviceFrom = deviceFrom; }
        public string getDeviceFrom() { return this.deviceFrom; }
        private string manufacturer;
        public void setManufacturer(string manufacturer) { this.manufacturer = manufacturer; }
        public string getManufacturer() { return this.manufacturer; }
        private DateTime useDate;
        public void setUseDate(DateTime useDate) { this.useDate = useDate; }
        public DateTime getUseDate() { return this.useDate; }
        private int deviceLife;
        public void setDeviceLife(int deviceLife) { this.deviceLife = deviceLife; }
        public int getDeviceLife() { return this.deviceLife; }
        private string usePlace;
        public void setUsePlace(string usePlace) { this.usePlace = usePlace; }
        public string getUsePlace() { return this.usePlace; }
        private int deviceCount;
        public void setDeviceCount(int deviceCount) { this.deviceCount = deviceCount; }
        public int getDeviceCount() { return this.deviceCount; }
        private string deviceState;
        public void setDeviceState(string deviceState) { this.deviceState = deviceState; }
        public string getDeviceState() { return this.deviceState; }

        public string Author;

        public UsingDeviceModel()
        {
        }
    }

}
