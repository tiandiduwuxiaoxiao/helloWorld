﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// UserModel的摘要说明:关系映射数据库中的用户信息表
/// </summary>
/// 

namespace Device.Model
{

    /*用户信息表
    CREATE TABLE [dbo].t_user(
	    [username] [varchar](50) COLLATE Chinese_PRC_CI_AS NOT NULL,    //用户名
	    [password] [varchar](50) COLLATE Chinese_PRC_CI_AS NULL,        //密码
        CONSTRAINT [PK_t_user] PRIMARY KEY CLUSTERED 
        (
	        [username] ASC
        )WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
     */
    public class UserModel
    {
        private string username;
        private string password;
        public void setUsername(string username) { this.username = username; }
        public string getUsername() { return this.username; }
        public void setPassword(string password) { this.password = password; }
        public string getPassword() { return this.password; }
        public UserModel()
        {
            username = password = "";
        }
    }

}
