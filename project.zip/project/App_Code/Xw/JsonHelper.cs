﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///JsonHelper 的摘要说明
/// </summary>
public class JsonHelper
{
	public JsonHelper()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
}