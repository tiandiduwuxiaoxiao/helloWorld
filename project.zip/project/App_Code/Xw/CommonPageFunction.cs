﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using BootStrapControls;
using OrderFunction;

/// <summary>
///CommonPageFunction 的摘要说明
/// </summary>
public class CommonPageFunction : BootStrapControl
{
    /// <summary>
    /// 用户
    /// </summary>
    public string SessionUID = "";
    /// <summary>
    /// 用户部门
    /// </summary>
    public string userDEPNAME = "";
    private string MAIN_INFO = "";
    public string INSERTORDERSQL = "";
    public CommonPageFunction(string uid, string depName)
    {
        SessionUID = uid;
        userDEPNAME = depName;
    }

    /// <summary>
    /// 获取内容
    /// </summary>
    /// <param name="tablename"></param>
    /// <returns></returns>
    public string GetHtmlText(string tablename,string type)
    {
        string error = "";
        try
        {
            MAIN_INFO = GetBodyContent(tablename.ToUpper(), "");
        }
        catch (Exception ex)
        {
            error = ex.Message + ex.StackTrace;

            Loger.Error("通用功能页面类==>CommonPageFunction()=====》", ex);
        }

        if (string.IsNullOrEmpty(error))
        {
            //没有异常
            BootStrapControl c_temp = new BootStrapControl();
            if (string.IsNullOrEmpty(MAIN_INFO))
            {
                MAIN_INFO = "error!";
            }
            c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);
            string s_result = "";
            BtsInputButton btn1 = new BtsInputButton("保 存");
            btn1.InputID = "btnAdd";
            btn1.OnClick = "DefaultSave('" + type + "')";// "$('#btn_OK').click();";
            BtsColumnedControl cc1 = new BtsColumnedControl(btn1);
            cc1.ClassName = "col-md-2";
            cc1.OffSet = "col-md-offset-4";

            BtsInputButton btn2 = new BtsInputButton("返 回");
            btn2.ClassName = "btn btn-warning";
            btn2.InputID = "btnCancel";
            btn2.OnClick = "showTableDiv('" + type + "');";

            BtsColumnedControl cc2 = new BtsColumnedControl(btn2);
            cc1.ClassName = "col-md-2";

            string s_btn = cc1.GetHtmlText() + cc2.GetHtmlText();
            string s_btnrow = BootStrapControl.AddDiv("row", s_btn);

            //附件添加
            //int column_count = Convert.ToInt32(ConfigurationManager.AppSettings["column_count"]);
            //string file = "<div class=\"row\"><div class=\"row\"><div class='col-lg-10 col-lg-offset-1'>";
            //file += "<div class='panel panel-default box border primary'>";
            //file += "<div class='box-title'><span>附件信息</span></div>";
            //file += "<div class='panel-body'>";
            //file += "<table class=\"table\" border='0'cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\"><tr><td style='border:0'  colspan='" + (column_count * 2) + "'><iframe id=\"file\"  style=\"width:700px;border:0px;\"></iframe></td></tr></table>";
            //file += "</div></div></div></div></div>";
            //s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + file + "<div class=\"separator\"></div>" + s_btnrow;
            s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + s_btnrow;
            s_result = BootStrapControl.AddDiv("panel-body", s_result);
            s_result = BootStrapControl.AddDiv("panel", s_result);
            s_result = BootStrapControl.AddDiv("col-lg-12", s_result);
            this.HtmlText = s_result;
        }
        else
        {
            //出现异常
            BtsPage404 page404 = new BtsPage404();
            page404.Remark = "对不起，出错了...</br>error:" + error;
            page404.BackUrl = "javascript:showTableDiv();";
            this.HtmlText = page404.GetHtmlText();
        }
        return this.HtmlText;
    }

    /// <summary>
    /// 获取内容
    /// </summary>
    /// <param name="tableName"></param>
    /// <param name="viewName"></param>
    /// <returns></returns>
    public string GetBodyContent(string tableName, string viewName)
    {
        FormList formList = new FormList(SessionUID, userDEPNAME);
        OracleDataBase odb = new OracleDataBase("0");
        Hashtable searchHashtable = InitCache.xwbm_sjzd;
        ArrayList seaList = null;
        ArrayList dList = new ArrayList();

        if (searchHashtable != null && tableName != null)
        {
            seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(viewName) ? tableName : viewName).ToUpper()];
        }
        if (seaList != null)
        {
            StringBuilder upsql = new StringBuilder();
            for (int i = 0; i < seaList.Count; i++)
            {
                FormControl fc = new FormControl();
                DictionaryContent dc = (DictionaryContent)seaList[i];
                if (!dc.style.Contains("40"))
                {
                    continue;
                }
                fc.TableName = dc.tableName;
                fc.FieldDisName = dc.fieldAliasName;
                fc.FieldName = dc.fieldName;
                fc.FieldType = dc.style;
                fc.FIELDORDER = dc.colid;
                fc.MAPINGCODE = dc.dm;
                fc.MAPSQL = dc.mappsql;
                fc.VALIDRULES = dc.validrules;
                fc.SUBFIELD = dc.subfield;
                fc.Type = dc.fieldType;
                fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                fc.title = dc.title;
                fc.titleStyle = dc.titleStyle;
                formList.Add(fc);
                upsql.AppendFormat("{0},", fc.FieldName + "|" + fc.FieldType + "|" + fc.IsNull + "|" + fc.MAPSQL);
            }
            INSERTORDERSQL = upsql.ToString();
        }
        string result = formList.GetHtmlText();
        return result;
    }
}