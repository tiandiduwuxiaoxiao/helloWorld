﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace BootStrapControls
{

    //BootStrap控件基类
    interface IBootStrapControl
    {
        string GetHtmlText();
    }

    public class BootStrapControl : IBootStrapControl
    {
        //原始数据
        private string html_text = string.Empty;
        public string HtmlText
        {
            get
            {
                return this.html_text;
            }
            set
            {
                this.html_text = value;
            }
        }
        /// <summary>
        /// 获取生成的HTML
        /// </summary>
        /// <returns></returns>
        public virtual string GetHtmlText()
        {
            return HtmlText;
        }
        /// <summary>
        /// 获取生成的HTML
        /// </summary>
        /// <returns></returns>
        public virtual string GetHtmlTextDetail()
        {
            return HtmlText;
        }
        /// <summary>
        ///添加一个DIV
        /// </summary>
        /// <param name="divClassName">样式</param>
        /// <param name="str">内容</param>
        public static string AddDiv(string divClassName, string str)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("<div class=\"{0}\">", divClassName);
            sb.Append(str);
            sb.Append("</div>");
            return sb.ToString();
        }
    }

    /// <summary>
    /// bootstrap a带i(fontawesome)的控件
    /// </summary>
    public class AWithIcon : BootStrapControl
    {
        #region 属性
        private string i_class = "fa fa-adjust";
        private string i_string = string.Empty;
        private string a_class = string.Empty;
        private string a_href = "#";
        private string data_toggle = string.Empty;


        public string IClass
        {
            get { return this.i_class; }
            set { this.i_class = value; }
        }
        public string IString
        {
            get { return this.i_string; }
            set { this.i_string = value; }
        }
        public string AClass
        {
            get { return this.a_class; }
            set { this.a_class = value; }
        }
        public string AHREF
        {
            get { return this.a_href; }
            set { this.a_href = value; }
        }

        public string DataToggle
        {
            get { return this.data_toggle; }
            set { this.data_toggle = value; }
        }
        #endregion

        //构造函数
        public AWithIcon()
        {
        }

        //函数
        public  override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            string s_temp = string.Format("<i class=\"{0}\">{1}</i>", this.IClass, this.IString);
            string s_temp2 = "";
            s_temp2 += string.Format(" href=\"{0}\" ", this.AHREF);
            if (!string.IsNullOrEmpty(this.AClass))
            {
                s_temp2 += string.Format(" class=\"{0}\" ", this.AClass);
            }
            if (!string.IsNullOrEmpty(this.DataToggle))
            {
                s_temp2 += string.Format(" data-toggle=\"{0}\" ", this.DataToggle);
            }


            sb.AppendFormat("<a  {0} >{1}</a>", s_temp2, s_temp);

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }


    }

    /// <summary>
    /// AWithIcon按钮集合
    /// </summary>
    public class ToolsAssemble : BootStrapControl
    {
        public List<AWithIcon> Tools { get; set; }

        public ToolsAssemble()
        {
            this.Tools = new List<AWithIcon>();
        }
        public override string GetHtmlText()
        {
            if (this.Tools == null || this.Tools.Count == 0)
            {
                this.HtmlText = string.Empty;
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < this.Tools.Count; i++)
                {
                    sb.Append(this.Tools[i].GetHtmlText());
                }
                this.HtmlText = sb.ToString();
            }

            return this.HtmlText;
        }
    }

    /// <summary>
    /// 图标带文字
    /// </summary>
    public class IconWithText : BootStrapControl
    {
        private string text = string.Empty;
        private string icon_class = "fa fa-adjust";

        public enum OneWayDirection { Left, Right };
        private OneWayDirection WordsDirection = OneWayDirection.Right;

        public string Text
        {
            get { return this.text; }
            set { this.text = value; }
        }
        public string IconClass
        {
            get { return this.icon_class; }
            set { this.icon_class = value; }
        }

        public IconWithText()
        {
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            if (this.WordsDirection == OneWayDirection.Left)
            {
                sb.Append(this.Text);
                sb.AppendFormat("<i class=\"{0}\"></i>", this.IconClass);
            }
            else
            {
                sb.AppendFormat("<i class=\"{0}\"></i>", this.IconClass);
                sb.Append(this.Text);
            }
            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }


    /// <summary>
    /// 手风琴控件组成
    /// </summary>
    public class BtsPanel : BootStrapControl
    {
        private string head_size = "h4";
        private string panel_body_content = string.Empty;
        public string GroupID { get; set; }

        public string CollapseID { get; set; }

        private int collapse_id = 0;
        public int collapseID 
        {
            get { return this.collapse_id; }
            set 
            { 
                this.collapse_id = value;
                this.CollapseID = "Collapse" + this.collapse_id.ToString();
            }
        }

        public string HeadTitle { get; set; }

        public string HeadSize
        {
            get { return this.head_size; }
            set { this.head_size = value; }
        }

        public string PanelBodyContent
        {
            get { return this.panel_body_content; }
            set { this.panel_body_content = value; }
        }
        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<div class=\"panel panel-default\">");
            //head
            sb.AppendLine("<div class=\"panel-heading\">");
            sb.AppendFormat("<{0} class=\"panel-title\">", this.HeadSize);

            string str_a = string.Format("<a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#{0}\" href=\"#{1}\">{2}</a>", this.GroupID, this.CollapseID, this.HeadTitle);
            sb.AppendLine(str_a);
            sb.AppendFormat("</{0}>", this.HeadSize);
            sb.AppendLine("</div>");
            //endhead
            //collapse
            if(collapse_id == 0)
            {
                sb.AppendFormat("<div id=\"{0}\" class=\"panel-collapse collapse in\">", this.CollapseID);
            }else
            {
                sb.AppendFormat("<div id=\"{0}\" class=\"panel-collapse collapse\">", this.CollapseID);
            }
            sb.AppendLine("<div class=\"panel-body\">");
            sb.AppendLine( this.PanelBodyContent);
            sb.AppendLine("</div>");
            sb.AppendLine("</div><!-- /div panel-collapse  -->");
            //endcollapse

            sb.AppendLine("</div><!--/panel panel-default -->");
            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }

    /// <summary>
    /// 手风琴控件
    /// </summary>
    public class BtsPanelGroup : BootStrapControl
    {
        private string groupid = string.Empty;
        public List<BtsPanel> Panels;
        public BtsPanelGroup()
        {
            Panels = new List<BtsPanel>();
        }

        public BtsPanelGroup(string[] panelHeadTitle, string[] panelBodyContent)
        {
            Panels = new List<BtsPanel>();
            for (int i = 0; i < panelHeadTitle.Length; i++)
            {
                BtsPanel bp = new BtsPanel();
                bp.HeadTitle = panelHeadTitle[i];
                bp.collapseID = i;
                if (panelBodyContent != null && panelBodyContent.Length > i)
                {
                    bp.PanelBodyContent = panelBodyContent[i];
                }
                Panels.Add(bp);
            }
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            int mi = System.DateTime.Now.Millisecond;
            Random rd = new Random(mi);
            int rdnum = rd.Next(100);
            string groupid = "according" + rdnum.ToString();
            string s_temp = string.Format("<div class=\"panel-group\" id=\"{0}\">", groupid);

            sb.AppendLine(s_temp);
            if (Panels != null && Panels.Count > 0)
            {
                for (int i = 0; i < this.Panels.Count; i++)
                {
                    this.Panels[i].GroupID = this.groupid;
                    s_temp = this.Panels[i].GetHtmlText();
                    sb.AppendLine(s_temp);
                }
            }

            sb.AppendLine("</div>");

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }



    public class TempCache
    {
        //站点和状态对应的工单数量(后台实际数量)
        public static List<UI_Menu> UI_MenuList = null;

        //站点和状态对应的工单数量(前台界面显示在菜单的数量)
        public static List<UI_Menu> UI_MenuList_Show = null;
    }

    public class UI_MenuItem
    {
        public string SQLCOUNT { get; set; }
        public string IsCreate { get; set; }
        public string STATIONID { get; set; }

        public string STATIONNAME { get; set; }
        /// <summary>
        /// 对应工单状态的工单数量
        /// </summary>
        public string COUNT { get; set; }
        /// <summary>
        /// 工单状态：未派遣，申请销单等...
        /// </summary>
        public string STATE { get; set; }
    }

    public class UI_Menu
    {
        /// <summary>
        /// 站点名字：廊坊，沙河...
        /// </summary>
        public string STATIONNAME { get; set; }
        public string STATIONCODE { get; set; }
        public List<UI_MenuItem> MenuItemList { get; set; }
    }

    public class NewMsgDropDown 
    {
        /// <summary>
        /// 备注
        /// </summary>
        public string Note { get; set; }

        public string HREF { get; set; }

        public string IconClassName { get; set; }

        public bool showFooter { get; set; }

        public string Footer_HREF { get; set; }

        public string FooterName { get; set; }

        public string HeadIconClassName { get; set; }

        public string HeadName { get; set; }



        public List<NewMsgLi> NewMsgList { get; set; }


        public int ListCount { get; set; }

        public int MaxShowCount { get; set; }

        public NewMsgDropDown()
        {
            this.Note = "注释";
            this.HREF = "#";
            this.IconClassName = "fa fa-envelope";
            this.showFooter = false;
            this.Footer_HREF = "#";
            this.FooterName = "查看更多";
            this.HeadIconClassName = "fa fa-envelope";
            this.HeadName = "菜单标题";
            this.ListCount = 0;
            this.MaxShowCount = 1;
        }

        public  virtual  string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("<!-- BEGIN {0} -->", this.Note));
            sb.AppendLine("<li class=\"dropdown\">");
            sb.AppendLine(string.Format("<a href=\"{0}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">", this.HREF));

            int ListCount = this.NewMsgList.Count;
            sb.AppendLine(string.Format("<i class=\"{0}\"></i><span class=\"badge\">{1}</span>", this.IconClassName, ListCount));
            sb.AppendLine("</a>");
            if (ListCount > 0)
            {
                sb.AppendLine("<ul class=\"dropdown-menu inbox\">");
                sb.AppendLine("<li class=\"dropdown-title\">");
                sb.AppendLine(string.Format("<span><i class=\"{0}\"></i>{1}</span>", this.HeadIconClassName, this.HeadName));
                sb.AppendLine("</li>");
                int max = Math.Min(this.MaxShowCount, ListCount);
                for (int i = 0; i < max; i++)
                {
                    string s = this.NewMsgList[i].GetHtmlText();
                    sb.AppendLine(s);
                }
                if (this.showFooter)
                {
                    sb.AppendLine(string.Format("<li class=\"footer\"><a href=\"{0}\">{1}<i class=\"fa fa-arrow-circle-right\"></i></a></li>", this.Footer_HREF, this.FooterName));
                }
                sb.AppendLine("</ul>");
            }

            sb.AppendLine("</li><!-- dropdown -->");
            sb.AppendLine(string.Format("<!-- END {0} -->", this.Note));
            return sb.ToString();
        }
    }


    public class NewMsgLi 
    {
        /// <summary>
        /// 链接
        /// </summary>
        public string HREF { get; set; }

        /// <summary>
        /// Label:primary,info,danger,warning...
        /// </summary>
        public string Label { get; set; }

        /// <summary>
        /// 图标：fa fa-exclamation-triangle，fa fa-info...
        /// </summary>
        public string IconClassName { get; set; }

        /// <summary>
        /// 站点
        /// </summary>
        public string span_From { get; set; }

        /// <summary>
        /// 消息内容
        /// </summary>
        public string span_Message { get; set; }

        /// <summary>
        /// 加在消息内容前面
        /// </summary>
        public string span_Message_Prophase { get; set; }


        public NewMsgLi()
        {
            this.HREF = "#";
            this.Label = "label label-info";
            this.IconClassName = "fa fa-info";
            this.span_From = "站点A";
            this.span_Message = "消息内容";
            this.span_Message_Prophase = string.Empty;
        }

        public virtual string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<li>");
            sb.AppendLine(string.Format("<a href=\"{0}\"><span class=\"body\">", this.HREF));
            sb.AppendLine(string.Format("<span class=\"{0}\"><i class=\"{1}\"></i></span>", this.Label, this.IconClassName));
            sb.AppendLine(string.Format("<span class=\"from\">{0}</span>", this.span_From));
            sb.AppendLine(string.Format("<span class=\"message\">{0}</span>", this.span_Message_Prophase + this.span_Message));
            sb.AppendLine("</a>");
            sb.AppendLine("</li>");
            return sb.ToString();
        }

    }

    public class OverTimeDropDown : NewMsgDropDown
    {


        public OverTimeDropDown()
        {
            this.Note = "注释";
            this.HREF = "#";
            this.IconClassName = "fa fa-bell";
            this.showFooter = false;
            this.Footer_HREF = "#";
            this.FooterName = "查看更多";
            this.HeadIconClassName = "fa fa-bell";
            this.HeadName = "菜单标题";
            this.ListCount = 0;
            this.MaxShowCount = 1;
        }

        public new string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("<!-- BEGIN {0} -->", this.Note));
            sb.AppendLine("<li class=\"dropdown\">");
            sb.AppendLine(string.Format("<a href=\"{0}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">", this.HREF));

            int ListCount = this.NewMsgList.Count;
            sb.AppendLine(string.Format("<i class=\"{0}\"></i><span class=\"badge\">{1}</span>", this.IconClassName, ListCount));
            sb.AppendLine("</a>");
            if (ListCount > 0)
            {
                sb.AppendLine("<ul class=\"dropdown-menu inbox\">");
                sb.AppendLine("<li class=\"dropdown-title\">");
                sb.AppendLine(string.Format("<span><i class=\"{0}\"></i>{1}</span>", this.HeadIconClassName, this.HeadName));
                sb.AppendLine("</li>");
                int max = Math.Min(this.MaxShowCount, ListCount);
                for (int i = 0; i < max; i++)
                {
                    OverTimeLi li = this.NewMsgList[i] as OverTimeLi;
                    string s = li.GetHtmlText();
                    sb.AppendLine(s);
                }
                if (this.showFooter)
                {
                    sb.AppendLine(string.Format("<li class=\"footer\"><a href=\"{0}\">{1}<i class=\"fa fa-arrow-circle-right\"></i></a></li>", this.Footer_HREF, this.FooterName));
                }
                sb.AppendLine("</ul>");
            }

            sb.AppendLine("</li><!-- dropdown -->");
            sb.AppendLine(string.Format("<!-- END {0} -->", this.Note));
            return sb.ToString();
        }
    }

    public class OverTimeLi : NewMsgLi
    {

        /// <summary>
        /// 超时时间(小时)
        /// </summary>
        public string span_OverTime { get; set; }

        public OverTimeLi()
        {
            this.span_OverTime = "2008/08/08";
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<li>");
            sb.AppendLine(string.Format("<a href=\"{0}\"><span class=\"body\">", this.HREF));
            sb.AppendLine(string.Format("<span class=\"{0}\"><i class=\"{1}\"></i></span>", this.Label, this.IconClassName));
            sb.AppendLine(string.Format("<span class=\"from\">{0}</span>", this.span_From));
            sb.AppendLine(string.Format("<span class=\"message\">{0}</span>", this.span_Message_Prophase + this.span_Message));
            sb.AppendLine(string.Format("<span class=\"time\"><i class=\"fa fa-clock-o\"></i>{0}</span></span>", this.span_OverTime));
            sb.AppendLine("</a>");
            sb.AppendLine("</li>");
            return sb.ToString();
        }

    }

    public class UserDropDown 
    {
        public string Note { get; set; }
        public string UserName { get; set; }
        public string UserImgUrl { get; set; }
        public string UserIcon { get; set; }
        private string UserImgUrlAlt = "头像";
        public List<UserDropDownLi> menuList { get; set; }

        public UserDropDown()
        {
            this.Note = "注释";
            this.UserName = "fa fa-user";
            this.UserImgUrl = "img/avatars/avatar3.jpg";
            this.UserImgUrlAlt = "头像";
            this.UserIcon = "fa-angle-down";
        }

        public virtual string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<li class='dropdown user'>");
            sb.AppendLine("<a href='#' class='dropdown-toggle' data-toggle='dropdown'>");
            sb.AppendLine(string.Format("<img alt='{0}' src='{1}' />", this.UserImgUrlAlt, this.UserImgUrl));
            sb.AppendLine(string.Format("<span class='username'  runat='server'>{0}</span>", this.UserName));
            sb.AppendLine(string.Format("<i class='fa  {0}'></i></a>",this.UserIcon));

            if (menuList != null && menuList.Count > 0)
            {
                sb.AppendLine("<ul class='dropdown-menu'>");
                foreach (var item in this.menuList)
                {
                    string s = item.GetHtmlText();
                    sb.AppendLine(s);
                }
                sb.AppendLine("</ul>");
            }
            sb.AppendLine("</li>");
            return sb.ToString();
        }
    }

    public class UserDropDownLi 
    {
        public string iconClassName { get; set; }
        public string MenuName { get; set; }
        private string UserImgUrlAlt { get; set; }
        public string HREF { get; set; }
        public string TARGET { get; set; }
        public UserDropDownLi()
        {
            this.iconClassName = "fa fa-user";
            this.MenuName = "操作A";
            this.UserImgUrlAlt = "ICON";
            this.HREF = "#";
            this.TARGET = "_self";
        }
        public virtual string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<li>");
            sb.AppendLine(string.Format("<a href='{0}' target='{3}'><i class='{1}'></i>{2}</a>", this.HREF, this.iconClassName, this.MenuName, this.TARGET));
            sb.AppendLine("</li>");
            return sb.ToString();
        }
    }

    public class BasisDropDown
    {
        public List<BasisDDropDownLi> menuList { get; set; }

        public virtual string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            if (menuList != null && menuList.Count > 0)
            {
                foreach (var item in this.menuList)
                {
                    string s = item.GetHtmlText();
                    sb.AppendLine(s);
                }
            }
            return sb.ToString();
        }
    }
    public class BasisDDropDownLi
    {
        public string iconClassName { get; set; }
        public string MenuName { get; set; }
        private string UserImgUrlAlt { get; set; }
        public string HREF { get; set; }
        public BasisDDropDownLi()
        {
            this.iconClassName = "fa fa-user";
            this.MenuName = "操作A";
            this.UserImgUrlAlt = "ICON";
            this.HREF = "#";
        }
        public virtual string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<li>");
            sb.AppendLine(string.Format("<a href='{0}'><i class='{1}'></i>{2}</a>", this.HREF, this.iconClassName, this.MenuName));
            sb.AppendLine("</li>");
            return sb.ToString();
        }
        //public virtual string GetHtmlText(string )
        //{
        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("<li>");
        //    sb.AppendLine(string.Format("<a href='{0}'><i class='{1}'></i>{2}</a>", this.HREF, this.iconClassName, this.MenuName));
        //    sb.AppendLine("</li>");
        //    return sb.ToString();
        //}
    }

    public class BtsLi : BootStrapControl
    {
        public AWithIcon AI { get; set; }


        private string li_class = string.Empty;
        public string LiClass 
        {
            get { return this.li_class; }
            set { this.li_class = value; }
        }

        public BtsLi()
        {
            this.AI = new AWithIcon();
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            string str_ai = this.AI.GetHtmlText();
            if (string.IsNullOrEmpty(this.LiClass))
            {
                sb.AppendFormat("<li>{0}</li>", str_ai);
            }
            else
            {
                sb.AppendFormat("<li class=\"{0}\">{1}</li>", this.LiClass, str_ai);
            }


            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }

    /// <summary>
    /// Tab页控件
    /// </summary>
    public class BtsTabbable : BootStrapControl
    {

        public List<BtsLi> BtsLiList { get; set; }

        public List<string> TabContentList { get; set; }

        public string TabIdName { get; set; }

        private string tabid = "myTab";

        public string TabId 
        {
            get { return this.tabid; }
            set { this.tabid = value; }
        }

        public BtsTabbable()
        {
            this.BtsLiList = new List<BtsLi>();
            this.TabContentList = new List<string>();
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            string s_temp = string.Empty;
            sb.AppendLine("<div class=\"tabbable\">");

            //nav tabs

            sb.AppendLine(string.Format("<ul class=\"nav nav-tabs\" id=\"{0}\">", this.TabId));

            if (this.BtsLiList != null && this.BtsLiList.Count > 0)
            {
                for (int i = 0; i < this.BtsLiList.Count; i++)
                {
                    if (i == 0)
                    {
                        this.BtsLiList[i].LiClass = "active";
                    }
                     s_temp = this.BtsLiList[i].GetHtmlText();
                     sb.AppendLine(s_temp);
                }

            }


            sb.AppendLine("</ul>");
            //end nav tabs

            //tab content
            sb.AppendLine("<div class=\"tab-content\">");

            if (TabContentList != null && TabContentList.Count > 0)
            {
                for (int i = 0; i < this.TabContentList.Count; i++)
                {
                    if (i == 0)
                    {
                         s_temp = string.Format("<div class=\"tab-pane fade in active\" id=\"{0}\">", this.TabIdName + "_" + i.ToString());
                    }
                    else
                    {
                        s_temp = string.Format("<div class=\"tab-pane fade\" id=\"{0}\">", this.TabIdName + "_" + i.ToString());
                    }
                    sb.AppendLine(s_temp);
                    sb.AppendLine(TabContentList[i]);
                    sb.AppendLine("</div><!-- /tab-pane -->");
                }
            }
            sb.AppendLine("</div><!-- /tab-content -->");
            //end tab content

            sb.AppendLine("</div><!-- /tabbable -->");

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    
        

    
    }


    /// <summary>
    /// 窗体头部
    /// </summary>
    public class BoxTitle : BootStrapControl
    {
        #region 属性
        private string startstring = "<div class=\"box-title\">";
        private string endstring = "</div>";

        private string title_size = "h4";
        private bool show_title_h = true;
        private bool show_title_tools = true;
        #endregion



        //标题字体大小。eg：h1,h2...
        public string TitleSize
        {
            get { return this.title_size; }
            set { this.title_size = value; }
        }

        //窗体右上按钮
        public ToolsAssemble TitleTools { get; set; }

        //窗体标题
        public IconWithText TitleHead { get; set; }

        //是否显示窗体标题
        public bool ShowTitleH
        {
            get { return this.show_title_h; }
            set { this.show_title_h = value; }
        }

        //是否显示右侧按钮，默认为是
        public bool ShowTitleTools
        {
            get { return this.show_title_tools; }
            set { this.show_title_tools = value; }
        }

        public bool ShowCloseButton { get; set; }

        //构造函数
        public BoxTitle(bool hasCloseButton = false)
        {
            this.TitleHead = new IconWithText();
            this.TitleHead.Text = "样例标题";
            this.TitleHead.IconClass = "fa fa-bars";

            this.TitleTools = new ToolsAssemble();
            //默认添加一个关闭按钮
            if (hasCloseButton)
            {
                AWithIcon ai = new AWithIcon();
                ai.AClass = "remove";
                ai.IClass = "fa fa-times";
                this.TitleTools.Tools.Add(ai);
            }

        }


        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.startstring);

            if (ShowTitleH == true)
            {
                //生成标题
                string s_h = string.Format("<{0}>{1}</{2}>", this.TitleSize, this.TitleHead.GetHtmlText(), this.TitleSize);
                sb.Append(s_h);
            }

            if (ShowTitleTools == true)
            {
                //生成右侧按钮。eg:关闭，刷新等
                string s_t = string.Format("<div class=\"tools\" >{0}</div>", this.TitleTools.GetHtmlText());
                sb.Append(s_t);
            }

            sb.Append(this.endstring);

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }

    /// <summary>
    /// 窗体内容
    /// </summary>
    public class BoxBody : BootStrapControl
    {
        private string startstring = "<div class=\"box-body\" >";
        private string endstring = "</div>";

        private string body_content = string.Empty;

        public string BodyContent
        {
            get { return this.body_content; }
            set { this.body_content = value; }
        }

        public BoxBody()
        {
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.startstring);
            sb.Append(this.BodyContent);
            sb.Append(this.endstring);

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }

    }

    /// <summary>
    ///BootStrap Box 页
    /// </summary>
    public class BtsBox : BootStrapControl
    {
        private string box_class = "box border";

        private string col_class = "col-md-12";

        private bool has_col_class = false;

        public string BoxClass
        {
            get { return this.box_class; }
            set { this.box_class = value; }
        }

        public bool HasColClass
        {
            get { return this.has_col_class; }
            set { this.has_col_class = value; }
        }
        public BoxTitle BtsBoxTitle { get; set; }

        public BoxBody BtsBoxBody { get; set; }

        //构造函数
        public BtsBox()
        {
            this.BtsBoxTitle = new BoxTitle(false);
            this.BtsBoxBody = new BoxBody();
        }
        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            string s_temp = string.Empty;
            if (HasColClass)
            {
                s_temp = string.Format("<div class=\"{0}\">", this.col_class);
                sb.Append(s_temp);
            }


            s_temp = string.Format("<div class=\"{0}\">", this.box_class);
            sb.Append(s_temp);

            //BoxTitle
            s_temp = this.BtsBoxTitle.GetHtmlText();
            sb.Append(s_temp);

            //BoxBody
            s_temp = this.BtsBoxBody.GetHtmlText();
            sb.Append(s_temp);

            sb.Append("</div>");
            if (HasColClass)
            {
                sb.Append("</div>");
            }

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class BtsRow : BootStrapControl
    {
        

        public BtsRow()
        {
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<div class=\"row\">");

            sb.AppendLine("</div>");

            this.HtmlText = sb.ToString();
            return this.HtmlText;

        }
    }


    /// <summary>
    /// 自定义404页面
    /// </summary>
    public class BtsPage404 : BootStrapControl
    {
        private string remark = "对不起, 您的页面走丢了";
        private string  back_href =string.Empty;

        public string Remark
        {
            get{ return this.remark; }
            set{ this.remark = value; }
        }

        public string BackUrl
        {
            get { return this.back_href; }
            set { this.back_href = value; }
        }


        public BtsPage404()
        {
        }
        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<div class=\"row\">");
            sb.AppendLine("<div class=\"col-md-12 not-found text-center\"><div class=\"error\">404</div></div>");
            sb.AppendLine("<div class=\"col-md-4 col-md-offset-4 not-found text-center\">");
            sb.AppendLine("<div class=\"content\">");
            sb.AppendFormat("<h3>Page not Found</h3><p>{0}<br /></p><h3><a href=\"{1}\"><i class=\"fa fa-arrow-left\">返 回</a></i></h3>", this.Remark, this.BackUrl);
            sb.AppendLine("</div><!-- content -->");
            sb.AppendLine("</div><!-- col-md-4 -->");
            sb.AppendLine("</div><!-- /row -->");

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }

    /// <summary>
    /// 输入框
    /// </summary>
    public class BtsInput : BootStrapControl
    {
        public string InputID { get; set; }
        public string InputName { get; set; }
        public string InputType { get; set; }
        public string OnClick { get; set; }
        public string OnServerClick { get; set; }
        public string ClassName { get; set; }
        public string InputValue { get; set; }
        public string RunAt { get; set; }
        public string InputStyle { get; set; }
        public string PlaceHolder { get; set; }

        public  override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<input ");
            if (!string.IsNullOrEmpty(InputID))
            {
                sb.Append(" id=\"" + InputID + "\" ");
            }
            if (!string.IsNullOrEmpty(InputName))
            {
                sb.Append(" name=\"" + InputName + "\" ");
            }
            if (!string.IsNullOrEmpty(InputType))
            {
                sb.Append(" type=\"" + InputType + "\" ");
            }
            if (!string.IsNullOrEmpty(ClassName))
            {
                sb.Append(" class=\"" + ClassName + "\" ");
            }
            if (!string.IsNullOrEmpty(RunAt))
            {
                sb.Append(" runat=\"" + RunAt + "\"");
            }

            if (!string.IsNullOrEmpty(OnClick))
            {
                sb.Append(" onclick=\"" + OnClick + "\" ");
            }

            if (!string.IsNullOrEmpty(OnServerClick))
            {
                sb.Append(" onserverclick=\"" + OnServerClick + "\" ");
            }
            if (!string.IsNullOrEmpty(InputStyle))
            {
                sb.Append(" style=\"" + InputStyle + "\" ");
            }

            if (!string.IsNullOrEmpty(InputValue))
            {
                sb.Append(" value=\"" + InputValue + "\" ");
            }
            if (!string.IsNullOrEmpty(PlaceHolder))
            {
                sb.Append(" placeholder=\"" + PlaceHolder + "\" ");
            }


            sb.Append(" />");
            return sb.ToString();
        }
    }

    /// <summary>
    /// 文本输入框
    /// </summary>
    public class BtsInputText : BtsInput
    {


        public BtsInputText()
        {
            this.InputType = "text";
            this.ClassName = "form-control";
            this.InputValue = "";
        }
    }

    public class BtsLabel : BootStrapControl
    {
        private string label = "样例label";
        public string Label
        {
            get
            {
                return this.label;
            }
            set
            {
                this.label = value;
            }
        }

        public string LabelFor { get; set; }

        public string LabelClass { get; set; }

        public BtsLabel()
        {
        }
        public BtsLabel(string labeltext, string labelfor = null ,string labelclass = null)
        {
            this.Label = labeltext;
            this.LabelFor = labelfor;
            this.LabelClass = labelclass;
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<label");
            if (!string.IsNullOrEmpty(this.LabelFor))
            {
                sb.Append(" for=\"" + LabelFor + "\" ");
            }
            if (!string.IsNullOrEmpty(this.LabelClass))
            {
                sb.Append(" class=\"" + LabelClass  + "\" ");
            }
            sb.Append(">");
            sb.Append(this.Label);
            sb.Append("</label>");

            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }

    /// <summary>
    /// 输入框—按钮
    /// </summary>
    public class BtsInputButton : BtsInput
    {
        public BtsInputButton()
        {
            this.InputType = "button";
            this.ClassName = "btn btn-primary";
            this.InputStyle = "width:100px;height:30px;";
            this.InputValue = "样例按钮";
        }
        public BtsInputButton(string btnValue)
        {
            this.InputType = "button";
            this.ClassName = "btn btn-primary";
            this.InputStyle = "width:100px;height:30px;";
            this.InputValue = btnValue;
        }

    }

    /// <summary>
    /// 固定为一行
    /// </summary>
    public class BtsRowedControl : BootStrapControl
    {
        public BootStrapControl Control { get; set; }

        public BtsRowedControl(BootStrapControl c)
        {
            Control = c;
        }

        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<div class=\"row\">");
            if (Control != null)
                sb.AppendLine(Control.GetHtmlText());
            sb.AppendLine("</div><!-- /row -->");
            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }


    }



    /// <summary>
    /// 固定列大小
    /// </summary>
    public class BtsColumnedControl : BootStrapControl
    {
        public BootStrapControl Control { get; set; }



        private string class_name = "col-md-4";

        public string ClassName
        {
            get 
            {
                return this.class_name;
            }
            set
            {
                this.class_name = value;
            }
        }

        public string OffSet { get; set; }



        public BtsColumnedControl(BootStrapControl c)
        {
            Control = c;
        }


        /// <summary>
        /// 组成HTML返回
        /// </summary>
        /// <returns></returns>
        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            if (string.IsNullOrEmpty(this.OffSet))
            {
                sb.AppendFormat("<div class=\"{0}\">", this.ClassName);
            }
            else
            {
                sb.AppendFormat("<div class=\"{0} {1}\">", this.ClassName, this.OffSet);
            }
            sb.AppendLine(Control.GetHtmlText());
            sb.AppendLine("</div><!-- /row -->");
            this.HtmlText = sb.ToString();

            return this.HtmlText;
        }

    }


}