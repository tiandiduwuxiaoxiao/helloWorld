﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///Config 的摘要说明
/// </summary>
public static class Config
{
    /// <summary>
    /// 获取搜索列的值
    /// </summary>
    /// <returns></returns>
    public static List<string> GetSearchCodeList()
    {
        List<string> list = new List<string> {"60", "61"};
        return list;
    }

    /// <summary>
    /// 判断多媒体类型
    /// </summary>
    /// <returns></returns>
    public static Dictionary<string, string> FileType()
    {

        Dictionary<string, string> dc = new Dictionary<string, string>
                {
                    { "JPG", "" },
                    { "JPEG", "" },
                    { "GIF", "" },
                    { "PNG", "" },
                    { "wav", "2" },
                    { "mid", "2" },
                    { "rm", "2" },
                    { "ape", "2" },
                    { "flac", "2" },
                    { "mp3", "2" }
                };

        return dc;
    }
    
}