﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;
using System.Linq;
using System.Web;

/// <summary>
///SearchFunction 的摘要说明
/// </summary>
public class SearchFunction
{
	public SearchFunction()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    /// <summary>
    /// 获取查询DataTable
    /// </summary>
    /// <param name="sqlFilter"></param>
    /// <param name="procName"></param>
    /// <returns></returns>
    public DataTable GetDataTable(string sqlFilter, string procName, string sSortDir, string mDataProp, int iStart, int pageSize, string mType, ref string count)
    {
        List<OracleParameter> list = new List<OracleParameter>();
        OracleDataBase odb = new OracleDataBase();
        odb.Open();

        OracleParameter op = new OracleParameter("sqlFilter", OracleType.VarChar);
        op.Direction = ParameterDirection.Input;
        op.Value = sqlFilter;
        list.Add(op);

        OracleParameter opsSortDir = new OracleParameter("sSortDir", OracleType.VarChar);
        opsSortDir.Direction = ParameterDirection.Input;
        opsSortDir.Value = sSortDir;
        list.Add(opsSortDir);

        OracleParameter opmDataProp = new OracleParameter("mDataProp", OracleType.VarChar);
        opmDataProp.Direction = ParameterDirection.Input;
        opmDataProp.Value = mDataProp;
        list.Add(opmDataProp);

        OracleParameter opiStart = new OracleParameter("iStart", OracleType.VarChar);
        opiStart.Direction = ParameterDirection.Input;
        opiStart.Value = iStart;
        list.Add(opiStart);

        OracleParameter oppageSize = new OracleParameter("pageSize", OracleType.VarChar);
        oppageSize.Direction = ParameterDirection.Input;
        oppageSize.Value = pageSize;
        list.Add(oppageSize);

        OracleParameter opmType = new OracleParameter("mType", OracleType.VarChar);
        opmType.Direction = ParameterDirection.Input;
        opmType.Value = mType;
        list.Add(opmType);

        OracleParameter opOutcount = new OracleParameter("p_count", OracleType.VarChar, 50);
        opOutcount.Direction = ParameterDirection.Output;
        list.Add(opOutcount);

        OracleParameter opOut = new OracleParameter("p_cursor", OracleType.Cursor);
        opOut.Direction = ParameterDirection.Output;
        list.Add(opOut);


        count = "0";
        DataTable dt = odb.getPro(procName, list, ref count);
        return dt;
    }


    /// <summary>
    /// 获取存储过程名称
    /// </summary>
    /// <param name="_rid">ID</param>
    public string GetProcName(string _rid)
    {
        OracleDataBase odb = new OracleDataBase();
        string procName = "";
        try
        {
            string sql = string.Format(@" SELECT PROCENAME  FROM PZ_REPORT M WHERE 1=1 and ISVISIBLE='{0}' and ID='{1}'  order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), _rid);
            procName = odb.GetScalarInfo(sql);
        }
        catch (Exception ex)
        {
            Loger.Error("GetProcName===>" + ex);
        }
        finally
        {
            odb.Close();
        }
        return procName;
    }
}