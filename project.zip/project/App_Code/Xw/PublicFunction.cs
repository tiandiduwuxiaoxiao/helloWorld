﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using Maticsoft.DBUtility;
/// <summary>
/// PublicFunction 的摘要说明
/// </summary>
public class PublicFunction
{
    public PublicFunction()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public static void _NewColunms(DataTable tableDataName, GridView gvName, OracleDataBase odb, string tableName)
    {
        BoundField field = null;
        Dictionary<string, ShowListClass> dctNames = GetTableColumnNames(tableName, odb);
        if (tableDataName.Rows.Count > 0)
        {
            string columnName = string.Empty;
            ShowListClass show = new ShowListClass();
            string columnValue = string.Empty;
            for (int i = 0; i < tableDataName.Columns.Count; i++)
            {
                columnName = tableDataName.Columns[i].ColumnName.ToUpper();
                if (dctNames.ContainsKey(columnName))
                {

                    field = new BoundField();
                    field.DataField = columnName;//绑定数据字段
                    dctNames.TryGetValue(columnName, out show);
                    columnValue = show.name;
                    field.HeaderText = columnValue + "▲";//表头
                    field.HeaderStyle.HorizontalAlign = HorizontalAlign.Left;
                    field.ItemStyle.HorizontalAlign = HorizontalAlign.Left;
                    field.HeaderStyle.CssClass = "HorizontalAlign-left";
                    field.SortExpression = columnName;//排序字段
                    //是否为图片列
                    if (columnName.Contains(Globals.DICT_COLUMN_URGENCY_ORDER))
                    {
                        field.HeaderText = columnValue;//表头
                        field.HeaderImageUrl = "~/images/mark/HQ.png";
                        field.ShowHeader = false;

                    }
                    //现场图片
                    if (columnName.Contains(Globals.DICT_COLUMN_PHOTO))
                    {
                        field.HeaderText = columnValue;//表头
                        field.HeaderImageUrl = "~/images/mark/TP.png";
                        field.ShowHeader = false;
                    }
                    //现场录音
                    if (columnName.Contains(Globals.DICT_COLUMN_TAPE))
                    {
                        field.HeaderText = columnValue;//表头
                        field.HeaderImageUrl = "~/images/mark/LY.png";
                        field.ShowHeader = false;
                    }
                    //是否查看
                    if (columnName.Contains(Globals.DICT_COLUMN_ISLOOK))
                    {
                        field.HeaderText = columnValue;//表头
                        field.HeaderImageUrl = "~/images/mark/WK.png";
                        field.ShowHeader = false;
                    }
                    //是否到场
                    if (columnName.Contains(Globals.DICT_COLUMN_ISDAOCHANG))
                    {
                        field.HeaderText = columnValue;//表头
                        field.HeaderImageUrl = "~/images/mark/dc.jpg";
                        field.ShowHeader = false;
                    }
                    //材料补填
                    if (columnName.Contains(Globals.DICT_COLUMN_ISEXTENDS))
                    {
                        field.HeaderText = columnValue;//表头
                        field.HeaderImageUrl = "~/images/mark/CLBQ.png";
                        field.ShowHeader = false;
                    }
                    //延期结果
                    if (columnName.Contains(Globals.DICT_COLUMN_TRACK_RESULT))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/guaqi.gif";
                        field.ShowHeader = false;
                    }
                    //销单结果
                    if (columnName.Contains(Globals.DICT_COLUMN_XIAODAN_RESULT))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/yxd.gif";
                        field.ShowHeader = false;
                    }
                    //入保结果
                    if (columnName.Contains(Globals.DICT_COLUMN_RB_RESULT))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/rbtg.png";
                        field.ShowHeader = false;
                    }
                    //是否入保
                    if (columnName.Contains(Globals.DICT_COLUMN_DOINSURANCE))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/mark/RB.png";
                        field.ShowHeader = false;
                    }
                    //路面修复
                    if (columnName.Contains(Globals.DICT_COLUMN_LMXF))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/mark/LMXF.png";
                        field.ShowHeader = false;
                    }
                    //区分请照
                    if (columnName.Contains(Globals.DICT_COLUMN_QZORGZ))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/mark/QZ.png";
                        field.ShowHeader = false;
                    }
                    //重复单
                    if (columnName.Contains(Globals.DICT_COLUMN_REPEAT))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/mark/cfd.png";
                        field.ShowHeader = false;
                    }
                    //催办工单
                    if (columnName.Contains(Globals.DICT_COLUMN_REMINDER))
                    {
                        field.HeaderText = columnValue;//表头images/guaqi.gif
                        field.HeaderImageUrl = "~/images/mark/cb.png";
                        field.ShowHeader = false;
                    }
                    gvName.Columns.Add(field);
                }
            }
        }

    }

    public static string _NewColunms(DataTable tableDataName, OracleDataBase odb, string tableName, ref string columns)
    {
        StringBuilder sb = new StringBuilder();
        Dictionary<string, ShowListClass> dctNames = GetTableColumnNames(tableName, odb);
        ShowListClass show = new ShowListClass();
        if (tableDataName.Rows.Count > 0)
        {
            string columnName = string.Empty;
            string columnValue = string.Empty;
            for (int i = 0; i < tableDataName.Columns.Count; i++)
            {
                columnName = tableDataName.Columns[i].ColumnName.ToUpper();
                dctNames.TryGetValue(columnName, out show);
                columnValue = show.name;
                string th = columnName == "ID" ? "<th style='display:none;'>{0}</th>" : "<th>{0}</th>";
                if (dctNames.ContainsKey(columnName))
                {
                    sb.AppendFormat(th, columnValue);
                    columns = columns + columnName + ",";
                }
            }
        }
        return "<thead><tr>" + sb.ToString() + "</tr></thead>";
    }
    public static string _InitColunms(OracleDataBase odb, string tableName)
    {
        StringBuilder sb = new StringBuilder();
        Dictionary<string, ShowListClass> dctNames = GetTableColumnNames(tableName, odb);
        string Columns = ConfigurationManager.AppSettings["ListColunms"] == null ? "ID,URGENCY_ORDER,PHOTO,CUSTOMSERVICEID,INFONUM,ACCEPTTIME,SOLVETIME_PLAN,ACCEPTSTATION,REPORTTYPE,REPORTCONTENT,HAPPENADDR,ACCEPTREMARK" : ConfigurationManager.AppSettings["ListColunms"];
        string[] ListColunms = Columns.Split(',');
        if (ListColunms.Length > 0)
        {
            string columnName = string.Empty;
            string columnValue = string.Empty;
            ShowListClass show = new ShowListClass();

            sb.Append("\"aoColumns\": [");


            for (int i = 0; i < ListColunms.Length; i++)
            {
                columnName = ListColunms[i].ToUpper();
                dctNames.TryGetValue(columnName, out show);
                columnValue = show.name;
                if (dctNames.ContainsKey(columnName))
                {
                    if (columnName == "ID" || columnName == "URGENCY_ORDER" || columnName == "PHOTO")
                        sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue + "\", \"sClass\": \"center\", \"bVisible\": false }");
                    else
                    {
                        if (Convert.ToInt32(show.length) >= 200)
                        {
                            sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue +
                                      "\" ,\"sWidth\": \"260px\"}");
                        }
                        else
                        {
                            sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue + "\", \"sClass\": \"center\",\"sWidth\": \"190px\" }");
                        }

                        //sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue + "\",\"sWidth\": \"100%\"}");

                    }
                    if (i != ListColunms.Length - 1)
                        sb.Append(",");
                }
            }
            sb.Append("], ");
        }
        return sb.ToString();
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="odb"></param>
    /// <param name="tableName"></param>
    /// <param name="countColums"></param>
    /// <param name="operateBar">第一列添加工具栏</param>
    /// <returns></returns>
    public static string _InitColunm(OracleDataBase odb, string tableName, ref int countColums, bool operateBar = false)
    {
        StringBuilder sb = new StringBuilder();
        Dictionary<string, ShowListClass> dctNames = GetTableColumnNames(tableName, odb);
        countColums = dctNames.Count;
        string columnName = string.Empty;
        string columnValue = string.Empty;
        ShowListClass show = new ShowListClass();
        sb.Append("\"aoColumns\": [");
        int index = 0;
        foreach (var item in dctNames)
        {
            columnName = item.Key.ToUpper();
            dctNames.TryGetValue(columnName, out show);
            columnValue = show.name;
            if (dctNames.ContainsKey(columnName))
            {
                if (index == 0 && operateBar)
                {
                    index++;
                    sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"操作\", \"sClass\": \"left\" ,\"sWidth\": \"110px\"},");
                }

                if (columnName == "ID" || columnName == "URGENCY_ORDER" || columnName == "PHOTO")
                    sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue + "\", \"sClass\": \"center\", \"bVisible\": false }");
                else
                {
                    if (!string.IsNullOrWhiteSpace(show.listlenght))
                    {
                        sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue +
                                  "\",\"sWidth\": \"" + show.listlenght + "px\"}");
                    }
                    else
                    {
                        if (Convert.ToInt32(show.length) >= 200)
                        {
                            sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue +
                                      "\" ,\"sWidth\": \"260px\"}");
                        }
                        else
                        {
                            sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue + "\",\"sWidth\": \"170px\"}");
                        }
                    }

                    //sb.Append("{ \"mData\": \"" + columnName + "\", \"sTitle\" : \"" + columnValue + "\",\"sWidth\": \"100%\"}");

                }
                sb.Append(",");
            }
        }
        sb.Remove(sb.Length - 1, 1);
        sb.Append("], ");

        return sb.ToString();
    }
    /// <summary>
    /// 动态获取 数据字典中的列名
    /// </summary>
    /// <param name="tableName">数据字典中的表，如果传多个用逗号分割，格式如下:" 'tz_main','tz_main_clinfo' "</param>
    /// <param name="odb">OracleDataBase</param>
    /// <returns>Dictionary格式的列模板</returns>
    public static Dictionary<string, ShowListClass> GetTableColumnNames(string tableName, OracleDataBase odb)
    {
        //tip 是否显示 0 显示1不显示 
        //validity 是否有效 0有效1无效
        string sql = string.Format("select  s_dict.FIELDNAME,s_dict.FIELDDISNAME,s_dict.LENGTH,s_dict.LISTLENGTH from s_dict where  validity=0   and tableid in (select tableid from s_tabinfo where tablename in ({0}) ) order by s_dict.fieldorder", tableName.ToUpper());
        DataTable dt = odb.GetDataSet(sql).Tables[0];
        Dictionary<string, ShowListClass> dctNames = new Dictionary<string, ShowListClass>();
        foreach (DataRow dr in dt.Rows)
        {
            //2014年7月3日10:25:38 张豪修改，请注意，字典添加重复key的话 会直接报异常的
            if (!dctNames.ContainsKey(dr["FIELDNAME"].ToString().ToUpper()))
            {
                ShowListClass show = new ShowListClass();
                show.name = dr["FIELDDISNAME"].ToString();
                show.length = dr["LENGTH"].ToString();
                show.listlenght = dr["LISTLENGTH"].ToString();
                dctNames.Add(dr["FIELDNAME"].ToString().ToUpper(), show);
            }
        }
        return dctNames;
    }

    /// <summary>
    /// 已重载.计算两个日期的时间间隔（分钟）,返回的是时间间隔的日期差的绝对值.
    /// </summary>
    /// <param name="DateTime1">第一个日期和时间</param>
    /// <param name="DateTime2">第二个日期和时间</param>
    /// <returns></returns>
    public static string DateDiff(DateTime DateTime1, DateTime DateTime2)
    {
        string dateDiff = string.Empty;
        try
        {
            TimeSpan ts1 = new TimeSpan(DateTime1.Ticks);
            TimeSpan ts2 = new TimeSpan(DateTime2.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            //dateDiff = ts.Days.ToString() + "天"
            //        + ts.Hours.ToString() + "小时"
            //        + ts.Minutes.ToString() + "分钟"
            //        + ts.Seconds.ToString() + "秒";
            dateDiff = string.Format("{0} 分钟", ts.Minutes.ToString());
        }
        catch (Exception ex)
        {
            Loger.Error(" DateDiff(DateTime DateTime1, DateTime DateTime2) =====》", ex);
        }
        return dateDiff;
    }
    /// <summary>
    /// 已重载.计算一个时间与当前本地日期和时间的时间间隔,返回的是时间间隔的日期差的绝对值.
    /// </summary>
    /// <param name="DateTime1">一个日期和时间</param>
    /// <returns></returns>
    public static string DateDiff(DateTime DateTime1)
    {
        return DateDiff(DateTime1, DateTime.Now);
    }

    /// <summary>
    /// 获取时间戳
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static double ToTimestamp(DateTime value)
    {
        TimeSpan span = (value - new DateTime(1970, 1, 1, 0, 0, 0, 0).ToLocalTime());
        return (double)span.TotalSeconds;
    }
    /// <summary>
    /// 根据地址模糊匹配坐标
    /// </summary>
    /// <param name="tableName">tz_dmku</param>
    /// <param name="addr">地址</param>
    /// <returns>示例：31333,3322</returns>
    public static string xy = "";
    public static string GetLocation(string tableName, string addr)
    {
        xy = "";
        GetLocationInfo(tableName, addr);
        return xy;
    }

    private static void GetLocationInfo(string tableName, string addr)
    {

        string sqlStr = "select * from " + tableName + " where (mc like '%" + addr.ToUpper() + "%' or py like '%" + addr.ToUpper() + "%') and rownum <=1 ";
        DataSet ds = DbHelperOra.Query(sqlStr);

        if (ds != null && ds.Tables.Count > 0)
        {
            DataTable dt = ds.Tables[0];
            if (dt.Rows.Count > 0)
            {
                xy = Convert.ToString(dt.Rows[0]["X"]) + "," + Convert.ToString(dt.Rows[0]["Y"]);
            }
            else
            {
                //如果查询结果为空，则addr删除最后一位，递归查询
                addr = addr.Substring(0, addr.Length - 1);
                GetLocationInfo(tableName, addr);
            }
        }

    }

    /// <summary>
    /// 维护zlsdb库的地名表
    /// </summary>
    /// <returns></returns>
    public static bool InsertDmKu()
    {
        OracleDataBase database = new OracleDataBase();
        string sql = "insert into tz_dmku(mc, py, x, y, type, qp, prjname)values()";
        if (database.InsertOrUpdate(sql) > 0)
        {
            return true;
        }
        return false;
    }
    /// <summary>
    /// 根据用户名获取配置的受理站点信息
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static ArrayList GetAcceptstationInfo(string uid)
    {
        ArrayList al = new ArrayList();
        string RescatalogName = ConfigurationManager.AppSettings["RescatalogName"].ToString(); //资源大类名称
        string rescatalogName = RescatalogName;
        string rescatalog = GetRescatalog(rescatalogName);
        if (string.IsNullOrEmpty(rescatalog))
            return al;

        ArrayList holdResources = DAL_AuthorGlobal.getResources(uid);
        for (int i = 0; i < holdResources.Count; i++)
        {
            ResourceBean resBean = (ResourceBean)holdResources[i];
            if (resBean.rescatalog == rescatalog)
            {
                al.Add(resBean.resname);
            }
        }
        return al;
    }

    /// <summary>
    /// 获取的HeaderText获取该列对应的索引
    /// </summary>
    /// <param name="gdView">GridView控件</param>
    /// <param name="columnName">HeaderText名</param>
    public static int GetGridViewColumnsIndex(GridView gdView, string columnName)
    {
        int index = -1;
        for (int i = 0; i < gdView.Columns.Count; i++)
        {
            DataControlField dcField = gdView.Columns[i];

            if (dcField.HeaderText.Equals(columnName) || dcField.HeaderText.Equals(columnName + "▼") || dcField.HeaderText.Equals(columnName + "▲"))
            {
                index = i;
            }
        }
        return index;
    }

    /// <summary>
    /// 获取当前用户配置的受理站点
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static string GetAcceptstationValuesForDisp(string uid)
    {
        if (!string.IsNullOrEmpty(uid))
        {
            System.Collections.ArrayList list = GetAcceptstationInfoForDIsp(uid);
            return ConvertArrayListToString(list);
        }
        return string.Empty;
    }

    /// <summary>
    /// 将arraylist种的的值组成 '值',形式的字符串
    /// </summary>
    /// <param name="list"></param>
    /// <returns></returns>
    public static string ConvertArrayListToString(ArrayList list)
    {
        if (list == null || list.Count < 0) return string.Empty;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < list.Count; i++)
        {
            if (i == list.Count - 1)
            {
                result.Append(string.Format("'{0}'", list[i].ToString()));
            }
            else
            {
                result.Append(string.Format("'{0}',", list[i].ToString()));
            }
        }
        return result.ToString();
    }
    /// <summary>
    /// 根据用户名获取配置的菜单信息
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static ArrayList GetAcceptstationInfoForMenu(string uid)
    {
        ArrayList al = new ArrayList();
        string rescatalogNmae = ConfigurationManager.AppSettings["RescatalogNameForDisp"].ToString();
        string rescatalog = GetRescatalog(rescatalogNmae);
        if (string.IsNullOrEmpty(rescatalog))
            return al;

        ArrayList holdResources = AuthorGlobal.getResources(uid);
        for (int i = 0; i < holdResources.Count; i++)
        {
            ResourceBean resBean = (ResourceBean)holdResources[i];
            if (resBean.rescatalog == rescatalog)
            {
                al.Add(resBean.resname);
            }
        }
        return al;
    }

    /// <summary>
    /// 根据用户名获取配置的受理站点信息
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static ArrayList GetAcceptstationInfoForDIsp(string uid, string type)
    {
        ArrayList al = new ArrayList();
        string rescatalogNmae = ConfigurationManager.AppSettings["RescatalogNameForDisp"].ToString();
        if (type == "1")
        {
            rescatalogNmae = ConfigurationManager.AppSettings["H5zhName"].ToString();
        }
        string rescatalog = GetRescatalog(rescatalogNmae);
        if (string.IsNullOrEmpty(rescatalog))
            return al;

        ArrayList holdResources = AuthorGlobal.getResources(uid);
        for (int i = 0; i < holdResources.Count; i++)
        {
            ResourceBean resBean = (ResourceBean)holdResources[i];
            if (resBean.rescatalog == rescatalog)
            {
                al.Add(resBean.resname);
            }
        }
        return al;
    }

    /// <summary>
    /// 根据用户名获取配置的受理站点信息
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static ArrayList GetAcceptstationInfoForDIsp(string uid)
    {
        ArrayList al = new ArrayList();
        string rescatalogNmae = ConfigurationManager.AppSettings["RescatalogNameForDisp"].ToString();
        string rescatalog = GetRescatalog(rescatalogNmae);
        if (string.IsNullOrEmpty(rescatalog))
            return al;

        ArrayList holdResources = AuthorGlobal.getResources(uid);
        for (int i = 0; i < holdResources.Count; i++)
        {
            ResourceBean resBean = (ResourceBean)holdResources[i];
            if (resBean.rescatalog == rescatalog)
            {
                al.Add(resBean.resname);
            }
        }
        return al;
    }
    /// <summary>
    /// 根据资源名称大类获取ID
    /// </summary>
    /// <param name="rescatalogName"></param>
    /// <returns></returns>
    public static string GetRescatalog(string rescatalogName)
    {
        OracleDataBase odb = new OracleDataBase("1");
        string strSql = string.Format("select id from author_rescatalog t where t.cataname='{0}'", rescatalogName);
        object obj = odb.GetScalarobj(strSql);
        return obj != null ? obj.ToString() : string.Empty;
    }

    public static void BindDropDownList(string sqlstr, string value, string text, DropDownList list)
    {
        try
        {
            OracleDataBase odb = new OracleDataBase();
            DataSet ds = odb.GetDataSet(sqlstr);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                list.Items.Clear();
                list.Items.Add(new ListItem("==请选择==", "==请选择=="));
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    list.Items.Add(new ListItem(row[text].ToString(), row[value].ToString()));
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("BindDropDownList==>SQL:" + sqlstr, ex);
        }
    }
    public static void BindDropDownList(OracleDataBase odb, string sqlstr, string value, string text, DropDownList list)
    {
        try
        {
            DataSet ds = odb.GetDataSet(sqlstr);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                list.Items.Clear();
                list.Items.Add(new ListItem("==请选择==", "==请选择=="));
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    list.Items.Add(new ListItem(row[text].ToString(), row[value].ToString()));
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("BindDropDownList==>SQL:" + sqlstr, ex);
        }
    }

    public static void BindHtmlSelect(OracleDataBase odb, string sqlstr, string value, string text, HtmlSelect list)
    {
        try
        {
            DataSet ds = odb.GetDataSet(sqlstr);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                list.Items.Clear();
                list.Items.Add(new ListItem("请选择", "请选择"));
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    list.Items.Add(new ListItem(row[text].ToString(), row[value].ToString()));
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("BindHtmlSelect==>SQL:" + sqlstr, ex);
        }
    }
}
