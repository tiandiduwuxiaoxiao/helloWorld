﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using System.IO;
using System.Web;
using Microsoft.Office.Interop.Excel;

using System.Text.RegularExpressions;


public class ExcelExport
{
    /// <summary>   
    /// 直接导出Excel   
    /// </summary>   
    /// <param name="ds">数据源DataSet</param>   
    /// <param name="fileName">保存文件名</param>   
    /// <returns></returns>   
    //public bool DoExport(DataSet ds, string sheetName)
    //{
    //    string saveFileName = string.Empty;
    //    //弹出保存框
    //    SaveFileDialog saveDialog = new SaveFileDialog();
    //    saveDialog.DefaultExt = "xls";
    //    saveDialog.Filter = "Excel文件|*.xls";
    //    saveDialog.FileName = sheetName;


    //    if (saveDialog.ShowDialog() == DialogResult.OK)
    //    {
    //        saveFileName = saveDialog.FileName;
    //    }
    //    else
    //    {
    //        return false;
    //    }

    //    if (ds.Tables.Count == 0)
    //    {
    //        MessageBox.Show("未查询到相关数据，请确认！");
    //        return false;
    //    }
    //    //1.创建excelapp对象
    //    Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
    //    if (excelApp == null)
    //    {
    //        MessageBox.Show("无法创建Excel对象，可能您的机器未安装Excel");
    //        return false;
    //    }

    //    Microsoft.Office.Interop.Excel.Workbooks workBooks = excelApp.Workbooks;
    //    Microsoft.Office.Interop.Excel.Workbook workBook = workBooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
    //    Microsoft.Office.Interop.Excel.Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.Worksheets[1];//取得sheet1 

    //    workSheet.Name = sheetName;

    //    int rowindex = 2;
    //    int colindex = 0;

    //    System.Data.DataTable table = ds.Tables[0];
    //    //foreach (DataColumn col in table.Columns)
    //    //{
    //    //    colindex++;
    //    //    workSheet.Cells[1, colindex] = "";
    //    //    workSheet.Cells[2, colindex] = col.ColumnName;
    //    //    Range range = (Range)workSheet.Cells[2, colindex];
    //    //    range.Font.Bold = true;

    //    //}

    //    for (int i = 0; i < table.Columns.Count; i++)
    //    {
    //        int j = i + 1;//因为Excel的索引是从1开始，而DataTable是从0开始.
    //        workSheet.Cells[1, j] = "";
    //        workSheet.Cells[2, j] = table.Rows[table.Rows.Count - 1][i].ToString();
    //        Range range = (Range)workSheet.Cells[2, j];
    //        range.Font.Bold = true;
    //    }
    //    table.Rows.RemoveAt(table.Rows.Count - 1);

    //    //获取第一行第一列和第二行第一列的单元格区域
    //    Range mergeRows= workSheet.get_Range(workSheet.Cells[1, 1], workSheet.Cells[2, 1]);
    //    mergeRows.MergeCells = true;//合并单元格
    //    mergeRows.HorizontalAlignment = XlHAlign.xlHAlignCenter;
    //    mergeRows.Font.Bold = true;
    //    //获取第一行第二列到第第一行最后一列的单元格区域
    //    int col_count = (table.Columns.Count - 1) / 2;
    //    Range mergeCells1 = workSheet.get_Range(workSheet.Cells[1, 2], workSheet.Cells[1, col_count + 1]);
    //    mergeCells1.MergeCells = true;
    //    workSheet.Cells[1, 2] = "本期发生长度  (米)";
    //    mergeCells1.HorizontalAlignment = XlHAlign.xlHAlignCenter;
    //    mergeCells1.Font.Bold = true;

    //    Range mergeCells2 = workSheet.get_Range(workSheet.Cells[1, col_count + 2],workSheet.Cells[1, table.Columns.Count] );
    //    mergeCells2.MergeCells = true;
    //    workSheet.Cells[1, col_count + 2] = "期末发生长度  (米)";
    //    mergeCells2.HorizontalAlignment = XlHAlign.xlHAlignCenter;
    //    mergeCells2.Font.Bold = true;

    //    foreach (DataRow row in table.Rows)
    //    {
    //        rowindex++;
    //        colindex = 0;
    //        foreach (DataColumn col in table.Columns)
    //        {
    //            colindex++;
    //            //正则匹配是否为中文
    //            //Regex regex = new Regex("^[\u4e00-\u9fa5]{0,}$");
    //            //double clo_value = !regex.IsMatch(row[col.ColumnName].ToString()) ? ConvertUtil.ToDouble(row[col.ColumnName].ToString()) : 0;

    //            workSheet.Cells[rowindex, colindex] = row[col.ColumnName].ToString();
    //            Range data_range = (Range)workSheet.Cells[rowindex, colindex];
    //            //过滤掉口径这一列
    //            if (colindex == 1)
    //            {
    //                data_range.Font.Bold = true; //所有口径列字体加粗
    //            }
    //            //else
    //            //{
    //            //    data_range.Font.ColorIndex = clo_value > 0 ? 4 : 0;//如果大于0，则设置字体颜色为绿色
    //            //    data_range.Font.ColorIndex = clo_value < 0 ? 3 : 0;//如果小于0，则设置字体颜色为红色
    //            //}
    //        }
    //    }
    //    workSheet.Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;// 文本水平居中方式 
    //    workSheet.Cells.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;//文本垂直居中方式   
    //    workSheet.Columns.EntireColumn.AutoFit();//列宽自适应

    //    excelApp.Visible = false;
    //    excelApp.DisplayAlerts = false;//保存Excel的时候，不弹出是否保存的窗口直接进行保存  


    //    if (!string.IsNullOrEmpty(saveFileName))
    //    {
    //        try
    //        {
    //            workBook.Saved = true;
    //            workBook.SaveCopyAs(saveFileName);
    //        }
    //        catch (Exception ex)
    //        {
    //            return false;
    //            MessageBox.Show("导出文件时出错,文件可能正被打开！\n" + ex.Message);
    //        }

    //    }
    //    excelApp.Quit();
    //    excelApp = null;
    //    GC.Collect();

    //    return true;
    //}
    /// <summary>   
    /// 直接导出Excel   
    /// </summary>   
    /// <param name="ds">数据源DataSet</param>   
    /// <param name="columns">列名数组,允许为空(columns=null),为空则表使用默认数据库列名 </param>   
    /// <param name="fileName">保存文件名(例如：E:\a.xls)</param>   
    /// <returns></returns>   
    public  bool DoExport(DataSet ds, string[] columns, string fileName)
    {
        if (ds.Tables.Count == 0 || fileName == string.Empty)
        {
            return false;
        }
        Microsoft.Office.Interop.Excel.Application excel = new ApplicationClass();
        int rowindex = 1;
        int colindex = 0;
        Workbook work = excel.Workbooks.Add(true);
        //Worksheet sheet1 = (Worksheet)work.Worksheets[0];   
        System.Data.DataTable table = ds.Tables[0];
        if (columns != null)
        {
            for (int i = 0; i < columns.Length; i++)
            {
                colindex++;
                if (columns[i] != null && columns[i] != "")
                {
                    excel.Cells[1, colindex] = columns[i];
                }
                else
                {
                    excel.Cells[1, colindex] = table.Columns[i].ColumnName;
                }
            }
        }
        else
        {
            foreach (DataColumn col in table.Columns)
            {
                colindex++;
                excel.Cells[1, colindex] = col.ColumnName;
            }
        }
        foreach (DataRow row in table.Rows)
        {
            rowindex++;
            colindex = 0;
            foreach (DataColumn col in table.Columns)
            {
                colindex++;
                excel.Cells[rowindex, colindex] = row[col.ColumnName].ToString();
            }
        }
        excel.Visible = false;
        //((Worksheet)work.Sheets[0]).Name = "sss";   
        excel.ActiveWorkbook.SaveAs(fileName, XlFileFormat.xlExcel7, null, null, false, false, XlSaveAsAccessMode.xlNoChange, null, null, null, null, null);
        excel.Quit();
        excel = null;
        GC.Collect();
        return true;
    }

    /// <summary>   
    /// 直接导出Excel   
    /// </summary>   
    /// <param name="sql">SQL查询语句</param>   
    /// <param name="columns">列名数组</param>   
    /// <param name="fileName">保存文件名(例如：E:\a.xls)</param>   
    /// <returns></returns>   
    public bool DoExport(string sql, string[] columns, string fileName)
    {
        OracleDataBase db = new OracleDataBase();

        DataSet ds = db.GetDataSet(sql);
        if (ds.Tables.Count == 0 || fileName == string.Empty)
        {
            return false;
        }
        Microsoft.Office.Interop.Excel.Application excel = new ApplicationClass();
        int rowindex = 1;
        int colindex = 0;
        Workbook work = excel.Workbooks.Add(true);
        //Worksheet sheet1 = (Worksheet)work.Worksheets[0];   
        System.Data.DataTable table = ds.Tables[0];
        if (columns != null)
        {
            for (int i = 0; i < columns.Length; i++)
            {
                colindex++;
                if (columns[i] != null && columns[i] != "")
                {
                    excel.Cells[1, colindex] = columns[i];
                }
                else
                {
                    excel.Cells[1, colindex] = table.Columns[i].ColumnName;
                }
            }
        }
        else
        {
            foreach (DataColumn col in table.Columns)
            {
                colindex++;
                excel.Cells[1, colindex] = col.ColumnName;
            }
        }
        foreach (DataRow row in table.Rows)
        {
            rowindex++;
            colindex = 0;
            foreach (DataColumn col in table.Columns)
            {
                colindex++;
                excel.Cells[rowindex, colindex] = row[col.ColumnName].ToString();
            }
        }
        excel.Visible = false;
        //((Worksheet)work.Sheets[0]).Name = "sss";   
        excel.ActiveWorkbook.SaveAs(fileName, XlFileFormat.xlExcel9795, null, null, false, false, XlSaveAsAccessMode.xlNoChange, null, null, null, null, null);
        excel.Quit();
        excel = null;
        GC.Collect();
        return true;
    }
    /// <summary>   
    /// 通过流导出Excel   
    /// </summary>   
    /// <param name="ds">数据源DataSet</param>   
    /// <param name="fileName">保存文件名(例如：a.xls)</param>   
    /// <returns></returns>   
    public bool StreamExport(DataSet ds, string fileName)
    {
        if (ds.Tables.Count == 0 || fileName == string.Empty)
        {
            return false;
        }
        System.Data.DataTable dt = ds.Tables[0];
        StringBuilder content = new StringBuilder();
        StringBuilder strtitle = new StringBuilder();
        content.Append("<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>");
        content.Append("<head><title></title><meta http-equiv='Content-Type' content=\"text/html; charset=utf-8\"></head><body><table x:str cellspacing='0' rules='all' border='1' id='title1' style='border-collapse:collapse;' mce_style='border-collapse:collapse;'>");
        content.Append("<tr>");
        for (int j = 0; j < dt.Columns.Count; j++)
        {
            content.Append("<td>" + dt.Columns[j].ColumnName + "</td>");
        }
        content.Append("</tr>\n");
        for (int j = 0; j < dt.Rows.Count; j++)
        {
            content.Append("<tr>");
            for (int k = 0; k < dt.Columns.Count; k++)
            {
                content.Append("<td>" + dt.Rows[j][k].ToString() + "</td>");
            }
            content.Append("</tr>\n");
        }
        content.Append("</table></body></html>");
        content.Replace(" ", "");
        //fileContent = (byte[])System.Text.Encoding.Default.GetBytes(content.ToString());       
        //System.Web.UI.WebControls.   
        System.Web.HttpContext.Current.Response.Clear();
        System.Web.HttpContext.Current.Response.Buffer = true;
        System.Web.HttpContext.Current.Response.ContentType = "application/ms-excel";
        System.Web.HttpContext.Current.Response.Charset = "utf-8";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
        System.Web.HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName + ".xls");//HttpUtility.UrlEncode(fileName));   
        //            HttpUtility.UrlEncode(fileName,Encoding.UTF8);   
        //System.Web.HttpContext.Current.Response.ContentEncoding=System.Text.Encoding.Default;   
        System.Web.HttpContext.Current.Response.Write(content.ToString());
        System.Web.HttpContext.Current.Response.End();

        //Response.Charset = "UTF-8";
        //this.EnableViewState = false;
        //Response.AddHeader("Content-Disposition", "attachment; filename=" + DateTime.Now.ToString() + ".xls");
        //Response.ContentType = "application/ms-excel";
        return true;
    }
    //public bool ttete()
    //{

    //    StringWriter sw = new StringWriter();
    //    sw.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
    //    sw.WriteLine("<head>");
    //    sw.WriteLine("<!--[if gte mso 9]>");
    //    sw.WriteLine("<xml>");
    //    sw.WriteLine(" <x:ExcelWorkbook>");
    //    sw.WriteLine("  <x:ExcelWorksheets>");
    //    sw.WriteLine("   <x:ExcelWorksheet>");
    //    //sw.WriteLine("    <x:Name>" + sheetName + "</x:Name>");
    //    sw.WriteLine("    <x:WorksheetOptions>");
    //    sw.WriteLine("      <x:Print>");
    //    sw.WriteLine("       <x:ValidPrinterInfo />");
    //    sw.WriteLine("      </x:Print>");
    //    sw.WriteLine("    </x:WorksheetOptions>");
    //    sw.WriteLine("   </x:ExcelWorksheet>");
    //    sw.WriteLine("  </x:ExcelWorksheets>");
    //    sw.WriteLine("</x:ExcelWorkbook>");
    //    sw.WriteLine("</xml>");
    //    sw.WriteLine("<![endif]-->");

    //    sw.WriteLine("</head>");
    //    sw.WriteLine("<body>");
    //    sw.WriteLine(" <table id='table' border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse;'><tr> <td colspan='9' style='font-size: 22px; font-weight: bold; padding: 10px 0 10px 0'        align='center'>        上海浦东威立雅自来水有限公司管网所 </td></tr><tr><td colspan='9'  style='font-size: 14px; font-weight: bold; padding: 3px 0 3px 0' align='center'>小修工作统计明细表</td></tr> <tr><td rowspan='2'>序号</td><td rowspan='2'>工作单编号</td><td rowspan='2'>施工地点</td><td colspan='2'>日期</td><td rowspan='2'>修漏养护类型</td><td rowspan='2'>工作内容</td><td rowspan='2'>&nbsp;修理方式耗用材料 口径×长度</td><td rowspan='2'>备注</td></tr><tr><td>开工</td><td>竣工</td></tr>");
    //    //<tr><td rowspan='2'>序号</td><td rowspan="2'>工作单编号</td><td rowspan='2'>施工地点</td><td colspan='2'>日期</td><td rowspan='2'>修漏养护类型</td><td rowspan='2'>工作内容</td><td rowspan='2'>&nbsp;修理方式耗用材料 口径×长度</td><td rowspan='2'>备注</td></tr><tr><td>开工</td><td>竣工</td></tr>
    //    //sw.WriteLine(html);
    //    sw.WriteLine("</table>");
    //    sw.WriteLine("</body>");
    //    sw.WriteLine("</html>");
    //    sw.Close();
    //    Response.Clear();
    //    Response.Buffer = true;
    //    Response.Charset = "UTF-8";
    //    this.EnableViewState = false;
    //    Response.AddHeader("Content-Disposition", "attachment; filename=" + DateTime.Now.ToString() + ".xls");
    //    Response.ContentType = "application/ms-excel";
    //    Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
    //    Response.Write(sw);
    //    Response.End();
    //}

    /// <summary>   
    /// 通过流导出Excel   
    /// </summary>   
    /// <param name="ds">数据源DataSet</param>   
    /// <param name="columns">列名数组,允许为空(columns=null),为空则表使用默认数据库列名</param>   
    /// <param name="fileName"></param>   
    /// <returns></returns>   
    public static bool StreamExport(DataSet ds, string[] columns, string fileName)
    {
        if (ds.Tables.Count == 0 || fileName == string.Empty)
        {
            return false;
        }
        System.Data.DataTable dt = ds.Tables[0];
        StringBuilder content = new StringBuilder();
        StringBuilder strtitle = new StringBuilder();
        content.Append("<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>");
        content.Append("<head><title></title><meta http-equiv='Content-Type' content=\"text/html; charset=utf-8\"></head><body><table x:str cellspacing='0' rules='all' border='1' id='title1' style='border-collapse:collapse;' mce_style='border-collapse:collapse;'>");
        content.Append("<tr>");
        if (columns != null)
        {
            for (int i = 0; i < columns.Length; i++)
            {
                if (columns[i] != null && columns[i] != "")
                {
                    content.Append("<td>" + columns[i] + "</td>");
                }
                else
                {
                    content.Append("<td>" + dt.Columns[i].ColumnName + "</td>");
                }
            }
        }
        else
        {
            for (int j = 0; j < dt.Columns.Count; j++)
            {
                content.Append("<td>" + dt.Columns[j].ColumnName + "</td>");
            }
        }
        content.Append("</tr>\n");
        for (int j = 0; j < dt.Rows.Count; j++)
        {
            content.Append("<tr>");
            for (int k = 0; k < dt.Columns.Count; k++)
            {
                content.Append("<td>" + dt.Rows[j][k].ToString() + "</td>");
            }
            content.Append("</tr>\n");
        }
        content.Append("</table></body></html>");
        content.Replace(" ", "");
        //fileContent = (byte[])System.Text.Encoding.Default.GetBytes(content.ToString());       
        //System.Web.UI.WebControls.   
       
            System.Web.HttpContext.Current.Response.Clear();
            System.Web.HttpContext.Current.Response.Buffer = true;
            System.Web.HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            System.Web.HttpContext.Current.Response.Charset = "utf-8";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
            System.Web.HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);//HttpUtility.UrlEncode(fileName));   
            //            HttpUtility.UrlEncode(fileName,Encoding.UTF8);   
            //System.Web.HttpContext.Current.Response.ContentEncoding=System.Text.Encoding.Default;   
            System.Web.HttpContext.Current.Response.Write(content.ToString());
          //  HttpContext.Current.ApplicationInstance.CompleteRequest();
          
            System.Web.HttpContext.Current.Response.End();
       
       
        return true;
    }
    /// <summary>   
    /// 通过流导出Excel   
    /// </summary>   
    /// <param name="ds">数据源DataSet</param>   
    /// <param name="columns">列名数组,允许为空(columns=null),为空则表使用默认数据库列名</param>   
    /// <param name="fileName"></param>   
    /// <returns></returns>   
    public bool StreamExport(string sql, string[] columns, string fileName)
    {
        OracleDataBase db = new OracleDataBase();
        DataSet ds = db.GetDataSet(sql);
        if (ds.Tables.Count == 0 || fileName == string.Empty)
        {
            return false;
        }
        System.Data.DataTable dt = ds.Tables[0];
        StringBuilder content = new StringBuilder();
        StringBuilder strtitle = new StringBuilder();
        content.Append("<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>");
        content.Append("<head><title></title><meta http-equiv='Content-Type' content=\"text/html; charset=utf-8\"></head><body><table x:str cellspacing='0' rules='all' border='1' id='title1' style='border-collapse:collapse;' mce_style='border-collapse:collapse;'>");
        content.Append("<tr>");
        if (columns != null)
        {
            for (int i = 0; i < columns.Length; i++)
            {
                if (columns[i] != null && columns[i] != "")
                {
                    content.Append("<td>" + columns[i] + "</td>");
                }
                else
                {
                    content.Append("<td>" + dt.Columns[i].ColumnName + "</td>");
                }
            }
        }
        else
        {
            for (int j = 0; j < dt.Columns.Count; j++)
            {
                content.Append("<td>" + dt.Columns[j].ColumnName + "</td>");
            }
        }
        content.Append("</tr>\n");
        for (int j = 0; j < dt.Rows.Count; j++)
        {
            content.Append("<tr>");
            for (int k = 0; k < dt.Columns.Count; k++)
            {
                content.Append("<td>" + dt.Rows[j][k].ToString() + "</td>");
            }
            content.Append("</tr>\n");
        }
        content.Append("</table></body></html>");
        content.Replace(" ", "");
     
        System.Web.HttpContext.Current.Response.Clear();
        System.Web.HttpContext.Current.Response.Buffer = true;
        System.Web.HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
        System.Web.HttpContext.Current.Response.Charset = "utf-8";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
        System.Web.HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);//HttpUtility.UrlEncode(fileName));   
        //            HttpUtility.UrlEncode(fileName,Encoding.UTF8);   
        //System.Web.HttpContext.Current.Response.ContentEncoding=System.Text.Encoding.Default;   
        System.Web.HttpContext.Current.Response.Write(content.ToString());
        System.Web.HttpContext.Current.Response.End();
        return true;
    }
     /// <summary>   
    /// 通用导出Excel   
    /// </summary>   
    /// <param name="ds">数据源DataSet</param>   
    /// <param name="columns">列名数组,允许为空(columns=null),为空则表使用默认数据库列名</param>   
    /// <param name="fileName"></param>   
    /// <returns></returns>  
    public static bool CommExportExcel(DataSet ds, string[] columns, string fileName)
    {
        try
        {
            if (ds.Tables.Count == 0 || fileName == string.Empty)
            {
                return false;
            }
            System.Data.DataTable dt = ds.Tables[0];
            StringBuilder content = new StringBuilder();

            content.Append("<table>");
            content.Append("<tr>");
            if (columns != null)
            {
                for (int i = 0; i < columns.Length; i++)
                {
                    if (columns[i] != null && columns[i] != "")
                    {
                        content.Append("<td>" + columns[i] + "</td>");
                    }
                    else
                    {
                        content.Append("<td>" + dt.Columns[i].ColumnName + "</td>");
                    }
                }
            }
            else
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    content.Append("<td>" + dt.Columns[j].ColumnName + "</td>");
                }
            }
            content.Append("</tr>\n");
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                content.Append("<tr>");
                for (int k = 0; k < dt.Columns.Count; k++)
                {
                    object obj = dt.Rows[j][k];
                    content.AppendFormat("<td style='vnd.ms-excel.numberformat:@'>{0}</td>", obj);
                    //if (k == 0) content.AppendFormat("<td style='vnd.ms-excel.numberformat:@'>{0}</td>", obj);
                    //else content.AppendFormat("<td>{0}</td>", obj);

                }
                content.Append("</tr>\n");
            }
            content.Append("</table>");
            //  content.Replace(" ", "");

            StringWriter sw = new StringWriter();
            sw.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
            sw.WriteLine("<head><meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>");
            sw.WriteLine("<!--[if gte mso 9]>");
            sw.WriteLine("<xml>");
            sw.WriteLine(" <x:ExcelWorkbook>");
            sw.WriteLine("  <x:ExcelWorksheets>");
            sw.WriteLine("   <x:ExcelWorksheet>");
            sw.WriteLine("    <x:Name>Sheet1</x:Name>");
            sw.WriteLine("    <x:WorksheetOptions>");
            sw.WriteLine("      <x:Print>");
            sw.WriteLine("       <x:ValidPrinterInfo />");
            sw.WriteLine("      </x:Print>");
            sw.WriteLine("    </x:WorksheetOptions>");
            sw.WriteLine("   </x:ExcelWorksheet>");
            sw.WriteLine("  </x:ExcelWorksheets>");
            sw.WriteLine("</x:ExcelWorkbook>");
            sw.WriteLine("</xml>");
            sw.WriteLine("<![endif]-->");
            sw.WriteLine("</head>");
            sw.WriteLine("<body>");
            sw.WriteLine(content);
            sw.WriteLine("</body>");
            sw.WriteLine("</html>");
            sw.Close();
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.Charset = "UTF-8";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + System.Web.HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8) + ".xls");
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            HttpContext.Current.Response.Write(sw);
            HttpContext.Current.ApplicationInstance.CompleteRequest();
            HttpContext.Current.Response.End();
            return true;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public static bool CommExportExcel(string _html, string fileName)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(_html))
            {
                return false;
            }
            StringWriter sw = new StringWriter();
            sw.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
            sw.WriteLine("<head><meta http-equiv=\"content-type\" content=\"application/ms-excel; charset=UTF-8\"/>");
            sw.WriteLine("<!--[if gte mso 9]>");
            sw.WriteLine("<xml>");
            sw.WriteLine(" <x:ExcelWorkbook>");
            sw.WriteLine("  <x:ExcelWorksheets>");
            sw.WriteLine("   <x:ExcelWorksheet>");
            sw.WriteLine("    <x:Name>Sheet1</x:Name>");
            sw.WriteLine("    <x:WorksheetOptions>");
            sw.WriteLine("      <x:Print>");
            sw.WriteLine("       <x:ValidPrinterInfo />");
            sw.WriteLine("      </x:Print>");
            sw.WriteLine("    </x:WorksheetOptions>");
            sw.WriteLine("   </x:ExcelWorksheet>");
            sw.WriteLine("  </x:ExcelWorksheets>");
            sw.WriteLine("</x:ExcelWorkbook>");
            sw.WriteLine("</xml>");
            sw.WriteLine("<![endif]-->");
            sw.WriteLine("</head>");
            sw.WriteLine("<body>");
            sw.WriteLine(_html);
            sw.WriteLine("</body>");
            sw.WriteLine("</html>");
            sw.Close();
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.Charset = "UTF-8";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + System.Web.HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8) + ".xls");
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            HttpContext.Current.Response.Write(sw);
            HttpContext.Current.ApplicationInstance.CompleteRequest();
            HttpContext.Current.Response.End();
            return true;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

}

