﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Globals 的摘要说明
/// 定义常量和枚举变量
/// </summary>
public class Globals
{
    public Globals()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    ///////////////********************************终端申请延期********************
    /// <summary>
    ///  process_O_check_TrackOrder 终端申请延期
    /// </summary>
    public const string PROCESS_O_CHECK_TRACKORDER = "办事处直接申请延期";
    /// <summary>
    ///  PROCESS_O_CHECK_TRACKORDER_URL 终端申请延期URL
    /// </summary>
    public const string PROCESS_O_CHECK_TRACKORDER_URL = "O_check_TrackOrder.aspx";
    ///////////////////////////////////////********************gridview索引信息*************************///////////////////////////
    /// <summary>
    ///  TZ_MAIN 编号
    /// </summary>
    public const string INDEX_TZ_MAIN_ID = "编号";

    /// <summary>
    /// INDEX_TZ_XCQKSB_ID 编号
    /// </summary>
    public const string INDEX_TZ_XCQKSB_ID = "编号";
    /// <summary>
    /// INDEX_TZ_XCQKSB_PDA 编号
    /// </summary>
    public const string INDEX_TZ_XCQKSB_PDA = "PDA编号";
    /// <summary>
    /// INDEX_TZ_XCQKSB_URGENCY_ORDER 紧急程度
    /// </summary>
    public const string INDEX_TZ_MAIN_URGENCY_ORDER = "紧急程度";
    /// <summary>
    /// INDEX_TZ_MAIN_PHOTO 现场图片
    /// </summary>
    public const string INDEX_TZ_MAIN_PHOTO = "现场图片";
    /// <summary>
    ///     INDEX_TZ_MAIN_TAPE 现场录音
    /// </summary>
    public const string INDEX_TZ_MAIN_TAPE = "现场录音";
    /// <summary>
    /// INDEX_TZ_MAIN_ISLOOK 是否查看
    /// </summary>
    public const string INDEX_TZ_MAIN_ISLOOK = "是否查看";
    /// <summary>
    /// INDEX_TZ_MAIN_ISDAOCHANG 是否到场
    /// </summary>
    public const string INDEX_TZ_MAIN_ISDAOCHANG = "是否到场";
    /// <summary>
    /// INDEX_TZ_MAIN_TRACK_RESULT 跟踪结果
    /// </summary>
    public const string INDEX_TZ_MAIN_TRACK_RESULT = "延期结果";
    /// <summary>
    /// INDEX_TZ_MAIN_XIAODAN_RESULT 销单结果
    /// </summary>
    public const string INDEX_TZ_MAIN_XIAODAN_RESULT = "销单结果";
    /// <summary>
    /// INDEX_TZ_MAIN_REMINDER 催办工单
    /// </summary>
    public const string INDEX_TZ_MAIN_REMINDER = "催办工单";
    /// <summary>
    /// INDEX_TZ_MAIN_RB_RESULT 入保结果
    /// </summary>
    public const string INDEX_TZ_MAIN_RB_RESULT = "入保结果";
    /// <summary>
    /// INDEX_TZ_MAIN_DOINSURANCE 是否入保
    /// </summary>
    public const string INDEX_TZ_MAIN_DOINSURANCE = "是否入保";
    /// <summary>
    /// INDEX_TZ_MAIN_QZORGZ 区分请照
    /// </summary>
    public const string INDEX_TZ_MAIN_QZORGZ = "区分请照";
    /// <summary>
    /// INDEX_TZ_MAIN_LMXF 路面修复
    /// </summary>
    public const string INDEX_TZ_MAIN_LMXF = "路面修复";
    /// <summary>
    /// INDEX_TZ_MAIN_REPEAT 重复单
    /// </summary>
    public const string INDEX_TZ_MAIN_REPEAT = "重复单";
    
     /// <summary>
    /// INDEX_TZ_XCQKSB_PHOTO 现场图片
    /// </summary>
    public const string INDEX_TZ_XCQKSB_PHOTO = "现场图片";
     /// <summary>
    /// INDEX_TZ_MAIN_EXECUTIVEREMARK 处理备注
    /// </summary>
    public const string INDEX_TZ_MAIN_EXECUTIVEREMARK = "处理备注";
    /// <summary>
    /// INDEX_TZ_MAIN_ISEXTENDS PDA材料补填
    /// </summary>
    public const string INDEX_TZ_MAIN_ISEXTENDS = "材料补填";
    /// <summary>
    /// INDEX_TZ_MAIN_CUSTOMSERVICEID 客服编号
    /// </summary>
    public const string INDEX_TZ_MAIN_CUSTOMSERVICEID = "客服编号";
    
    
    ///////////////////////////////////////********************GRIDVIEW数据字典信息*************************///////////////////////////
    /// <summary>
    /// TZ_MAIN
    /// </summary>
    public const string DICT_TZ_MAIN = "'TZ_MAIN'";
    /// <summary>
    /// TZ_MAIN_CLINFO
    /// </summary>
    public const string DICT_TZ_MAIN_CLINFO = "'TZ_MAIN_CLINFO'";
    /// <summary>
    /// TZ_XCQKSB
    /// </summary>
    public const string DICT_TZ_XCQKSB = "'TZ_XCQKSB'";

    /// <summary>
    /// ISLOOK PDA是否已查看
    /// </summary>
    public const string DICT_COLUMN_ISLOOK = "ISLOOK";

    /// <summary>
    /// ISDAOCHANG PDA是否已到场
    /// </summary>
    public const string DICT_COLUMN_ISDAOCHANG = "ISDAOCHANG";

    /// <summary>
    /// URGENCY_ORDER 是否紧急单
    /// </summary>
    public const string DICT_COLUMN_URGENCY_ORDER = "URGENCY_ORDER";

    /// <summary>
    /// PHOTO PDA现场图片
    /// </summary>
    public const string DICT_COLUMN_PHOTO = "PHOTO";
    /// <summary>
    ///TAPE PDA现场录音
    /// </summary>
    public const string DICT_COLUMN_TAPE = "TAPE";
    /// <summary>
    /// DICT_COLUMN_ISEXTENDS PDA材料补填
    /// </summary>
    public const string DICT_COLUMN_ISEXTENDS = "ISEXTENDS";
    /// <summary>
    /// DICT_COLUMN_TRACK_RESULT 延期结果
    /// </summary>
    public const string DICT_COLUMN_TRACK_RESULT = "TRACK_RESULT";
    /// <summary>
    /// DICT_COLUMN_XIAODAN_RESULT 销单结果
    /// </summary>
    public const string DICT_COLUMN_XIAODAN_RESULT = "XIAODAN_RESULT";
    /// <summary>
    /// DICT_COLUMN_REMINDER 催办工单
    /// </summary>
    public const string DICT_COLUMN_REMINDER = "REMINDER";
    /// <summary>
    /// DICT_COLUMN_RB_RESULT 入保结果
    /// </summary>
    public const string DICT_COLUMN_RB_RESULT = "RB_RESULT";
    /// <summary>
    /// DICT_COLUMN_DOINSURANCE 是否入保
    /// </summary>
    public const string DICT_COLUMN_DOINSURANCE = "DOINSURANCE";
    /// <summary>
    /// DICT_COLUMN_REPEAT 区分请照
    /// </summary>
    public const string DICT_COLUMN_QZORGZ = "QZORGZ";
    /// <summary>
    /// DICT_COLUMN_REPEAT 路面修复
    /// </summary>
    public const string DICT_COLUMN_LMXF = "LMXF";
    /// <summary>
    /// DICT_COLUMN_REPEAT 重复单
    /// </summary>
    public const string DICT_COLUMN_REPEAT = "REPEAT";

    ///////////////////////////////////////********************存储过程配置信息*************************///////////////////////////
    /// <summary>
    /// 存储过程名称
    /// </summary>
    public const string PROCEDURE_NAME = "pd_pro_main";
    ///////////////////////////////////////*********************************日期格式************************///////////////////////////
    /// <summary>
    /// 年月日时分秒
    /// </summary>
    public const string LAST_MOD_TIME_FORMAT = "yyyy-MM-dd hh:mm:ss.fff tt";

    /// <summary>
    /// 年月日
    /// </summary>
    public const string DATE_STRING = "yyyy-MM-dd";

    /// <summary>
    /// 时分秒
    /// </summary>
    public const string TIME_STRING = "HH:mm:ss";

    /// <summary>
    /// 未找到符合查询条件的记录
    /// </summary>
    public const string NO_RECORD_FOUND_MSG = "未找到符合查询条件的记录";


    /// <summary>
    /// 默认验证组
    /// </summary>
    public const string VALIDATION_GROUPNAME = "Global_ValidationGroup";

    public const string EMPTY_GUID_STRING = "00000000-0000-0000-0000-000000000000";

    #region  流程状态相关
    /////////////////////////////////////////////////////////////////////// *******办事处************////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 办事处未派遣
    /// </summary>
    public const string Z_NOT_SEND = "办事处未派遣";
    /// <summary>
    /// 办事处已派遣
    /// </summary>
    public const string Z_YET_SEND = "办事处已派遣";
    /// <summary>
    /// 办事处申请延期
    /// </summary>
    public const string Z_APPLY_DELAY = "办事处申请延期";
    /// <summary>
    /// 办事处已审延期
    /// </summary>
    public const string Z_YET_DELAY = "办事处已审延期";
    /// <summary>
    /// 办事处申请销单
    /// </summary>
    public const string Z_APPLY_CLOSE = "办事处申请销单";
    /// <summary>
    /// 办事处已审销单
    /// </summary>
    public const string Z_YET_CLOSE = "办事处已审销单";
    /// <summary>
    /// 办事处申请退单
    /// </summary>
    public const string Z_APPLY_EXIT = "办事处申请退单";
    /// <summary>
    /// 办事处已审退单
    /// </summary>
    public const string Z_YET_EXIT = "办事处已审退单";


    ///////////////////////////////////////////////////////////// *******共用************//////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 重复单
    /// </summary>
    public const string REPEAT = "重复单";
    //******************************************************
    /// <summary>
    /// 筛选条件一日内
    /// </summary>
    public const string DATE_ONE = "一日内";

    /// <summary>
    /// 筛选条件三日内
    /// </summary>
    public const string DATE_THREE = "三日内";

    /// <summary>
    /// 筛选条件五日内
    /// </summary>
    public const string DATE_FIVE = "五日内";

    /// <summary>
    /// 筛选条件七日内
    /// </summary>
    public const string DATE_SEVEN = "七日内";

    /// <summary>
    /// 筛选条件更多
    /// </summary>
    public const string MORE = "更多";
    #endregion

    /// <summary>
    /// 配置表中数据是否有效
    /// </summary>
    public enum IsStatus
    {
        //有效
        Effective = 0,
        //无效
        Invalid = 1,
    }

}
