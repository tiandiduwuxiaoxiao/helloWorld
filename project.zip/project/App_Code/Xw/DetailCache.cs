﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Collections;

/// <summary>
/// InitCache 的摘要说明
/// </summary>
public class DetailCache
{
    public DetailCache()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public static Hashtable tabs;
    public static Hashtable tabsName;
    public static Hashtable dicts;
}
public class PZ_TAB
{
    public string TID;
    public string TCNNAME;
    public string FIELDGROUP;
    public string TABTYPE;
    public string TABNAME;
    public string TABMAINID;
    public string TABORDER;
    public string TICON;
}

public class S_DICT
{
    public string TID;
    public string TCNNAME;
    public string FIELDGROUP;
    public string FIELDNAME;
    public string FIELDDISNAME;
    public string TABLEID;
    public string COUNTNUMBER;
    public string LENGTH;
    public string STYLE;
}