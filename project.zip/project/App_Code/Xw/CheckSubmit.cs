﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///CheckSubmit 的摘要说明
/// </summary>
public class CheckSubmit
{
	public CheckSubmit()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}

    /// <summary>
    /// 验证自开单是否已提交过
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public bool CheckAddOrder(string id)
    {
        string sql = "select count(1) from tz_main where id='"+id+"'";
        try
        {
            OracleDataBase odb = new OracleDataBase();
            int i = odb.GetRecordCount(sql);
            if (i == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            Loger.Error("CheckSubmit=>CheckAddOrder异常，sql=" + sql, ex);
            return false;
        }
       
    }


   
}