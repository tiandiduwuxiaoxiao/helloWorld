﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Words 的摘要说明
/// </summary>
public class Wordinfo
{
    public Wordinfo()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    /// <summary>
    /// 根据反映类别 获取反应内容
    /// </summary>
    /// <param name="fylbstr"></param>
    /// <returns></returns>
    public string getFYNRByFYLBM(string canshustr)
    {
        string sql = "";
        if (canshustr == "用水问题")
        {
            sql = "select * from words where belongcode='004003' ";
        }
        else if (canshustr == "水质问题")
        {
            sql = "select * from words where belongcode='004004' ";
        }
        else if (canshustr == "水管设备")
        {
            sql = "select * from words where belongcode='004005' ";
        }
        else if (canshustr == "套室表")
        {
            sql = "select * from words where belongcode='004006' ";
        }
        else if (canshustr == "表务问题")
        {
            sql = "select * from words where belongcode='004007' ";
        }
        else if (canshustr == "物业问题")
        {
            sql = "select * from words where belongcode='004000' ";
        }
        else if (canshustr == "二次供水")
        {
            sql = "select * from words where belongcode='004002' ";
        }
        else if (canshustr == "水管问题")
        {
            sql = "select * from words where belongcode='004011' ";
        }
        else if (canshustr == "服务咨询")
        {
            sql = "select * from words where belongcode='004009' ";
        }
        else if (canshustr == "服务投诉")
        {
            sql = "select * from words where belongcode='004010' ";
        }
        else if (canshustr == "其它类别")
        {
            sql = "select * from words where belongcode='004001' ";
        }

        return sql;
    }
    public string getREPORTCONTENTByREPORTTYPE(string belongcode)
    {
        string sql = "select * from words t where t.belongcode='000000000000000000'";
        if (!string.IsNullOrEmpty(belongcode))
            sql = "select * from words t where t.belongcode='" + belongcode + "'";
        return sql;
    }

    /// <summary>
    /// 处理内容
    /// </summary>
    /// <param name="canshustr"></param>
    /// <returns></returns>
    public string getCLNRByCLLB(string canshustr)
    {
        string sql = "";
        if (canshustr == "用水问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013000' ";
        }
        else if (canshustr == "水质问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013001' ";
        }
        else if (canshustr == "水管设备")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013002' ";
        }
        else if (canshustr == "套室表")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013003' ";
        }
        else if (canshustr == "表务问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013004' ";
        }
        else if (canshustr == "服务咨询")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013005' ";
        }
        else if (canshustr == "服务投诉")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013006' ";
        }
        else if (canshustr == "物业问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013007' ";
        }
        else if (canshustr == "其它类别")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013008' ";
        }
        else if (canshustr == "明漏")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013009' ";
        }
        else if (canshustr == "明漏复听")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013010' ";
        }
        else if (canshustr == "暗漏")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013011' ";
        }
        else if (canshustr == "管网养护")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013012' ";
        }
        else if (canshustr == "小修")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='013013' ";
        }
        else
        {
            sql = "select * from words where 1=2 ";
        }
        return sql;
    }

    /// <summary>
    /// 发生原因
    /// </summary>
    /// <param name="canshustr"></param>
    /// <returns></returns>
    public string getFSYYByCLLB(string canshustr)
    {
        string sql = "";
        if (canshustr == "用水问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016000' ";
        }
        else if (canshustr == "水质问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016001' ";
        }
        else if (canshustr == "水管设备")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016002' ";
        }
        else if (canshustr == "套室表")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016003' ";
        }
        else if (canshustr == "表务问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016004' ";
        }
        else if (canshustr == "服务咨询")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016005' ";
        }
        else if (canshustr == "服务投诉")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016006' ";
        }
        else if (canshustr == "物业问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016007' ";
        }
        else if (canshustr == "其它类别")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='016008' ";
        }
        else if (canshustr == "明漏")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='012009' ";
        }
        else if (canshustr == "明漏复听")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='012010' ";
        }
        else if (canshustr == "暗漏")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='012011' ";
        }
        else if (canshustr == "管网养护")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='012012' ";
        }
        else if (canshustr == "小修")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='012013' ";
        }
        else
        {
            sql = "select * from words where 1=2 ";
        }
        return sql;
    }

    /// <summary>
    /// 解决措施
    /// </summary>
    /// <param name="canshustr"></param>
    /// <returns></returns>
    public string getJJCSByCLLB(string canshustr)
    {
        string sql = "";
        if (canshustr == "用水问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017000' ";
        }
        else if (canshustr == "水质问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017001' ";
        }
        else if (canshustr == "水管设备")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017002' ";
        }
        else if (canshustr == "套室表")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017003' ";
        }
        else if (canshustr == "表务问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017004' ";
        }
        else if (canshustr == "服务咨询")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017005' ";
        }
        else if (canshustr == "服务投诉")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017006' ";
        }
        else if (canshustr == "物业问题")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017007' ";
        }
        else if (canshustr == "其它类别")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017007' ";
        }
        else if (canshustr == "明漏")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017008' ";
        }
        else if (canshustr == "明漏复听")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017009' ";
        }
        else if (canshustr == "暗漏")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017010' ";
        }
        else if (canshustr == "管网养护")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017011' ";
        }
        else if (canshustr == "小修")
        {
            sql = "select * from words where replace(belongcode,chr(10),'')='017012' ";
        }
        else
        {
            sql = "select * from words where 1=2 ";
        }
        return sql;
    }

    /// <summary>
    /// 销单及时
    /// 2014年12月29日16:24:30 modify
    /// </summary>
    /// <returns></returns>
    public string getWRITEOFFINTIME()
    {
        return ConfigurationManager.AppSettings["xdInTime"].ToString().Split(',')[0];
    }

    /// <summary>
    /// 销单不及时
    ///  2014年12月29日16:24:30 add
    /// </summary>
    /// <returns></returns>
    public string getWRITEOFFOUTTIME()
    {
        return ConfigurationManager.AppSettings["xdInTime"].ToString().Split(',')[1];
    }

    /// <summary>
    /// 到场及时
    /// </summary>
    /// <returns></returns>
    public string getARRIVALINTIME()
    {
        return ConfigurationManager.AppSettings["dCInTime"].ToString().Split(',')[0];
    }

    /// <summary>
    /// 处理及时
    /// 2014年12月29日16:24:22  modify
    /// </summary>
    /// <returns></returns>
    public string getEXECUTIVEINTIME()
    {
        return ConfigurationManager.AppSettings["clInTime"].ToString().Split(',')[0];
    }
    /// <summary>
    /// 处理不及时
    /// 2014年12月29日16:27:33  add
    /// </summary>
    /// <returns></returns>
    public string getEXECUTIVEOUTTIME()
    {
        return ConfigurationManager.AppSettings["clInTime"].ToString().Split(',')[1];
    }
}
