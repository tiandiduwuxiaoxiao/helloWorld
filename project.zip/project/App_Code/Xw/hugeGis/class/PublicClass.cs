﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;

/// <summary>
/// PublicClass 的摘要说明
/// </summary>
public class PublicClass
{
    public PublicClass()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    #region 根据日期得到对应的数字
    /// <summary>
    /// 根据日期得到对应的数字
    /// </summary>
    /// <param name="date">日期</param>
    /// <returns>返回相应的数字</returns>
    public string SelectWeek(string date)
    {
        string week_num = DateTime.Parse(date).DayOfWeek.ToString();
        if (week_num == "Monday")
        {
            week_num = "A";
        }
        else if (week_num == "Tuesday")
        {
            week_num = "B";
        }
        else if (week_num == "Wednesday")
        {
            week_num = "C";
        }
        else if (week_num == "Thursday")
        {
            week_num = "D";
        }
        else if (week_num == "Friday")
        {
            week_num = "E";
        }
        else if (week_num == "Saturday")
        {
            week_num = "F";
        }
        else //Sunday
        {
            week_num = "G";
        }
        return week_num;
    }
    #endregion

    #region 根据日期得到对应的数字（大写）
    /// <summary>
    /// 根据日期得到对应的数字（大写）
    /// </summary>
    /// <param name="date">日期</param>
    /// <returns>返回相应的数字</returns>
    public string SelectDWeek(string date)
    {
        string week_num = DateTime.Parse(date).DayOfWeek.ToString();
        if (week_num == "Monday")
        {
            //week_num = "1";
            week_num = "一";
        }
        else if (week_num == "Tuesday")
        {
            //week_num = "2";
            week_num = "二";
        }
        else if (week_num == "Wednesday")
        {
            //week_num = "3";
            week_num = "三";
        }
        else if (week_num == "Thursday")
        {
            //week_num = "4";
            week_num = "四";
        }
        else if (week_num == "Friday")
        {
            //week_num = "5";
            week_num = "五";
        }
        else if (week_num == "Saturday")
        {
            //week_num = "6";
            week_num = "六";
        }
        else //Sunday
        {
            //week_num = "7";
            week_num = "日";
        }
        return week_num;
    }
    #endregion

    #region 查询检测项目
    /// <summary>
    /// 查询检测项目
    /// </summary>
    /// <param name="MODELID">模板ID</param>
    /// <returns>查询检测项目</returns>
    public string SelectJCXM(string MODELID)
    {
        //查询检测项目
        string jcxm = "";
        using (OracleConnection conn1 = Global.getOracleConnection())
        {
            conn1.Open();
            using (OracleCommand cmd1 = conn1.CreateCommand())
            {
                cmd1.CommandText = "select CSXM.CSXMID,TARGETTOTAL.PROJECT as cxName from CSXM " +
                                   "inner join TARGETTOTAL on TARGETTOTAL.ID=CSXM.CSXMID " +
                                   "where CSXM.MODELID='" + MODELID + "'";
                //(select PROJECT from TARGETTOTAL where TARGETTOTAL.ID=CSXM.CSXMID) as cxName from CSXM where MODELID='" + MODELID + "'";
                using (OracleDataReader reader1 = cmd1.ExecuteReader())
                {
                    while (reader1.Read())
                    {
                        jcxm += reader1["cxName"].ToString().Trim() + "、";
                    }
                    if (!reader1.IsClosed)
                        reader1.Close();
                }
                jcxm = jcxm.TrimEnd('、');
            }
            conn1.Close();
        }
        return jcxm;
    }
    #endregion

    #region 查询检测项目
    /// <summary>
    /// 查询检测项目
    /// </summary>
    /// <param name="MODELID">模板ID</param>
    /// <returns>查询检测项目</returns>
    public string SelectJCXM_CHK(string RECORDINFO1ID, string RECORDINFO2ID, string MODELID, string TAG)
    {
        //查询检测项目
        string jcxm = "";
        using (OracleConnection conn1 = Global.getOracleConnection())
        {
            conn1.Open();
            using (OracleCommand cmd1 = conn1.CreateCommand())
            {
                cmd1.CommandText = "select CSXM.CSXMID as jcxmid,TARGETTOTAL.PROJECT as cxName from CSXM " +
                                   "inner join TARGETTOTAL on TARGETTOTAL.ID=CSXM.CSXMID " +
                                   "where CSXM.MODELID='" + MODELID + "'";
                //(select PROJECT from TARGETTOTAL where TARGETTOTAL.ID=CSXM.CSXMID) as cxName from CSXM where MODELID='" + MODELID + "'";
                using (OracleDataReader reader1 = cmd1.ExecuteReader())
                {
                    while (reader1.Read())
                    {
                        cmd1.CommandText = "select id from PFJCRY where RECORDINFO1ID='" + RECORDINFO1ID + "' and RECORDINFO2ID='" + RECORDINFO2ID + "' and MODELID='" + MODELID + "' and JCXMID='" + reader1["jcxmid"].ToString() + "'";
                        using (OracleDataReader reader2 = cmd1.ExecuteReader())
                        {
                            if (reader2.Read())
                            {
                                if (TAG == "1")
                                {
                                    jcxm += "<input id='" + RECORDINFO1ID + "=" + RECORDINFO2ID + "=" + MODELID + "=" + reader1["jcxmid"].ToString() + "' type='checkbox' tag='1' disabled='disabled' style='display:none' />" + reader1["cxName"].ToString() + "、";
                                }
                                else
                                {
                                    jcxm += "<input id='" + RECORDINFO1ID + "=" + RECORDINFO2ID + "=" + MODELID + "=" + reader1["jcxmid"].ToString() + "' type='checkbox' tag='1' checked='checked' disabled='disabled' />" + reader1["cxName"].ToString() + "、";
                                }
                            }
                            else
                            {
                                if (TAG == "1")
                                {
                                    jcxm += "<input id='" + RECORDINFO1ID + "=" + RECORDINFO2ID + "=" + MODELID + "=" + reader1["jcxmid"].ToString() + "' type='checkbox' tag='1' disabled='disabled' style='display:none' />" + reader1["cxName"].ToString() + "、";
                                }
                                else
                                {
                                    jcxm += "<input id='" + RECORDINFO1ID + "=" + RECORDINFO2ID + "=" + MODELID + "=" + reader1["jcxmid"].ToString() + "' type='checkbox' tag='0' />" + reader1["cxName"].ToString() + "、";
                                }
                            }
                            if (!reader2.IsClosed)
                                reader2.Close();
                        }
                    }
                    if (!reader1.IsClosed)
                        reader1.Close();
                }
            }
            conn1.Close();
        }
        return jcxm.Trim('、');
    }
    #endregion

    #region 查询监测室所有的人员并拼接HTML
    /// <summary>
    /// 查询监测室所有的人员并拼接HTML
    /// </summary>
    /// <returns>返回拼接HTML</returns>
    public string SelAllJCS()
    {
        string html = "";
        using (OracleConnection conn1 = Global.getOracleConnection())
        {
            conn1.Open();
            using (OracleCommand cmd1 = conn1.CreateCommand())
            {
                cmd1.CommandText = "select ID,CUSER from author_user where depid='2226BADCEBEA4E9EB805AC7E45B55FB8'";
                using (OracleDataReader reader1 = cmd1.ExecuteReader())
                {
                    while (reader1.Read())
                    {
                        html += "<option value=\"" + reader1["ID"].ToString() + "\">" + reader1["CUSER"].ToString() + "</option>";
                    }
                    if (!reader1.IsClosed)
                        reader1.Close();
                }
            }
            conn1.Close();
        }
        return html;
    }
    #endregion
}
