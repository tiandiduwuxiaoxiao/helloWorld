﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Tz_MainInfo 的摘要说明
/// </summary>
public class Tz_MainInfo
{
	public Tz_MainInfo()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    /// <summary>
    /// ID
    /// </summary>
    public static string ID="ID";
    /// <summary>
    /// //客服编号
    /// </summary>
    public static string CUSTOMSERVICEID = "CUSTOMSERVICEID";
    /// <summary>
    /// 客户号
    /// </summary>
    public static string CUSTOMID = "CUSTOMID";                                                            //信息编号户号
    public static string INFONUM = "INFONUM";                                                                //登录站点
    public static string LOGONSTATION = "LOGONSTATION";                                         //受理登录
    public static string ACCEPTPEOPLE = "ACCEPTPEOPLE";                                              //接报时间
    public static string ACCEPTTIME = "ACCEPTTIME";                                                       //预约时间
    public static string AGREEDTIME = "AGREEDTIME";                                                      //发生时间
    public static string HAPPENTIME = "HAPPENTIME";                                                    //发生地址
    public static string HAPPENADDR = "HAPPENADDR";                                                //反映区名
    public static string REPORTAREA = "REPORTAREA";                                                    //反映类别
    public static string REPORTTYPE = "REPORTTYPE";                                                      //反映内容
    public static string REPORTCONTENT = "REPORTCONTENT";                                    //反映形式
    public static string REPORTFORM = "REPORTFORM";                                                 //反映来源
    public static string REPORTSOURCE = "REPORTSOURCE";                                         //反映人
    public static string REPORTPEOPLE = "REPORTPEOPLE";                                             //反映单位
    public static string REPORTDEPT = "REPORTDEPT";                                                      //受理单位
    public static string ACCEPTSTATION = "ACCEPTSTATION";                                        //受理备注
    public static string ACCEPTREMARK = "ACCEPTREMARK";                                        //电话
    public static string EMAIL = "EMAIL";                                                                             //邮件
    public static string MOBILE = "MOBILE";                                                                         //手机
    public static string PRIORITY = "PRIORITY";                                                                   //处理级别
    public static string ISSELFSEND = "ISSELFSEND";                                                          //自开单
    public static string REPEATCOUNT = "REPEATCOUNT";                                              //重复次数
    public static string REPEATHOTINFO = "REPEATHOTINFO";                                       //重复记录
}                                                                                                                                                 
