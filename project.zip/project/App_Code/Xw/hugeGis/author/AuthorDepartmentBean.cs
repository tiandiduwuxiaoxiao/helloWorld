﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// AuthorDepartmentBean 的摘要说明
/// </summary>
public class AuthorDepartmentBean
{
    public string id;
    public string pid;
    public string depname;
    public string depdisc;

    public AuthorDepartmentBean(string id, string pid, string depname, string depdisc)
	{
        this.id = id;
        this.pid = pid;
        this.depname = depname;
        this.depdisc = depdisc;
	}
}
