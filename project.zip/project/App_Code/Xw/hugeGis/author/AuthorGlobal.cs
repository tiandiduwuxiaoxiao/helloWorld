﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using System.Collections;
using hugegis.DBUtility;

/// <summary>
/// AuthorGlobal 的摘要说明
/// </summary>
public class AuthorGlobal
{
	public AuthorGlobal()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    public static ArrayList getResources(string uid)
    {
        ArrayList al = new ArrayList();
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string userid = "";
        while (data.Read())
        {
            object id = data.GetValue(data.GetOrdinal("id"));
            userid = Convert.ToString(id);
            object utype = data.GetValue(data.GetOrdinal("utype"));
            if (Convert.ToString(utype) != "")
            {
                oraComm.CommandText = "select * from author_role_res where roleid='" + Convert.ToString(utype) + "'";
                OracleDataReader data1 = oraComm.ExecuteReader();
                while (data1.Read())
                {
                    object resid = data1.GetValue(data1.GetOrdinal("resid"));
                    al.Add(Convert.ToString(resid));
                }
                data1.Close();
            }
        }
        if (!data.IsClosed)
            data.Close();
        oraComm.CommandText = "select * from author_user_res where userid='" + userid + "'";
        data = oraComm.ExecuteReader();
        while (data.Read())
        {
            object resid = data.GetValue(data.GetOrdinal("resid"));
            al.Add(Convert.ToString(resid));
        }
        if (!data.IsClosed)
            data.Close();

        string where = "";
        for (int i = 0; i < al.Count; i++)
        {
            string resid = (string)al[i];
            string temp = "t.id='" + resid + "'";
            where = where == "" ? temp : where + " or " + temp;
        }
        ArrayList resList = new ArrayList();
        if (al.Count != 0)
        {
            oraComm.CommandText = "select t.*,c.cataname from author_resource t,author_rescatalog c where t.rescatalog=c.id and ("+where+") ";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object id = data.GetValue(data.GetOrdinal("id"));
                object rescatalogid = data.GetValue(data.GetOrdinal("rescatalog"));
                object resname = data.GetValue(data.GetOrdinal("resname"));
                object depid = data.GetValue(data.GetOrdinal("depid"));
                object cataname = data.GetValue(data.GetOrdinal("cataname"));
                ResourceBean rb = new ResourceBean(Convert.ToString(id), Convert.ToString(rescatalogid), Convert.ToString(resname), Convert.ToString(depid));
                rb.rescataname = Convert.ToString(cataname);
                resList.Add(rb);
            }
            if (!data.IsClosed)
                data.Close();

            oraComm.CommandText = "select t.*,c.equipcataname from author_equipment t,author_equipcatalog c where t.equipcataid=c.id and (" + where + ") ";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object id = data.GetValue(data.GetOrdinal("id"));
                object rescatalogid = data.GetValue(data.GetOrdinal("equipcataid"));
                object resname = data.GetValue(data.GetOrdinal("EQUIPNAMEPHONENUM"));
                object depid = data.GetValue(data.GetOrdinal("depid"));
                object cataname = data.GetValue(data.GetOrdinal("equipcataname"));
                ResourceBean rb = new ResourceBean(Convert.ToString(id), Convert.ToString(rescatalogid), Convert.ToString(resname), Convert.ToString(depid));
                rb.rescataname = Convert.ToString(cataname);
                resList.Add(rb);
            }
            if (!data.IsClosed)
                data.Close();
        }

        conn.Close();
        return resList;
    }

    public static bool isAuthor(string uid)
    {
        if (uid == "admin") return true;
        ArrayList al = getResources(uid);
        for (int i = 0; i < al.Count; i++)
        {
            ResourceBean rb = (ResourceBean)al[i];
            if (rb.resname.Contains("用户管理"))
            {
                return true;
            }
        }
        return false;
    }

    public static bool isContainRes(ArrayList al,string resid)
    {
        if (al == null) return false;
        for (int i = 0; i < al.Count; i++)
        {
            ResourceBean rb = (ResourceBean)al[i];
            if (rb.id == resid)
            {
                return true;
            }
        }
        return false;
    }

    public static ArrayList getAllDepartmentWithUserID(string uid)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department order by DEPDISC";
        OracleDataReader data = oraComm.ExecuteReader();
        Hashtable ht = new Hashtable();
        while (data.Read())
        {
            object id = data.GetValue(data.GetOrdinal("id"));
            object pid = data.GetValue(data.GetOrdinal("pid"));
            object depname = data.GetValue(data.GetOrdinal("depname"));
            object depdisc = data.GetValue(data.GetOrdinal("depdisc"));
            AuthorDepartmentBean adb = new AuthorDepartmentBean(Convert.ToString(id), Convert.ToString(pid), Convert.ToString(depname), Convert.ToString(depdisc));
            if (ht[Convert.ToString(pid)] == null)
            {
                ArrayList al = new ArrayList();
                al.Add(adb);
                ht.Add(Convert.ToString(pid), al);
            }
            else
            {
                ArrayList al = (ArrayList)ht[Convert.ToString(pid)];
                al.Add(adb);
            }
        }
        if (!data.IsClosed)
            data.Close();

        string root = "0";

        if (uid != "")
        {
            oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object depid = data.GetValue(data.GetOrdinal("depid"));
                root = Convert.ToString(depid);

            }
            if (!data.IsClosed)
                data.Close();
        }

        conn.Close();

        ArrayList deps = new ArrayList();
        deps.Add(root);
        fillNode(ht, root, deps);
        return deps;
    }

    public static string getUserDepartment(string uid)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_user where cuser='" + uid + "'"; 
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("depid"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getPDADepartment(string pdaname)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_equipment  where relationobj='" + pdaname + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("depid"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getUserDepartmentName(string depidva)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department where id='" + depidva + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("DEPNAME"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getUserDepartmentPID(string depidva)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department where id='" + depidva + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("PID"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static ArrayList getAllDepartmentWithDepName(string depName)
    {
        OracleDataBase odb = new OracleDataBase();
        string sqlstr = "select * from author_department order by DEPDISC";
        DataTable dt = odb.GetDataSet(sqlstr).Tables[0];
        Hashtable ht = new Hashtable();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            object id = Convert.ToString(dt.Rows[i]["id"]);
            object pid = Convert.ToString(dt.Rows[i]["pid"]);
            object depname = Convert.ToString(dt.Rows[i]["depname"]);
            object depdisc = Convert.ToString(dt.Rows[i]["depdisc"]);
            AuthorDepartmentBean adb = new AuthorDepartmentBean(Convert.ToString(id), Convert.ToString(pid), Convert.ToString(depname), Convert.ToString(depdisc));
            if (ht[Convert.ToString(pid)] == null)
            {
                ArrayList al = new ArrayList();
                al.Add(adb);
                ht.Add(Convert.ToString(pid), al);
            }
            else
            {
                ArrayList al = (ArrayList)ht[Convert.ToString(pid)];
                al.Add(adb);
            }
        }

        string root = "0";

        if (depName != "")
        {
            string sql = "SELECT * FROM author_department WHERE depname='" + depName + "'";
            DataTable dep = odb.GetDataSet(sql).Tables[0];
            for (int i = 0; i < dep.Rows.Count; i++)
            {
                object depid = dep.Rows[i]["id"];
                root = Convert.ToString(depid);
            }
        }

        ArrayList deps = new ArrayList();
        deps.Add(depName);
        fillNode(ht, root, deps);
        return deps;
    }

    public static string getUserParentDepartmentName(string depidva)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department where id=(select PID from author_department where ID='" + depidva + "')";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("DEPNAME"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }
    public static ArrayList getUserChildDepartmentName(string depidva)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department ";
        OracleDataReader data = oraComm.ExecuteReader();
        OracleDataAdapter oda = new OracleDataAdapter(oraComm);
        DataSet ds= new DataSet();
        oda.Fill(ds);
        DataView dv = ds.Tables[0].DefaultView;
        dv.RowFilter = "PID='" + depidva + "'";
        ArrayList list =new ArrayList();

        
        foreach (DataRowView row in dv)
        {
            list.Add(row["DEPNAME"]);
            getUserChildDepartmentList(dv, row["ID"].ToString(), list);         
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return list;
    }

    public static void getUserChildDepartmentList(DataView dv1,string childid,ArrayList listva)
    {
        DataView dv = new DataView(dv1.Table);
        dv.RowFilter = "PID='" + childid + "'";   

        foreach  (DataRowView row  in  dv)   
        {
            listva.Add(row["DEPNAME"]);
            getUserChildDepartmentList(dv, row["id"].ToString(), listva);   
        }
    }

    public static ArrayList getAllDepartmentWithUid(string uid)
    {
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department order by DEPDISC";
        OracleDataReader data = oraComm.ExecuteReader();
        Hashtable ht = new Hashtable();
        while (data.Read())
        {
            object id = data.GetValue(data.GetOrdinal("id"));
            object pid = data.GetValue(data.GetOrdinal("pid"));
            object depname = data.GetValue(data.GetOrdinal("depname"));
            object depdisc = data.GetValue(data.GetOrdinal("depdisc"));
            AuthorDepartmentBean adb = new AuthorDepartmentBean(Convert.ToString(id), Convert.ToString(pid), Convert.ToString(depname), Convert.ToString(depdisc));
            if (ht[Convert.ToString(pid)] == null)
            {
                ArrayList al = new ArrayList();
                al.Add(adb);
                ht.Add(Convert.ToString(pid), al);
            }
            else
            {
                ArrayList al = (ArrayList)ht[Convert.ToString(pid)];
                al.Add(adb);
            }
        }
        if (!data.IsClosed)
            data.Close();

        string root = "0";

        if (uid != "")
        {
            oraComm.CommandText = "select * from author_user where id='" + uid + "'";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object depid = data.GetValue(data.GetOrdinal("depid"));
                root = Convert.ToString(depid);

            }
            if (!data.IsClosed)
                data.Close();
        }

        conn.Close();

        ArrayList deps = new ArrayList();
        deps.Add(root);
        fillNode(ht, root, deps);
        return deps;
    }

    public static void fillNode(Hashtable ht, string key, ArrayList deps)
    {
        if (ht[key] != null)
        {
            ArrayList al = (ArrayList)ht[key];
            for (int i = 0; i < al.Count; i++)
            {
                AuthorDepartmentBean adb = (AuthorDepartmentBean)al[i];
                deps.Add(adb.id); 
                if (ht[adb.id] != null)
                {
                    fillNode(ht, adb.id, deps);
                }
            }
        }
    }

    public static ArrayList getResourceWithUserid(string uid)
    {
        ArrayList deps = AuthorGlobal.getAllDepartmentWithUserID(uid);
        string whereDepStr = "";
        for (int i = 0; i < deps.Count; i++)
        {
            string tempStr = "depid='" + Convert.ToString(deps[i]) + "'";
            whereDepStr = whereDepStr == "" ? tempStr : whereDepStr + " or " + tempStr;
        }

        ArrayList al = new ArrayList();
        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();


        oraComm.CommandText = "select * from author_equipment equipment,author_equipcatalog equipcatalog where equipment.equipcataid=equipcatalog.id  and (" + whereDepStr + ")";
        OracleDataReader data = oraComm.ExecuteReader();
        while (data.Read())
        {

            object resname = data.GetValue(data.GetOrdinal("equipname"));

            al.Add(resname);
        }
        if (!data.IsClosed)
            data.Close();

        conn.Close();

        return al;
    }
}
