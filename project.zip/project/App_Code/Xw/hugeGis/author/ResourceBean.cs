﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// ResourceBean 的摘要说明
/// </summary>
public class ResourceBean
{
    public string id;
    public string rescatalog;
    public string resname;
    public string depid;
    public string rescataname;

    public ResourceBean(string id, string rescatalog, string resname, string depid)
	{
        this.id = id;
        this.rescatalog = rescatalog;
        this.resname = resname;
        this.depid = depid;
	}
}
