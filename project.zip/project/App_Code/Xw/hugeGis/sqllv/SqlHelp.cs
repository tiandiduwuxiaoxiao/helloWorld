﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using System.Drawing;
using System.Collections;

/// <summary>
/// SqlHelp 的摘要说明
/// </summary>
public class SqlHelp
{
	public SqlHelp()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    /// <summary>
    /// 判断数据库是否有此条数据
    /// </summary>
    /// <param name="sql">SQL 语句</param>
    /// <returns></returns>
    public static bool getExecuteScalar(string sql)
    {
        bool b = false;
        using (OracleConnection con = Global.getOracleConnection())
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = sql;
            object i = cmd.ExecuteScalar();
            if (Convert.ToInt32(i) > 0)
            {
                b = true;
            }
        }
        return b;
    }

    public static object getExecuteScalarReturnValue(string sql)
    {
        
        using (OracleConnection con = Global.getOracleConnection())
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = sql;
            return cmd.ExecuteScalar();
        }
       
    }

    /// <summary>
    /// 打印提示之后跳转页面
    /// </summary>
    /// <param name="message">打印的内容</param>
    /// <param name="url">跳转的页面</param>
    public static void ShowAlert(string message,string url)
    {
        System.Web.HttpContext.Current.Response.Write("<script type='text/javascript'>alert('" + message + "');window.location.href='"+url+"';</script>");
    }

    public static void ShowAlert(string message)
    {
         //ClientScript.RegisterStartupScript(this.GetType(), "a", "alert('" + message + "');", true);
        //System.Web.HttpContext.Current.Response.Write("<script type='text/javascript'>alert('" + message + "');</script>");
         System.Web.UI.Page page = (System.Web.UI.Page)System.Web.HttpContext.Current.Handler;
         if (!page.ClientScript.IsStartupScriptRegistered(page.GetType(), "clientScript"))
             page.ClientScript.RegisterStartupScript(page.GetType(), "clientScript", "<script language=javascript>alert('" + message + "');</script>");

    }

    public static string getName(string id) 
    {
        string str = "";
        switch (id)
        {
            case "1": str = "污水"; break;
            case "2": str = "污泥"; break;
            case "3": str = "气"; break;
            //default: str = id;
        }
        return str;
    }

    public static bool getExecuteNonQuery(string sql)
    {
        bool b = false;
        using (OracleConnection con = Global.getOracleConnection())
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = sql;
            object i = cmd.ExecuteNonQuery();
            if (Convert.ToInt32(i) > 0)
            {
                b = true;
            }
        }
        return b;
    }

   
    public static void getExecuteNonQueryNotReturn(string sql)
    {
        using (OracleConnection con = Global.getOracleConnection())
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
        }
    }
    /// <summary>
    /// 循环执行SQL语句时使用，可提高效率
    /// </summary>
    /// <param name="sql">一批SQL句话</param>
    public static void getExecuteNonQueryNotReturn(ArrayList sql)
    {
        using (OracleConnection con = Global.getOracleConnection())
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            for (int i = 0; i < sql.Count; i++)
            {
                if (sql[i] != null && sql[i].ToString() != "")
                {
                    cmd.CommandText = sql[i].ToString();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }

    public static void getStatusTrColor(GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            int num = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "STATUS"));
            if (num == 1)
            {
                e.Row.BackColor = Color.FromArgb(227, 249, 230);
            }
            else if (num == 2)
            {
                e.Row.BackColor = Color.FromArgb(254, 237, 237);
            }
            else if (num == 3)
            {
                e.Row.BackColor = Color.FromArgb(238, 238, 238);
            }
            else
            {
                e.Row.BackColor = Color.FromArgb(255, 255, 255);
            }
        }
    }

    public static string getStatusToDel(string num)
    {
        string str = "";

        switch (num)
        {
            //case "0": str = "删除"; break;
            //case "1": str = "删除"; break;
            case "2": str = "取消删除"; break;
            //case "3": str = "删除"; break;
            default: str = "删除"; break;
            //default: str = id;
        }
        return str;
    }

    public static string getStatusName(string num)
    {
        string str = "";

        switch (num)
        {
            case "0": str = "已审核"; break;
            case "1": str = "已修改"; break;
            case "2": str = "已删除"; break;
            case "3": str = "新增"; break;
            
        }
        return str;
    }

    public static DropDownList getDropDownList(DropDownList drop,string sql)
    {
        using (OracleConnection conn = Global.getOracleConnection())
        {
            conn.Open();
            using (OracleCommand cmd = conn.CreateCommand())
            {
                //加载受检单位名称下拉列表
                cmd.CommandText = sql;
                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        drop.Items.Add(new ListItem(ds.Tables[0].Rows[i][1].ToString(), ds.Tables[0].Rows[i][0].ToString()));
                    }
                }
              
            }
            conn.Close();
        }
        return drop;
    }

    /// <summary>
    /// 判断是否为Number类型
    /// </summary>
    /// <param name="num">所判断的值</param>
    /// <returns></returns>
    public static string getNumber(string num)
    {
        double n = 0;
        if (Double.TryParse(num, out n))
        {
            return num;
        }
        else
        {
            return "";
        }
    }

    public static double getNumberReturnZero(string num)
    {
        double n = 0;
        if (Double.TryParse(num, out n))
        {
            return Convert.ToDouble(num);
        }
        else
        {
            return 0;
        }
    }

}
