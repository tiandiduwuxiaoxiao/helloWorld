﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// LabelBean 的摘要说明
/// </summary>
public class LabelBean
{
	public LabelBean()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    public string samplenum;//样品编号
    public string sampleaddressname;//取样点名称
    public string amount2;//单瓶容量
    public string amount2unit;//容量单位
    public string barcode;//条码
    public string count;//数量，几瓶
}
