﻿using System;
using System.Collections.Generic;

using System.Web;

/// <summary>
/// Summary description for iddataclass
/// </summary>
public class IdUtil
{
    public bool isvalid;
    public string chkinfo;
    public string Sex = "";

    public IdUtil()
    {

    }

    private string Convert15to18(string cid)
    {
        char[] strjiaoyan = { '1', '0', 'x', '9', '8', '7', '6', '5', '4', '3', '2' };
        int[] intquan = { 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1 };
        string strtemp;
        int inttemp = 0;

        strtemp = cid.Substring(0, 6) + "19" + cid.Substring(6);
        for (int i = 0; i <= strtemp.Length - 1; i++)
        {
            inttemp += int.Parse(strtemp.Substring(i, 1)) * intquan[i];
        }
        inttemp = inttemp % 11;
        return strtemp + strjiaoyan[inttemp];
    }

    public IdUtil CheckCidInfo(string cid)
    {
        string[] acity = new string[] { null, null, null, null, null, null, null, null, null, null, null, "北京", "天津", "河北", "山西", "内蒙古", null, null, null, null, null, "辽宁", "吉林", "黑龙江", null, null, null, null, null, null, null, "上海", "江苏", "浙江", "安微", "福建", "江西", "山东", null, null, null, "河南", "湖北", "湖南", "广东", "广西", "海南", null, null, null, "重庆", "四川", "贵州", "云南", "西藏", null, null, null, null, null, null, "陕西", "甘肃", "青海", "宁夏", "新疆", null, null, null, null, null, "台湾", null, null, null, null, null, null, null, null, null, "香港", "澳门", null, null, null, null, null, null, null, null, "外国" };
        double isum = 0;
        IdUtil _ciddata = new IdUtil();
        System.Text.RegularExpressions.Regex rg = new System.Text.RegularExpressions.Regex(@"^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$");//(@"^\d{17}(\d|x)$|^\d{15}$");
        System.Text.RegularExpressions.Match mc = rg.Match(cid);
        if (!mc.Success)
        {
            _ciddata.isvalid = false;
            _ciddata.chkinfo = "不是有效的身份证号";
            return _ciddata;
        }
        if (cid.Length == 15) cid = this.Convert15to18(cid);
        cid = cid.ToLower();
        cid = cid.Replace("x", "a");
        if (acity[int.Parse(cid.Substring(0, 2))] == null)
        {
            _ciddata.isvalid = false;
            _ciddata.chkinfo = "非法地区(身份证)";
            return _ciddata;
        }
        try
        {
            DateTime.Parse(cid.Substring(6, 4) + "/" + cid.Substring(10, 2) + "/" + cid.Substring(12, 2));
        }
        catch
        {
            _ciddata.isvalid = false;
            _ciddata.chkinfo = "非法生日(身份证)";
            return _ciddata;
        }
        for (int i = 17; i >= 0; i--)
        {

            isum += (System.Math.Pow(2, i) % 11) * int.Parse(cid[17 - i].ToString(), System.Globalization.NumberStyles.HexNumber);

        }
        if (isum % 11 != 1)
        {
            _ciddata.isvalid = false;
            _ciddata.chkinfo = "非法证号";
            return _ciddata;
        }
        string strIdSEX = cid.Substring(cid.Length - 2, 1);
        int iIdSex = int.Parse(strIdSEX);
        if (iIdSex == 1 || iIdSex == 3 || iIdSex == 5 || iIdSex == 7 || iIdSex == 9)
        {
            Sex = "M";
        }
        else
        {
            Sex = "F";
        }

        _ciddata.isvalid = true;
        _ciddata.chkinfo = acity[int.Parse(cid.Substring(0, 2))] + "," + cid.Substring(6, 4) + "-" + cid.Substring(10, 2) + "-" + cid.Substring(12, 2) + "," + (int.Parse(cid.Substring(16, 1)) % 2 == 1 ? "男" : "女");
        return _ciddata;
    }

    /// <summary>
    /// 检查身份证号码是否合法（是否与提供的出生日期和性别相匹配）
    /// </summary>
    /// <param name="errMessage"></param>
    /// <returns></returns>
    private bool IsValidID(string strBOD, string strSEX, string strId, ref string errMessage)
    {
        strId.ToLower();
        string strIdDate = "";
        string strIdSEX = "";
        string strRtn = "";
        int iIdSex = 0;
        IdUtil idclass = new IdUtil();
        IdUtil idclass1;

        if (strId.Length != 15 && strId.Length != 18)
        {
            errMessage = "身份证长度不正确";
            return false;
        }
        DateTime dt = DateTime.MinValue;
        if (!DateTime.TryParse(strBOD, out dt))
        {
            errMessage = "不可利用的生日(身份证)";
            return false;
        }

        strIdSEX = strId.Substring(strId.Length - 2, 1);
        if (strId.Length == 15)
        {
            strIdDate = strId.Substring(6, 6);
            strRtn = DateTime.Parse(strRtn).ToString("yyMMdd");
            if (!strRtn.Equals(strIdDate))
            {
                errMessage = "身份证中日期与填写的生日不一致";
                return false;
            }
        }
        else
        {
            strIdDate = strId.Substring(6, 8);
            strRtn = DateTime.Parse(strRtn).ToString("yyyyMMdd");
            if (!strRtn.Equals(strIdDate))
            {
                errMessage = "身份证中生日与填写的生日不一致";
                return false;
            }
        }
        iIdSex = int.Parse(strIdSEX);
        if (iIdSex == 1 || iIdSex == 3 || iIdSex == 5 || iIdSex == 7 || iIdSex == 9)
        {
            if (!strSEX.Equals("0"))
            {
                errMessage = "身份证中性别与填写的性别不一致";
                return false;
            }
        }
        else
        {
            if (strSEX.Equals("0"))
            {
                errMessage = "身份证中性别与填写的性别不一致";
                return false;
            }
        }
        idclass1 = idclass.CheckCidInfo(strId.ToLower());
        if (!idclass1.isvalid)
        {
            errMessage = idclass1.chkinfo;
            return false;
        }

        //check id 
        return true;
    }

    /// <summary>
    /// 校验身份证
    /// </summary>
    /// <param name="strID"></param>
    /// <param name="strMsg"></param>
    /// <returns></returns>
    public static bool CheckID(string strID, ref string strMsg)
    {
        IdUtil idclass = new IdUtil();
        IdUtil idclass1;

        if (!string.IsNullOrEmpty(strID))
        {
            idclass1 = idclass.CheckCidInfo(strID.ToLower());
            if (!idclass1.isvalid)
            {
                strMsg = idclass1.chkinfo;
                return false;
            }
        }
        return true;
    }

    public static bool CheckID(string strID, ref string sex, ref string strMsg)
    {
        IdUtil idclass = new IdUtil();
        IdUtil idclass1;

        if (!string.IsNullOrEmpty(strID))
        {
            idclass1 = idclass.CheckCidInfo(strID.ToLower());
            if (!idclass1.isvalid)
            {
                strMsg = idclass1.chkinfo;
                return false;
            }
            sex = idclass1.Sex;
        }
        return true;
    }

    public static string GetGender(string strId)
    {
        if (string.IsNullOrEmpty(strId))
            return null;

        string sex = null;
        if (strId.Length == 18)
            sex = strId.Substring(14, 3);
        else if (strId.Length == 15)
            sex = strId.Substring(12, 3);
        else
            return null;

        if (int.Parse(sex) % 2 == 0)
            return "F";
        else
            return "M";
    }

    public static string GetBirthday(string strId)
    {
        if (string.IsNullOrEmpty(strId))
            return string.Empty;

        string birthday = null;
        if (strId.Length == 18)
            birthday = strId.Substring(6, 4) + "-" + strId.Substring(10, 2) + "-" + strId.Substring(12, 2);
        if (strId.Length == 15)
            birthday = "19" + strId.Substring(6, 2) + "-" + strId.Substring(8, 2) + "-" + strId.Substring(10, 2);
        return birthday;
    }
}
