﻿using System;
using System.Collections.Generic;
using System.Text;


public class StrUtil
{
    public static string SplitString(string strs, string key, char splitChar)
    {
        string strVal = "";
        string[] strArray = strs.Split(splitChar);
        string[] Val;
        for (int i = 0; i < strArray.Length; i++)
        {
            Val = strArray[i].Split('=');
            if (Val.Length > 1)
            {
                if (Val[0].Equals(key, StringComparison.CurrentCultureIgnoreCase))
                {
                    strVal = Val[1];
                    break;
                }
            }
        }
        return strVal;
    }

    public static string QueryString(string url, string key)
    {
        if (string.IsNullOrEmpty(url))
            return null;
        int idx = url.IndexOf('?');
        return SplitString(url.Substring(idx + 1), key, '&');
    }

    /// <summary>
    /// 检验字符串是否包涵SQL关键字或非法字符，验证通过返回true；否则false
    /// </summary>
    /// <param name="strValue"></param>
    /// <returns></returns>
    public static bool CheckSQLInjection(string strValue)
    {
        if (strValue.ToUpper().Contains("DELETE") && strValue.ToUpper().Contains("FROM"))
        {
            return false;
        }
        if (strValue.ToUpper().Contains("TRUNCATE") && strValue.ToUpper().Contains("TABLE"))
        {
            return false;
        }
        if (strValue.ToUpper().Contains("DROP") && strValue.ToUpper().Contains("TABLE"))
        {
            return false;
        }
        //or'1'='1'
        if (strValue.ToUpper().Contains("OR") && strValue.ToUpper().Contains("'"))
        {
            return false;
        }
        return true;

    }

    public static string InputText(string inputString, int maxLength)
    {
        StringBuilder retVal = new StringBuilder();
        if ((inputString != null) && (inputString != String.Empty))
            inputString = inputString.Trim();
        if (inputString.Length > maxLength)
        {
            inputString = inputString.Substring(0, maxLength);

        }
        for (int i = 0; i < inputString.Length; i++)
        {
            switch (inputString[i])
            {
                case '"':
                    retVal.Append("&quot;");
                    break;
                case '<':
                    retVal.Append("&lt;");
                    break;
                case '>':
                    retVal.Append("&gt;");
                    break;

                default:
                    retVal.Append(inputString[i]);
                    break;
            }
        }
        retVal.Replace("'", Convert.ToChar(96).ToString());
        return retVal.ToString();
    }

    public static string ConvertToString(object obj)
    {
        if (obj == null)
            return string.Empty;

        if (obj == DBNull.Value)
            return string.Empty;

        return obj.ToString();
    }
}
