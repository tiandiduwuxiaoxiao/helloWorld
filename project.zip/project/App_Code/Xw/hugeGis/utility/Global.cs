﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using System.Collections;
using System.Xml;
using Encrypt;
using MyAuth.authServices;
using hugegis.DBUtility;
using System.Collections.Generic;
//using hugegis.DAL.DAL_WebPage;

/// <summary>
/// Global 的摘要说明
/// </summary>
public class Global
{

    //解码 (注意首先要注册Encrypt.dll(32位操作系统放到C:\Windows\SysWOW32，64位操作系统C:\Windows\SysWOW64)，然后添加引用——COM，再引用命名空间 using Encrypt。)
    //private static IHugeEncrypt hugeEncrypt = new HugeEncryptClass();

    /// <summary>
    /// 获取亮点距离
    /// </summary>
    /// <param name="X"></param>
    /// <param name="Y"></param>
    /// <param name="X1"></param>
    /// <param name="Y1"></param>
    /// <returns></returns>
    public static double GetXYLength(double X, double Y, double X1, double Y1)
    {
        double xylen = Math.Sqrt(Math.Pow(X1 - X, 2) + Math.Pow(Y1 - Y, 2));
        return xylen;
    }

    /// <summary>
    /// 计算距离
    /// </summary>
    /// <param name="pdaid"></param>
    /// <returns></returns>
    public static string GetDistince(string pdaid, double x1, double y1)
    {
        string result = "0";
        double x = 0;
        double y = 0;

        DateTime dt = DateTime.Now;
        OracleDataBase odb = new OracleDataBase("2");
        try
        {

            if (!string.IsNullOrEmpty(pdaid))
            {
                string posTableName = "trackpos_" + DateTime.Now.ToString("yyMM");
                string sql = string.Format("select X,Y,dt from (select X,Y,dt from track_pos.{0} t where  t.msid='{1}' order by t.dt desc )where rownum=1", posTableName, pdaid);
                DataSet ds = odb.GetDataSet(sql);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];
                    x = dr["X"] == DBNull.Value ? 0 : Convert.ToDouble(dr["X"]);
                    y = dr["Y"] == DBNull.Value ? 0 : Convert.ToDouble(dr["Y"]);
                    dt = dr["dt"] == DBNull.Value ? DateTime.Now : Convert.ToDateTime(dr["dt"]);
                }
            }
            result = Convert.ToInt64(Global.GetXYLength(x, y, x1, y1)).ToString();
        }
        catch (Exception ex)
        {
            Loger.Error("qiangDan.GetDistince()", ex);
        }
        return result;
    }
    /// <summary>
    ///     解密
    /// </summary>
    /// <param name="str">字符串</param>
    /// <returns>解密字符串</returns>
    public static string Decode(string str)
    {
        object result = null;
        result = EncryptServices.HugegisDecode(str);
        // hugeEncrypt.HugegisDecode(str, out result);

        return result.ToString();
    }

    public static int getMapResourceIndex()
    {
        return 1;
    }

    public Global()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    /// <summary>
    /// 获取加密后的连接字符串
    /// </summary>
    /// <param name="ConstrName"></param>
    /// <returns></returns>
    public static string GetConnectionStringFromConfig(string ConstrName)
    {
        string connstring = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]) ? EncryptServices.HugegisDecode(System.Configuration.ConfigurationManager.ConnectionStrings[ConstrName].ConnectionString) : System.Configuration.ConfigurationManager.ConnectionStrings[ConstrName].ConnectionString;
        return connstring;

    }

    /// <summary>
    /// 获取连接字符串,不加密
    /// </summary>
    /// <param name="ConstrName"></param>
    /// <returns></returns>
    public static string GetConnectionStringFromConfigNoDecode(string ConstrName)
    {
        return System.Configuration.ConfigurationManager.ConnectionStrings[ConstrName].ConnectionString;

    }
    /// <summary>
    ///  工单是否超期
    /// </summary>
    /// <param name="id">工单编号</param>
    /// <returns></returns>
    public static bool Is_Timeout(string id)
    {
        double time_out = ConvertUtil.ToDouble(ConfigurationManager.AppSettings["Timeout"]);//超时时间
        DateTime dt_Now = DateTime.Now;
        DateTime dt_HandlingTime = GetSolveTime(id);
        if (dt_HandlingTime == System.DateTime.MinValue)
        {
            return false;
        }

        dt_HandlingTime = dt_HandlingTime.AddMinutes(-time_out);
        System.TimeSpan t_span = dt_HandlingTime - dt_Now;

        return t_span.TotalMinutes < 0;
    }
    /// <summary>
    /// 根据mainID获取上报ID
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string GetXcqksbID(string id)
    {
        string sql = string.Format("select id from tz_xcqksb where main_id='{0}'", id);
        OracleDataBase dao = new OracleDataBase();
        return ConvertUtil.ToString(dao.GetScalarobj(sql));
    }
    /// <summary>
    /// 获取服务期时间
    /// </summary>
    /// <returns></returns>
    public static DateTime GetSysDate()
    {
        string sql = "select sysdate from dual";
        OracleDataBase dao = new OracleDataBase();
        return ConvertUtil.GetDateTime(dao.GetScalarobj(sql));
    }

    /// <summary>
    /// 获取工作单处理时限
    /// </summary>
    /// <returns></returns>
    public static DateTime GetHandingTime(string id)
    {
        string sql = string.Format("select tz_main_handlingtime(id) from tz_main where id='{0}'", id);
        OracleDataBase dao = new OracleDataBase();
        return ConvertUtil.ToDateTime(dao.GetScalarobj(sql));
    }
    /// <summary>
    /// 获取工作单处理时限
    /// </summary>
    /// <returns></returns>
    public static DateTime GetSolveTime(string id)
    {
        string sql = string.Format("select SOLVETIME_PLAN from tz_main where id='{0}'", id);
        OracleDataBase dao = new OracleDataBase();
        return ConvertUtil.ToDateTime(dao.GetScalarobj(sql));
    }
    /// <summary>
    /// 获取工作单到场时限
    /// </summary>
    /// <returns></returns>
    public static DateTime GetComeTime(string id)
    {
        string sql = string.Format("select Tz_Main_ComeTime(id) from tz_main where id='{0}'", id);
        OracleDataBase dao = new OracleDataBase();
        return ConvertUtil.ToDateTime(dao.GetScalarobj(sql));
    }
    #region 重写Substring方法（支持开始和结束索引）--李志光
    /// <summary>
    /// 重写Substring方法（支持开始和结束索引）--李志光
    /// </summary>
    /// <param name="source">字符串</param>
    /// <param name="start">开始索引</param>
    /// <param name="end">结束索引</param>
    /// <returns>返回截取后的字符串</returns>
    public static string _substring(string source, int start, int end)
    {
        string _strout = string.Empty;
        try
        {
            _strout = source.Substring(0, end + 1);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return _strout.Substring(start, _strout.Length - start - 1);
    }
    #endregion


    /// <summary>
    ///     根据资源父类获取下面所有的子级资源
    /// </summary>
    /// <param name="myresult"></param>
    /// <param name="operationID"></param>
    /// <param name="resourceCategoryName"></param>
    /// <returns></returns>
    public static ArrayList GetAuthResourceNameByResourceCategoryName(WSPermissionResult myresult, string operationID,
                                                                      string resourceCategoryName)
    {
        if (myresult == null) return null;
        WSPermissionItem[] permissions = myresult.permissions;
        if (permissions == null) return null;
        ArrayList al = new ArrayList();
        for (int i = 0; i < permissions.Length; i++)
        {
            WSPermissionItem permission = permissions[i];
            if (permission.operationBid.ToUpper() == operationID.ToUpper() &&
                permission.resourceCategoryName == resourceCategoryName)
            {
                al.Add(permission.resourceName);
            }
        }
        return al;
    }


    public static string SetDepName(string depname)
    {
        string result = string.Empty;
        if (depname.Contains("超级管理员"))
        {
            result = ConfigurationManager.AppSettings["all"].ToString();
        }
        else if (depname.Contains("管网技术科"))
        {
            result = ConfigurationManager.AppSettings["all"].ToString();
        }
        else if (depname.Contains("管网大道办"))
        {
            result = ConfigurationManager.AppSettings["dd"].ToString();
        }
        else if (depname.Contains("管网曹路办"))
        {
            result = ConfigurationManager.AppSettings["cl"].ToString();
        }
        else if (depname.Contains("管网雪野办"))
        {
            result = ConfigurationManager.AppSettings["xy"].ToString();
        }
        else if (depname.Contains("管网高南办"))
        {
            result = ConfigurationManager.AppSettings["gn"].ToString();
        }
        else if (depname.Contains("管网浦江办"))
        {
            result = ConfigurationManager.AppSettings["pj"].ToString();
        }
        else if (depname.Contains("管网办公室"))
        {
            result = ConfigurationManager.AppSettings["bgs"].ToString();
        }
        else if (depname.Contains("管网质安科"))
        {
            result = ConfigurationManager.AppSettings["bgs"].ToString();
        }

        return result;
    }
    /// <summary>
    /// 多媒体表中获取X坐标 track_media
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static float get_X(string id)
    {
        string sql = "select x from (select x from  track_media  where mediatype is null and  eventrecordid='" + id + "' order by  rq desc) where rownum=1";
        OracleDataBase odb = new OracleDataBase();
        if (Convert.IsDBNull(odb.GetScalarobj(sql)))
        {
            return Convert.ToSingle(0);
        }
        if (string.IsNullOrEmpty(odb.GetScalarobj(sql).ToString()))
        {
            return Convert.ToSingle(0);
        }
        return Convert.ToSingle(odb.GetScalarobj(sql));
    }
    /// <summary>
    /// 多媒体表中获取Y坐标 track_media
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static float get_Y(string id)
    {
        string sql = "select y from (select y from  track_media  where mediatype is null and  eventrecordid='" + id + "' order by  rq desc) where rownum=1";
        OracleDataBase odb = new OracleDataBase();
        if (Convert.IsDBNull(odb.GetScalarobj(sql)))
        {
            return Convert.ToSingle(0);
        }
        if (string.IsNullOrEmpty(odb.GetScalarobj(sql).ToString()))
        {
            return Convert.ToSingle(0);
        }
        return Convert.ToSingle(odb.GetScalarobj(sql));
    }


    /// <summary>
    /// 返回时间差[小时] 
    /// </summary>
    /// <param name="DateTimex">时间1 小</param>
    /// <param name="DateTimed">时间2 大</param>
    /// <returns></returns>
    public static double TDiff(DateTime DateTimex, DateTime DateTimed)
    {
        return ((TimeSpan)(DateTimed - DateTimex)).TotalHours;
    }
    /// <summary>
    /// 返回当前时间距离凌晨23：59：59的时间差
    /// </summary>
    /// <returns></returns>
    public static double dtDiff()
    {
        DateTime dt1 = DateTime.Now;
        DateTime dt2 = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
        return Global.TDiff(dt1, dt2);
    }
    public static string getyq(string id)
    {
        string sql = "select AGREEDTIME from  tz_main where PRIORITY='约期'  and id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 根据反映级别 获取 时间差
    /// </summary>
    /// <returns></returns>
    public static double getDiffByPRIORITY(string id)
    {
        double yqH = 0;
        string PRIORITY = Global.getPRIORITY(id);

        if (PRIORITY == "约期")
        {
            string yq = getyq(id);
            DateTime accepttime = getACCEPTTIME(id);
            if (yq.Contains("-"))
            {
                yqH = DiffTime(yq, accepttime);
            }
            else
            {
                yqH = 100;
            }
        }
        double soure = 0;
        switch (PRIORITY.Trim())
        {
            case "2小时":
                soure = 2;
                break;
            case "2 小时":
                soure = 2;
                break;
            case "当天":
                soure = dtDiff();
                break;
            case "24小时":
                soure = 24;
                break;
            case "3天":
                soure = 72;
                break;
            case "7天":
                soure = 7 * 24;
                break;
            case "5天":
                soure = 5 * 24;
                break;
            case "3 天":
                soure = 72;
                break;
            case "7 天":
                soure = 7 * 24;
                break;
            case "5 天":
                soure = 5 * 24;
                break;
            case "约期":
                soure = yqH;
                break;
            default:
                soure = 1000;
                break;
        }
        return soure;
    }
    private static double DiffTime(string yq, DateTime dt1)
    {
        DateTime yqTime;
        string[] tt = yq.Split('-');
        if (tt.Length > 3)
        {
            yq = tt[0] + "-" + tt[1] + "-" + tt[2].Split(' ')[0] + " " + tt[3];
        }
        if (DateTime.TryParse(yq, out yqTime))
        {
            TimeSpan tm = yqTime.Subtract(dt1);
            return tm.TotalHours;
        }
        else
            return 0;
    }
    /// <summary>
    /// 获取流程最新节点
    /// </summary>
    /// <param name="id">工单编号</param>
    /// <returns></returns>
    public static string GetTokenname(string id)
    {
        //string sql = @"select tokenname from tz_main t inner join bpmi_tokenlast b on t.taskid=b.taskid where t.id='" + id + "'";
        string sql = @"select tokenname from tz_main t where t.id='" + id + "'  or CUSTOMSERVICEID='"+id+"'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    public static string GetArrivalTime(string id)
    {
        //string sql = @"select tokenname from tz_main t inner join bpmi_tokenlast b on t.taskid=b.taskid where t.id='" + id + "'";
        string sql = @"select ARRIVALTIME from v_tz_main t where t.id='" + id + "'  or CUSTOMSERVICEID='" + id + "' ";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取处理级别
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getPRIORITY(string id)
    {
        string sql = "select PRIORITY from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 延期的销单及时
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getWRITEOFFINTIME1(string id)
    {
        Wordinfo words = new Wordinfo();
        string sql = @"select WRITEOFFINTIME from (  select round((a.checktime - c.ACCEPTTIME),3)*24 -16 WRITEOFFINTIME
                                from tz_yq_sh a inner join tz_main c
                                on a.main_id = c.id  where a.main_id = '" + id + "' order by ACCEPTTIME desc ) where rownum = 1";
        OracleDataBase odb = new OracleDataBase();
        double dt1 = Convert.ToDouble(odb.GetScalarobj(sql));
        double dt2 = getDiffByPRIORITY(id);

        if (dt2 - dt1 > 0)
        {
            return words.getWRITEOFFINTIME();
        }
        else
        {
            return words.getWRITEOFFOUTTIME();
        }
    }
    /// <summary>
    /// 请照的销单及时
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getWRITEOFFINTIME_SH(string id)
    {
        string sql = @"select WRITEOFFINTIME from (  select round((a.checktime - c.ACCEPTTIME),3)*24 -16 WRITEOFFINTIME
                                from tz_qz_sh a  inner join tz_main c
                                on a.main_id = c.id  where a.main_id = '" + id + "' order by ACCEPTTIME desc ) where rownum = 1";
        OracleDataBase odb = new OracleDataBase();
        double dt1 = Convert.ToDouble(odb.GetScalarobj(sql));
        double dt2 = getDiffByPRIORITY(id);
        Wordinfo words = new Wordinfo();
        if (dt2 - dt1 > 0)
        {
            return words.getWRITEOFFINTIME();
        }
        else
        {
            return words.getWRITEOFFOUTTIME();
        }
    }
    /// <summary>
    /// 销件及时
    /// </summary>
    /// <param name="id">工单编号</param>
    /// <returns></returns>
    public static string getWRITEOFFINTIME(string id)
    {




        OracleDataBase odb = new OracleDataBase();
        //判断
        //string strISHXSql = "select status, checktime from tz_qz_sh where main_id = '"+id+"' and status = 1 union select status, checktime from tz_yq_sh where main_id = '"+id+"' and status = 1";//是否唤醒单子 判断请照是否有该记录 并且为同意 延期
        string sql = @"";
        #region 注释之前计算唤醒工单
        //该工单是否被唤醒过
        string strISHXSql = "select * from tz_main_clinfo where waketime is not null and main_id = '" + id + "'";

        bool isHX = false;//是否
        ArrayList al_ISHX = odb.getDBRecord(strISHXSql);

        if (al_ISHX != null)
        {
            if (al_ISHX.Count > 0)
            {
                isHX = true;
            }
        }


        #endregion
        sql = @"select EXECUTIVEINTIME from ( 
select round(ARRIVALTIME-WRITEOFFTIME  ,3)*24+24 EXECUTIVEINTIME 
from tz_main_clinfo where main_id = '" + id + "'  ) where rownum = 1";
        double dt1 = Convert.ToDouble(odb.GetScalarobj(sql));

        Wordinfo words = new Wordinfo();
        if (dt1 >= 0)
        {
            return words.getWRITEOFFINTIME();
        }
        else
        {
            return words.getWRITEOFFOUTTIME();
        }
    }
    /// <summary>
    /// 处理及时
    /// 增加计划时间
    /// 单子被延期
    /// 2014年8月22日13:05:44 李
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getEXECUTIVEINTIME(string id)
    {
        Wordinfo words = new Wordinfo();
        string result = words.getWRITEOFFINTIME();
        OracleDataBase odb = new OracleDataBase();
        string sql = @"";
        #region 计算之前唤醒工单
        //该工单是否被唤醒过
        string strISHXSql = "select * from tz_main_clinfo where waketime is not null and main_id = '" + id + "'";

        bool isHX = false;//是否
        ArrayList al_ISHX = odb.getDBRecord(strISHXSql);

        if (al_ISHX != null)
        {
            if (al_ISHX.Count > 0)
            {
                isHX = true;
            }
        }


        #endregion

        string SOLVETIME_PLANSql = " select SOLVETIME_PLAN from tz_main where id='" + id + "' and rownum = 1 order by ACCEPTTIME desc   ";
        string ARRIVALTIMESql = " select ARRIVALTIME from tz_main_clinfo where main_id='" + id + "' and  rownum = 1";

        //2014年8月22日15:16:11 添加
        string finishplan = string.Empty;
        string SOLVETIME_PLAN = string.Empty;
        string ARRIVALTIME = string.Empty;
        SOLVETIME_PLAN = odb.GetScalarInfo(SOLVETIME_PLANSql);
        ARRIVALTIME = odb.GetScalarInfo(ARRIVALTIMESql);
        if (!string.IsNullOrEmpty(id))
        {
            string pSql = string.Format(@"select max(finishtimeinplan)as FINISHTIMEINPLAN from tz_yanqihis t where main_id='{0}'", id);
            finishplan = odb.GetScalarInfo(pSql);
            if (string.IsNullOrEmpty(finishplan))
            {
                string qzSql = string.Format(@"select max(finishtimeinplan) from tz_qz_his  t where main_id='{0}'", id);
                finishplan = odb.GetScalarInfo(qzSql);
            }
        }
        if (!string.IsNullOrEmpty(finishplan.Trim()) && !string.IsNullOrEmpty(ARRIVALTIME.Trim()))
        {
            if (Convert.ToDateTime(ARRIVALTIME.Trim()) > Convert.ToDateTime(finishplan.Trim()))
                result = words.getWRITEOFFOUTTIME();

        }
        else if (!string.IsNullOrEmpty(SOLVETIME_PLAN.Trim()) && !string.IsNullOrEmpty(ARRIVALTIME.Trim()))
        {
            if (Convert.ToDateTime(ARRIVALTIME.Trim()) > Convert.ToDateTime(SOLVETIME_PLAN.Trim()))
                result = words.getWRITEOFFOUTTIME(); 

        }
        return result;
    }

    /// <summary>
    /// 处理及时率判断
    /// </summary>
    /// <returns> 0.处理不及时  1。处理及时</returns>
    public static string ChuLiJiShi(string XFSJ, string SOLVETIME_PLAN)
    {
        if (SOLVETIME_PLAN != "" && XFSJ != "")
            if (DateTime.Parse(XFSJ).CompareTo(DateTime.Parse(SOLVETIME_PLAN)) > 0)
            {
                // msgstr += " <font color=red>处理不及时，修正修复时间！</font>";
                return "0";
            }
        return "1";
    }



    /// <summary>
    /// 销单及时率判断
    /// </summary>
    /// <returns> 0.销单不及时 1.销单及时  </returns>
    public static string XiaoDanJiShi(string WCSJ, string SOLVETIME_PLAN)
    {
        if (SOLVETIME_PLAN != "" && WCSJ != "")
            if (DateTime.Parse(WCSJ).CompareTo(DateTime.Parse(SOLVETIME_PLAN).AddHours(24)) > 0)
            {
                //msgstr += " <font color=red>销单不及时，修正完成时间</font>";
                return "0";
            }
        return "1";
    }
    /// <summary>
    /// 获取工作流水号(infonum)
    /// </summary>
    /// <param name="id">工作单编号</param>
    /// <returns></returns>
    public static string getInfoNum(string id)
    {
        string sql = "select infonum from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取Acceptstation(infonum)
    /// </summary>
    /// <param name="id">工作单编号</param>
    /// <returns></returns>
    public static string getAcceptstation(string id)
    {
        string sql = "select Acceptstation from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取ID(CUSTOMSERVICEID)
    /// 通过工单编号获取工单ID
    /// </summary>
    /// <param name="CUSTOMSERVICEID"></param>
    /// <returns></returns>
    public static string getOrderId(string CUSTOMSERVICEID)
    {
        string sql = "select ID from  tz_main where CUSTOMSERVICEID='" + CUSTOMSERVICEID + "'";
        OracleDataBase odb = new OracleDataBase();
        return  odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取工作流水号(CUSTOMSERVICEID)
    /// </summary>
    /// <param name="id">工作单编号</param>
    /// <returns></returns>
    public static string getCUSTOMSERVICEID(string id)
    {
        string sql = "select CUSTOMSERVICEID from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取工作流水号(MISSIONBH)
    /// </summary>
    /// <param name="id">工作单编号</param>
    /// <returns></returns>
    public static string getMISSIONBH(string id)
    {
        string sql = "select MISSIONBH from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }

    /// <summary>
    /// 获取tz_main中的ID (MISSIONBH)
    /// </summary>
    /// <param name="missionbh">任务编号</param>
    /// <returns></returns>
    public static string getTZMAINID(string missionbh)
    {
        string sql = "select id from  tz_main where missionbh='" + missionbh + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    public static string getAddress(string id)
    {
        string sql = "select HAPPENADDR from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取入保标识(保险)
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getREPAIRTYPE(string id)
    {
        string sql = "select REPAIRTYPE from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取受理站点 (SOURCESTATION)
    /// </summary>
    /// <param name="id">工作单编号</param>
    /// <returns></returns>
    public static string getSourceStation(string id)
    {
        string sql = "select ACCEPTSTATION from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }

    /// <summary>
    /// 判断是否需要二次审核
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static bool GetTWOAUDIT(string id)
    {
        try
        {
            int calibre = Convert.ToInt32(Global.getAppString("CALIBRE"));
            string sql = "select nvl(calibre, '0') as kj  from tz_main t where id = '" + id + "' and (calibre <> '' or calibre is not null)";
            OracleDataBase odb = new OracleDataBase();
            string kj = odb.GetScalarInfo(sql);
            if (string.IsNullOrEmpty(kj))
                return true;
            int tdkj = Convert.ToInt32(kj);
            return tdkj <= calibre;
        }
        catch (Exception ex)
        {
            return false;
        }
        
    }
    /// <summary>
    /// 获取反映类型
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getREPORTTYPE(string id)
    {
        string sql = "select REPORTTYPE from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取apk最新版本
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getAPKVersion()
    {
        string sql = "select versionid from t_versioninfo";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取接报时间
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static DateTime getACCEPTTIME(string id)
    {
        string sql = "select ACCEPTTIME from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return Convert.ToDateTime(odb.GetScalarInfo(sql));
    }

    /// <summary>
    /// 获取申请时间
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getSendtime(string id, string time, string tablename)
    {
        string sql = "select * from (select " + time + " from " + tablename + " where main_id='" + id + "'  order by " + time + " desc )t where rownum=1";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }

    /// <summary>
    /// 获取DPA名称
    /// </summary>
    /// <param name="pdaid"></param>
    /// <returns></returns>
    public static string getPdaName(string pdaid)
    {
        string sql = "select realname from author_user a,author_equipment b where a.cuser=b.relationobj and b.equipname='" + pdaid + "'";
        OracleDataBase odb = new OracleDataBase("1");
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 获取DPA所在办事处
    /// </summary>
    /// <param name="pdaid"></param>
    /// <returns></returns>
    public static string getPdaDepName(string pdaid)
    {
        OracleDataBase odb = new OracleDataBase("1");

        string sql_depname = string.Format("select depname from AUTHOR_EQUIPMENT_VIEW t where equipname='{0}'", pdaid);
        string depname = odb.GetScalarInfo(sql_depname);
        if (depname.Contains("班组"))
        {
            string sql = string.Format(@"select depname from author_department where id=(select pid from author_department where depname=(
select depname from AUTHOR_EQUIPMENT_VIEW t where equipname='{0}'))", pdaid);
            depname = odb.GetScalarInfo(sql);

        }

        return depname;
    }
    /// <summary>
    /// 获取工作但流程状态
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static string getStatus(string id)
    {
        string sql = "select status from  tz_main where id='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetScalarInfo(sql);
    }
    /// <summary>
    /// 是否可以激活
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static int getWorking(string id)
    {
        string sql = @"select count(*) count from (select r.* from tz_qz_sh r union select  y.* from tz_yq_sh y) 
                        where main_id='" + id + "'  and status = '0'";
        OracleDataBase odb = new OracleDataBase();
        return odb.GetRecordCount(sql);
    }
    /// <summary>
    /// 判断工单是否已备注（只能备注一次）
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public static bool GetBeiZhuInfo(string id)
    {
        string sql = string.Format("select count(id) from TZ_MAIN_XIAODANBEIZHU where main_id='{0}'", id);
        OracleDataBase odb = new OracleDataBase();
        return Convert.ToInt32(odb.GetScalarobj(sql)) > 0 ? false : true;
    }
    public static String getMapResourceNAME()
    {
        return "MapResourceItem_test";
    }
    public static bool isContainMobileNum(string mobileNum, string userid)
    {
        bool isContainMobile = false;
        OracleConnection conn = Global.getOracleConnection();
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from mobilelocatelist where userid='" + userid + "' and mobilenum='" + mobileNum + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        if (data.HasRows)
        {
            isContainMobile = true;
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return isContainMobile;
    }
    public static void insertToMobileList(string mobileNum, string userid)
    {
        OracleConnection conn = Global.getOracleConnection();
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "insert into mobilelocatelist(userid,mobilenum,addtime) values('" + userid + "','" + mobileNum + "',sysdate)";
        oraComm.ExecuteNonQuery();
        conn.Close();
    }
    public static void deleteFromMobileList(string mobileNum, string userid)
    {
        OracleConnection conn = Global.getOracleConnection();
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "delete from mobilelocatelist where userid='" + userid + "' and mobilenum='" + mobileNum + "'";
        oraComm.ExecuteNonQuery();
        conn.Close();
    }

    public static System.Drawing.Point fillScreenPoint(System.Drawing.Point screeaPoint, int cou)
    {
        int perX = 1;
        int perY = 1;
        screeaPoint.X = screeaPoint.X + (cou * perX);
        screeaPoint.Y = screeaPoint.Y + (cou * perY);
        return screeaPoint;
    }
    public static double getRamdomX()
    {
        Random ran = new Random();
        double x = 120.1 + (ran.NextDouble() / 10);
        return x;
    }

    public static double Fun_Rad(double d)
    {
        return d * Math.PI / 180.0;
    }

    public static double Fun_GetDistance(double lat1, double lng1, double lat2, double lng2)
    {
        double d_EarthRadius = 6378.137;
        double radLat1 = Fun_Rad(lat1);
        double radLat2 = Fun_Rad(lat2);
        double radLat = Fun_Rad(lat1) - Fun_Rad(lat2);
        double radLng = Fun_Rad(lng1) - Fun_Rad(lng2);
        double s = 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(radLat / 2), 2) +
         Math.Cos(radLat1) * Math.Cos(radLat2) * Math.Pow(Math.Sin(radLng / 2), 2)));
        s = s * d_EarthRadius;
        s = Math.Round(s * 10000) / 10000;
        return s;
    }

    public static double getRamdomY()
    {
        Random ran = new Random();
        ran.NextDouble();
        double y = 30.2 + (ran.NextDouble() / 10);
        return y;
    }
    public static OracleConnection getQXOracleConnection()
    {
        string connstring = System.Configuration.ConfigurationManager.ConnectionStrings["PDWXFWQX"].ConnectionString;
        //是否加密处理
        bool ConStringEncrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]);
        if (ConStringEncrypt)
        {
            connstring = Global.Decode(connstring);
        }
        OracleConnection conn = new OracleConnection(connstring);
        return conn;
    }
    public static OracleConnection getOracleConnection()
    {
        string connstring = Decrypt.PropDBConn; //System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        //是否加密处理
        bool ConStringEncrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]);
        if (ConStringEncrypt)
        {
            connstring = Global.Decode(connstring);
        }
        OracleConnection conn = new OracleConnection(connstring);
        return conn;
    }
    public static OracleConnection getOracleConnection_YW()
    {
        string connstring = System.Configuration.ConfigurationManager.ConnectionStrings["ZLSWXFWDB"].ConnectionString;
        //是否加密处理
        bool ConStringEncrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]);
        if (ConStringEncrypt)
        {
            connstring = Global.Decode(connstring);
        }
        OracleConnection conn = new OracleConnection(connstring);
        return conn;
    }
    public static OracleConnection getOracleConnection(string connectionString)
    {
        OracleConnection conn = new OracleConnection(connectionString);
        return conn;
    }
    public static OracleConnection getOracleConnection1(string connectionString)
    {
        string connstring = System.Configuration.ConfigurationManager.ConnectionStrings[connectionString].ConnectionString;
        //是否加密处理
        bool ConStringEncrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]);
        if (ConStringEncrypt)
        {
            connstring = Global.Decode(connstring);
        }
        OracleConnection conn = new OracleConnection(connstring);
        return conn;
    }
    public static string GetClientIP(HttpRequest request)
    {
        string result = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (null == result || result == String.Empty)
        {
            result = request.ServerVariables["REMOTE_ADDR"];
        }
        if (null == result || result == String.Empty)
        {
            result = request.UserHostAddress;
        }
        return result;
    }
    public static DictionaryContent getFieldObject(string tablename, string fieldname)
    {
        Hashtable xwbm_sjzd = InitCache.xwbm_sjzd;
        if (xwbm_sjzd[tablename] != null)
        {
            ArrayList al = (ArrayList)xwbm_sjzd[tablename];
            for (int i = 0; i < al.Count; i++)
            {
                DictionaryContent dc = (DictionaryContent)al[i];
                if (dc.fieldName == fieldname)
                {
                    return dc;
                }
            }
        }
        return null;
    }

    public static string getRamFileName()
    {
        DateTime dt = new DateTime();
        string name = Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Hour) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second) + Convert.ToString(DateTime.Now.Millisecond);
        return name;
    }

    public static string getIMSIFromMobileNo(string tablename, string mobileNo)
    {

        OracleConnection conn = Global.getOracleConnection();
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from " + tablename + " where isdn like '%" + mobileNo + "%' and imsi is not null";
        OracleDataReader data = oraComm.ExecuteReader();
        object imsi = null;
        while (data.Read())
        {
            imsi = data.GetValue(data.GetOrdinal("imsi"));
            if (imsi != null) break;
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        if (imsi != null && Convert.ToString(imsi) != "")
        {
            return Convert.ToString(imsi);
        }
        return null;
    }

    public static MyAuth.authServices.WSPermissionResult getPermissionResult(XmlNode[] xmlNode)
    {
        MyAuth.authServices.WSPermissionResult permissionResult = new MyAuth.authServices.WSPermissionResult();

        for (int i = 0; i < xmlNode.Length; i++)
        {
            XmlNode node = xmlNode[i];
            if (node.Name == "department")
            {
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(node.OuterXml);
                System.Xml.XmlNode root = doc.DocumentElement;
                ArrayList al = new ArrayList();
                foreach (System.Xml.XmlNode childElement in root.ChildNodes)
                {
                    if (childElement.Name.ToUpper() == "DEPARTMENT")
                    {
                        MyAuth.authServices.WSDepartment department = new MyAuth.authServices.WSDepartment();
                        foreach (System.Xml.XmlNode childElement1 in childElement.ChildNodes)
                        {
                            if (childElement1.Name.ToUpper() == "BUSINESSID")
                            {
                                department.businessId = childElement1.InnerText;
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "DISPLAYORDER")
                            {
                                department.displayOrder = Convert.ToInt32(childElement1.InnerText);
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "NAME")
                            {
                                department.name = childElement1.InnerText;
                                continue;
                            }
                        }
                        al.Add(department);
                    }

                }
                MyAuth.authServices.WSDepartment[] deps = (MyAuth.authServices.WSDepartment[])al.ToArray(Type.GetType("MyAuth.authServices.WSDepartment"));
                permissionResult.department = deps;
                continue;
            }
            if (node.Name == "message")
            {
                permissionResult.message = node.InnerText;
                continue;
            }
            if (node.Name == "permissions")
            {
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(node.OuterXml);
                System.Xml.XmlNode root = doc.DocumentElement;
                ArrayList al = new ArrayList();
                foreach (System.Xml.XmlNode childElement in root.ChildNodes)
                {
                    if (childElement.Name.ToUpper() == "PERMISSIONS")
                    {
                        MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                        foreach (System.Xml.XmlNode childElement1 in childElement.ChildNodes)
                        {
                            if (childElement1.Name.ToUpper() == "OPERATIONBID")
                            {
                                permissionItem.operationBid = childElement1.InnerText;
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "OPERATIONNAME")
                            {
                                permissionItem.operationName = childElement1.InnerText;
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "resourceBid".ToUpper())
                            {
                                permissionItem.resourceBid = childElement1.InnerText;
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "resourceCategoryBid".ToUpper())
                            {
                                permissionItem.resourceCategoryBid = childElement1.InnerText;
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "resourceCategoryName".ToUpper())
                            {
                                permissionItem.resourceCategoryName = childElement1.InnerText;
                                continue;
                            }
                            if (childElement1.Name.ToUpper() == "resourceName".ToUpper())
                            {
                                permissionItem.resourceName = childElement1.InnerText;
                                continue;
                            }
                        }
                        al.Add(permissionItem);
                    }

                }
                MyAuth.authServices.WSPermissionItem[] permissions = (MyAuth.authServices.WSPermissionItem[])al.ToArray(Type.GetType("MyAuth.authServices.WSPermissionItem"));
                permissionResult.permissions = permissions;
                continue;
            }

            if (node.Name == "success")
            {
                bool isSuccess = false;
                if (node.InnerXml.ToUpper() == "TRUE")
                {
                    isSuccess = true;
                }
                permissionResult.success = isSuccess;
                continue;
            }
            if (node.Name == "user")
            {
                MyAuth.authServices.WSUser user = new MyAuth.authServices.WSUser();
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(node.OuterXml);
                System.Xml.XmlNode root = doc.DocumentElement;
                foreach (System.Xml.XmlNode childElement in root.ChildNodes)
                {
                    if (childElement.Name.ToUpper() == "BUSINESSID")
                    {
                        user.businessId = childElement.InnerText;
                        continue;
                    }
                    if (childElement.Name.ToUpper() == "DISPLAYORDER")
                    {
                        user.displayOrder = Convert.ToInt32(childElement.InnerText);
                        continue;
                    }
                    if (childElement.Name.ToUpper() == "LOGINNAME")
                    {
                        user.loginName = childElement.InnerText;
                        continue;
                    }
                    if (childElement.Name.ToUpper() == "PASSWORD")
                    {
                        user.password = childElement.InnerText;
                        continue;
                    }
                    if (childElement.Name.ToUpper() == "REALNAME")
                    {
                        user.realName = childElement.InnerText;
                        continue;
                    }
                    if (childElement.Name.ToUpper() == "USERTYPE")
                    {
                        user.userType = childElement.InnerText;
                        continue;
                    }
                }
                permissionResult.user = user;
                continue;
            }
        }
        return permissionResult;
    }

    public static bool isHaveAuth(MyAuth.authServices.WSPermissionResult myresult, string operationID, string resourceName)
    {
        if (myresult == null) return false;
        MyAuth.authServices.WSPermissionItem[] permissions = myresult.permissions;
        if (permissions == null) return false;
        for (int i = 0; i < permissions.Length; i++)
        {
            MyAuth.authServices.WSPermissionItem permission = permissions[i];
            if (permission.operationBid.ToUpper() == operationID.ToUpper() && permission.resourceName.ToUpper() == resourceName.ToUpper())
            {
                return true;
            }
        }
        return false;
    }

    public static ArrayList getAuthGzq(MyAuth.authServices.WSPermissionResult myresult, string operationID)
    {
        if (myresult == null) return null;
        MyAuth.authServices.WSPermissionItem[] permissions = myresult.permissions;
        if (permissions == null) return null;
        ArrayList al = new ArrayList();
        for (int i = 0; i < permissions.Length; i++)
        {
            MyAuth.authServices.WSPermissionItem permission = permissions[i];
            if (permission.operationBid.ToUpper() == operationID.ToUpper() && permission.resourceCategoryName == InitCache.genzongqiAuthName)
            {
                al.Add(permission.resourceName);
            }
        }
        return al;
    }

    public static void resetDragImageCount()
    {
        System.Web.HttpContext.Current.Session.Add("hg_DragImageCount", 0);
    }

    public static MyAuth.authServices.WSPermissionResult getPermission(string uid, string pwd)
    {
        try
        {
         Loger.Info("执行登陆权限验证==>");
        MyAuth.authServices.WSPermissionResult permissionResult = new MyAuth.authServices.WSPermissionResult();

        OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();

        MyAuth.authServices.WSUser user = new MyAuth.authServices.WSUser();
        permissionResult.user = user;
        permissionResult.success = false;
        permissionResult.message = "用户名或密码错误。";

        oraComm.CommandText = "select * from author_user where cuser='" + uid + "' and cpass='" + pwd + "'";
        //oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
        OracleDataReader data1 = oraComm.ExecuteReader();
        while (data1.Read())
        {
            permissionResult.success = true;
            object id = data1.GetValue(data1.GetOrdinal("id"));
            object realname = data1.GetValue(data1.GetOrdinal("realname"));
            user.businessId = Convert.ToString(id);
            user.loginName = uid;
            user.password = pwd;
            user.realName = Convert.ToString(realname);
        }
        if (!data1.IsClosed)
            data1.Close();
        if (permissionResult.success == false)
        {
            conn.Close();
            return permissionResult;
        }

        //取功能权限
        ArrayList al = new ArrayList();
        if (uid != "admin")
        {
            ArrayList holdResources = AuthorGlobal.getResources(uid);
            for (int i = 0; i < holdResources.Count; i++)
            {
                ResourceBean resBean = (ResourceBean)holdResources[i];
                MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                permissionItem.resourceBid = resBean.id;
                permissionItem.resourceCategoryBid = resBean.rescatalog;
                permissionItem.resourceCategoryName = resBean.rescataname;
                permissionItem.resourceName = resBean.resname;
                permissionItem.operationBid = "use";
                al.Add(permissionItem);
                if (resBean.resname != null && resBean.resname == "用户管理功能")
                {
                    user.userType = "管理员";
                }
            }
        }
        else
        {
            user.userType = "超级管理员";
            oraComm.CommandText = "select * from author_rescatalog";
            data1 = oraComm.ExecuteReader();
            while (data1.Read())
            {
                object cataid = data1.GetValue(data1.GetOrdinal("id"));
                object cataname = data1.GetValue(data1.GetOrdinal("cataname"));

                oraComm.CommandText = "select * from author_resource where rescatalog='" + Convert.ToString(cataid) + "'";
                OracleDataReader data = oraComm.ExecuteReader();
                while (data.Read())
                {
                    object id = data.GetValue(data.GetOrdinal("id"));
                    object rescatelog = data.GetValue(data.GetOrdinal("rescatalog"));
                    object resname = data.GetValue(data.GetOrdinal("resname"));
                    object depid = data.GetValue(data.GetOrdinal("depid"));
                    MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                    permissionItem.resourceBid = Convert.ToString(id);
                    permissionItem.resourceCategoryBid = Convert.ToString(rescatelog);
                    permissionItem.resourceCategoryName = Convert.ToString(cataname);
                    permissionItem.resourceName = Convert.ToString(resname);
                    permissionItem.operationBid = "use";
                    al.Add(permissionItem);
                }
                if (!data.IsClosed)
                    data.Close();
            }
            if (!data1.IsClosed)
                data1.Close();
        }


        //取设备权限
        ArrayList deps = AuthorGlobal.getAllDepartmentWithUserID(uid);
        string whereDepStr = "";
        for (int i = 0; i < deps.Count; i++)
        {
            string tempStr = "depid='" + Convert.ToString(deps[i]) + "'";
            whereDepStr = whereDepStr == "" ? tempStr : whereDepStr + " or " + tempStr;
        }

        oraComm.CommandText = "select * from author_equipcatalog";
        data1 = oraComm.ExecuteReader();
        while (data1.Read())
        {
            object cataid = data1.GetValue(data1.GetOrdinal("id"));
            object cataname = data1.GetValue(data1.GetOrdinal("equipcataname"));

            oraComm.CommandText = "select * from author_equipment  where equipcataid='" + Convert.ToString(cataid) + "' and (" + whereDepStr + ")";
            OracleDataReader data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object id = data.GetValue(data.GetOrdinal("id"));
                object rescatelog = data.GetValue(data.GetOrdinal("equipcataid"));
                object resname = data.GetValue(data.GetOrdinal("equipname"));
                object depid = data.GetValue(data.GetOrdinal("depid"));
                MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                permissionItem.resourceBid = Convert.ToString(id);
                permissionItem.resourceCategoryBid = Convert.ToString(rescatelog);
                permissionItem.resourceCategoryName = Convert.ToString(cataname);
                permissionItem.resourceName = Convert.ToString(resname);
                permissionItem.operationBid = "use";
                al.Add(permissionItem);
            }
            if (!data.IsClosed)
                data.Close();
        }
        if (!data1.IsClosed)
            data1.Close();

        conn.Close();
        MyAuth.authServices.WSPermissionItem[] permissions = (MyAuth.authServices.WSPermissionItem[])al.ToArray(Type.GetType("MyAuth.authServices.WSPermissionItem"));
        permissionResult.permissions = permissions;
        return permissionResult;
        }
        catch (Exception ex)
        {

            throw;
        }   
    }

    public static MyAuth.authServices.WSPermissionResult getPermission(string uid)
    {
        try
        {
            Loger.Info("执行登陆权限验证==>");
            MyAuth.authServices.WSPermissionResult permissionResult = new MyAuth.authServices.WSPermissionResult();

            OracleConnection conn = Global.getOracleConnection(Decrypt.AuthDBConn);
            conn.Open();
            OracleCommand oraComm = conn.CreateCommand();

            MyAuth.authServices.WSUser user = new MyAuth.authServices.WSUser();
            permissionResult.user = user;
            permissionResult.success = false;
            permissionResult.message = "用户名或密码错误。";

            oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
            //oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
            OracleDataReader data1 = oraComm.ExecuteReader();
            while (data1.Read())
            {
                permissionResult.success = true;
                object id = data1.GetValue(data1.GetOrdinal("id"));
                object realname = data1.GetValue(data1.GetOrdinal("realname"));
                user.businessId = Convert.ToString(id);
                user.loginName = uid;
                user.realName = Convert.ToString(realname);
            }
            if (!data1.IsClosed)
                data1.Close();
            if (permissionResult.success == false)
            {
                conn.Close();
                return permissionResult;
            }

            //取功能权限
            ArrayList al = new ArrayList();
            if (uid != "admin")
            {
                ArrayList holdResources = AuthorGlobal.getResources(uid);
                for (int i = 0; i < holdResources.Count; i++)
                {
                    ResourceBean resBean = (ResourceBean)holdResources[i];
                    MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                    permissionItem.resourceBid = resBean.id;
                    permissionItem.resourceCategoryBid = resBean.rescatalog;
                    permissionItem.resourceCategoryName = resBean.rescataname;
                    permissionItem.resourceName = resBean.resname;
                    permissionItem.operationBid = "use";
                    al.Add(permissionItem);
                    if (resBean.resname != null && resBean.resname == "用户管理功能")
                    {
                        user.userType = "管理员";
                    }
                }
            }
            else
            {
                user.userType = "超级管理员";
                oraComm.CommandText = "select * from author_rescatalog";
                data1 = oraComm.ExecuteReader();
                while (data1.Read())
                {
                    object cataid = data1.GetValue(data1.GetOrdinal("id"));
                    object cataname = data1.GetValue(data1.GetOrdinal("cataname"));

                    oraComm.CommandText = "select * from author_resource where rescatalog='" + Convert.ToString(cataid) + "'";
                    OracleDataReader data = oraComm.ExecuteReader();
                    while (data.Read())
                    {
                        object id = data.GetValue(data.GetOrdinal("id"));
                        object rescatelog = data.GetValue(data.GetOrdinal("rescatalog"));
                        object resname = data.GetValue(data.GetOrdinal("resname"));
                        object depid = data.GetValue(data.GetOrdinal("depid"));
                        MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                        permissionItem.resourceBid = Convert.ToString(id);
                        permissionItem.resourceCategoryBid = Convert.ToString(rescatelog);
                        permissionItem.resourceCategoryName = Convert.ToString(cataname);
                        permissionItem.resourceName = Convert.ToString(resname);
                        permissionItem.operationBid = "use";
                        al.Add(permissionItem);
                    }
                    if (!data.IsClosed)
                        data.Close();
                }
                if (!data1.IsClosed)
                    data1.Close();
            }


            //取设备权限
            ArrayList deps = AuthorGlobal.getAllDepartmentWithUserID(uid);
            string whereDepStr = "";
            for (int i = 0; i < deps.Count; i++)
            {
                string tempStr = "depid='" + Convert.ToString(deps[i]) + "'";
                whereDepStr = whereDepStr == "" ? tempStr : whereDepStr + " or " + tempStr;
            }

            oraComm.CommandText = "select * from author_equipcatalog";
            data1 = oraComm.ExecuteReader();
            while (data1.Read())
            {
                object cataid = data1.GetValue(data1.GetOrdinal("id"));
                object cataname = data1.GetValue(data1.GetOrdinal("equipcataname"));

                oraComm.CommandText = "select * from author_equipment  where equipcataid='" + Convert.ToString(cataid) + "' and (" + whereDepStr + ")";
                OracleDataReader data = oraComm.ExecuteReader();
                while (data.Read())
                {
                    object id = data.GetValue(data.GetOrdinal("id"));
                    object rescatelog = data.GetValue(data.GetOrdinal("equipcataid"));
                    object resname = data.GetValue(data.GetOrdinal("equipname"));
                    object depid = data.GetValue(data.GetOrdinal("depid"));
                    MyAuth.authServices.WSPermissionItem permissionItem = new MyAuth.authServices.WSPermissionItem();
                    permissionItem.resourceBid = Convert.ToString(id);
                    permissionItem.resourceCategoryBid = Convert.ToString(rescatelog);
                    permissionItem.resourceCategoryName = Convert.ToString(cataname);
                    permissionItem.resourceName = Convert.ToString(resname);
                    permissionItem.operationBid = "use";
                    al.Add(permissionItem);
                }
                if (!data.IsClosed)
                    data.Close();
            }
            if (!data1.IsClosed)
                data1.Close();

            conn.Close();
            MyAuth.authServices.WSPermissionItem[] permissions = (MyAuth.authServices.WSPermissionItem[])al.ToArray(Type.GetType("MyAuth.authServices.WSPermissionItem"));
            permissionResult.permissions = permissions;
            return permissionResult;
        }
        catch (Exception ex)
        {

            throw;
        }
    }

    public static string md5(string str)
    {
        string newpwd = FormsAuthentication.HashPasswordForStoringInConfigFile(str.Trim(), "MD5");
        return newpwd;
    }

    /// <summary>
    /// PDA是否在线
    /// </summary>
    /// <returns>0.不在线 1.在线</returns>
    public static string PdaisOnLine(string loctime)
    {

        int pdaonlinenum = Convert.ToInt32(ConfigurationManager.AppSettings["Loctime"]); ;// int.Parse(pdakeyValue["ONLINENUM"].ToString());
        if (loctime != "" && DateTime.Parse(loctime).AddMinutes(pdaonlinenum).CompareTo(DateTime.Now) > 0)
            return "1";
        return "0";

    }

    public static string getAppString(string AppString)
    {
        string connstring = System.Configuration.ConfigurationManager.AppSettings[AppString].ToString();
        return connstring;
    }

    /// <summary>
    /// 审核处理后修改当前审核站点
    /// </summary>
    /// <param name="main_id"></param>
    /// <returns></returns>
    public static bool SHCL(string main_id, string shstate, string shtype, string uid, OracleCommand UpdateCommand)
    {
        try
        {
            string shcode = "028";
            if(shtype == "1")
                shcode = "028";
            if (shtype == "2")
                shcode = "029";
            if (shtype == "3")
                shcode = "031";
            string sql = "select hisorder, hisstation from stationpaidanhis t where status is null and  hisstation in (select wordscontent from words where belongcode = '" + shcode + "') and main_id = '" + main_id + "' order by hisorder ";
            if (shstate == "1")
                sql += " desc ";
            else
                sql += " asc ";
            OracleDataBase odb = new OracleDataBase();
            DataSet ds = odb.GetDataSet(sql);
            string shacceptstation = odb.GetScalarInfo(" select SHACCEPTSTATION from TZ_MAIN where id = '" + main_id + "'");            
            string shstation = "";
            string firstsh = "";
            string accpstation = "";
            bool flag = false;
            string sql1 = "";
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                string station = "";
                accpstation = ds.Tables[0].Rows[0]["hisstation"].ToString();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    station = ds.Tables[0].Rows[i]["hisstation"].ToString();
                    if (string.IsNullOrEmpty(firstsh))
                        firstsh = station;
                    if (station != shacceptstation)
                        continue;
                    if (i == ds.Tables[0].Rows.Count - 1)
                    {
                        if (string.IsNullOrEmpty(shstation))
                        {
                            firstsh = ds.Tables[0].Rows[i]["hisstation"].ToString();
                        }
                        continue;
                    }
                    shstation = ds.Tables[0].Rows[i + 1]["hisstation"].ToString();
                }
                if (!string.IsNullOrEmpty(shstation))
                {
                    flag = false;
                    sql1 = "update tz_main set SHACCEPTSTATION = '" + shstation + "' where id = '" + main_id + "'";
                    UpdateCommand.CommandText = sql1;
                    UpdateCommand.ExecuteNonQuery();
                }
                else
                {
                    flag = true;
                    sql1 = "update tz_main set SHACCEPTSTATION = '" + firstsh + "' where id = '" + main_id + "'";
                    if (shtype != "2" && shstate == "1")
                    {
                        sql1 = "update tz_main set SHACCEPTSTATION = '" + accpstation + "' where id = '" + main_id + "'";
                    }
                    if (!string.IsNullOrEmpty(firstsh))
                    {
                        UpdateCommand.CommandText = sql1;
                        UpdateCommand.ExecuteNonQuery();
                    }
                }
            }
            else
            {
                flag = true;
                sql1 = "update tz_main set SHACCEPTSTATION = '" + GetDepname(uid) + "' where id = '" + main_id + "'";
                UpdateCommand.CommandText = sql1;
                UpdateCommand.ExecuteNonQuery();
            }
            Loger.Error("Global.SHCL()==>string main_id" + main_id + ", string shstate:" + shstate + ", string shtype" + shtype + "sql1:" + sql1);
            return flag;
        }
        catch (Exception ex)
        {
            Loger.Error("Global.SHCL()==>", ex);
            return false;
        }
    }
    /// <summary>
    /// 根据用户ID获取部门名称
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static string GetDepname(string uid)
    {
        string result = "";
        string sql = "select depname from author_user a,author_department b where a.depid=b.id and cuser='" + uid + "'";
        OracleDataBase odb1 = new OracleDataBase("1");
        result = odb1.GetScalarInfo(sql).ToString();
        return result;
    }

    /// <summary>
    ///     获取显示组字段
    /// </summary>
    /// <returns>DataSet</returns>
    public static DataSet getGroupnum()
    {
        //string sql = string.Format("select GROUPNUM,Name from groupdis where 1=1 {0} order by groupnum", str_where);
        string sql = string.Format(@" select * from pz_tab t where status='{0}' and isdetail='{1}' order by fieldgroup asc", 0,1);
        OracleDataBase odb = new OracleDataBase();
        return odb.GetDataSet(sql);
    }
    /// <summary>
    ///  获取根据<<TCCNAME>>显示组字段
    /// </summary>
    /// <returns></returns>
    public static DataSet getGroupnum(string TCCNAME)
    {
        string sql = string.Format(@" select * from pz_tab t where status='{0}'  and TABNAME in ({1}) order by fieldgroup asc", 0, TCCNAME);
        OracleDataBase odb = new OracleDataBase();
        return odb.GetDataSet(sql);
    }
    /// <summary>
    ///获取组对应字段
    /// </summary>
    /// <returns>DataSet</returns>
    public static DataSet getFielddisname(string str_where, string rtID)
    {
        string sql = string.Format(@"SELECT D.STYLE,T.TID,D.LENGTH ,T.TCNNAME, T.FIELDGROUP, D.FIELDNAME, D.FIELDDISNAME,D.LENGTH, D.TABLEID, (SELECT COUNT(*) FROM S_DICT WHERE S_DICT.FIELDGROUP = T.FIELDGROUP) AS COUNTNUMBER FROM PZ_TAB T INNER JOIN S_DICT D ON T.FIELDGROUP = D.FIELDGROUP WHERE D.VALIDITY = '0' AND D.TIP = '0' {1} ORDER BY T.FIELDGROUP,d.fieldorder", rtID, str_where); 
        OracleDataBase odb = new OracleDataBase();
        return odb.GetDataSet(sql);
    }
    /// <summary>
    /// 获取工单材料信息
    /// </summary>
    /// <param name="id">工单编号</param>
    /// <returns></returns>
    public static DataTable GetEquipment_materialById(string id)
    {
        DataTable dt = new DataTable();
        if (!string.IsNullOrEmpty(id))
        {
            string strSql = string.Format(@"select * from equipment_material_used t where t.mainid='{0}'", id);
            OracleDataBase odb = new OracleDataBase();
            DataSet ds = odb.GetDataSet(strSql);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                dt = ds.Tables[0];
        }
        return dt; 
    }

    /// <summary>
    ///     获取工单详细信息
    /// </summary>
    /// <param name="id">主表id</param>
    /// <returns>工单详细信息</returns>
    public static Hashtable getDetailById(string id,string tableName)
    {
        string sql = "select * from "+tableName+" where ID='" + id + "' or CUSTOMSERVICEID='" + id + "'";
        OracleDataBase odb = new OracleDataBase();
        Hashtable HT = odb.getDBHT(sql);
        if (HT.Count > 0)
        {
            //格式化数据
            if (HT["ISSELFSEND"] != null)
            {
                HT["ISSELFSEND"] = HT["ISSELFSEND"].ToString() == "1" ? "是" : "否";
            }
            if (HT["HAPPENTIME"] != null)
            {
                HT["HAPPENTIME"] = !string.IsNullOrEmpty(HT["HAPPENTIME"].ToString())
                                       ? Convert.ToDateTime(HT["HAPPENTIME"]).ToString("yyyy-MM-dd")
                                       : "";
            }
            if (HT["ACCEPTTIME"] != null)
            {
                HT["ACCEPTTIME"] = !string.IsNullOrEmpty(HT["ACCEPTTIME"].ToString())
                                       ? Convert.ToDateTime(HT["ACCEPTTIME"]).ToString("yyyy-MM-dd HH:mm")
                                       : "";
            }
            if (HT["ACCEPTTIME"] != null)
            {
                HT["ACCEPTTIME"] = !string.IsNullOrEmpty(HT["ACCEPTTIME"].ToString())
                                       ? Convert.ToDateTime(HT["ACCEPTTIME"]).ToString("yyyy-MM-dd HH:mm")
                                       : "";
            }
            if (HT["PRINTDATE"] != null)
            {
                HT["PRINTDATE"] = !string.IsNullOrEmpty(HT["PRINTDATE"].ToString())
                                      ? Convert.ToDateTime(HT["PRINTDATE"]).ToString("yyyy-MM-dd HH:mm")
                                      : "";
            }
            if (HT["PRINTDATE"] != null)
            {
                HT["PRINTDATE"] = !string.IsNullOrEmpty(HT["PRINTDATE"].ToString())
                                      ? Convert.ToDateTime(HT["PRINTDATE"]).ToString("yyyy-MM-dd HH:mm")
                                      : "";
            }
            if (HT["PDAID"] != null)
            {
                if (!string.IsNullOrEmpty(HT["PDAID"].ToString()))
                {
                    string realname = getmyname(HT["PDAID"].ToString());
                    HT["PDAID"] = realname != "" ? realname : HT["PDAID"].ToString();
                }
            }
            if (HT["ZT"] != null)
            {
                HT["ZT"] = HT["ZT"].ToString() == "2" ? "<span style='color:red'>已接收</span>" : "未接收";
            }
            if (HT["RELATIONCUNSTZT"] != null)
            {
                HT["RELATIONCUNSTZT"] = HT["RELATIONCUNSTZT"].ToString() == "1" ? "是" : "否";
            }
            if (HT["ISPRINT"] != null)
            {
                HT["ISPRINT"] = HT["ISPRINT"].ToString() == "1" ? "是" : "否";
            }
        }
        return HT;
    }
    /// <summary>
    ///     获取使用者名称
    /// </summary>
    /// <param name="Pdaid">手机串号</param>
    /// <returns>使用者名称</returns>
    public static string getmyname(string Pdaid)
    {
        string temp = "";
        OracleDataBase odb1 = new OracleDataBase("1");
        if (Pdaid != "")
        {
            string sql =
                "select realname from author_user a,author_equipment b where a.cuser=b.relationobj and b.equipname='" +
                Pdaid + "'";
            DataSet ds = odb1.GetDataSet(sql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                temp = ds.Tables[0].Rows[0]["realname"].ToString();
            }
            else
            {
                sql = "select t.realname from author_user t where t.cuser='" + Pdaid + "'";
                string username = odb1.GetScalarInfo(sql);
                temp = username != null ? username.ToString() : Pdaid;
            }
        }
        return !string.IsNullOrEmpty(temp) ? temp : Pdaid;
    }
    /// <summary>
    ///     获取图片信息
    /// </summary>
    /// <param name="id">主表id</param>
    /// <returns>true,false</returns>
    public static ArrayList getPicDetailById(string id)
    {
        //加载现维图片
        string sql = string.Format("select * from (select FILEPATH||'/'||FILENAME,id,STEPTYPE,RQ,MEMO_,'1' type,realname from TRACK_MEDIA where   eventtype='1' and mediatype is null and EVENTRECORDID in (select id from wxfwdb.tz_main where (CUSTOMSERVICEID =  '{0}' or id='{0}') )", id);
        //加载巡检转工单时上传图片
        sql += string.Format("union all  select FILEPATH||'/'||FILENAME,id,STEPTYPE,RQ,MEMO_,'2' type,realname from TRACK_MEDIA where  eventtype='0'  and mediatype is null and  EVENTRECORDID in (select id from wxfwdb.tz_main   where (CUSTOMSERVICEID =  '{0}' or id='{0}')))", id);
        //string eventbh = GetXcqksbID(id);
        //if (!string.IsNullOrEmpty(eventbh))
        //{
        //    //sql = sql + string.Format(" or EVENTRECORDID='{0}'", eventbh);
        //    //sql = sql + "union select FILEPATH||'/'||FILENAME,id,STEPTYPE,RQ,MEMO_,'2' type,realname from TRACK_MEDIA where FILENAME is not null and mediatype is null and (EVENTRECORDID='{0}' or EVENTRECORDID in (select id from wxfwdb.tz_main where CUSTOMSERVICEID = '{0}' and reportsource<>'巡检上报'))";
        //}
        //按日期排序
        sql = sql + " order by rq desc";
        Loger.Error(sql);
        return new OracleDataBase().getDBRecord(sql);
    }

    public static Hashtable GetTabs()
    {
        Hashtable tabs = new Hashtable();
        try
        {
            tabs = DetailCache.tabs;
            if (tabs == null || tabs.Count < 1)
            {
                DataSet ds = Global.getGroupnum();
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable tabs_temp = new Hashtable();
                    foreach (System.Data.DataRow row in ds.Tables[0].Rows)
                    {
                        PZ_TAB tab = new PZ_TAB();
                        string fieldgroup = row["FIELDGROUP"].ToString();
                        tab.TID = row["TID"].ToString();
                        tab.TCNNAME = row["TCNNAME"].ToString();
                        tab.FIELDGROUP = fieldgroup;
                        tab.TABTYPE = row["TABTYPE"].ToString();
                        tab.TABNAME = row["TABNAME"].ToString();
                        tab.TABMAINID = row["TABMAINID"].ToString();
                        tab.TABORDER = row["TABORDER"].ToString();
                        tab.TICON = row["TICON"].ToString();
                        tabs_temp.Add(fieldgroup, tab);
                    }
                    tabs = tabs_temp;
                    DetailCache.tabs = tabs;
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTabs==>", ex);
        }
        return tabs;
    }
    //
    public static Hashtable GetTabs(string TabName)
    {
        Hashtable tabs = new Hashtable();
        try
        {
                DataSet ds = Global.getGroupnum(TabName);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable tabs_temp = new Hashtable();
                    foreach (System.Data.DataRow row in ds.Tables[0].Rows)
                    {
                        PZ_TAB tab = new PZ_TAB();
                        string fieldgroup = row["FIELDGROUP"].ToString();
                        tab.TID = row["TID"].ToString();
                        tab.TCNNAME = row["TCNNAME"].ToString();
                        tab.FIELDGROUP = fieldgroup;
                        tab.TABTYPE = row["TABTYPE"].ToString();
                        tab.TABNAME = row["TABNAME"].ToString();
                        tab.TABMAINID = row["TABMAINID"].ToString();
                        tab.TABORDER = row["TABORDER"].ToString();
                        tabs_temp.Add(fieldgroup, tab);
                    }
                    tabs = tabs_temp;
                }
            }
        catch (Exception ex)
        {
            Loger.Error("GetTabs==>", ex);
        }
        return tabs;
    }
    public static Hashtable GetFieldNames(string where, string rtID)
    {
        Hashtable dicts = new Hashtable();
        try
        {
            //dicts = DetailCache.dicts;
            if (dicts == null || dicts.Count < 1)
            {
                DataSet ds = Global.getFielddisname(where, rtID);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable dicts_temp = new Hashtable();
                    int index = 0;
                    foreach (System.Data.DataRow row in ds.Tables[0].Rows)
                    {
                        S_DICT dict = new S_DICT();
                        string fieldgroup = row["FIELDGROUP"].ToString();
                        dict.TID = row["TID"].ToString();
                        dict.TCNNAME = row["TCNNAME"].ToString();
                        dict.FIELDGROUP = fieldgroup;
                        dict.FIELDNAME = row["FIELDNAME"].ToString();
                        dict.FIELDDISNAME = row["FIELDDISNAME"].ToString();
                        dict.TABLEID = row["TABLEID"].ToString();
                        dict.COUNTNUMBER = row["COUNTNUMBER"].ToString();
                        dict.LENGTH = row["LENGTH"].ToString();
                        dict.STYLE = row["STYLE"].ToString();
                        dicts_temp.Add(index, dict);
                        index++;
                    }
                    dicts = dicts_temp;
                    //DetailCache.dicts = dicts;
                }
            }
        }
        catch (Exception ex)
        {
            Loger.Error("GetTabs==>", ex);
        }
        return dicts;
    }
    /// <summary>
    /// 驱动流程并添加流程记录
    /// </summary>
    ///<param name="odb"></param>
    /// <param name="main_id"></param>
    /// <param name="TokenName"></param>
    /// <returns></returns>
    public static bool DoProcess(string main_id, string TokenName, string cuser)
    {
        OracleDataBase odb = new OracleDataBase();
        List<string> _list = new List<string>();
        string gugid = System.Guid.NewGuid().ToString();
        string sql = string.Format("insert into tz_tokenlog(main_id,tokenname,cuser,type) values ('{0}',{1},'{2}','1')", main_id, TokenName, cuser);
        _list.Add(sql);
        sql = string.Format("update tz_main  set tokenname={0} where id='{1}'", TokenName, main_id);
        _list.Add(sql);
        bool falg = odb.SetExecuteTranSql(_list);
        odb.Close();
        return falg;
    }
    /// <summary>
    /// 流程
    /// </summary>
    /// <param name="main_id"></param>
    /// <param name="TokenName"></param>
    /// <param name="cuser"></param>
    /// <param name="Command"></param>
    /// <returns></returns>
    public static bool DoProcess(string main_id, string TokenName, string cuser, OracleCommand Command)
    {
        try
        {
            string gugid = System.Guid.NewGuid().ToString();
            string sql = string.Format("insert into tz_tokenlog(main_id,tokenname,cuser,type) values ('{0}',{1},'{2}','1')", main_id, TokenName, cuser);
            Command.CommandText = sql;
            Command.ExecuteNonQuery();
            sql = string.Format("update tz_main  set tokenname={0} where id='{1}'", TokenName, main_id);
            Command.CommandText = sql;
            return Command.ExecuteNonQuery() > 0 ? true : false;
        }
        catch (Exception)
        {
            return false;
        }
    }
   
    /// <summary>
    /// 获取受理站点
    /// </summary>
    /// <param name="uid"></param>
    /// <returns></returns>
    public static DataSet bindAcceptStation(string uid)
    {
        DataSet ds = new DataSet();
        try
        {
            OracleDataBase database = new OracleDataBase("1");
            string depid = database.GetScalarInfo("select depid from author_user where cuser = '" + uid + "'");
            string sql = "";
            if (!string.IsNullOrEmpty(depid))
            {
                //sql = string.Format("SELECT count(*) FROM author_department WHERE 1 = 1 AND exists (select 1 from words where belongcode = '032' and wordscontent = depname) START WITH id = '{0}' CONNECT BY PRIOR  id = pid", depid);
                //if (database.GetIDInsert(sql) < 1)
                //{
                    sql = string.Format("select v.RESNAME as wordscontent  from author_user_all_resource v  where USERID='{0}' and RESCATALOG='{1}'", uid, ConfigurationManager.AppSettings["ShouliAcception"]);
                //}
                //else
                //{
                //    sql = string.Format("SELECT depname as wordscontent FROM author_department WHERE 1 = 1 AND exists (select 1 from words where belongcode = '032' and wordscontent = depname) START WITH id = '{0}' CONNECT BY PRIOR  id = pid", depid);
                //}
            }
          return ds = database.GetDataSet(sql);
        }
        catch (Exception ex)
        {
            Loger.Error("bindAcceptStation=====>", ex);
            return ds;
        }
    }
    public static DataSet bindStie(string uid)
    {
        DataSet ds = new DataSet();
        try
        {
            OracleDataBase database = new OracleDataBase("1");
            string sql = "";
            sql = string.Format("select v.RESNAME as wordscontent  from author_user_all_resource v  where USERID='{0}' and RESCATALOG='{1}'", uid, ConfigurationManager.AppSettings["PaiQianNextSite"]);
            return ds = database.GetDataSet(sql);
        }
        catch (Exception ex)
        {
            Loger.Error("bindAcceptStation=====>", ex);
            return ds;
        }

    }
}
