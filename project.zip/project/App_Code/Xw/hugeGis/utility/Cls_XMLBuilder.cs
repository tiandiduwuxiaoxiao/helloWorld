﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

/// <summary>
/// XMLBuilder 的摘要说明
/// </summary>
public class XMLBuilder
{
    /// <summary>
    /// XML文档对象
    /// </summary>
    private XmlDocument xmlDoc;

    /// <summary>
    /// XML文档协议对象
    /// </summary>
    private XmlDeclaration xmlDec;
   
    public XMLBuilder(string xmlStr, string encoding)
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
        xmlDoc = new XmlDocument();
        if (xmlStr == "")
        {
            xmlDec = xmlDoc.CreateXmlDeclaration("1.0", encoding, null);
            xmlDoc.AppendChild(xmlDec);
        }
        else 
        {
            xmlDoc.LoadXml(xmlStr);
        }
	}



    /// <summary>
    /// XML字符串属性
    /// </summary>
    public string XmlText
    {
        get
        {
            //string fileName = @"D:\new.xml";
            //xmlDoc.Save(fileName);
            return xmlDoc.InnerXml;
        }
        set
        {
            xmlDoc.InnerXml = value;
        }
    }

    /// <summary>
    /// 根据节点路径获取节点对象
    /// </summary>
    /// <param name="NodeURL">节点路径</param>
    /// <returns></returns>
    public XmlNode SingleNode(string NodeURL)
    {
        return xmlDoc.SelectSingleNode(NodeURL);
    }

    /// <summary>
    /// 创建根节点
    /// </summary>
    /// <param name="RootName">根节点名称</param>
    /// <returns></returns>
    public XmlNode MakeRoot(string RootName)
    {
        XmlElement Element = xmlDoc.CreateElement("Result");
        Element.SetAttribute("Label", RootName);
        xmlDoc.AppendChild(Element);
        return Element;
    }

    /// <summary>
    /// 更新节点内容
    /// </summary>
    /// <param name="XmlPathNode">节点对象</param>
    /// <param name="Content">节点内容</param>
    public void Replace(string XmlPathNode, string Content)
    {
        xmlDoc.SelectSingleNode(XmlPathNode).InnerText = Content;
    }

    /// <summary>
    /// 删除节点
    /// </summary>
    /// <param name="Node">删除节点的名称</param>
    public void Delete(string Node)
    {
        string mainNode = Node.Substring(0, Node.LastIndexOf("/"));
        xmlDoc.SelectSingleNode(mainNode).RemoveChild(xmlDoc.SelectSingleNode(Node));
    }

    /// <summary>
    /// 插入Node节点
    /// </summary>
    /// <param name="mainNode">父节点</param>
    /// <param name="childNode">插入节点的名称</param>
    /// <param name="Element">插入节点的元素</param>
    /// <param name="Content">插入节点元素的上下文</param>
    /// <returns></returns>
    public XmlNode InsertNode(XmlNode mainNode, string childNode, string Element, string Content)
    {
        XmlElement objChildNode = xmlDoc.CreateElement(childNode);
        mainNode.AppendChild(objChildNode);
        if (Element != "")
        {
            XmlElement objElement = xmlDoc.CreateElement(Element);
            objElement.InnerText = Content;
            objChildNode.AppendChild(objElement);
        }
        return objChildNode;
    }

    /// <summary>
    /// 插入Node节点
    /// </summary>
    /// <param name="mainNode">父节点名称</param>
    /// <param name="childNode">插入节点的名称</param>
    /// <param name="Element">插入节点的元素</param>
    /// <param name="Content">插入节点元素的上下文</param>
    /// <returns></returns>
    public XmlNode InsertNode(string mainNode, string childNode, string Element, string Content)
    {
        XmlNode objRootNode = xmlDoc.SelectSingleNode(mainNode);
        return InsertNode(objRootNode, childNode, Element, Content);
    }

    /// <summary>
    /// 插入Element元素
    /// </summary>
    /// <param name="mainNode">父节点</param>
    /// <param name="Element">插入元素</param>
    /// <param name="Attrib">属性</param>
    /// <param name="AttribContent">属性值</param>
    /// <param name="Content">元素的上下文</param>
    /// <returns></returns>
    public XmlElement InsertElement(XmlNode mainNode, string Element, string Attrib, string AttribContent, string Content)
    {
        XmlElement objElement = xmlDoc.CreateElement(Element);
        objElement.SetAttribute(Attrib, AttribContent);
        objElement.InnerText = Content;
        mainNode.AppendChild(objElement);
        return objElement;
    }

    /// <summary>
    /// 插入Element元素
    /// </summary>
    /// <param name="mainNode">父节点名称</param>
    /// <param name="Element">插入元素</param>
    /// <param name="Attrib">属性</param>
    /// <param name="AttribContent">属性值</param>
    /// <param name="Content">元素的上下文</param>
    /// <returns></returns>
    public XmlElement InsertElement(string mainNode, string Element, string Attrib, string AttribContent, string Content)
    {
        XmlNode objNode = xmlDoc.SelectSingleNode(mainNode);
        return InsertElement(objNode, Element, Attrib, AttribContent, Content);
    }

    /// <summary>
    /// 插入Element元素
    /// </summary>
    /// <param name="mainNode">父节点</param>
    /// <param name="Element">插入元素</param>
    /// <param name="Content">元素的上下文</param>
    /// <returns></returns>
    public XmlElement InsertElement(XmlNode mainNode, string Element, string Content)
    {
        XmlElement objElement = xmlDoc.CreateElement(Element);
        objElement.InnerText = Content;
        mainNode.AppendChild(objElement);
        return objElement;
    }

    /// <summary>
    /// 插入Element元素
    /// </summary>
    /// <param name="mainNode">父节点名称</param>
    /// <param name="Element">插入元素</param>
    /// <param name="Content">元素的上下文</param>
    /// <returns></returns>
    public XmlElement InsertElement(string mainNode, string Element, string Content)
    {
        XmlNode objNode = xmlDoc.SelectSingleNode(mainNode);
        return InsertElement(objNode, Element, Content);
    }
   
    /// <summary>
    /// 更新Element元素的属性
    /// </summary>
    /// <param name="Element">更新元素</param>
    /// <param name="Attrib">属性</param>
    /// <param name="AttribContent">属性值</param>
    public void UpdateElement(XmlElement Element, string Attrib, string AttribContent)
    {
        Element.SetAttribute(Attrib, AttribContent);
    }

    /// <summary>
    /// 插入Element元素
    /// </summary>
    /// <param name="Element">父元素</param>
    /// <param name="childElement">插入元素</param>
    /// <param name="Attrib">属性</param>
    /// <param name="AttribContent">属性值</param>
    /// <param name="Content">元素的上下文</param>
    /// <returns></returns>
    public XmlElement InsertElement(XmlElement Element, string childElement, string Attrib, string AttribContent, string Content)
    {
        XmlElement cElement = xmlDoc.CreateElement(childElement);
        cElement.SetAttribute(Attrib, AttribContent);
        cElement.InnerText = Content;
        Element.AppendChild(cElement);
        return cElement;
    }
}
