﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

/// <summary>
/// ImageManager 的摘要说明
/// </summary>
public class ImageManager
{
    /// <summary>
    /// 图像切割
    /// </summary>
    /// <param name="url">图像文件名称</param>
    /// <param name="count">切割的个数</param>
    /// <param name="savePath">切割后图像文件保存路径</param>
    /// <param name="fileExt">切割后图像文件扩展名</param>
    /// 
	public ImageManager()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    public void cut(string url,int count, string savePath, string fileExt)
    {
        Bitmap bitmap = new Bitmap(url);

        int picHeight = bitmap.Height;
        int picWidth = bitmap.Width;

        int width = picWidth / count;
        int height = picHeight;

        Decimal MaxRow = 1;
        Decimal MaxColumn = count;
        for (decimal i = 0; i < MaxRow; i++)
        {
            for (decimal j = 0; j < MaxColumn; j++)
            {
                string filename =  j.ToString() + "." + fileExt;
                Bitmap bmp = new Bitmap(width, height);

                for (int offsetX = 0; offsetX < width; offsetX++)
                {
                    for (int offsetY = 0; offsetY < height; offsetY++)
                    {
                        if (((j * width + offsetX) < bitmap.Width) && ((i * height + offsetY) < bitmap.Height))
                        {
                            bmp.SetPixel(offsetX, offsetY, bitmap.GetPixel((int)(j * width + offsetX), (int)(i * height + offsetY)));
                        }
                    }
                }
                Graphics g = Graphics.FromImage(bmp);
                g.DrawString("科技", new Font("黑体", 20), new SolidBrush(Color.FromArgb(70, Color.WhiteSmoke)), 60, height / 2);//加水印
                ImageFormat format = ImageFormat.Png;
                switch (fileExt.ToLower())
                {
                    case "png":
                        format = ImageFormat.Png;
                        break;
                    case "bmp":
                        format = ImageFormat.Bmp;
                        break;
                    case "gif":
                        format = ImageFormat.Gif;
                        break;
                    case "jpg":
                        format = ImageFormat.Jpeg;
                        break;

                }
                string sp = savePath + "\\" + Convert.ToString(count);
                DirectoryInfo dir = new DirectoryInfo(sp);
                if (!dir.Exists)
                {
                    dir.Create();
                }

                bmp.Save(sp + "\\" + filename, format); 
            }
        }


    }
}
