﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using System.Collections;
using System.Reflection;
using System.Collections.Generic;


    public class ListControlUtil
    {
        public ListControlUtil()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public const string HEAD_SELECT = "请选择";
        public const string HEAD_NOSELECT = "0";
        public const string HEAD_SELECT_ALL = "全部";

        /// <summary>
        /// 加载时有请选择
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownWithSelect(DataTable dt, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            ddl.Items.Add(new ListItem(HEAD_SELECT, string.Empty));
            string textField = string.Empty;
            string valueField = string.Empty;
            if (dt == null) return;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textField = Convert.ToString(dt.Rows[i][dataTextField]).Trim();
                valueField = Convert.ToString(dt.Rows[i][dataValueField]).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 加载时无请选择
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownWithNoSelect(DataTable dt, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            string textField = string.Empty;
            string valueField = string.Empty;
            if (dt == null) return;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (!string.IsNullOrEmpty(dataTextField))
                    textField = Convert.ToString(dt.Rows[i][dataTextField]).Trim();
                if (!string.IsNullOrEmpty(dataValueField))
                    valueField = Convert.ToString(dt.Rows[i][dataValueField]).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 加载时无请选择
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownWithNoSelect(DataView dt, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            string textField = string.Empty;
            string valueField = string.Empty;
            if (dt == null) return;
            for (int i = 0; i < dt.Count; i++)
            {
                if (!string.IsNullOrEmpty(dataTextField))
                    textField = Convert.ToString(dt[i][dataTextField]).Trim();
                if (!string.IsNullOrEmpty(dataValueField))
                    valueField = Convert.ToString(dt[i][dataValueField]).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 加载时默认空值
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownWithEmpty(DataTable dt, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            string textField = string.Empty;
            string valueField = string.Empty;
            ddl.Items.Add(new ListItem(string.Empty, string.Empty));
            if (dt == null) return;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (!string.IsNullOrEmpty(dataTextField))
                    textField = Convert.ToString(dt.Rows[i][dataTextField]).Trim();
                if (!string.IsNullOrEmpty(dataValueField))
                    valueField = Convert.ToString(dt.Rows[i][dataValueField]).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 加载时默认全部
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownWithSelectAll(DataTable dt, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            string textField = string.Empty;
            string valueField = string.Empty;
            ddl.Items.Add(new ListItem(HEAD_SELECT_ALL, string.Empty));
            if (dt == null) return;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                textField = Convert.ToString(dt.Rows[i][dataTextField]).Trim();
                valueField = Convert.ToString(dt.Rows[i][dataValueField]).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 集合无默认值
        /// </summary>
        /// <param name="entityList"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownForEntityWithNoSelect(ICollection entityList, string dataTextField, string dataValueField, ListControl ddl)
        {
            string textField = string.Empty;
            string valueField = string.Empty;
            ddl.Items.Clear();
            if (entityList == null) return;
            foreach (object obj in entityList)
            {
                Type type = obj.GetType();
                PropertyInfo textInfo = type.GetProperty(dataTextField);
                textField = Convert.ToString(textInfo.GetValue(obj, null)).Trim();

                PropertyInfo valueInfo = type.GetProperty(dataValueField);
                valueField = Convert.ToString(valueInfo.GetValue(obj, null)).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 集合加载时默认全部
        /// </summary>
        /// <param name="entityList"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownForEntityWithSelectAll(ICollection entityList, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            string textField = string.Empty;
            string valueField = string.Empty;
            ddl.Items.Add(new ListItem(HEAD_SELECT_ALL, string.Empty));
            if (entityList == null) return;
            foreach (object obj in entityList)
            {
                Type type = obj.GetType();
                PropertyInfo textInfo = type.GetProperty(dataTextField);
                textField = Convert.ToString(textInfo.GetValue(obj, null)).Trim();

                PropertyInfo valueInfo = type.GetProperty(dataValueField);
                valueField = Convert.ToString(valueInfo.GetValue(obj, null)).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 集合加载时默认请选择
        /// </summary>
        /// <param name="entityList"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownForEntityWithSelect(ICollection entityList, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            if (entityList == null)
            {
                ddl.Items.Add(new ListItem(HEAD_SELECT, string.Empty));
                return;
            }
            string textField = string.Empty;
            string valueField = string.Empty;
            ddl.Items.Add(new ListItem(HEAD_SELECT, string.Empty));
            foreach (object obj in entityList)
            {
                Type type = obj.GetType();
                PropertyInfo textInfo = type.GetProperty(dataTextField);
                if (textInfo != null)
                    textField = Convert.ToString(textInfo.GetValue(obj, null)).Trim();

                PropertyInfo valueInfo = type.GetProperty(dataValueField);
                if (valueInfo != null)
                    valueField = Convert.ToString(valueInfo.GetValue(obj, null)).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
        }

        /// <summary>
        /// 集合加载时默认无
        /// </summary>
        /// <param name="entityList"></param>
        /// <param name="dataTextField"></param>
        /// <param name="dataValueField"></param>
        /// <param name="ddl"></param>
        public static void BindDropdownForEntityWithEmpty(ICollection entityList, string dataTextField, string dataValueField, ListControl ddl)
        {
            ddl.Items.Clear();
            if (entityList == null) return;
            string textField = string.Empty;
            string valueField = string.Empty;
            //ddl.Items.Add(new ListItem(string.Empty, string.Empty));
            foreach (object obj in entityList)
            {
                Type type = obj.GetType();
                PropertyInfo textInfo = type.GetProperty(dataTextField);
                if (textInfo != null)
                    textField = Convert.ToString(textInfo.GetValue(obj, null)).Trim();

                PropertyInfo valueInfo = type.GetProperty(dataValueField);
                if (valueInfo != null)
                    valueField = Convert.ToString(valueInfo.GetValue(obj, null)).Trim();
                ddl.Items.Add(new ListItem(textField, valueField));
            }
            ddl.Items.Insert(0, new ListItem(string.Empty, string.Empty));
            //ddl.Items.Insert(0, new ListItem(HEAD_SELECT, string.Empty));
        }

        public static void BindDropdownForEntityWithSelect(ICollection entityList, ListControl ddl)
        {
            BindDropdownForEntityWithSelect(entityList, "RefText", "RefValue", ddl);
        }

        public static void SetCtrlValue(string key, ListControl ctrl)
        {
            string sTemp = "";
            if (key == null)
                key = "";
            for (int i = 0; i < ctrl.Items.Count; i++)
            {
                sTemp = ctrl.Items[i].Value.Trim();
                if (key.Trim().Equals(sTemp))
                {
                    ctrl.SelectedValue = key;
                    return;
                }
            }
            if (ctrl.Items.Count > 0)
            {
                ClearSelectedValue(ctrl);

                if (ctrl.Items[0].Text.Equals(HEAD_SELECT, StringComparison.CurrentCultureIgnoreCase) || ctrl.Items[0].Text.Equals(HEAD_SELECT_ALL, StringComparison.CurrentCultureIgnoreCase))
                    ctrl.Items[0].Selected = true;
            }
        }

        public static void SetCtrlLikeValue(string key, ListControl ctrl)
        {
            if (string.IsNullOrEmpty(key))
                return;
            foreach (ListItem item in ctrl.Items)
            {
                if (!string.IsNullOrEmpty(item.Value) && key.StartsWith(item.Value))
                {
                    ctrl.SelectedValue = item.Value;
                    return;
                }
            }
        }

        public static void SetChecked(CheckBoxList checkList, string selval)
        {
            foreach (ListItem item in checkList.Items)
            {
                if (item.Value.Equals(selval))
                    item.Selected = true;
            }
        }

        /// <summary>
        /// 初始化CheckBoxList中哪些是选中了的
        /// <param name="checkList">CheckBoxList</param>
        /// <param name="selval">选中了的值串例如："0,1,1,2,1"</param>
        /// <param name="separator">值串中使用的分割符例如"0,1,1,2,1"中的逗号</param>
        public static string SetChecked(CheckBoxList checkList, string selval, string separator)
        {
            selval = separator + selval + separator;        //例如："0,1,1,2,1"->",0,1,1,2,1,"
            for (int i = 0; i < checkList.Items.Count; i++)
            {
                checkList.Items[i].Selected = false;
                string val = separator + checkList.Items[i].Value + separator;
                if (selval.IndexOf(val) != -1)
                {
                    checkList.Items[i].Selected = true;
                    selval = selval.Replace(val, separator);        //然后从原来的值串中删除已经选中了的
                    if (selval == separator)        //selval的最后一项也被选中的话，此时经过Replace后，只会剩下一个分隔符
                    {
                        selval += separator;        //添加一个分隔符
                    }
                }
            }
            selval = selval.Substring(1, selval.Length - 2);        //除去前后加的分割符号
            return selval;
        }

        /// <summary>
        /// 得到CheckBoxList中选中了的值
        /// </summary>
        /// <param name="checkList">CheckBoxList</param>
        /// <param name="separator">分割符号</param>
        /// <returns></returns>
        public static string GetChecked(CheckBoxList checkList, string separator)
        {
            string selval = "";
            for (int i = 0; i < checkList.Items.Count; i++)
            {
                if (checkList.Items[i].Selected)
                {
                    if (selval == "")
                        selval += checkList.Items[i].Value;
                    else
                        selval += separator + checkList.Items[i].Value;
                }
            }
            return selval;
        }

        public static void SetChecked(CheckBox checkBox, string value)
        {
            if (checkBox != null && !string.IsNullOrEmpty(value) && value == "Y")
                checkBox.Checked = true;
            else
                checkBox.Checked = false;
        }

        public static string GetChecked(CheckBox checkBox)
        {
            if (checkBox != null && checkBox.Checked)
                return "Y";
            else
                return "N";
        }

        public static TreeNode FindNode(TreeNodeCollection nodes, string value)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Value == value)
                    return node;
                if (node.ChildNodes != null)
                {
                    TreeNode returnNode = FindNode(node.ChildNodes, value);
                    if (returnNode != null)
                        return returnNode;
                }
            }
            return null;
        }

        /// <summary>
        /// 清除ListControl的选中状态
        /// </summary>
        /// <param name="ctrl"></param>
        public static void ClearSelectedValue(ListControl ctrl)
        {
            if (ctrl == null || ctrl.Items.Count == 0)
                return;

            foreach (ListItem e in ctrl.Items)
                e.Selected = false;
        }

        /// <summary>
        /// 绑定DropDownList
        /// </summary>
        /// <param name="dtSource">数据表</param>
        /// <param name="drpControlName">控件名</param>
        /// <param name="textName">显示字段名</param>
        /// <param name="valueName">实际字段值</param>
        /// <param name="bl">是否有请选择</param>
        //public static void LodaDrpTextAndValue(DataTable dtSource, DropDownList drpControlName, string textName, string valueName, bool bl)
        //{
        //    if (bl)
        //    {
        //        ListItem item = new ListItem();
        //        item.Text = Globals.PLEASESELECTTEXT;
        //        item.Value = Globals.PLEASESELECTVALUE;
        //        item.Selected = true;
        //        drpControlName.Items.Add(item);
        //    }
        //    ListItem items = null;
        //    foreach (DataRow dr in dtSource.Rows)
        //    {
        //        items = new ListItem();
        //        items.Text = dr[textName].ToString();
        //        items.Value = dr[valueName].ToString();
        //        drpControlName.Items.Add(items);
        //    }

        //}
    }

