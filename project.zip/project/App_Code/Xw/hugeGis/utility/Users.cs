﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Users 的摘要说明
/// </summary>
public class Users
{
    public string dengluming;//登录名
    public string realname;//真实姓名
    public string department;//所属部门

	public Users()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
}
