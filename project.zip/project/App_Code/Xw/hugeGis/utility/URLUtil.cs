using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;


/// <summary>
/// URL������
/// </summary>
public static class URLUtil
{
    #region Http �������ʽ

    private static string lowalpha = @"[a-z]";
    private static string hialpha = @"[A-Z]";
    private static string alpha = String.Format(@"({0}|{1})", lowalpha, hialpha);
    private static string digit = @"[0-9]";
    private static string safe = @"(\$|-|_|\.|\+)";
    private static string extra = @"(!|\*|'|\(|\)|,)";
    private static string hex = String.Format(@"({0}|A|B|C|D|E|F|a|b|c|d|e|f)", digit);
    private static string escape = String.Format(@"(%{0}{0})", hex);
    private static string unreserved = String.Format(@"({0}|{1}|{2}|{3})", alpha, digit, safe, extra);
    private static string uchar = String.Format(@"({0}|{1})", unreserved, escape);
    private static string reserved = @"(;|/|\?|:|@|&|=)";
    private static string xchar = String.Format(@"({0}|{1}|{2})", unreserved, reserved, escape);
    private static string digits = String.Format(@"({0}+)", digit);

    private static string alphadigit = String.Format(@"({0}|{1})", alpha, digit);
    private static string domainlabel = String.Format(@"({0}|{0}({0}|-)*{0})", alphadigit);
    private static string toplabel = String.Format(@"({0}|{0}({1}|-)*{1})", alpha, alphadigit);
    private static string hostname = String.Format(@"(({0}\.)*{1})", domainlabel, toplabel);
    private static string hostnumber = String.Format(@"{0}\.{0}\.{0}\.{0}", digits);
    private static string host = String.Format(@"({0}|{1})", hostname, hostnumber);
    private static string port = digits;
    private static string hostport = String.Format(@"({0}(:{1}){{0,1}})", host, port);
    private static string hsegment = String.Format(@"(({0}|;|:|@|&|=)*)", uchar);
    private static string search = String.Format(@"(({0}|;|:|@|&|=)*)", uchar);
    private static string hpath = String.Format(@"{0}(/{0})*", hsegment);
    private static string httpurl = String.Format(@"http://{0}(/{1}(\?{2}){{0,1}}){{0,1}}", hostport, hpath, search);

    #endregion

    /// <summary>
    /// URL��ַ�󸽼Ӳ���
    /// </summary>
    /// <param name="url"></param>
    /// <param name="key"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public static string AppendParameter(string url, string key, string value)
    {
        if (IsValidURL(url))
        {
            if (url.IndexOf("?") > 0)
                return string.Format("{0}&{1}={2}", url, key, value);
            else
                return string.Format("{0}?{1}={2}", url, key, value);
        }

        return "";
    }

    /// <summary>
    /// ��֤URL�Ϸ���
    /// </summary>
    /// <param name="url"></param>
    /// <returns></returns>
    public static bool IsValidURL(string url)
    {
        Regex regex = new Regex(httpurl);
        return regex.IsMatch(url);
    }

    public static string GetRootURI()
    {
        string AppPath = "";
        HttpContext HttpCurrent = HttpContext.Current;
        HttpRequest Req;
        if (HttpCurrent != null)
        {
            Req = HttpCurrent.Request;

            string UrlAuthority = Req.Url.GetLeftPart(UriPartial.Authority);
            if (Req.ApplicationPath == null || Req.ApplicationPath == "/")
                //ֱ�Ӱ�װ��   Web   վ��   
                AppPath = UrlAuthority;
            else
                //��װ��������Ŀ¼��   
                AppPath = UrlAuthority + Req.ApplicationPath;
        }
        if (!AppPath.Substring(AppPath.Length - 1, 1).Equals("/"))
        {
            AppPath = AppPath + "/";
        }
        AppPath = AppPath.Substring(0, AppPath.Length - 1);
        return AppPath;
    }

    public static string GetAbsoluteURL(string url)
    {
        return System.IO.Path.Combine(GetRootURI(), url);
    }
}