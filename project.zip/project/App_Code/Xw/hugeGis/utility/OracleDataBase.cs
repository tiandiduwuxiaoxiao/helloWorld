﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// OracleDataBase 的摘要说明
/// </summary>
public class OracleDataBase
{
    //私有变量，数据库连接
    protected OracleConnection Connection;
    protected string ConnectionString;
    public static string SessionUid = "";//保存session UID
    public OracleTransaction transtc = null;
    //是否加密处理
    bool ConStringEncrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConStringEncrypt"]);

    //构造函数
    public OracleDataBase()
    {
        Hashtable pHT = ConfigurationManager.GetSection("PropDBConn") as Hashtable;
        string pServer = pHT["Server"].ToString();
        string pUserName = pHT["UserID"].ToString();
        string pPassWord = pHT["Password"].ToString();
      
        pPassWord = Global.Decode(pPassWord);
        ConnectionString = "Data Source=" + pServer + ";Persist Security Info=True;User ID=" + pUserName + ";Password=" + pPassWord + ";";
    }

    //构造函数
    /// <summary>
    /// 0.业务数据连接  1.权限数据连接 2.多媒体数据连接  3.轨迹数据连接
    /// </summary>
    /// <param name="conntype"></param>
    public OracleDataBase(string connType)
    {
        #region
        Hashtable pHT = new Hashtable();
        if (connType == "0")
            pHT = ConfigurationManager.GetSection("PropDBConn") as Hashtable;
        else if (connType == "1")
            pHT = ConfigurationManager.GetSection("AuthDBConn") as Hashtable;
        else if (connType == "2")
            pHT = ConfigurationManager.GetSection("MediaDBConn") as Hashtable;
        else if (connType == "3")
            pHT = ConfigurationManager.GetSection("TrackDBConn") as Hashtable;
        else
            pHT = ConfigurationManager.GetSection("PropDBConn") as Hashtable;
        string pServer = pHT["Server"].ToString();
        string pUserName = pHT["UserID"].ToString();
        string pPassWord = pHT["Password"].ToString();
        

        pPassWord = Global.Decode(pPassWord);

        ConnectionString = "Data Source=" + pServer + ";Persist Security Info=True;User ID=" + pUserName + ";Password=" + pPassWord + ";";
        #endregion
    }


    //保护方法，打开数据库连接
    public void Open()
    {
        //判断数据库连接是否存在
        if (Connection == null)
        {
            //不存在，新建并打开
            Connection = new OracleConnection(ConnectionString);
            Connection.Open();
        }
        else
        {
            //存在，判断是否处于关闭状态
            if (Connection.State.Equals(ConnectionState.Closed))
                Connection.Open();    //连接处于关闭状态，重新打开
        }
    }

    //公有方法，关闭数据库连接
    public void Close()
    {
        if (Connection.State.Equals(ConnectionState.Open))
        {
            Connection.Close();     //连接处于打开状态，关闭连接
        }
    }

    /// <summary>
    /// 析构函数，释放非托管资源
    /// </summary>
    ~OracleDataBase()
    {
        try
        {
            if (Connection != null)
                Connection.Close();
        }
        catch { }
        try
        {
            Dispose();
        }
        catch { }
    }

    //公有方法，释放资源
    public void Dispose()
    {
        if (Connection != null)		// 确保连接被关闭
        {
            Connection.Dispose();
            Connection = null;
        }
    }

    //公有方法，根据Sql语句，返回是否查询到记录
    public bool GetRecord(string XSqlString)
    {
        try
        {
            Open();
            OracleDataAdapter adapter = new OracleDataAdapter(XSqlString, Connection);
            DataSet dataset = new DataSet();
            adapter.Fill(dataset);

            if (dataset.Tables[0].Rows.Count > 0)
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息GetRecordCount sql:" + XSqlString, ex);
        }
        finally
        {
            Close();
        }
        return false;
    }

    //公有方法，返回Sql语句获得的数据值
    //SqlString的格式：select count(*) from XXX where ...
    //                 select max(XXX) from YYY where ...
    public int GetRecordCount(string XSqlString)
    {
        string SCount = "0";
        try
        {
            Open();
            OracleCommand Cmd = new OracleCommand(XSqlString, Connection);
            SCount = Cmd.ExecuteScalar().ToString().Trim();
            if (SCount == "")
                SCount = "0";
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息GetRecordCount sql:" + XSqlString, ex);
        }
        finally
        {
            Close();
        }
        return Convert.ToInt32(SCount);
    }
    /// <summary>
    /// 第一行第一列
    /// </summary>
    /// <param name="XSqlString"></param>
    /// <returns></returns>
    public string GetScalarInfo(string XSqlString)
    {
        object SCount="";
        try
        {
            Open();
            OracleCommand Cmd = new OracleCommand(XSqlString, Connection);
            SCount = Cmd.ExecuteScalar();
            if (SCount == null)
                SCount = "";
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息GetScalarInfo sql:" + XSqlString, ex);
        }
        finally
        {
            Close();
        }
        return SCount.ToString();
    }

    /// <summary>
    /// 第一行第一列
    /// </summary>
    /// <param name="XSqlString"></param>
    /// <returns></returns>
    public object GetScalarobj(string XSqlString)
    {
        object SCount = "";

        Open();
        try
        {
            OracleCommand Cmd = new OracleCommand(XSqlString, Connection);
            SCount = Cmd.ExecuteScalar();
            if (SCount == null)
                SCount = "";
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息GetScalarobj sql:" + XSqlString, ex);
        }
        finally
        {
            Close();
        }
        return SCount;
    }
    //公有方法，查询数据
    //输入：
    //			查询条件sql语句
    //输出：
    //			将执行结果以DataSet返回    
    public DataSet GetDataSet(string queryString)
    {
        DataSet dataset = new DataSet();
        try
        {
            Open();
            OracleDataAdapter adapter = new OracleDataAdapter(queryString, Connection);
            adapter.Fill(dataset);
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息 GetDataSet sql:" + queryString, ex);
        }
        finally
        {
            Close();
        }
        return dataset;
    }

    //公有方法，根据Sql语句，插入记录并返回生成的ID号
    public int GetIDInsert(string XSqlString)
    {
        int Count = -1;
        try
        {
            Open();
            OracleCommand cmd = new OracleCommand(XSqlString, Connection);
            Count = Convert.ToInt32(cmd.ExecuteScalar().ToString().Trim());
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息GetIDInsert sql:" + XSqlString, ex);
        }
        finally
        {
            Close();
        }

        return Count;
    }

    //执行插入，更新，删除等操作，返回受影响的记录行数
    public int InsertOrUpdate(string sqlString)
    {
        Open();
        OracleCommand cmd = new OracleCommand(sqlString, Connection);
        int effectCount = -1;
        try
        {
            effectCount = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息InsertOrUpdate sql:" + sqlString, ex);
            throw ex;
        }
        finally
        {
            Close();
        }
        return effectCount; //返回受影响的行数
    }
    //执行插入，更新，删除等操作，返回受影响的记录行数
    public int InsertOrUpdateClob(string sqlString, string clob)
    {
        Open();
        //OracleCommand cmd = new OracleCommand(sqlString, Connection);
        int effectCount = -1;
        try
        {
            Open();
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Connection;
            cmd.CommandText = sqlString;
            OracleParameter op1 = new OracleParameter(":strclob", OracleType.Clob);
            op1.Value = clob;
            cmd.Parameters.Add(op1);
            effectCount = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息InsertOrUpdateClob sql:" + sqlString, ex);
        }
        finally
        {
            Close();
        }
        return effectCount; //返回受影响的行数


    }


    /// <summary>
    /// 执行事务
    /// </summary>
    /// <param name="sql"></param>
    /// <returns></returns>
    public bool BeginTransactionTest(string listsql, ref OracleTransaction transtc)
    {
        try
        {
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Connection;
            if (transtc == null)
            {
                transtc = Connection.BeginTransaction();
                cmd.Transaction = transtc;
            }
            else
            {
                cmd.Transaction = transtc;
            }
            cmd.CommandText = listsql;
            cmd.ExecuteNonQuery();
            return true;
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息BeginTransactionTest sql:" + listsql, ex);
            return false;
        }
        finally
        {
            Close();
        }
    }

    /// <summary>
    /// 插入数据 包括大字段类型
    /// </summary>
    public void insertBlob(String sql, Byte[] byteva)
    {
        try
        {
            Open();
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = Connection;
            cmd.CommandText = sql;
            OracleParameter op1 = new OracleParameter(":fileblob", OracleType.Blob);
            op1.Value = byteva;
            cmd.Parameters.Add(op1);
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息insertBlob sql:" + sql, ex);

        }
        finally
        {
            Close();

        }
    }


    /// <summary>
    /// 进入数据库查值
    /// </summary>
    public ArrayList getDBRecord(String sql)
    {
        try
        {
            string[] columnName;
            Open();
            System.Data.OracleClient.OracleCommand oraComm = Connection.CreateCommand();
            oraComm.CommandText = sql;

            OracleDataReader reader = oraComm.ExecuteReader();
            int fieldcount = reader.FieldCount;
            columnName = new string[fieldcount];
            String[] record = new String[fieldcount];
            ArrayList al = new ArrayList();

            while (reader.Read())
            {
                record = new String[fieldcount];
                for (int i = 0; i < fieldcount; i++)
                {
                    record[i] = reader.GetValue(i).ToString();          //列值
                    columnName[i] = reader.GetName(i);                  //当前的列名
                }
                al.Add(record);
            }
            if (!reader.IsClosed)
                reader.Close();
            return al;
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息getDBRecord sql:" + sql, ex);
        }
        finally
        {
            Close();

        }
        return new ArrayList();
    }

    /// <summary>
    /// 进入数据库查值返回哈希表只返回一行
    /// </summary>
    public Hashtable getDBHT(String sql)
    {

        try
        {
            string[] columnName;
            Open();
            System.Data.OracleClient.OracleCommand oraComm = Connection.CreateCommand();
            oraComm.CommandText = sql;

            OracleDataReader reader = oraComm.ExecuteReader();
            int fieldcount = reader.FieldCount;
            columnName = new string[fieldcount];
            String[] record = new String[fieldcount];
            Hashtable HT = new Hashtable();

            if (reader.Read())
            {
                record = new String[fieldcount];
                for (int i = 0; i < fieldcount; i++)
                {
                    HT.Remove(reader.GetName(i).ToUpper());

                    HT.Add(reader.GetName(i).ToUpper(), reader.GetValue(i).ToString());
                }

            }
            if (!reader.IsClosed)
                reader.Close();
            return HT;
        }
        catch (Exception ex)
        {
            Loger.Error("OracleDataBase异常信息getDBHT sql:" + sql, ex);
        }
        finally
        {
            Close();

        }
        return new Hashtable();
    }
    /// <summary>
    /// 更新语句记录
    /// </summary>
    /// 
    public int updateTable(string sql)
    {
        Open();
        OracleConnection conn = Connection;

        try
        {
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;
            OracleString rowid = null;
            return oraComm.ExecuteOracleNonQuery(out rowid);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.StackTrace);
            throw new Exception(ex.StackTrace);
            Loger.Error("updateTable===sql ===>" + sql, ex);
        }
        finally
        {

            conn.Close();

        }
        return 0;
    }


    /// <summary>
    /// 获得第一行第一列的值
    /// </summary>
    public int executeScalar(string sql)
    {
        // OracleDataBase o = new OracleDataBase("0");
        //OracleConnection conn = Connection; ;
        try
        {
            //conn.Open();
            Open();
            System.Data.OracleClient.OracleCommand oraComm = Connection.CreateCommand();
            oraComm.CommandText = sql;

            return Convert.ToInt32(oraComm.ExecuteScalar());


        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.StackTrace);
            Loger.Error("executeScalar==>" + sql, ex);
        }
        finally
        {

            Connection.Close();

        }
        return 0;

    }


    /// <summary>
    /// 用事务执行增删改
    /// </summary>
    /// <param name="strList">集合</param>
    /// <returns></returns>
    public bool SetExecuteTranSql(List<string> strList)
    {
        if (strList.Count == 0)
            return false;
        Open();
        OracleCommand cmd = new OracleCommand();
        int effectCount = -1;
        OracleTransaction tran = Connection.BeginTransaction();
        cmd.Connection = Connection;
        cmd.Transaction = tran;
        string sql = string.Empty;
        try
        {
            for (int i = 0; i < strList.Count; i++)
            {
                effectCount = -1;
                sql = strList[i];
                cmd.CommandText = strList[i];
                effectCount = cmd.ExecuteNonQuery();
                if (effectCount >= 1)
                    Loger.Error("用事务执行增删改成功语句SetExecuteTranSql：" + strList[i]);

            }
            tran.Commit();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();

            Loger.Error("执行SetExecuteTranSql()：" + ex.Message + "====>t-SQL：" + sql);
            return false;
        }
        finally
        {
            Close();
        }
    }

    public DataTable getPro(string procedureName, List<OracleParameter> Parameter, ref string count)
    {
        DataTable datatable = new System.Data.DataTable();
        try
        {
            OracleCommand pOracleCMD = new OracleCommand(procedureName, Connection);
            pOracleCMD.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < Parameter.Count; i++)
            {
                pOracleCMD.Parameters.Add(Parameter[i]);
            }
            OracleDataAdapter pOracleDataAdapter = new OracleDataAdapter(pOracleCMD);
            pOracleDataAdapter.Fill(datatable);
            count = Convert.ToString(pOracleCMD.Parameters[Parameter.Count - 2].Value);
        }
        catch (Exception ex)
        {
            Connection.Dispose();

        }
        finally
        {
            Connection.Close();
        }
        
        return datatable;
    }

    //执行特定存储过程（变电抢修缺陷报表）
    public  DataTable RunProcedure(string procedureName)
    {
        OracleConnection connection = Connection;
        //获取连接对象
        //OracleConnection connection = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        try
        {
            //打开连接
            //定义OracleCommand对象,设置命令类型为存储过程
            OracleCommand pOracleCMD = new OracleCommand(procedureName, connection);
            pOracleCMD.CommandType = CommandType.StoredProcedure;

            //根据存储过程的参数个数及类型生成参数对象
            OracleParameter p1 = new OracleParameter("starTime", OracleType.VarChar, 400);
            OracleParameter p2 = new OracleParameter("Endtime", OracleType.VarChar, 4000);
            OracleParameter p4 = new OracleParameter("acceptstation", OracleType.VarChar, 4000);
            OracleParameter p5 = new OracleParameter("v_orderby", OracleType.VarChar, 4000);
            OracleParameter p3 = new OracleParameter("p_cursor", OracleType.Cursor);

            //设置参数的输入输出类型,默认为输入
            p1.Direction = ParameterDirection.Input;
            p2.Direction = ParameterDirection.Input;
            p3.Direction = ParameterDirection.Output;
            p4.Direction = ParameterDirection.Input;
            p5.Direction = ParameterDirection.Input;
            //对输入参数定义初值,输出参数不必赋值.
            p1.Value = "";
            p2.Value = "";
            p4.Value = "";
            p5.Value = "";
            //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
            pOracleCMD.Parameters.Add(p1);
            pOracleCMD.Parameters.Add(p2);
            pOracleCMD.Parameters.Add(p3);
            pOracleCMD.Parameters.Add(p4);
            pOracleCMD.Parameters.Add(p5);
            //执行,把结果集填入datatable中
            OracleDataAdapter pOracleDataAdapter = new OracleDataAdapter(pOracleCMD);
            DataTable datatable = new DataTable();
            pOracleDataAdapter.Fill(datatable);
            //在执行结束后,从存储过程输出参数中取得相应的值放入引用参数中以供程序调用
            //p_msg = p3.Value.ToString();
            return datatable;
        }
        catch (OracleException e)
        {
            throw new Exception(e.Message);
        }
        finally
        {
            //关闭连接
            connection.Close();
        }
    }

    /// <summary>
    /// 执行特定的存储过程
    /// </summary>
    /// <param name="procedureName"></param>
    /// <param name="ACCEPTSTATION"></param>
    /// <param name="SENDSTATION"></param>
    /// <param name="main_id"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    public int ExeProcedure(string procedureName, string ACCEPTSTATION, string SENDSTATION, string main_id,string type)
    {
        OracleConnection connection = Connection;
        connection.Open();
        //获取连接对象
        //OracleConnection connection = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        try
        {
            //打开连接
            //定义OracleCommand对象,设置命令类型为存储过程
            OracleCommand pOracleCMD = new OracleCommand(procedureName, connection);
            pOracleCMD.CommandType = CommandType.StoredProcedure;

            //根据存储过程的参数个数及类型生成参数对象
            OracleParameter p1 = new OracleParameter("V_ACCEPTSTATION", OracleType.VarChar, 400);
            OracleParameter p2 = new OracleParameter("V_SENDSTATION", OracleType.VarChar, 4000);
            OracleParameter p3 = new OracleParameter("V_main_id", OracleType.VarChar, 4000);
            OracleParameter p4 = new OracleParameter("V_type", OracleType.VarChar, 50);
            //设置参数的输入输出类型,默认为输入
            p1.Direction = ParameterDirection.Input;
            p2.Direction = ParameterDirection.Input;
            p3.Direction = ParameterDirection.Input;
            p4.Direction = ParameterDirection.Input;
            //对输入参数定义初值,输出参数不必赋值.
            p1.Value = ACCEPTSTATION;
            p2.Value = SENDSTATION;
            p3.Value = main_id;
            p4.Value = type;
            //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
            pOracleCMD.Parameters.Add(p1);
            pOracleCMD.Parameters.Add(p2);
            pOracleCMD.Parameters.Add(p3);
            pOracleCMD.Parameters.Add(p4);
            //执行,把结果集填入datatable中
            return  pOracleCMD.ExecuteNonQuery();
        }
        catch (OracleException e)
        {
            throw new Exception(e.Message);
        }
        finally
        {
            //关闭连接
            connection.Close();
        }
    }

    /// <summary>
    /// 执行特定的存储过程
    /// </summary>
    /// <param name="procedureName"></param>
    /// <param name="list"></param>
    /// <returns></returns>
    public int ExeProcedure(string procedureName, List<OracleParameter> list)
    {
        OracleConnection connection = Connection;
        connection.Open();
        try
        {
            //打开连接
            //定义OracleCommand对象,设置命令类型为存储过程
            OracleCommand pOracleCMD = new OracleCommand(procedureName, connection);
            pOracleCMD.CommandType = CommandType.StoredProcedure;
            //按照存储过程参数顺序把参数依次加入到OracleCommand对象参数集合中
            for (int i = 0; i < list.Count; i++)
            {
                pOracleCMD.Parameters.Add(list[i]);
            }
            //执行,把结果集填入datatable中
            return pOracleCMD.ExecuteNonQuery();
        }
        catch (OracleException e)
        {
            throw new Exception(e.Message);
        }
        finally
        {
            //关闭连接
            connection.Close();
        }
    } 
}

