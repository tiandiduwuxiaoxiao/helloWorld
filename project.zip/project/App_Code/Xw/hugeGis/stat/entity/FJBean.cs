﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// FJBean 的摘要说明
/// </summary>
public class FJBean
{
	public FJBean()
	{
        
	} 
    private string id;

    public string Id
    {
        get { return id; }
        set { id = value; }
    }
    private string companyName;

    public string CompanyName
    {
        get { return companyName; }
        set { companyName = value; }
    }
    private string dateTime;

    public string DateTime
    {
        get { return dateTime; }
        set { dateTime = value; }
    }
    private string projectEn;
    public string ProjectEn
    {
        get { return projectEn; }
        set { projectEn = value; }
    }
    private string sampleAddressName;

    public string SampleAddressName
    {
        get { return sampleAddressName; }
        set { sampleAddressName = value; }
    }
    private string jcValue;

    public string JcValue
    {
        get { return jcValue; }
        set { jcValue = value; }
    }
    private string sampleingType;

    public string SampleingType
    {
        get { return sampleingType; }
        set { sampleingType = value; }
    }

    private string modelId;

    public string ModelId
    {
        get { return modelId; }
        set { modelId = value; }
    }

    private string targetId;

    public string TargetId
    {
        get { return targetId; }
        set { targetId = value; }
    }
     
    private string sampleNum;
    public string SampleNum
    {
        get { return sampleNum; }
        set { sampleNum = value; }
    }
    private string flag;

    public string Flag
    {
        get { return flag; }
        set { flag = value; }
    }
    private string rec2id;
    public string Rec2id
    {
        get { return rec2id; }
        set { rec2id = value; }
    }
}
