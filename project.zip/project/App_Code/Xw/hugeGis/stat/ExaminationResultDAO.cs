using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.OracleClient;
/// <summary>
/// ExaminationResult ��ժҪ˵��
/// </summary>
public class ExaminationResultDAO
{
    public ExaminationResultDAO()
    {
        //
        // TODO: �ڴ˴����ӹ��캯���߼�
        //
    }
    
    public ArrayList getFeiJianMathResult(string dateTime_month, string dateTime_year)
    {

        ArrayList FJBeanList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = "select jcjg.id,com.companyname,rec2.datetime,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE,rec2.id as rec2id  from HUGEGIS_JCJG jcjg join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id join TARGETTOTAL tar on jcjg.jclx=tar.id join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id  where to_char(datetime,'yyyy-mm')='" + dateTime_year + "-" + dateTime_month + "'  and  jcbg.sqshjg = '1'";
            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        FJBeanList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }

        }
        return FJBeanList;
    }

    
    /// <summary>
    /// �����ݿ�ȡ��ԭʼֵ
    /// 
    /// </summary>
    /// <param name="queryDate0">��ѯ����</param>
    /// <param name="sjdw0">��ѯ���ܼ쵥λ</param>
    /// <returns></returns>
    public ArrayList getValue(string dateTime_year, string dateTime_month, string company_)
    {
        ArrayList al = new ArrayList();
        OracleConnection conn = Global.getOracleConnection();
        conn.Open();
        try
        {
            OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = "select jcjg.id,com.companyname,rec2.datetime,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID,rec2.id as rec2id  from HUGEGIS_JCJG jcjg"
                                + " join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id"
                                + " join TARGETTOTAL tar on jcjg.jclx=tar.id"
                                + " join TESTCOMPANY com on rec2.companynameid=com.id  join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id "
                                + " where to_char(datetime,'yyyy-mm')='" + dateTime_year + "-" + dateTime_month + "' and com.id='" + company_ + "'  and jcjg.jclb<>'3' and jcbg.sqshjg = '1'";
            OracleDataReader data = oraComm.ExecuteReader();
            while (data.Read())
            { 
                FJBean fjbean = new FJBean();
                fjbean.CompanyName = Convert.ToString(data.GetValue(data.GetOrdinal("companyname")));
                fjbean.DateTime = Convert.ToString(((DateTime)data.GetValue(data.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                fjbean.JcValue =  Convert.ToString(data["jcvalue"]);
                fjbean.ProjectEn =  Convert.ToString(data["projecten"]); 
                fjbean.SampleAddressName =  Convert.ToString(data["sampleaddressname"]);
                fjbean.ModelId = Convert.ToString(data.GetValue(data.GetOrdinal("modelid")));
                fjbean.TargetId = Convert.ToString(data.GetValue(data.GetOrdinal("TID")));
                fjbean.Rec2id = Convert.ToString(data.GetValue(data.GetOrdinal("rec2id")));
                al.Add(fjbean);
            }
            if (!data.IsClosed)
                data.Close();
        }
        catch (Exception)
        {


        }
        finally
        {
            conn.Close();
        }
        return al;
    }

    public DataSet getCompanyNameAll()
    {
        DataSet ds = null;
        using (OracleConnection conn = Global.getOracleConnection())
        {
            conn.Open();
            using (OracleCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = "select ID,COMPANYNAME from TESTCOMPANY order by COMPANYNAME";
                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    ds = new DataSet();
                    da.Fill(ds);
                }
            }
            conn.Close();
        }
        return ds;
    }
    
    public ArrayList getFeiJianResultByCompany(string dateTime_month, string dateTime_year, string companyId)
    {

        ArrayList FJBeanList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = "select jcjg.id,com.companyname,rec2.datetime,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID,rec2.id as rec2id from HUGEGIS_JCJG jcjg join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id join TARGETTOTAL tar on jcjg.jclx=tar.id join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id  where to_char(datetime,'yyyy-mm')='" + dateTime_year + "-" + dateTime_month + "' and com.id='" + companyId + "'  and  jcbg.sqshjg = '1'";
            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.ModelId = Convert.ToString(odr.GetValue(odr.GetOrdinal("modelid")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("TID")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        FJBeanList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }

        }
        return FJBeanList;
    }
    

    public ArrayList getFeiJianResultByCompany_Type_Date(string dateTime_month, string dateTime_year, string companyId, string jcType, bool flag)
    {

        ArrayList FJBeanList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = string.Empty;
            if (flag == false)
            {
                sql = "select jcjg.id,com.companyname,rec2.datetime,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID,jcjg.flag,rec2.id as rec2id  from HUGEGIS_JCJG jcjg join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id join TARGETTOTAL tar on jcjg.jclx=tar.id join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id  where to_char(datetime,'yyyy-mm')='" + dateTime_year + "-" + dateTime_month + "' and rec2.jclbid ='" + jcType + "'  and  jcbg.sqshjg = '1'";
            } 
            else  
            {
                sql = "select jcjg.id,com.companyname,rec2.datetime,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID,jcjg.flag,rec2.id as rec2id from HUGEGIS_JCJG jcjg join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id join TARGETTOTAL tar on jcjg.jclx=tar.id join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id  where to_char(datetime,'yyyy-mm')='" + dateTime_year + "-" + dateTime_month + "' and com.id='" + companyId + "' and rec2.jclbid ='" + jcType + "'  and  jcbg.sqshjg = '1'";
            }

            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.ModelId = Convert.ToString(odr.GetValue(odr.GetOrdinal("modelid")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("TID")));
                        fjbean.Flag = Convert.ToString(odr.GetValue(odr.GetOrdinal("flag")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        FJBeanList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {
                Loger.Error("sql==>" + sql, ex);
            }
            finally
            {
                conn.Close();
            }

        }
        return FJBeanList;
    }


    #region �ж��ı����Ƿ���ʾ��ɫ����
    /// <summary>
    /// �ж��ı����Ƿ���ʾ��ɫ����
    /// </summary>
    /// <param name="key"></param>
    /// <param name="v_key"></param>
    /// <returns></returns>
    public string IS_RED(string moderID, string targetID, string JCvalue)
    {
        double min_value = 0;
        double max_value = 0;
        double jcvalue = 0;
        string is_red = "";
        try
        {
            using (OracleConnection conn = Global.getOracleConnection())
            {
                conn.Open();
                using (OracleCommand cmd = conn.CreateCommand())
                {

                    if (moderID != "" && JCvalue != "")
                    {
                        jcvalue = Convert.ToDouble(JCvalue); //��Ҫ�ж��Ƿ��������֡�

                        cmd.CommandText = "select MIN,MAX from YJZJL where MODELID='" + moderID + "' and TARGETID='" + targetID + "'";
                        using (OracleDataReader reader1 = cmd.ExecuteReader())
                        {
                            if (reader1.Read())
                            {
                                if (reader1["MIN"].ToString() != "")
                                {
                                    min_value = Convert.ToDouble(reader1["MIN"].ToString());
                                }
                                if (reader1["MAX"].ToString() != "")
                                {
                                    max_value = Convert.ToDouble(reader1["MAX"].ToString());
                                }
                                //�����Сֵ��Ϊ0�����жϣ�ֱ�Ӱ�ֵ�ŵ��ı�����
                                if (min_value != 0 && max_value == 0)
                                {
                                    if (jcvalue < min_value)
                                    {
                                        is_red = "style='background-color:red'";
                                    }
                                }
                                else if (min_value == 0 && max_value != 0)
                                {
                                    if (jcvalue > max_value)
                                    {
                                        is_red = "style='background-color:red'";
                                    }
                                }
                                else if (min_value != 0 && max_value != 0)
                                {
                                    if ((jcvalue < min_value) || (jcvalue > max_value))
                                    {
                                        is_red = "style='background-color:red'";
                                    }
                                }
                            }
                            if (!reader1.IsClosed)
                                reader1.Close();
                        }
                    }
                }
                conn.Close();
            }
        }
        catch (Exception ex)
        {
            is_red = "";
        }
        return is_red;
    }
    #endregion

    public DataSet getExaminatinType()
    {
        DataSet ds = null;
        using (OracleConnection conn = Global.getOracleConnection())
        {
            conn.Open();
            using (OracleCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT id,sortname FROM testsort  where testsort.sortname != '������'";
                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    ds = new DataSet();
                    da.Fill(ds);
                }
            }
            conn.Close();
        }
        return ds;
    }

    public ArrayList gesDetectionResult(string dateTime_month, string dateTime_year, string companyId)
    {
        ArrayList gesDetectionList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = "select jcjg.id,com.companyname,rec2.datetime,rec2.SAMPLENUM,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID,jcjg.flag ,rec2.id as rec2id from HUGEGIS_JCJG jcjg join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id join TARGETTOTAL tar on jcjg.jclx=tar.id join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id  where to_char(datetime,'yyyy-mm')='" + dateTime_year + "-" + dateTime_month + "' and com.id='" + companyId + "' and jcjg.jclb= '3' and  jcbg.sqshjg = '1'";
            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.SampleNum = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLENUM")));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.ModelId = Convert.ToString(odr.GetValue(odr.GetOrdinal("modelid")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("TID")));
                        fjbean.Flag = Convert.ToString(odr.GetValue(odr.GetOrdinal("flag")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        gesDetectionList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

        }
        return gesDetectionList;
    }
    public ArrayList getAllCompanyDiralExaminationResult(string _dateTime, string jcType)
    {
        ArrayList CompanyDiralList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = "select jcjg.id,com.companyname,rec2.datetime,rec2.SAMPLENUM,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID  ,jcjg.jclb,rec2.jclbid,rec2.id as rec2id from HUGEGIS_JCJG jcjg"
                          + " join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id "
                          + " join TARGETTOTAL tar on jcjg.jclx=tar.id "
                          + " join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id "
                          + " where to_char(datetime,'yyyy-mm-dd')='" + _dateTime + "' and jcjg.jclb='" + jcType + "'  and com.companyname <>'��ˮ��˾' and  jcbg.sqshjg = '1'";
            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.SampleNum = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLENUM")));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.ModelId = Convert.ToString(odr.GetValue(odr.GetOrdinal("modelid")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("TID")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        CompanyDiralList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
        }
        return CompanyDiralList;
    }



    public ArrayList getWaterQualityResult(string _dateTime, string jcfun)
    {
        ArrayList WaterQualityList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = "select jcjg.id,com.companyname,rec2.datetime,rec2.SAMPLENUM,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID  ,jcjg.jclb,rec2.jclbid,rec2.id as rec2id from HUGEGIS_JCJG jcjg"
                      + "  join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id"
                      + "  join TARGETTOTAL tar on jcjg.jclx=tar.id "
                      + "  join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id "
                      + "  where to_char(datetime,'yyyy-mm-dd')='" + _dateTime + "' and  rec2.SAMPLINGTYPE = '" + jcfun + "'and jcjg.jclb = '1'  and com.companyname <>'��ˮ��˾' ";
            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.SampleNum = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLENUM")));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.ModelId = Convert.ToString(odr.GetValue(odr.GetOrdinal("modelid")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("TID")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        WaterQualityList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
        }
        return WaterQualityList;
    }

    public ArrayList getTargettotal()
    {
        ArrayList targettotalList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            try
            {
                string sql = " SELECT id,projecten,qyldw FROM targettotal WHERE targettype = '1'";
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("projecten")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("qyldw")));
                        targettotalList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                } 
            }
            catch (Exception ex)
            { 
                throw;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            } 
        }
        return targettotalList;
    }

    public ArrayList getPaiWaterCompanyQualityResult(string _dateTime, string jcfun)
    {
        ArrayList WaterQualityList = new ArrayList();
        using (OracleConnection conn = Global.getOracleConnection())
        {
            string sql = "select jcjg.id,com.companyname,rec2.datetime,rec2.SAMPLENUM,tar.Projecten ,rec2.sampleaddressname,jcjg.jcvalue,rec2.SAMPLINGTYPE ,rec2.modelid,tar.id as TID  ,jcjg.jclb,rec2.jclbid,rec2.id as rec2id from HUGEGIS_JCJG jcjg"
                      + "  join RECORDINFO2 rec2 on jcjg.ypbh=rec2.id"
                      + "  join TARGETTOTAL tar on jcjg.jclx=tar.id "
                      + "  join TESTCOMPANY com on rec2.companynameid=com.id    join hugegis_jcjgzb jcjgzb  on jcjgzb.id = jcjg.jcjgzbid  join jcbgshjl jcbg on jcbg.jcjgzbid = jcjgzb.id "
                      + "  where to_char(datetime,'yyyy-mm-dd')='" + _dateTime + "' and  rec2.SAMPLINGTYPE = '" + jcfun + "'and jcjg.jclb = '1' and com.companyname='��ˮ��˾'  and  jcbg.sqshjg = '1'";
            try
            {
                using (OracleCommand cmd = new OracleCommand(sql, conn))
                {
                    conn.Open();
                    OracleDataReader odr = cmd.ExecuteReader();
                    while (odr.Read())
                    {
                        FJBean fjbean = new FJBean();
                        fjbean.Id = Convert.ToString(odr.GetValue(odr.GetOrdinal("id")));
                        fjbean.CompanyName = Convert.ToString(odr.GetValue(odr.GetOrdinal("companyname")));
                        fjbean.DateTime = Convert.ToString(((DateTime)odr.GetValue(odr.GetOrdinal("datetime"))).ToString("yyyy.MM.dd"));
                        fjbean.SampleNum = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLENUM")));
                        fjbean.ProjectEn = Convert.ToString(odr.GetValue(odr.GetOrdinal("Projecten")));
                        fjbean.SampleAddressName = Convert.ToString(odr.GetValue(odr.GetOrdinal("sampleaddressname")));
                        fjbean.JcValue = Convert.ToString(odr.GetValue(odr.GetOrdinal("jcvalue")));
                        fjbean.SampleingType = Convert.ToString(odr.GetValue(odr.GetOrdinal("SAMPLINGTYPE")));
                        fjbean.ModelId = Convert.ToString(odr.GetValue(odr.GetOrdinal("modelid")));
                        fjbean.TargetId = Convert.ToString(odr.GetValue(odr.GetOrdinal("TID")));
                        fjbean.Rec2id = Convert.ToString(odr.GetValue(odr.GetOrdinal("rec2id")));
                        WaterQualityList.Add(fjbean);
                    }
                    if (!odr.IsClosed)
                        odr.Close();
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
        }
        return WaterQualityList;
    }
}