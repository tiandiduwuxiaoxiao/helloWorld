﻿using System;
using System.Data;
using System.Configuration;
using System.Reflection;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using log4net;
using logertest;
using logertest.Func;

/// <summary>
/// Loger 的摘要说明
/// </summary>
public class Loger
{
    static IWebLog ilog = null;

    public static string username = "";

    public static string exceptiontype = "系统异常";
    public static string optiontype = "操作日志";
    static Loger()
    {
        //System.IO.FileInfo fin = new System.IO.FileInfo(System.Web.HttpContext.Current.Server.MapPath(".") + "/log4net.config");
        //log4net.Config.XmlConfigurator.Configure(fin);
    }

    public static void CreateLoger()
    {
        username = HttpContext.Current.Session == null
            ? "": HttpContext.Current.Session["uid"]== null?""
        : HttpContext.Current.Session["uid"].ToString();
        //if (ilog == null)
        //    ilog = WebLogManager.Exists("PenavicoxmLogger");
        if (ilog == null)
        {
            Log4netHelper.LoadADONetAppender();
            //ilog = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            ilog = WebLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }
        //if (ilog.IsDebugEnabled)
        //  ilog.Debug("test", new Exception("test1ssss22"));
    }

    ///// <summary>
    ///// 系统异常使用
    ///// </summary>
    ///// <param name="titlname">标题</param>
    ///// <param name="exceptionmsg">具体异常信息</param>
    //public static void Debug(string titlname,Exception ex) {
    //    CreateLoger();
    //    if (ilog!=null)
    //        if (ilog.IsDebugEnabled)
    //            ilog.Debug(username, exceptiontype, System.Web.HttpContext.Current.Request.UserHostAddress, System.Web.HttpContext.Current.Request.Url.ToString(), titlname, ex);
    //}

    ///// <summary>
    ///// 系统异常使用
    ///// </summary>
    ///// <param name="titlname">信息</param>
    //public static void Debug(string titlname)
    //{
    //    CreateLoger();
    //    if (ilog!=null)
    //    if (ilog.IsDebugEnabled)
    //        ilog.Debug(username, exceptiontype, System.Web.HttpContext.Current.Request.UserHostAddress, System.Web.HttpContext.Current.Request.Url.ToString(), titlname);
    //}
    /// <summary>
    /// 操作日志
    /// </summary>
    /// <param name="titlname">信息</param>
    public static void Info(string titlname)
    {
        CreateLoger();
        if (ilog != null)
            if (ilog.IsInfoEnabled)
                ilog.Info(username, optiontype, System.Web.HttpContext.Current.Request.UserHostAddress, System.Web.HttpContext.Current.Request.Url.ToString(), titlname);
    }

    /// <summary>
    /// 系统异常使用
    /// </summary>
    /// <param name="titlname">信息</param>
    public static void Error(string titlname)
    {
        CreateLoger();
        if (ilog != null)
            if (ilog.IsErrorEnabled)
            {
                //在出现未处理的错误时运行的代码
                ilog.Error(username, exceptiontype, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Url.ToString(), titlname);
            }

    }

    /// <summary>
    /// 系统异常使用
    /// </summary>
    /// <param name="titlname">信息</param>
    public static void Error(string titlname, Exception ex)
    {
        CreateLoger();
        if (ilog != null)
            if (ilog.IsErrorEnabled)
            {
                //在出现未处理的错误时运行的代码
                ilog.Error(username, exceptiontype, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Url.ToString(), ex.Message, ex);
            }

    }

}
