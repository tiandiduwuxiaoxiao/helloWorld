﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.IO;
using System.Text;

/// <summary>
/// PublicOperBean 的摘要说明
/// </summary>
public class PublicOperBean
{
    public PublicOperBean()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }


    /// <summary>
    /// al:要打印的记录集    columnname:表头显示名称 startrecordnum 可能会多出几列，可以从第二列开始
    /// </summary>
    public static void outtoExcel(ArrayList al, string[] columnname, int startrecordnum)
    {


        Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
        Microsoft.Office.Interop.Excel.Workbook workbook = excel.Application.Workbooks.Add(true);
        Microsoft.Office.Interop.Excel._Worksheet wsheet = (Microsoft.Office.Interop.Excel._Worksheet)workbook.Worksheets.Add(Type.Missing, Type.Missing, 1, Type.Missing);
        wsheet.Name = "报表";
        int i = 1;
        foreach (String[] str in al)
        {

            if (i == 1)
            {
                //object[] columnname = daobean.getTableColumnName(tableFlag);

                int k = 0;
                //foreach (DictionaryContent str2 in columnname)
                //{
                foreach (string strname in columnname)
                {
                    excel.Cells[1, k + 1] = strname;//表头初始化
                    k++;
                }
                //}

            }
            i++;
            for (int j = startrecordnum; j < str.Length; j++)
            {//进入内部循环，以增加表格列
                excel.Cells[i, j + 1] = str[j] + " ";
            }

        }
        excel.Visible = true;
        //Response.Write("<script>parent.delScreenConvert();</script>");

        //======
        string fileName = Global.getRamFileName();
        workbook.SaveCopyAs(System.Web.HttpContext.Current.Server.MapPath(".") + "\\excel\\" + fileName + ".xls");
        workbook.Close(false, null, null);
        excel.Quit();

        System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
        System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);
        System.Runtime.InteropServices.Marshal.ReleaseComObject(wsheet);
        workbook = null;
        excel = null;
        wsheet = null;

        string path = System.Web.HttpContext.Current.Server.MapPath("excel\\" + fileName + ".xls");

        System.IO.FileInfo file = new System.IO.FileInfo(path);
        System.Web.HttpContext.Current.Response.Clear();
        System.Web.HttpContext.Current.Response.Charset = "UTF-8";
        System.Web.HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
        // 添加头信息，为"文件下载/另存为"对话框指定默认文件名 
        System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + System.Web.HttpContext.Current.Server.UrlEncode(file.Name));
        // 添加头信息，指定文件大小，让浏览器能够显示下载进度 
        System.Web.HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());

        // 指定返回的是一个不能被客户端读取的流，必须被下载 
        System.Web.HttpContext.Current.Response.ContentType = "application/ms-excel";

        // 把文件流发送到客户端 
        System.Web.HttpContext.Current.Response.WriteFile(file.FullName);
        // 停止页面的执行 

        System.Web.HttpContext.Current.Response.End();
        //CheckBoxList1.Items.Clear();


    }

    /// <summary>
    /// 对列表进行排序
    /// </summary>
    public static Hashtable SortHashTable(Hashtable layerTotal)
    {
        //  Hashtable sblb = InitCache.sblb_xwbm;
        Hashtable sblb = new Hashtable();
        Hashtable returnhashtable = new Hashtable();
        string sql = "select SBLB from sblb order by AIFH asc";
        DAOBean daobean = new DAOBean();
        ArrayList al = daobean.getDBRecord(sql);

        foreach (string[] str in al)
        {
            sblb.Add(str[0], str[0]);
        }

        foreach (DictionaryEntry layerTotalde in layerTotal)
        {
            string layerTotaldesblb = layerTotalde.Key as string;
            Hashtable layerTotaldehtal = layerTotalde.Value as Hashtable;
            Hashtable alnewtabble = new Hashtable();
            int num = 0;
            foreach (string[] str1 in al)
            {
                //string sblbstr = de.Key as string;
                //  SblbBean sblbBean = de.Value as SblbBean;
                // string[] tempstr = al ;

                ArrayList alsblb = layerTotaldehtal[str1[0]] as ArrayList;
                string sblbstr = str1[0];
                if (alsblb != null)
                {
                    alnewtabble.Add(sblbstr, alsblb);
                    num++;
                    if (num >= layerTotaldehtal.Count)
                        break;


                }
            }

            // layerTotal[layerTotaldesblb] = alnewtabble;
            returnhashtable.Add(layerTotaldesblb, alnewtabble);
        }
        return returnhashtable;
    }

    /// <summary>
    /// 判断是否全部为英文字母
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static bool IsNatural(string str)
    {
        System.Text.RegularExpressions.Regex reg1 = new System.Text.RegularExpressions.Regex(@"^[A-Za-z]+$");
        return reg1.IsMatch(str);
    }

    /// <summary>
    /// 判断是否全部为数字
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static bool IsNum(string str)
    {
        System.Text.RegularExpressions.Regex reg1 = new System.Text.RegularExpressions.Regex(@"^[0-9]+$");
        return reg1.IsMatch(str);
    }

    /// <summary>
    /// al:要打印的记录集    columnname:表头显示名称 startrecordnum 可能会多出几列，可以从第二列开始
    /// 导出ＥＸＣＥＬ　另一种方法　
    /// 此方法速度也是超级快，只不过导出的格式非标准的Excel格式，默认工作表名与文件名相同
    /// </summary>
    public static void outtoExcelByWrite(ArrayList al, string[] columnname, int startrecordnum)
    {
        string fileName = Global.getRamFileName();
        string FileName = System.Web.HttpContext.Current.Server.MapPath("excel\\" + fileName + ".xls");
        //  System.Data.DataTable dt=new System.Data.DataTable();
        FileStream objFileStream;
        StreamWriter objStreamWriter;
        string strLine = "";
        objFileStream = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write);
        objStreamWriter = new StreamWriter(objFileStream, System.Text.Encoding.Unicode);

        for (int i = 0; i < columnname.Length; i++)
        {
            strLine = strLine + columnname[i] + Convert.ToChar(9);
        }
        objStreamWriter.WriteLine(strLine);
        strLine = "";


        foreach (string[] record in al)
        {
            for (int j = startrecordnum; j < record.Length; j++)
            {
                strLine = strLine + record[j].Replace("\n", "") + Convert.ToChar(9);//专业换行
            }

            objStreamWriter.WriteLine(strLine);
            strLine = "";
        }

        objStreamWriter.WriteLine(strLine);
        strLine = "";
        objStreamWriter.Close();
        objFileStream.Close();

        string path = System.Web.HttpContext.Current.Server.MapPath("excel\\" + fileName + ".xls");

        System.IO.FileInfo file = new System.IO.FileInfo(path);
        //System.Web.HttpContext.Current.Response.Clear();
        //System.Web.HttpContext.Current.Response.Charset = "UTF-8";
        //System.Web.HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
        //// 添加头信息，为"文件下载/另存为"对话框指定默认文件名 
        //System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + System.Web.HttpContext.Current.Server.UrlEncode(file.Name));
        //// 添加头信息，指定文件大小，让浏览器能够显示下载进度 
        //System.Web.HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());

        //// 指定返回的是一个不能被客户端读取的流，必须被下载 
        //System.Web.HttpContext.Current.Response.ContentType = "application/ms-excel";

        //// 把文件流发送到客户端 
        //System.Web.HttpContext.Current.Response.WriteFile(file.FullName);
        //// 停止页面的执行 

        //System.Web.HttpContext.Current.Response.End();


        System.Web.HttpContext.Current.Response.ContentType = "application/ms-excel";
        System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + System.Web.HttpContext.Current.Server.UrlEncode(file.Name));

        System.Web.HttpContext.Current.Response.TransmitFile(path);
        System.Web.HttpContext.Current.Response.Flush();
        System.Web.HttpContext.Current.Response.End();

    }

    /// <summary>
    /// 导出excel
    /// </summary>
    /// <param name="ctl"></param>
    public static void ToExcel(System.Web.UI.Control ctl)
    {

        HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + DateTime.Now.Ticks.ToString() + ".xls");

        HttpContext.Current.Response.Charset = "UTF-8";

        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;

        HttpContext.Current.Response.ContentType = "application/ms-excel";//image/JPEG;text/HTML;image/GIF;vnd.ms-excel/msword

        ctl.Page.EnableViewState = false;

        System.IO.StringWriter tw = new System.IO.StringWriter();

        System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);

        ctl.RenderControl(hw);

        HttpContext.Current.Response.Write(tw.ToString());

        HttpContext.Current.Response.End();

    }
    /// <summary>
    /// 导出数据到exel表格
    /// </summary>
    /// <param name="Filetype"></param>
    /// <param name="FileName"></param>
    /// <param name="html"></param>
    public static void Export(string Filetype, string FileName, string html)
    {
        StringWriter sw = new StringWriter();
        sw.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
        sw.WriteLine("<head><meta http-equiv=Content-Type content='text/html;'>");
        sw.WriteLine("<!--[if gte mso 9]>");
        sw.WriteLine("<xml>");
        sw.WriteLine("<x:ExcelWorkbook>");
        sw.WriteLine("<x:ExcelWorksheets>");
        sw.WriteLine("<x:ExcelWorksheet>");
        sw.WriteLine("<x:Name>Sheet1</x:Name>");
        sw.WriteLine("<x:WorksheetOptions>");
        sw.WriteLine("<x:Print>");
        sw.WriteLine("<x:ValidPrinterInfo />");
        sw.WriteLine("</x:Print>");
        sw.WriteLine("</x:WorksheetOptions>");
        sw.WriteLine("</x:ExcelWorksheet>");
        sw.WriteLine("</x:ExcelWorksheets>");
        sw.WriteLine("</x:ExcelWorkbook>");
        sw.WriteLine("</xml>");
        sw.WriteLine("<![endif]-->");
        sw.WriteLine("</head>");
        sw.WriteLine("<body>");
        sw.WriteLine(html);
        sw.WriteLine("</body>");
        sw.WriteLine("</html>");
        sw.Close();

        System.Web.HttpContext.Current.Response.Clear();
        System.Web.HttpContext.Current.Response.Buffer = true;
        System.Web.HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlDecode(FileName, Encoding.UTF8).ToString());
        System.Web.HttpContext.Current.Response.ContentType = Filetype;
        // this.EnableViewState = false;
        System.Web.HttpContext.Current.Response.Write(sw);
        System.Web.HttpContext.Current.Response.End();
    }
    /// <summary>
    /// 导出excel
    /// </summary>
    /// <param name="html">table格式的数据</param>
    public static void ToExcelByHtml(string html, string FileName)
    {
        string sheetName = HttpUtility.UrlDecode(FileName, System.Text.Encoding.UTF8).ToString();
        string FName = HttpUtility.UrlEncode(FileName, System.Text.Encoding.UTF8).ToString();
        StringWriter sw = new StringWriter();
        sw.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
        sw.WriteLine("<head>");
        sw.WriteLine("<!--[if gte mso 9]>");
        sw.WriteLine("<xml>");
        sw.WriteLine("<x:ExcelWorkbook>");
        sw.WriteLine("  <x:ExcelWorksheets>");
        sw.WriteLine("   <x:ExcelWorksheet>");
        sw.WriteLine("    <x:Name>" + sheetName + "</x:Name>");
        sw.WriteLine("    <x:WorksheetOptions>");
        sw.WriteLine("      <x:Print>");
        sw.WriteLine("       <x:ValidPrinterInfo />");
        sw.WriteLine("      </x:Print>");
        sw.WriteLine("    </x:WorksheetOptions>");
        sw.WriteLine("   </x:ExcelWorksheet>");
        sw.WriteLine("  </x:ExcelWorksheets>");
        sw.WriteLine("</x:ExcelWorkbook>");
        sw.WriteLine("</xml>");
        sw.WriteLine("<![endif]-->");
        sw.WriteLine("</head>");
        sw.WriteLine("<body>");
        sw.WriteLine(html);
        sw.WriteLine("</body>");
        sw.WriteLine("</html>");
        sw.Close();
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.Charset = "UTF-8";
        //this.EnableViewState = false;
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + FName + DateTime.Now.ToString("yyyyMMddHHmm") + ".xls");
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
        HttpContext.Current.Response.Write(sw);
        //HttpContext.Current.Response.Flush();
        HttpContext.Current.Response.End();

    }
}

