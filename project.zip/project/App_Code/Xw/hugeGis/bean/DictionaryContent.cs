﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// DictionaryContent 的摘要说明
/// </summary>
public class DictionaryContent
{
	public DictionaryContent()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public string tableName;
    public string fieldName;
    public string fieldAliasName;
    public string fieldType;
    public string fieldLength;
    public string dm;
    //排序呢
    public string colid;
    public string tableAliasName;
    public string blx;
    public string kzdm;
    public string tip;
    public string validrules;
    public string   style;
    public string   foreignField ;
    public string   fielddategroup ;
    public string   tableindex ;
    public string   mappsql;
    public string foreignfieldkey;
    public string subfield;
    public string nullable;
    public string title;
    public int titleStyle;
    public string updtaetable;
    public string listlength;
    public string fieldconfig;
    public string defaultvalue;
    public string defaulttype;
}
