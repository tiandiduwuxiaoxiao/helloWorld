﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// GridViewTextTemplate 的摘要说明 模版列
/// </summary>
public class GridViewTextTemplate : System.Web.UI.ITemplate
{

    private DataControlRowType templateType;
    private string columnName;
    private string cId;
    private string tablename;
    private string showFieldstr;
    private string typeop;

    public GridViewTextTemplate(DataControlRowType type, string colname, string controlId, string tablenamestr, string showFieldstrinit, string typeopstr)
    {

        templateType = type;
        columnName = colname;
        cId = controlId;
        tablename = tablenamestr;
        showFieldstr = showFieldstrinit;
        typeop = typeopstr;
    }

    public void InstantiateIn(System.Web.UI.Control container)
    {

        // Create the content for the different row types.
        switch (templateType)
        {
            case DataControlRowType.Header:
                // Create the controls and set id properties to put in the header
                Literal myHeadLiteral = new Literal();
                myHeadLiteral.ID = cId;
                myHeadLiteral.Text = "<B>" + columnName + "</B>";
                container.Controls.Add(myHeadLiteral);
                break;

            case DataControlRowType.DataRow:

                // Create the controls and set id properties to put in a data row
                //TextBox myTextBox = new TextBox();
                // myTextBox.ID = cId;
                HtmlAnchor HTA = new HtmlAnchor();
                //if (typeop == "lookpic")
                //{
                //    HTA.DataBinding += new EventHandler(this.TextBoxDataBinding);
                //    container.Controls.Add(HTA);
                //}
                //if (typeop == "del")
                //{
                //    HTA.DataBinding += new EventHandler(this.TextBoxDataBindingbydel);
                //    container.Controls.Add(HTA);
                //}
                //if (typeop == "update")
                //{
                //    HTA.DataBinding += new EventHandler(this.TextBoxDataBindingbyupdate);
                //    container.Controls.Add(HTA);
                //}
                if (typeop == "iszt") {
                    Label label = new Label();
                    label.DataBinding += new EventHandler(this.TextBoxDataBindingISZT);
                    container.Controls.Add(label);
                }
                break;

            default:
                // Insert code to handle unexpected values.
                break;

        }

    }


    /// <summary>
    /// 数据绑定
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TextBoxDataBinding(Object sender, EventArgs e)
    {

        //TextBox myTextBox = (TextBox)sender;
        HtmlAnchor HTA = (HtmlAnchor)sender;
        GridViewRow row = (GridViewRow)HTA.NamingContainer;
        HTA.HRef = "imageshow.ashx?fieldstr=" + showFieldstr + "&tablename=" + tablename + "&imageid=" + System.Web.HttpContext.Current.Server.UrlEncode((System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString()));
        HTA.InnerText = "查看";
        HTA.Target = "_blank";
        // myTextBox.Text = System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString();   
    }

    /// <summary>
    /// 数据绑定
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TextBoxDataBindingbydel(Object sender, EventArgs e)
    {

        //TextBox myTextBox = (TextBox)sender;
        HtmlAnchor HTA = (HtmlAnchor)sender;
        GridViewRow row = (GridViewRow)HTA.NamingContainer;
        HTA.HRef = "FangWuShuXingFubiao.aspx?GJZstr=" + System.Web.UI.DataBinder.Eval(row.DataItem, "gjz") + "&op=del&fieldstr=" + showFieldstr + "&tablename=" + tablename + "&rowid=" + System.Web.HttpContext.Current.Server.UrlEncode(System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString());
        HTA.InnerText = "删除";
        // myTextBox.Text = System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString();   
    }

    /// <summary>
    /// 数据绑定
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TextBoxDataBindingbyupdate(Object sender, EventArgs e)
    {

        //TextBox myTextBox = (TextBox)sender;
        HtmlAnchor HTA = (HtmlAnchor)sender;
        GridViewRow row = (GridViewRow)HTA.NamingContainer;
        HTA.HRef = "FangWuShuXingFubiao.aspx?GJZstr=" + System.Web.UI.DataBinder.Eval(row.DataItem, "gjz") + "&op=update&fieldstr=" + showFieldstr + "&tablename=" + tablename + "&rowid=" + System.Web.HttpContext.Current.Server.UrlEncode(System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString());
        HTA.InnerText = "修改";
        // myTextBox.Text = System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString();   
    }

    /// <summary>
    /// 数据绑定
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void TextBoxDataBindingISZT(Object sender, EventArgs e)
    {

        //TextBox myTextBox = (TextBox)sender;
        Label HTA = (Label)sender;
        GridViewRow row = (GridViewRow)HTA.NamingContainer;
       // HTA.HRef = "FangWuShuXingFubiao.aspx?GJZstr=" + System.Web.UI.DataBinder.Eval(row.DataItem, "gjz") + "&op=update&fieldstr=" + showFieldstr + "&tablename=" + tablename + "&rowid=" + System.Web.HttpContext.Current.Server.UrlEncode(System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString());
       // HTA.InnerText = "修改";
        // myTextBox.Text = System.Web.UI.DataBinder.Eval(row.DataItem, columnName).ToString(); 
        if (System.Web.UI.DataBinder.Eval(row.DataItem, "ZT").ToString() == "1")
        {
            HTA.Text = "已通过";
        }
        else if (System.Web.UI.DataBinder.Eval(row.DataItem, "ZT").ToString() == "2")
        {
            HTA.Text = "未通过";
        }
        else if (System.Web.UI.DataBinder.Eval(row.DataItem, "ZT").ToString() == "0")
        {
            HTA.Text = "未审核";
        }

    }
}
