﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model.Internal
{
    public class SearchItem
    {
        public string ItemName;
        public string ItemValue;
    }
}
