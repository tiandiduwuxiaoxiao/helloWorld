﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.OracleClient;
using System.Data.Common;

/// <summary>
/// DAOBean 的摘要说明
/// </summary>
public class DAOBean
{
    public DAOBean()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    public string[] columnName;        //记录的列名
    // String[] tableColumnName = {"",}
    /// <summary>
    /// 进入数据库查值
    /// </summary>
    public ArrayList getDBRecord(String sql)
    {
        ArrayList al = new ArrayList();
        OracleConnection conn = Global.getOracleConnection(); ;
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            //oraComm.CommandText = "select * from YW_GXLS where x is not null and y is not null";  
            oraComm.CommandText = sql;
            DbCommand DC = (DbCommand)oraComm;
            DC.CommandTimeout = 100;

            OracleDataReader reader = oraComm.ExecuteReader();

            //  DataTable dt = reader.GetSchemaTable();             //当前记录的信息


            int fieldcount = reader.FieldCount;
            columnName = new string[fieldcount];
            String[] record = new String[fieldcount];
         

            while (reader.Read())
            {
                record = new String[fieldcount];
                for (int i = 0; i < fieldcount; i++)
                {
                    record[i] = reader.GetValue(i).ToString();          //列值
                    columnName[i] = reader.GetName(i);                  //当前的列名
                    // string f = reader.GetName(i);
                }
                al.Add(record);
            }
            if (!reader.IsClosed)
                reader.Close();
        }
        catch (Exception ex)
        {
            Loger.Error("getDBRecord==>" + sql, ex);
           
        }
        finally
        {
            conn.Close();
        }
        return al;
    }

    /// <summary>
    /// 列名
    /// </summary>
    public String[] getColumndName()
    {
        return columnName;
    }

    /// <summary>
    /// 列中文名 "YW_BG";    //表名
    /// </summary>
    public String[] getTableColumnName()
    {

        String tableStr = "YW_BG";    //表名
        Hashtable xwbm_sjzd = InitCache.xwbm_sjzd;
        ArrayList al1 = (ArrayList)xwbm_sjzd[tableStr];
        String[] tableColumnName = new String[al1.Count];

        if (al1 != null)
        {
            for (int i = 0; i < al1.Count; i++)
            {
                DictionaryContent dc = (DictionaryContent)al1[i];
                tableColumnName[i] = dc.fieldAliasName;
                //    li.Value = dc.fieldName;
            }
        }
        return tableColumnName;

    }


    /// <summary>
    /// 更新语句记录
    /// </summary>
    /// 
    public static int updateTable(string sql)
    {
        OracleConnection conn = Global.getOracleConnection();
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;
            // oraComm.Transaction.Commit();
            OracleString rowid = null;
            //  oraComm.ExecuteNonQuery(); 
            return oraComm.ExecuteOracleNonQuery(out rowid);

            // return 1;
        }
        catch (Exception ex)
        {
            Loger.Error("updateTable===sql ===>" + sql, ex);
        }
        finally
        {
            conn.Close();
        }
        return 0;
    }

    /// <summary>
    /// 更新语句记录，并且得到rowid
    /// </summary>
    /// 
    public static int updateTable(string sql, out string rowid)
    {
        OracleConnection conn = Global.getOracleConnection();
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;
            OracleString rowidstr = null;
            int num = oraComm.ExecuteOracleNonQuery(out rowidstr);
            rowid = rowidstr.Value;
            return num;

        }
        catch (Exception ex)
        {
            Loger.Error("updateTable()==>" + sql, ex);
        }
        finally
        {
            conn.Close();
        }
        rowid = "-1";
        return -1;
    }

    /// 
    /// 
    /// <summary>
    /// 列中文名 与英文名
    /// </summary>
    public object[] getTableColumnName(string tableStr)
    {
        object[] tableColumnName = new object[1];
        if (tableStr != "" && tableStr != null)
        {
            // String tableStr = "YW_BG";    //表名
            Hashtable xwbm_sjzd = InitCache.xwbm_sjzd;
            ArrayList al1 = (ArrayList)xwbm_sjzd[tableStr.ToUpper()];

            tableColumnName = new object[al1.Count];
            // String[] columnName = new String[2]; 

            if (al1 != null)
            {
                for (int i = 0; i < al1.Count; i++)
                {
                    DictionaryContent dc = (DictionaryContent)al1[i];
                    //  columnName[0] = dc.fieldAliasName;
                    //  columnName[1] = dc.fieldName;
                    tableColumnName[i] = dc;
                }
            }
        }
        return tableColumnName;

    }

    /// <summary>
    /// 获得第一行第一列的值
    /// </summary>
    public object executeScalar(string sql)
    {

        OracleConnection conn = Global.getOracleConnection(); ;
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;
            return oraComm.ExecuteScalar();
        }
        catch (Exception ex)
        {
            Loger.Error("executeScalar()==>" + sql, ex);
        }
        finally
        {
            conn.Close();
        }
        return -1;

    }


    /// 
    /// <summary>
    ///获得IP
    /// </summary>
    public static string GetClientIP(HttpRequest request)
    {
        string result = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (null == result || result == String.Empty)
        {
            result = request.ServerVariables["REMOTE_ADDR"];
        }
        if (null == result || result == String.Empty)
        {
            result = request.UserHostAddress;
        }
        return result;
    }


    /// 
    /// 
    /// <summary>
    /// 根据表名与英文列名 得到中文列名
    /// </summary>
    public string getTableCurrenChineseColumnName(string tableStr, string fieldname)
    {

        if (tableStr != "" && tableStr != null)
        {
            Hashtable xwbm_sjzd = InitCache.xwbm_sjzd;
            ArrayList al1 = (ArrayList)xwbm_sjzd[tableStr];

            if (al1 != null)
            {
                for (int i = 0; i < al1.Count; i++)
                {
                    DictionaryContent dc = (DictionaryContent)al1[i];
                    if (dc.fieldName == fieldname)
                        return dc.fieldAliasName;
                }
            }
        }
        return null;

    }



    /// <summary>
    /// 读取大字段类型
    /// </summary>
    public byte[] getBigByteDBRecord(String sql)
    {

        OracleConnection conn = Global.getOracleConnection(); ;
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;

            OracleDataReader reader = oraComm.ExecuteReader();

            if (reader.Read())
            {
                return (byte[])reader[0];
            } 
            if (!reader.IsClosed)
                reader.Close();
        }
        catch(Exception ex)
        {
            Loger.Error("getBigByteDBRecord()==>" + sql, ex);
        }
        finally
        {
            conn.Close();

        }
        return null;
    }



    /// <summary>
    /// 插入数据 包括大字段类型
    /// </summary>
    public void insertLongRaw(String sql, Byte[] byteva)
    {

        OracleConnection conn = Global.getOracleConnection(); ;
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;
            OracleParameter op1 = new OracleParameter(":picva", OracleType.LongRaw);
            op1.Value = byteva;
            oraComm.Parameters.Add(op1);

            oraComm.ExecuteNonQuery();


        }
        catch
        {
            Console.WriteLine();
        }
        finally
        {
            conn.Close();

        }

    }

    /// <summary>
    /// 插入数据 包括大字段类型
    /// </summary>
    public void insertBlob(String sql, Byte[] byteva)
    {

        OracleConnection conn = Global.getOracleConnection(); ;
        try
        {
            conn.Open();
            System.Data.OracleClient.OracleCommand oraComm = conn.CreateCommand();
            oraComm.CommandText = sql;
            OracleParameter op1 = new OracleParameter(":picva", OracleType.Blob);
            op1.Value = byteva;
            oraComm.Parameters.Add(op1);

            oraComm.ExecuteNonQuery();


        }
        catch
        {
            Console.WriteLine();
        }
        finally
        {
            conn.Close();

        }

    }


    /// <summary>
    /// 根据设备类别得到表名
    /// </summary>
    public static string SBLBConvertToXWBM(string SBLB)
    {
        string tableName = "";
        if (SBLB != "" && SBLB != null)
        {
            // String tableStr = "YW_BG";    //表名
            Hashtable sblb_xwbmHS = InitCache.sblb_xwbm;
            // SblbBean sblbBean = (SblbBean)sblb_xwbmHS[SBLB.ToUpper()];

            //  tableName=sblbBean.xwbm;

        }
        return tableName;

    }

   
}

