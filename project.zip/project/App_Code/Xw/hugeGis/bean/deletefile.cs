﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

/// <summary>
/// deletefile 的摘要说明
/// </summary>
public class deletefile
{
	public deletefile()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    /// <summary>
    /// dirPath 文件路径
    /// </summary>
    public static void deleteFile(string dirPath) 
    {

        if (Directory.Exists(dirPath))
        {
            DirectoryInfo dir = new DirectoryInfo(dirPath);
            if (dir.GetFiles().Length >= 20)
            {
                foreach (FileInfo f in dir.GetFiles())
                {
                    if(!f.IsReadOnly)
                        f.Delete();
                }
            }
        }
    }



    /// <summary>
    /// dirPath 文件路径
    /// 
    /// </summary>
    public static void deleteFile(string dirPath,int filenum)
    {

        if (Directory.Exists(dirPath))
        {
            DirectoryInfo dir = new DirectoryInfo(dirPath);
            if (dir.GetFiles().Length >= filenum)
            {
                foreach (FileInfo f in dir.GetFiles())
                {
                    if (!f.IsReadOnly)
                        f.Delete();
                }
            }
        }
    } 
 }
