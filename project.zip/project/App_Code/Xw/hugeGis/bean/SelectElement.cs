﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// SelectElement 的摘要说明
/// </summary>
public struct SelectElement
{
	public SelectElement(Object sblb,Object gjz,Object shape,Object display)
	{
        this.sblb = sblb;
        this.gjz = gjz;
        this.shape = shape;
        this.display = display;
	}
    public Object sblb;
    public Object gjz;
    public Object shape;
    public Object display;
}

