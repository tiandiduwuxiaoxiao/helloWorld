﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Text;

/// <summary>
/// PDA 的摘要说明
/// </summary>
public class PDA
{
	public PDA()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    //得到PDA列表
    public string initPdaList(string orderbystr)
    {
        DAOBean daoBean = new DAOBean();

        //当前用户的PDA列表
        ArrayList pdaList = AuthorGlobal.getResourceWithUserid(System.Web.HttpContext.Current.Session["uid"].ToString());
        string pdaWhere = "";
        for (int i = 0; i < pdaList.Count; i++)
        {
            string temp = "'" + Convert.ToString(pdaList[i]) + "'";
            pdaWhere = pdaWhere == "" ? temp : pdaWhere + "," + temp;
        }
        pdaWhere = (pdaWhere == "") ? "'-1'" : pdaWhere;

        string sql = "select PDAID,NUM,x,y,loctime,relationobj,EQUIPNAMEPHONENUM from pdalist";
        int pdaonlinenum = int.Parse(publicbean.pdakeyValue["ONLINENUM"].ToString());
        if (pdaWhere != "")
        {
            sql += " where PDAID in(" + pdaWhere + ")";
        }

        if (orderbystr == "orderrenwu")
            sql += " order by NUM desc,loctime desc";
        else if (orderbystr == "orderPDA")
        {
            sql += " order by PDAID,loctime desc";
        }
        else if (orderbystr == "orderdate")
        {
            sql += " order by loctime,loctime desc";
        }
        else if (orderbystr == "")
        {
            sql += " order by loctime desc";
        }
        else if (orderbystr == "ordershuliangyuanze")//数量原则,30分钟内的
        {
            sql += " and loctime>sysdate-(pdaonlinenum/24.0f/60) order by NUM desc,loctime desc";
        }
        ArrayList al = daoBean.getDBRecord(sql);
        StringBuilder sbstr = new StringBuilder();
       
        if (al.Count > 0)
        {

            sbstr.Append("-1");
            foreach (string[] str in al)
            {
                if (str[4] != "" && DateTime.Parse(str[4]).AddMinutes(pdaonlinenum).CompareTo(DateTime.Now) > 0)
                {
                    sbstr.Append("," + str[0] + ":" + str[1] + ":" + str[2] + ":" + str[3] + ":在线" + ":" + str[5] + ":" + str[6]);
                }
                else
                {
                    sbstr.Append("," + str[0] + ":" + str[1] + ":" + str[2] + ":" + str[3] + ":离线" + ":" + str[5] + ":" + str[6]);
                }
            }

        }
        return sbstr.ToString();

    }

    /// <summary>
    /// 派遣PDA
    /// </summary>
    /// <param name="eventArgument"></param>
    public int paiqianPDA(string eventArgument,string mainid,string pdaname)
    {
            string[] split = eventArgument.Split('|');
            if (split.Length > 5)
            {
                string uid = (string)System.Web.HttpContext.Current.Session["uid"];
                string updatesql = "update tz_main set PDAID='" + split[1] + "',ISDISPATCH='1',ZTSH='0',ZT='0',SENDTIME=sysdate,SENDPEOPLE='"+uid+"'";
                if (split[2] != "") updatesql += " ,COMETIME_PLAN=to_date('" + split[2] + "','yyyy-mm-dd hh24:mi:ss')";
                if (split[3] != "") updatesql += " ,SOLVETIME_PLAN=to_date('" + split[3] + "','yyyy-mm-dd hh24:mi:ss')";
                updatesql += " ,SENDREMARK='" + split[4] + "',EXECUTIVEPEOPLE='" + pdaname + "'";
                if (split[5] != "")
                {
                    updatesql += " ,TARGETX=" + split[5];
                }
                if (split[6] != "")
                {
                    updatesql += " ,TARGETY=" + split[6];
                }
                updatesql += " where id='" + mainid + "' AND (ISDISPATCH='0')";
               return DAOBean.updateTable(updatesql);
               
            }
            return 0;
    }

    /// <summary>
    /// 根据反映类别得到反映内容语句
    /// </summary>
    /// <returns></returns>
    public static string getFYNRByFYLBM(string fylbstr ) {

        Wordinfo words = new Wordinfo();
        return words.getFYNRByFYLBM(fylbstr);
        //string sql = "";
        //string canshustr = fylbstr;
        //if (canshustr == "用水问题")
        //{
        //    sql = "select * from words where belongcode='004003' ";
        //}
        //else if (canshustr == "水质问题")
        //{
        //    sql = "select * from words where belongcode='004004' ";
        //}
        //else if (canshustr == "水管设备")
        //{
        //    sql = "select * from words where belongcode='004005' ";
        //}
        //else if (canshustr == "套室表")
        //{
        //    sql = "select * from words where belongcode='004006' ";
        //}
        //else if (canshustr == "表务问题")
        //{
        //    sql = "select * from words where belongcode='004007' ";
        //}
        //else if (canshustr == "物业问题")
        //{
        //    sql = "select * from words where belongcode='004000' ";
        //}
        //else if (canshustr == "二次供水")
        //{
        //    sql = "select * from words where belongcode='004002' ";
        //}
        //else if (canshustr == "水管问题")
        //{
        //    sql = "select * from words where belongcode='004011' ";
        //}
        //else
        //{
        //    sql = "select * from words where 1=2 ";
        //}
        //return sql;
    }

    public static void PDATransferTo(string PDACTYPE, string mainid)
    {
        string TURL = "";
        //0.初始状态 1.套室表 2.水管设备
        if (PDACTYPE == "1")
        {
            TURL = "xiangxixinxixiaoxiu.aspx";
        }
        else if (PDACTYPE == "2")
        {
            TURL = "xiangxixinxidaxiu.aspx";
        }
        if (TURL != "")
            System.Web.HttpContext.Current.Response.Redirect(TURL + "?istransfer=optt&recordid=" + mainid);
    }


}
