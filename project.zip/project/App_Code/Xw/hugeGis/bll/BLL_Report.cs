﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data;
using hugegis.DBUtility;
using System.Data.OracleClient;
using System.IO;
using Maticsoft.DBUtility;

public class BLL_Report
{
    private static OracleDataBase odb = new OracleDataBase();
    /// <summary>
    /// 报表相关绑定部门下拉框
    /// </summary>
    /// <param name="drop"></param>
    public static void BindDropDownList(DropDownList drop)
    {
        drop.Items.Clear();
        string psql = "select id,depname from author_department";
        DataSet ds = DbHelperOra.Query(psql);
        drop.DataSource = ds;
        drop.DataValueField = "id";
        drop.DataTextField = "depname";
        drop.DataBind();

        drop.Items.Insert(0, new ListItem("请选择"));
    }

    /// <summary>
    /// 报表相关绑定部门下拉框（抢修）
    /// </summary>
    /// <param name="drop"></param>
    public static void BindAcceptstationDropDownList(DropDownList drop)
    {
        drop.Items.Clear();
        //  string psql = "select id,depname from author_department";
        string psql = "select stationid as id, stationname as depname from stationinfo t order by to_number(stationid)";
        DataSet ds = DbHelperOra.Query(psql);
        drop.DataSource = ds;
        drop.DataValueField = "id";
        drop.DataTextField = "depname";
        drop.DataBind();

        drop.Items.Insert(0, new ListItem("请选择"));
    }

    /// <summary>
    /// 获取人员登录信息数据
    /// </summary>
    /// <returns></returns>
    public static string GetLoginingData(string sql)
    {
        StringBuilder builder = new StringBuilder();

        int num = 0;
        try
        {
            using (OracleConnection con = new OracleConnection(Decrypt.PropDBConn))
            {
                con.Open();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql.ToString();
                    OracleDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        num++;
                        //style="font-family: 宋体; font-size: 11px; font-weight: normal; text-align: left;"
                        string dataRow = string.Format("<tr><td style='{6}' >{0}</td><td style='{6}'colspan='2' >{1}</td><td style='{6}'colspan='2' >{2}</td><td style='{6}' >{5}</td></tr>", num, dr["userName"].ToString(), dr["depName"].ToString(),
                            dr["logintime"].ToString(), dr["logouttime"].ToString(), dr["DHour"].ToString(), "font-family: 宋体;   font-weight: normal; text-align: center;");
                        builder.Append(dataRow);
                    }
                    cmd.Clone();
                }
                con.Close();

                // html += "<tr><td colspan='5'>主管：</td><td colspan='10'>制表人：</td><td colspan='5'>制表日期：</td></tr>";
                //  html += "</table>";
            }
        }
        catch (Exception ex)
        {
            Loger.Error("BLL_Report=====>异常：", ex);

        }
        return builder.ToString();
    }

    public static string GetPdaInfoData(string sql, DataTable dt)
    {
        StringBuilder builder = new StringBuilder();

        int num = 0;
        try
        {
            int rcrwCount = 0;
            int tfrwCount = 0;
            int countNumber = 0;
            using (OracleConnection con = new OracleConnection(Decrypt.PropDBConn))
            {
                con.Open();
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql.ToString();
                    OracleDataReader dr = cmd.ExecuteReader();

                    double zxxs = 0; int rcrws = 0, tfrwzs = 0, sjsbs = 0, gdzs = 0, jsxds = 0, csxds = 0, yqgds = 0, tdgds = 0, clzgds = 0;
                    while (dr.Read())
                    {
                        countNumber = 0;
                        rcrwCount = 0;
                        tfrwCount = 0;
                        foreach (DataRow drs in dt.Rows)
                        {
                            if (drs["cuserName"].ToString() == dr["cuserName"].ToString() && drs["acceptstation"].ToString() == dr["acceptstation"].ToString())
                            {
                                countNumber = ConvertUtil.ToInt32(drs["numbers"]);
                                break;
                            }
                        }
                        num++;


                        if (dr["ACCEPTSTATION"].ToString() == "管网巡线队")
                        {
                            rcrwCount = ConvertUtil.ToInt32(dr["xunxianrichangcount"]);
                            tfrwCount = ConvertUtil.ToInt32(dr["xunxiantufacount"]);
                        }
                        else if (dr["ACCEPTSTATION"].ToString() == "检漏公司")
                        {
                            rcrwCount = ConvertUtil.ToInt32(dr["jianlourichangcount"]);
                            tfrwCount = ConvertUtil.ToInt32(dr["jianloutufacount"]);
                        }

                        string dataRow = string.Empty;
                        if (dr["ACCEPTSTATION"].ToString() == "检漏公司" || dr["ACCEPTSTATION"].ToString() == "管网巡线队")
                        {
                            //cursor:pointer;text-decoration:underline;color:blue;
                            dataRow = string.Format(@"<tr><td style='text-align: center;' >{0}</td><td style='text-align: center;' >{1}</td><td style='text-align: center;' ><span onclick=goDetail('{2}') style=''>{2}</span></td>
                            <td style='text-align: center;' >{3}</td><td style='text-align: center;' >{4}</td><td style='text-align: center;' >{5}</td>
<td style='text-align: center;' >{6}</td><td style='text-align: center;' >{7}</td>
<td style='text-align: center;' >{8}</td><td style='text-align: center;' >{9}</td>
                            <td style='text-align: center;' >{10}</td><td style='text-align: center;' >{11}</td><td style='text-align: center;' >{12}</td></tr>"
                          , num, dr["acceptstation"].ToString(), dr["cusername"].ToString(),
                          dr["HDate"].ToString(), rcrwCount, tfrwCount
                          , countNumber, "0", "0"
                          , "0", "0",
                         "0", "0");//, "font-family: 宋体;font-weight: normal; text-align: center;"
                            zxxs += ConvertUtil.ToDouble(dr["HDate"]);
                            rcrws += rcrwCount;
                            tfrwzs += tfrwCount;
                            sjsbs += countNumber;
                        }
                        else
                        {   //cursor:pointer;text-decoration:underline;color:blue;
                            dataRow = string.Format(@"<tr>
<td style='text-align: center;' >{0}</td>
<td style='text-align: center;' >{1}</td>
<td style='text-align: center;' ><span onclick=goDetail('{2}') style=''>{2}</span></td>
<td style='text-align: center;' >{3}</td>
<td style='text-align: center;' >{4}</td>
<td style='text-align: center;' >{5}</td>
<td style='text-align: center;' >{6}</td>
<td style='text-align: center;' >{7}</td>
<td style='text-align: center;' >{8}</td>
</tr>"
                         , num, dr["acceptstation"].ToString(),
                         dr["cusername"].ToString(),
                                // dr["HDate"].ToString(),
                         dr["totalNumber"].ToString(),
                         dr["JiShiNumber"].ToString(),
                         dr["BuJiShiNumber"].ToString(),
                         dr["YanQiNumber"].ToString(),
                         dr["TuiDanNumber"].ToString(),
                         dr["ChuLiZhongNumber"].ToString());

                            zxxs += ConvertUtil.ToDouble(dr["HDate"]);
                            gdzs += ConvertUtil.ToInt32(dr["totalNumber"]);
                            jsxds += ConvertUtil.ToInt32(dr["JiShiNumber"]);
                            csxds += ConvertUtil.ToInt32(dr["BuJiShiNumber"]);
                            yqgds += ConvertUtil.ToInt32(dr["YanQiNumber"]);
                            tdgds += ConvertUtil.ToInt32(dr["TuiDanNumber"]);
                            clzgds += ConvertUtil.ToInt32(dr["ChuLiZhongNumber"]);
                        }
                        builder.Append(dataRow);


                    }
                    string countRows = string.Format(@"<tr style='text-align: center;'><td colspan='3' style='text-align:right;'>总数</td>
                            <td>{0}</td> <td>{1}</td> <td>{2}</td> <td>{3}</td> <td>{4}</td> <td>{5}</td>
                             </tr>",
                                gdzs, jsxds, csxds, yqgds, tdgds, clzgds);
                    builder.Append(countRows);
                    cmd.Clone();
                }
                con.Close();

                // html += "<tr><td colspan='5'>主管：</td><td colspan='10'>制表人：</td><td colspan='5'>制表日期：</td></tr>";
                //  html += "</table>";
            }
        }
        catch (Exception ex)
        {
            Loger.Error("BLL_Report=====>异常：", ex);

        }
        return builder.ToString();
    }

    public static string GetBsInfoData(string sql)
    {
        StringBuilder builder = new StringBuilder();

        int num = 0;
        try
        {
            using (OracleConnection con = new OracleConnection(Decrypt.PropDBConn))
            {
                con.Open();
                int num1 = 0, num2 = 0, num3 = 0, num4 = 0, num5 = 0, num6 = 0, num7 = 0, num8 = 0, num9 = 0, num10 = 0,
                      num11 = 0, num12 = 0, num13 = 0, num14 = 0, num15 = 0, num16 = 0, num17 = 0, num18 = 0, num19 = 0,
                      num20 = 0, num21 = 0, num22 = 0, num23 = 0, num24 = 0, num25 = 0;
                using (OracleCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = sql.ToString();
                    OracleDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        num++;
                        //style="font-family: 宋体; font-size: 11px; font-weight: normal; text-align: left;"
                        //string dataRow = string.Format("<tr><td style='{6}'>{0}</td><td style='{6}' >{1}</td><td style='{6}' >{2}</td><td style='{6}' >{3}</td><td style='{6}' >{4}</td><td style='{6}' >{5}</td><td style='{6}' >{7}</td><td style='{6}' >{8}</td><td style='{6}' >{9}</td><td style='{6}' >{10}</td></tr>", 
                        //    num, dr["acceptstation"].ToString(), dr["cusername"].ToString(),
                        //    dr["HDate"].ToString(), dr["totalNumber"].ToString(), dr["JiShiNumber"].ToString(), "font-family: 宋体;   font-weight: normal; text-align: center;", dr["BuJiShiNumber"].ToString(), dr["YanQiNumber"].ToString(),
                        //    dr["TuiDanNumber"].ToString(), dr["ChuLiZhongNumber"].ToString());
                        string dataRow = string.Format(@"<tr> 
                            <td style='{0}'>{1}</td><td style='{0}'>{2}</td><td style='{0}'>{3}</td><td style='{0}'>{4}</td><td style='{0}'>{5}</td><td style='{0}'>{6}</td><td style='{0}'>{7}</td>
                            <td style='{0}'>{8}</td><td style='{0}'>{9}</td><td style='{0}'>{10}</td><td style='{0}'>{11}</td><td style='{0}'>{12}</td><td style='{0}'>{13}</td><td style='{0}'>{14}</td>
                            <td style='{0}'>{15}</td><td style='{0}'>{16}</td><td style='{0}'>{17}</td><td style='{0}'>{18}</td><td style='{0}'>{19}</td><td style='{0}'>{20}</td><td style='{0}'>{21}</td>
                            <td style='{0}'>{22}</td><td style='{0}'>{23}</td><td style='{0}'>{24}</td><td style='{0}'>{25}</td><td style='{0}'>{26}</td><td style='{0}'>{27}</td>  </tr>", "font-family: 宋体;   font-weight: normal; text-align: center;"
                    , num, dr["acceptstation"].ToString(), dr["totalPaiQNum"].ToString(), dr["WeiPaiQNum"].ToString(), dr["YiPaiQNum"].ToString()
                    , dr["YiPaiQNum0_5"].ToString(), dr["YiPaiQNum_1"].ToString(), dr["YiPaiQNum_2"].ToString(), dr["YiPaiQNum_4"].ToString()
                    , dr["YiPaiQNum_8"].ToString(), dr["YiPaiQNum_24"].ToString(), dr["YiPaiQNum_25"].ToString(), dr["TotalXiaoDnum"].ToString()
                    , dr["WeiShenXiaoDnum"].ToString(), dr["YiShenXiaoDnum"].ToString(), dr["YiShenXiaoDnum_24"].ToString(), dr["YiShenXiaoDnum_25"].ToString()
                    , dr["TotalTuiDnum"].ToString(), dr["WeiShenTuiDnum"].ToString(), dr["YiShenTuiDnum"].ToString(), dr["YiShenTuiDnum_24"].ToString(),
                     dr["YiShenTuiDnum_25"].ToString(), dr["TotalYanQnum"].ToString(), dr["WeiShenYanQnum"].ToString(), dr["YiShenYanQnum"].ToString(),
                     dr["YiShenYanQnum_24"].ToString(), dr["YiShenYanQnum_25"].ToString());
                        builder.Append(dataRow);
                        num1 += ConvertUtil.ToInt32(dr["totalPaiQNum"]); num2 += ConvertUtil.ToInt32(dr["WeiPaiQNum"]); num3 += ConvertUtil.ToInt32(dr["YiPaiQNum"]);
                        num4 += ConvertUtil.ToInt32(dr["YiPaiQNum0_5"]); num5 += ConvertUtil.ToInt32(dr["YiPaiQNum_1"]); num6 += ConvertUtil.ToInt32(dr["YiPaiQNum_2"]);
                        num7 += ConvertUtil.ToInt32(dr["YiPaiQNum_4"]); num8 += ConvertUtil.ToInt32(dr["YiPaiQNum_8"]); num9 += ConvertUtil.ToInt32(dr["YiPaiQNum_24"]);
                        num10 += ConvertUtil.ToInt32(dr["YiPaiQNum_25"]); num11 += ConvertUtil.ToInt32(dr["TotalXiaoDnum"]); num12 += ConvertUtil.ToInt32(dr["WeiShenXiaoDnum"]);
                        num13 += ConvertUtil.ToInt32(dr["YiShenXiaoDnum"]); num14 += ConvertUtil.ToInt32(dr["YiShenXiaoDnum_24"]); num15 += ConvertUtil.ToInt32(dr["YiShenXiaoDnum_25"]);
                        num16 += ConvertUtil.ToInt32(dr["TotalTuiDnum"]); num17 += ConvertUtil.ToInt32(dr["WeiShenTuiDnum"]); num18 += ConvertUtil.ToInt32(dr["YiShenTuiDnum"]);
                        num19 += ConvertUtil.ToInt32(dr["YiShenTuiDnum_24"]); num20 += ConvertUtil.ToInt32(dr["YiShenTuiDnum_25"]); num21 += ConvertUtil.ToInt32(dr["TotalYanQnum"]);
                        num22 += ConvertUtil.ToInt32(dr["WeiShenYanQnum"]); num23 += ConvertUtil.ToInt32(dr["YiShenYanQnum"]); num24 += ConvertUtil.ToInt32(dr["YiShenYanQnum_24"]);
                        num25 += ConvertUtil.ToInt32(dr["YiShenYanQnum_25"]);
                    }
                    cmd.Clone();
                }
                con.Close();
                string countRows = string.Format(@"<tr  style='text-align: center;'><td  colspan='2' style='text-align:right;'>总数</td>
<td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td><td>{10}</td>
<td>{11}</td><td>{12}</td><td>{13}</td><td>{14}</td><td>{15}</td><td>{16}</td><td>{17}</td><td>{18}</td><td>{19}</td><td>{20}</td><td>{21}</td>
<td>{22}</td><td>{23}</td><td>{24}</td></tr>", num1, num2, num3, num4, num5, num6, num7, num8, num9, num10,
                        num11, num12, num13, num14, num15, num16, num17, num18, num19,
                        num20, num21, num22, num23, num24, num25);
                builder.Append(countRows);
                // html += "<tr><td colspan='5'>主管：</td><td colspan='10'>制表人：</td><td colspan='5'>制表日期：</td></tr>";
                //  html += "</table>";
            }
        }
        catch (Exception ex)
        {
            Loger.Error("BLL_Report=====>异常：", ex);

        }
        return builder.ToString();
    }
    #region
    public static void Export(string sheetName, string filename, string tabHead, string tabBody)
    {
        StringWriter sw = new StringWriter();
        sw.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
        sw.WriteLine("<head>");
        sw.WriteLine("<!--[if gte mso 9]>");
        sw.WriteLine("<xml>");
        sw.WriteLine(" <x:ExcelWorkbook>");
        sw.WriteLine("  <x:ExcelWorksheets>");
        sw.WriteLine("   <x:ExcelWorksheet>");
        sw.WriteLine("    <x:Name>" + sheetName + "</x:Name>");
        sw.WriteLine("    <x:WorksheetOptions>");
        sw.WriteLine("      <x:Print>");
        sw.WriteLine("       <x:ValidPrinterInfo />");
        sw.WriteLine("      </x:Print>");
        sw.WriteLine("    </x:WorksheetOptions>");
        sw.WriteLine("   </x:ExcelWorksheet>");
        sw.WriteLine("  </x:ExcelWorksheets>");
        sw.WriteLine("</x:ExcelWorkbook>");
        sw.WriteLine("</xml>");
        sw.WriteLine("<![endif]-->");

        sw.WriteLine("</head>");
        sw.WriteLine("<body>");
        // sw.WriteLine("<table  id='table' border='1' cellpadding='0' cellspacing='0' style='border-collapse:collapse;'>");
        sw.WriteLine(tabHead);
        //sw.WriteLine("<tr><td colspan='20' style='font-size:22px;font-weight:bold;padding:10px 0 10px 0' align='center'>上海浦东威立雅自来水有限公司管网所 </td></tr><tr><td colspan='20' style='font-size:22px;font-weight:bold;padding:10px 0 10px 0 ' align='center'>修漏工作统计明细表</td></tr><tr><td rowspan='2'>序号</td><td rowspan='2'>工作单编号</td><td rowspan='2'>施工地点</td><td rowspan='2'>报漏日期</td><td rowspan='2'>修复日期</td><td rowspan='2'>是否及时</td><td colspan='2'>明漏</td><td rowspan='2'>暗漏</td><td colspan='8'>修<span style='mso-spacerun: yes'>&nbsp;&nbsp; </span>漏<span style='mso-spacerun: yes'>&nbsp;&nbsp;</span>类<span style='mso-spacerun: yes'>&nbsp;&nbsp; </span>别</td><td colspan='2'>漏失水量</td><td rowspan='2'><span style='mso-spacerun: yes'>&nbsp;&nbsp; </span>修理方式耗用材料<span style='mso-spacerun: yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>口径×长度</td><td rowspan='2'>备注</td></tr><tr><td>自报</td><td>外报</td><td>接头口径</td><td>水管口径</td><td>阀门口径</td><td>水表接头口径</td><td>接水阀口径</td><td>消防口径</td><td>自然暴管口径</td><td>人为损坏口径</td>  <td>明漏</td><td>暗漏</td></tr>");
        sw.WriteLine(tabBody);
        sw.WriteLine("</table>");
        sw.WriteLine("</body>");
        sw.WriteLine("</html>");
        sw.Close();
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.Charset = "UTF-8";
        // this.EnableViewState = false;
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + filename + ".xls");
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
        HttpContext.Current.Response.Write(sw);
        HttpContext.Current.Response.End();
    }
    #endregion
    #region  获取服务器时间

    /// <summary>
    ///     获取服务器时间
    /// </summary>
    /// <returns>服务器时间</returns>
    public static string GetSysDate()
    {
        return DbHelperOra.Query("select sysdate from dual").Tables[0].Rows[0]["sysdate"].ToString();
    }

    #endregion
}