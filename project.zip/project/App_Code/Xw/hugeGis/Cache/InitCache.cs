﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

/// <summary>
/// InitCache 的摘要说明
/// </summary>
public class InitCache
{
	public InitCache()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public static Hashtable sblb_xwbm;
    public static Hashtable xwbm_glbm;
    public static Hashtable xwbm_sjzd;
    public static double extendValue = 100;
    public static string queryLayers = "";
    public static string mohuQueryLayers = "";
    public static string roadLayerName = "";
    public static string objectIDField = "";
    public static string electriFollowUrl0 = "";
    public static string electriFollowUrl1 = "";
    public static string telephoneQueryLayer = "";
    public static string stationQueryLayer = "";
    public static int maxPerParagraph = 50;
    public static string callRecordService = "";
    public static Hashtable myConfig;
    public static int defaultZoomLevel = 6;
    public static string authCheckURL = "";
    public static string genzongqiAuthName = "";
    public static int initCount = 0;
    public static double coordExtend = 0;
    public static double jzcoordExtend = 0;
    public static Hashtable codeHash=new Hashtable();
}
