﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

/// <summary>
/// publicbean 的摘要说明
/// </summary>
public class publicbean
{
    public static Hashtable pdakeyValue = new Hashtable();
    public publicbean()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    /// <summary>
    /// 处理及时率判断
    /// </summary>
    /// <returns> 0.处理不及时  1。处理及时</returns>
    public static string ChuLiJiShi(string XFSJ, string SOLVETIME_PLAN)
    {
        if (SOLVETIME_PLAN != "" && XFSJ != "")
            if (DateTime.Parse(XFSJ).CompareTo(DateTime.Parse(SOLVETIME_PLAN)) > 0)
            {
                // msgstr += " <font color=red>处理不及时，修正修复时间！</font>";
                return "0";
            }
        return "1";
    }



    /// <summary>
    /// 销单及时率判断
    /// </summary>
    /// <returns> 0.销单不及时 1.销单及时  </returns>
    public static string XiaoDanJiShi(string WCSJ, string SOLVETIME_PLAN)
    {
        if (SOLVETIME_PLAN != "" && WCSJ != "")
            if (DateTime.Parse(WCSJ).CompareTo(DateTime.Parse(SOLVETIME_PLAN).AddHours(24)) > 0)
            {
                //msgstr += " <font color=red>销单不及时，修正完成时间</font>";
                return "0";
            }
        return "1";
    }

    /// <summary>
    /// PDA是否在线
    /// </summary>
    /// <returns>0.不在线 1.在线</returns>
    public static string PdaisOnLine(string loctime)
    {

        int pdaonlinenum = int.Parse(pdakeyValue["ONLINENUM"].ToString());
        if (loctime != "" && DateTime.Parse(loctime).AddMinutes(pdaonlinenum).CompareTo(DateTime.Now) > 0)
            return "1";
        return "0";

    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="SENDTIME"></param>
    /// <param name="SENDFINISHTIME"></param>
    /// <returns></returns>
    public static string JianGeSJ(string SENDTIME, string SENDFINISHTIME)
    {
        try
        {
            TimeSpan ts = DateTime.Parse(SENDFINISHTIME) - DateTime.Parse(SENDTIME);
            return ts.Hours + "小时" + ts.Minutes + "分" + ts.Seconds + "秒";
        }
        catch
        {

        }
        return "0分";
    }


    /// <summary>
    /// 发送状态显示
    /// </summary>
    /// <param name="SENDTIME"></param>
    /// <param name="SENDFINISHTIME"></param>
    /// <returns></returns>
    public static string JianGeSJZTSHOW(string SENDTIME, string SENDFINISHTIME)
    {
        try
        {
            TimeSpan ts = DateTime.Parse(SENDFINISHTIME) - DateTime.Parse(SENDTIME);
            return (ts.TotalMinutes <= 10) ? "正常发送" : "发送延迟";
        }
        catch
        {

        }
        return "未发送";
    }


    /// <summary>
    /// 生成表格
    /// </summary>
    /// <param name="ht"></param>
    /// <param name="recordal"></param>
    /// <param name="coloumnname"></param>
    public static void inittable(HtmlTable ht, ArrayList recordal, string[] coloumnname)
    {
        HtmlTableRow htr = new HtmlTableRow();
        HtmlTableCell htc = new HtmlTableCell();
        int countnum = 100;
        int i = 0;
        if (coloumnname.Length > 0)
            foreach (string coloumnnamestr in coloumnname)
            {
                htc = new HtmlTableCell();
                htc.InnerHtml = coloumnnamestr + " &nbsp;";
                htc.NoWrap = true;
                htc.Align = "center";
                htc.BgColor = "#CCDFFF";
                htr.Cells.Add(htc);
            }
        ht.Rows.Add(htr);
        foreach (string[] record in recordal)
        {
            htr = new HtmlTableRow();
            foreach (string recordstr in record)
            {
                htc = new HtmlTableCell();
                htc.InnerHtml = recordstr + " &nbsp;";
                htc.NoWrap = true;
                htr.Cells.Add(htc);
            }
            ht.Rows.Add(htr);
            i++;
            if (i >= countnum)
                break;
        }
    }


    /// <summary>
    /// 返回系数
    /// </summary>
    /// <returns></returns>
    public static string resultValue(string date)
    {
        OracleDataBase odb1 = new OracleDataBase();
        if (string.IsNullOrEmpty(date))
            return "0";
        DateTime daetime = Convert.ToDateTime(date);
        //节假日
        string sql = string.Format(@"select xs from DAYSET where (status='0' or status='3') and to_char(datev,'yyyy-mm-dd')='" + daetime.ToString("yyyy-MM-dd") + "'");
        DataTable dtDatSet = odb1.GetDataSet(sql).Tables[0];
        if (dtDatSet.Rows.Count > 0)
            return dtDatSet.Rows[0]["xs"].ToString();
        bool bl = false;
        if (daetime.DayOfWeek == DayOfWeek.Sunday || daetime.DayOfWeek == DayOfWeek.Saturday)
        {
            bl = true;
        }

        //获取双休日，夜班，白班
        sql = string.Format(@"select * from YB_Config order by status asc");
        DataTable dt = odb1.GetDataSet(sql).Tables[0];
        string ksDate = string.Empty;
        string jsDate = string.Empty;
        int hour = daetime.Hour;
        int minute = daetime.Minute;

        foreach (DataRow dr in dt.Rows)
        {
            if (bl)
            {
                if (dr["status"].ToString() == "2")
                    return dr["xs"].ToString();
            }
            else
            {
                if (dr["status"].ToString() == "0")//晚班
                {

                    if (hour == Convert.ToInt32(dr["HOURONE"]) && minute >= Convert.ToInt32(dr["MARKONE"]))
                    {
                        return dr["xs"].ToString();
                    }
                    else if (hour > Convert.ToInt32(dr["HOURONE"]))
                    {
                        return dr["xs"].ToString();
                    }
                    else if (hour == Convert.ToInt32(dr["HOURTWO"]) && minute <= Convert.ToInt32(dr["MARKTWO"]))
                    {
                        return dr["xs"].ToString();
                    }
                    else if (hour < Convert.ToInt32(dr["HOURTWO"]))
                    {
                        return dr["xs"].ToString();
                    }
                }
                else if (dr["status"].ToString() == "1") //日班
                {
                    if (hour >= Convert.ToInt32(dr["HOURONE"]))
                    {
                        if (hour == Convert.ToInt32(dr["HOURONE"]) && minute >= Convert.ToInt32(dr["MARKONE"]))
                        {
                            return dr["xs"].ToString();
                        }
                        else if (hour < Convert.ToInt32(dr["HOURTWO"]) && hour > Convert.ToInt32(dr["HOURONE"]))
                        {
                            return dr["xs"].ToString();
                        }
                        else if (hour == Convert.ToInt32(dr["HOURTWO"]) && minute <= Convert.ToInt32(dr["MARKTWO"]))
                        {
                            return dr["xs"].ToString();
                        }
                    }
                }
            }
        }
        return "0";
    }

}
