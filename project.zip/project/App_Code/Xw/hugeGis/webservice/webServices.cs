﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// webServices 的摘要说明
/// </summary>
/// 
[System.Web.Services.WebServiceBindingAttribute(Name = "ICommonLocatorservice", Namespace = "http://tempuri.org/")]
public class webServices : System.Web.Services.Protocols.SoapHttpClientProtocol
{
    
    public string roadname;

	public webServices(string url,string roadname)
	{
        this.Url = url;
        this.roadname = roadname;
	}
    [System.Web.Services.Protocols.SoapDocumentMethodAttribute
 ("http://tempuri.org/ICommonLocatorservice",
   RequestNamespace = "http://tempuri.org/",
   ResponseNamespace = "http://tempuri.org/",
    Use = System.Web.Services.Description.SoapBindingUse.Encoded,
    ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Bare)]   
    public void getValue()
    {
        object[] result = this.Invoke("GetRoadIntersect", new object[] { roadname });
        string aa = "";
        string bb = "";
    }
    
}
