﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Encrypt;

/// <summary>
/// EncryptServices 的摘要说明
/// </summary>
public class EncryptServices
{
   private static IHugeEncrypt hugeEncrypt = new HugeEncryptClass();

	public EncryptServices()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    /// <summary>
    /// 解密字符串  EncryptServices.HugegisDecode("048F5F1927D5926F5622DD");
    //  
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static string HugegisDecode(string str){
        object resulestr = null;
        hugeEncrypt.HugegisDecode(str, out resulestr);
        return resulestr != null ? resulestr as string : "";
    }

    /// <summary>
    /// 加密字符串 EncryptServices.HugegisEncode("管网技术科");//048F5F1927D5926F5622DD
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static string HugegisEncode(string str)
    {
        object resulestr = null;
        hugeEncrypt.HugegisEncode(str, out resulestr);
        return resulestr != null ? resulestr as string : "";
    }
}
