﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OracleClient;
using hugegis.DBUtility;
using System.Text;
using System.Collections.Generic;
using BootStrapControls;
using Maticsoft.DBUtility;
using System.Linq;
using OrderFunction;

//工单功能页面
namespace OrderFunction
{
    #region 数据库中配置，字段名称，属性，是否只读，是否必输，输入框类型等
    /// <summary>
    /// 数据库中配置，字段名称，属性，是否只读，是否必输，输入框类型等
    /// </summary>
    public class  FormControl : BootStrapControl
    {
        public string ID { get; set; }
        public string TableName { get; set; }
        public string FieldName { get; set; }
        public string FieldDisName { get; set; }
        public string IsNull { get; set; }
        public string FieldType { get; set; }
        public string Type { get; set; }
        public string ChildCode { get; set; }
        public int Length { get; set; }
        //关联连words表
        public string DROPCODE { get; set; }
        //排序
        public string FIELDORDER { get; set; }
        //是否是下拉
        public string MAPINGCODE { get; set; }
        public string MAPSQL { get; set; }
        public string VALIDRULES { get; set; }
        public string SUBFIELD { get; set; }
        //是否可空；否的话就是必填
        public string Nullable { get; set; }
        public string title { get; set; }
        public int titleStyle { get; set; }
        public string Updtaetable { get; set; }
        public string DefaultValue { get; set; }
        public string DefaultType { get; set; }
        //是否需要显示（代码控制）
        private string _isneedshow;
        public string isneedshow
        {
            get
            {
                if (_isneedshow == null)
                {
                    return "true";
                }
                else
                {
                    return _isneedshow;
                }
            }
            set { _isneedshow = value; }
        }
        public FieldConfig fconfig { get; set; }

        public OracleDataBase database = new OracleDataBase();
        public string SessionUid = null;
        public string SessionUserDEPNAME = null;

        /// <summary>
        /// 获取字段默认值
        /// </summary>
        /// <param name="fieldname"></param>
        /// <returns></returns>
        protected string GetDefaultValue(string fieldname,string defaultvalue,string defaulttype, string UId, string depName)
        {
            string value = "";
            if (fieldname == "CUSTOMSERVICEID" || fieldname.Equals("MISSIONBH"))
                value = DateTime.Now.ToString("yyMMddHHmmss");
            if (fieldname == "ACCEPTTIME" || fieldname == "HAPPENTIME" || fieldname == "TIANDTIME" || fieldname == "ARRIVALTIME" || fieldname == "WATERSTOPTIME" || fieldname == "EXECUTIVETIME" || fieldname == "FINISHTIME" || fieldname == "SENDTIME")
                value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            if (fieldname == "LOGONSTATION")
                value = depName == null ? "" : depName.ToString();
            //if (fieldname == "ACCEPTSTATION")
            // value = depName == null ? "" : depName.ToString();
            if (fieldname == "EXECUTIVEDEPARTMENT")
            value = depName == null ? "" : depName.ToString();
            if (fieldname == "EXECUTIVEPEOPLE" || fieldname == "ACCEPTPEOPLE" || fieldname == "EXECUTIVELOGON")
                value = getUserName(UId != null ? UId.ToString() : "admin");
            if (fieldname == "ISREPLY")
                value = "否";
            switch (defaulttype)
            {
                case "0":
                     value = defaultvalue;break;
                case "1":
                    value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");break;
                case "2":
                    value = getUserName(UId != null ? UId.ToString() : "admin");break;
                case "3":
                    value = depName == null ? "" : depName.ToString();break;
                case "4":
                    value = GetDefaultValue(defaultvalue);break;
            }
            return value;
        }

        /// <summary>
        /// 获取默认值
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public string GetDefaultValue(string sql)
        {
            OracleDataBase odb = new OracleDataBase();
            string value = odb.GetScalarobj(sql).ToString();
            return value;
        }
        //绑定受理站点
        protected string bindAcceptStation(string uid)
        {
            string sql = "";
            try
            {
                string sql_getdepid = "select depid from author_user where cuser = '" + uid + "'";
                object obj = DbHelperOra.GetSingle(sql_getdepid);
                string depid = Convert.ToString(obj);
                if (!string.IsNullOrEmpty(depid))
                {
                    sql = string.Format("SELECT count(*) FROM author_department WHERE 1 = 1 AND exists (select 1 from words where belongcode = '032' and wordscontent = depname) START WITH id = '{0}' CONNECT BY PRIOR pid = id", depid);
                    int id_insert = Convert.ToInt32(DbHelperOra.GetSingle(sql));
                    if (database.GetIDInsert(sql) < 1)
                    {
                        sql = "select WORDSCONTENT from words where belongcode = '032'";
                    }
                    else
                    {
                        sql = string.Format("SELECT depname as WORDSCONTENT FROM author_department WHERE 1 = 1 AND exists (select 1 from words where belongcode = '032' and wordscontent = depname) START WITH id = '{0}' CONNECT BY PRIOR pid = id", depid);
                    }
                }
                else
                {
                    sql = string.Format("select v.RESNAME as WORDSCONTENT  from author_user_all_resource v  where USERID='{0}' and RESCATALOG='{1}'", uid, ConfigurationManager.AppSettings["ShouliAcception"]);
                }
                Loger.Error("bindAcceptStation====>sql" + sql);
            }
            catch (Exception ex)
            {
                Loger.Error("bindAcceptStation=====>", ex);
            }
            return sql;
        }
        /// <summary>
        /// 获取用户名
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        public string getUserName(string uid)
        {
            string sql = "select realname from author_user where cuser='" + uid + "'";
            OracleDataBase odb = new OracleDataBase("1");
            return odb.GetScalarInfo(sql).ToString();
        }
        /// <summary>
        /// 处理过程，获取搜索html字符串
        /// </summary>
        public string GetSearchHtmlText(FormControl form)
        {
            OracleDataBase odb = new OracleDataBase("0");
            StringBuilder sb = new StringBuilder();
            string value = "";
            string inputStr = "";
            try
            {
                //value = GetDefaultValue(form.FieldName, this.SessionUid, this.SessionUserDEPNAME);
                inputStr = "<input runat=\"server\" class=\"form-control input-sm\" value=\"" + value + "\" name=\"" + form.FieldName + "\" type=\"text\" id=\"" + form.FieldName + "\" />";
                #region 时间格式

                if (this.FieldType.ToUpper().Contains("61"))
                {
                    inputStr = "<div class=\"form-group\"><input runat=\"server\" class=\"form-control\" style=\"width:45%;display:inline\"  onclick=\"laydate({istime: true, format: 'YYYY-MM-DD'})\" value=\"" + value + "\" name=\"" + form.FieldName + "BEGIN\" type=\"text\" id=\"" + form.FieldName + "BEG\"/>" + "--";
                    inputStr = inputStr + "<input runat=\"server\"class=\"form-control\" style=\"width:45%;display:inline\"  onclick=\"laydate({istime: true, format: 'YYYY-MM-DD'})\" value=\"" + value + "\" name=\"" + form.FieldName + "END\" type=\"text\" id=\"" + form.FieldName + "END\"  /></div>";
                }

                #endregion

                #region 下拉框
                if (form.MAPINGCODE.ToUpper() != "-1" && form.Type != "RADIO")
                {
                    string dm = form.MAPSQL;
                    if (!string.IsNullOrEmpty(form.MAPSQL))
                    {
                        DataTable dt = odb.GetDataSet(form.MAPSQL).Tables[0];
                        inputStr = "<select class=\"form-control\"  size=\"1\" name=\"" + form.FieldName + "\" id=\"" + form.FieldName + "\"><option value=\"\">==请选择==</option>";

                        if (!string.IsNullOrEmpty(form.SUBFIELD))
                        {
                            inputStr = "<select class=\"form-control\"  onchange=\"selectChange(this)\" fielddata=\"" + form.SUBFIELD + "\" size=\"1\" name=\"" + form.FieldName + "\" id=\"" + form.FieldName + "\"><option value=\"\">==请选择==</option>";
                        }

                        for (int j = 0; j < dt.Rows.Count; j++)
                        {
                            string temp = "<option wordscode=\"" + dt.Rows[j]["wordscode"] + "\" value=\"" + dt.Rows[j]["wordscontent"].ToString() + "\">" + dt.Rows[j]["wordscontent"].ToString() + "</option>";
                            inputStr += temp;
                        }

                        inputStr += "<asp:HiddenField ID=\"" + form.FieldName + "s\" runat=\"server\" />";
                        inputStr += "</select>";

                    }
                }
                #endregion



            }
            catch (Exception ex)
            {
                Loger.Error("GetSearchHtmlText==>", ex);
            }
            string s_temp = inputStr.ToString();
            StringBuilder sb2 = new StringBuilder();
            sb2.Append(s_temp);


            //sb2.AppendLine("<div class=\"separator\"></div>");
            this.HtmlText = sb2.ToString();
            return this.HtmlText;
        }

        /// <summary>
        /// 处理过程，获取html字符串
        /// </summary>
        public override string GetHtmlText()
        {
            OracleDataBase odb = new OracleDataBase("0");
            StringBuilder sb = new StringBuilder();
            string value = "";
            string inputStr = "";
            try
            {

                value = GetDefaultValue(this.FieldName,this.DefaultValue,this.DefaultType, this.SessionUid, this.SessionUserDEPNAME);
                inputStr = "<input runat=\"server\" class=\"form-control \" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr="<input runat=\"server\" class=\"form-control " + this.VALIDRULES.ToUpper() + "\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                }
                #region 时间格式
                if (this.Type.ToUpper() == "DATE" && this.FieldType.ToUpper().Contains("51"))
                {
                    inputStr = "<div class=\"form-group\"><input runat=\"server\" class=\"form-control\" placeholder=\"YYYY/MM/DD\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm:ss'})\" value=\"" + value + "\" name=\"" + this.FieldName + "BEGIN\" type=\"text\" id=\"" + this.FieldName + "BEGIN\"/></div>" + "--";
                    inputStr = inputStr + "<div class=\"form-group\"><input runat=\"server\" class=\"form-control \" placeholder=\"YYYY/MM/DD hh:mm\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm'})\" value=\"" + value + "\" name=\"" + this.FieldName + "END\" type=\"text\" id=\"" + this.FieldName + "END\"  /></div>";
                }
                if (this.Type.ToUpper() == "DATE" && this.FieldType.ToUpper().Contains("52"))
                {
                    inputStr = "<div class=\"form-group\"><input runat=\"server\" class=\"form-control \" placeholder=\"YYYY/MM/DD hh:mm:ss\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm:ss'})\" value=\"" + value + "\" name=\"" + this.FieldName + "BEGIN\" type=\"text\" id=\"" + this.FieldName + "BEGIN\" /></div>";
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.FieldType.ToUpper().Contains("52") && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<div class=\"form-group\"><input runat=\"server\" class=\"form-control " + this.VALIDRULES.ToUpper() + "\" placeholder=\"YYYY/MM/DD hh:mm:ss\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD'})\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\"  /></div>";
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.FieldType.ToUpper().Contains("51") && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<div class=\"form-group\"><input runat=\"server\" class=\"form-control  " + this.VALIDRULES.ToUpper() + "\" placeholder=\"YYYY/MM/DD hh:mm:ss\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm:ss'})\" value=\"" + value + "\" name=\"" + this.FieldName + "BEGIN\" type=\"text\" id=\"" + this.FieldName + "BEGIN\"/></div>" + "--";
                    inputStr = inputStr + "<div class=\"form-group\"><input runat=\"server\"class=\"form-control layer-date " + this.VALIDRULES.ToUpper() + "\" placeholder=\"YYYY/MM/DD hh:mm:ss\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm:ss'})\" value=\"" + value + "\" name=\"" + this.FieldName + "END\" type=\"text\" id=\"" + this.FieldName + "END\"  /></div>";
                }
                if (this.Type.ToUpper() == "DATE" && this.FieldType.ToUpper().Contains("50"))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control \" placeholder=\"YYYY/MM/DD hh:mm:ss\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm:ss'})\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.FieldType.ToUpper().Contains("50") && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control  " + this.VALIDRULES.ToUpper() + "\" placeholder=\"YYYY/MM/DD hh:mm:ss\" onclick=\"laydate({istime: true, format: 'YYYY/MM/DD hh:mm:ss'})\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                }
                #endregion
                #region 大文本
                if (this.Length >= 800)
                {
                    inputStr = "<textarea  runat=\"server\" class=\"form-control\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\" rows=\"2\" ></textarea>";
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.Length >= 800 && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<textarea  runat=\"server\" class=\"form-control  " + this.VALIDRULES.ToUpper() + "\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\" rows=\"2\" ></textarea>";
                }
                #endregion
                #region 地址带联想功能的文本框
                if (this.FieldType.Contains("53"))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control \" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                    inputStr += "<a href=\"javascript:getpoint();\">拾取坐标</a>"; 
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.FieldType.Contains("53") && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control " + this.VALIDRULES.ToUpper() + "\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                    inputStr += "<a href=\"javascript:getpoint();\">拾取坐标</a>"; 
                }
                #endregion
                #region 只读
                if (this.FieldType.ToUpper().Contains("32"))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control\" readonly=\"readonly\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\"  />";
                }
                if (this.Type.ToUpper() == "NVARCHAR2" && !this.FieldType.ToUpper().Contains("32"))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control\" style=\"width:300px\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                }
                if (this.Type.ToUpper() == "NUMBER" && !this.FieldType.ToUpper().Contains("32"))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control\" name=\"" + this.FieldName + "\" type=\"text\" value=\"" + value + "\" id=\"" + this.FieldName + "\" onKeyUp=\"clearNoNum(event,this)\" onBlur=\"checkNum(this)\"";
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.Type.ToUpper() == "NUMBER" && !this.FieldType.ToUpper().Contains("32") && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control " + this.VALIDRULES.ToUpper() + "\" name=\"" + this.FieldName + "\" type=\"text\" value=\"" + value + "\" id=\"" + this.FieldName + "\" onKeyUp=\"clearNoNum(event,this)\" onBlur=\"checkNum(this)\"";
                }
                if (this.Length >= 800 && this.FieldType.ToUpper().Contains("32"))
                {
                    inputStr = "<textarea  runat=\"server\" disabled=\"disabled\" class=\"form-control\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\" rows=\"2\" ></textarea>";
                }
                if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && this.Length >= 800 && this.FieldType.ToUpper().Contains("32") && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                {
                    inputStr = "<textarea  runat=\"server\"   readonly=\"readonly\" class=\"form-control  " + this.VALIDRULES.ToUpper() + "\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\" rows=\"2\" ></textarea>";
                }
                #endregion
                #region 下拉框
                if (this.MAPINGCODE.ToUpper() == "1")
                {
                    string dm = this.MAPSQL;
                    if (!string.IsNullOrEmpty(this.MAPSQL))
                    {

                        DataTable dt = odb.GetDataSet(this.MAPSQL).Tables[0];
                        inputStr = "<select class=\"form-control\"  size=\"1\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\"><option value=\"\">==请选择==</option>";
                        if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                        {
                            inputStr = "<select class=\"form-control  " + this.VALIDRULES + "\"  size=\"1\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\"><option value=\"\">==请选择==</option>";
                        }
                        if (!string.IsNullOrEmpty(this.SUBFIELD))
                        {
                            inputStr = "<select class=\"form-control\"  onchange=\"selectChange(this)\" fielddata=\"" + this.SUBFIELD + "\" size=\"1\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\"><option value=\"\">==请选择==</option>";
                        }
                        if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && !string.IsNullOrEmpty(this.SUBFIELD) && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                        {
                            inputStr = "<select class=\"form-control  " + this.VALIDRULES + "\"  fielddata=\"" + this.SUBFIELD + "\" onchange=\"selectChange(this)\" size=\"1\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\"><option value=\"\">==请选择==</option>";
                        }
                        if (this.FieldType.ToUpper().Contains("32"))
                        {
                            inputStr = "<select class=\"form-control \"  disabled=\"disabled\" size=\"1\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\"><option value=\"\">==请选择==</option>";
                        }
                        if (!string.IsNullOrEmpty(this.SUBFIELD) && this.FieldType.ToUpper().Contains("32"))
                        {
                            inputStr = "<select class=\"form-control\"  onchange=\"selectChange(this)\" disabled=\"disabled\" fielddata=\"" + this.SUBFIELD + "\" size=\"1\" name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\"><option value=\"\">==请选择==</option>";
                        }
                        if (this.FieldName.ToUpper().Equals("ACCEPTSTATION1"))
                        {
                            DataSet ds = Global.bindAcceptStation(SessionUid);
                            #region 受理站点和派遣站点
                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                dt = ds.Tables[0];
                                foreach (DataRow item in dt.Rows)
                                {
                                    string temp = "<option wordscode=\"" + item["wordscontent"] + "\" value=\"" + item["wordscontent"].ToString() + "\">" + item["wordscontent"].ToString() + "</option>";
                                    inputStr += temp;
                                }
                            }
                        }
                        else if (this.FieldName.ToUpper().Equals("ACCEPTSTATION"))
                        {
                            DataSet ds = Global.bindStie(SessionUid);
                            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                dt = ds.Tables[0];
                                foreach (DataRow item in dt.Rows)
                                {
                                    string temp = "<option wordscode=\"" + item["wordscontent"] + "\" value=\"" + item["wordscontent"].ToString() + "\">" + item["wordscontent"].ToString() + "</option>";
                                    inputStr += temp;
                                }
                            }
                        }
                            #endregion
                        else
                        {
                            for (int j = 0; j < dt.Rows.Count; j++)
                            {
                                string temp = "<option  wordscode=\"" + dt.Rows[j]["wordscode"] + "\" value=\"" + dt.Rows[j]["wordscontent"].ToString() + "\">" + dt.Rows[j]["wordscontent"].ToString() + "</option>";
                                inputStr += temp;
                            }
                        }
                        if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()))
                        {
                            inputStr += "</select>";
                            inputStr += "<asp:HiddenField ID=\"" + this.FieldName + "s\" runat=\"server\" />";
                        }
                        else
                        {
                            inputStr += "<asp:HiddenField ID=\"" + this.FieldName + "s\" runat=\"server\" />";
                            inputStr += "</select>";
                        }
                    }
                }
                #endregion
                #region 复选框
                if (this.MAPINGCODE.ToUpper() == "2")
                {
                    string dm = this.MAPSQL;
                    inputStr = "<div class=\"" + this.FieldName + "\">";
                    inputStr += "<input type=\"hidden\" runat=\"server\" ID=\"" + this.FieldName + "\" Name=\"" + this.FieldName + "\"/>";
                    if (!string.IsNullOrEmpty(this.MAPSQL))
                    {
                        DataTable dt = odb.GetDataSet(this.MAPSQL).Tables[0];
                        int num = 0;
                        if (!string.IsNullOrEmpty(this.SUBFIELD) && !string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                        {
                            foreach (DataRow item in dt.Rows)
                            {
                                inputStr += "<label class=\"checkbox-inline\">";
                                inputStr += "<input type=\"checkbox\" wordscode=\"" + item["wordscode"] + "\"  onchange=\"CheckBoxChangeSUB(this,'" + this.FieldName + "')\" fielddata=\"" + this.SUBFIELD + "\" name=\"" + (this.FieldName + num) + "\" id=\"" + (this.FieldName + num) + "\" class=\"form-control " + this.VALIDRULES.ToUpper() + "\" runat=\"server\" value=\"" + item["wordscontent"].ToString() + "\"/>" + item["wordscontent"].ToString();
                                inputStr += "</label>";
                            }
                        }
                        else if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                        {
                            foreach (DataRow item in dt.Rows)
                            {
                                inputStr += "<label class=\"checkbox-inline\">";
                                inputStr += "<input type=\"checkbox\" name=\"" + (this.FieldName + num) + "\" id=\"" + (this.FieldName + num) + "\" class=\"form-control " + this.VALIDRULES.ToUpper() + "\" runat=\"server\" value=\"" + item["wordscontent"].ToString() + "\"/>" + item["wordscontent"].ToString();
                                inputStr += "</label>";
                            }
                        }
                        else if (!string.IsNullOrEmpty(this.SUBFIELD))
                        {
                            foreach (DataRow item in dt.Rows)
                            {
                                inputStr += "<label class=\"checkbox-inline\">";
                                inputStr += "<input type=\"checkbox\" wordscode=\"" + item["wordscode"] + "\"  onchange=\"CheckBoxChangeSUB(this,'" + this.FieldName + "')\" fielddata=\"" + this.SUBFIELD + "\" name=\"" + (this.FieldName + num) + "\" id=\"" + (this.FieldName + num) + "\"  runat=\"server\" value=\"" + item["wordscontent"].ToString() + "\"/>" + item["wordscontent"].ToString();
                                inputStr += "</label>";
                            }
                        }
                        else
                        {
                            foreach (DataRow item in dt.Rows)
                            {
                                inputStr += "<label class=\"checkbox-inline\">";
                                inputStr += "<input type=\"checkbox\" name=\"" + (this.FieldName + num) + "\" id=\"" + (this.FieldName + num) + "\" runat=\"server\" value=\"" + item["wordscontent"].ToString() + "\"/>" + item["wordscontent"].ToString();
                                inputStr += "</label>";
                            }
                        }
                    }
                    inputStr += "</div>";
                }
                #endregion
                #region 单选按钮
                if (this.MAPINGCODE.ToUpper() == "3")
                {
                    string dm = this.MAPSQL;
                    if (!string.IsNullOrEmpty(this.MAPSQL))
                    {
                        DataTable dt = odb.GetDataSet(this.MAPSQL).Tables[0];
                        inputStr = "<div class=\"radio\">";
                        for (int j = 0; j < dt.Rows.Count; j++)
                        {
                            string falg = "";
                            if (dt.Rows[j]["wordscode"].ToString() == "1")
                            {
                                falg = "checked=\"checked\" ";
                            }
                            string temp = "<label> <input type=\"radio\" name=\"" + this.FieldName + "\" " + falg + " value=\"" + dt.Rows[j]["wordscode"] + "\" />" + dt.Rows[j]["wordscontent"] + "</label>";
                            inputStr += temp;
                        }
                        inputStr += "</div>";
                    }
                }
                #endregion

                #region 树
                if (this.MAPINGCODE.ToUpper() == "4")
                {

                    inputStr = "<input runat=\"server\" readonly='readonly' class=\"form-control input-sm\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";

                    if (!string.IsNullOrEmpty(this.VALIDRULES.ToUpper()) && ((fconfig != null && fconfig.type != "novalid") || fconfig == null))
                    {
                        inputStr = "<input runat=\"server\" readonly='readonly' class=\"form-control " + this.VALIDRULES.ToUpper() + "\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"text\" id=\"" + this.FieldName + "\" />";
                    }
                    inputStr += "<a herf='#' onclick=\"javascript:chooseData('" + this.FieldName + "','" + this.MAPSQL + "')\">选择</a>";
                    inputStr += "<input runat=\"server\" class=\"form-control input-sm\" name=\"" + this.FieldName + "_tree\" type=\"hidden\" id=\"" + this.FieldName + "_tree\" />";

                }
                #endregion

                #region
                if (this.FieldType.ToUpper().Contains("31"))
                {
                    inputStr = "<input runat=\"server\" class=\"form-control\" value=\"" + value + "\" name=\"" + this.FieldName + "\" type=\"hidden\" id=\"" + this.FieldName + "\"  />";
                }

                #endregion
            }
            catch (Exception ex)
            {
                Loger.Error("GetWordsHtml==>", ex);
            }
            string s_temp = inputStr.ToString();
            StringBuilder sb2 = new StringBuilder();
            sb2.Append(s_temp);


            //sb2.AppendLine("<div class=\"separator\"></div>");
            this.HtmlText = sb2.ToString();
            return this.HtmlText;
        }
        /// <summary>
        /// 处理过程，获取html字符串
        /// </summary>
        public override string GetHtmlTextDetail()
        {
            OracleDataBase odb = new OracleDataBase("0");
            StringBuilder sb = new StringBuilder();
            string value = "";
            string inputStr = "";
            try
            {
                inputStr = "<span name=\"" + this.FieldName + "\" id=\"" + this.FieldName + "\" >" + value + "</span>";
            }
            catch (Exception ex)
            {
                Loger.Error("GetWordsHtml==>", ex);
            }
            string s_temp = inputStr.ToString();
            StringBuilder sb2 = new StringBuilder();
            sb2.Append(s_temp);


            //sb2.AppendLine("<div class=\"separator\"></div>");
            this.HtmlText = sb2.ToString();
            return this.HtmlText;
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        public FormControl()
        {
            //非必填项：可空
            this.Nullable = "";
        }


        /// <summary>
        /// 构造函数
        /// </summary>
        public FormControl(string b)
        {
            //非必填项：可空
            this.Nullable = b;
        }

    }
    #endregion 

    #region FormControl组合
    /// <summary>
    /// FormControl组合
    /// </summary>
    public class FormList : BootStrapControl
    {
        private int controls_count = 0;
        private int column_count = Convert.ToInt32(ConfigurationManager.AppSettings["column_count"]);
        public string SessionUID = "";
        public List<FieldConfig> Flist = new List<FieldConfig>();
        public string userDEPNAME = "";
        public string isneedsqdx = "true";
        public int ControlsCount
        {
            get
            {
                controls_count = List == null ? 0 : List.Count;
                return controls_count;
            }
        }
        public List<FormControl> List { get; set; }

        public void Add(FormControl fc)
        {
            if (this.List == null)
            {
                this.List = new List<FormControl>();
            }
            this.List.Add(fc);
        }
        public FormList(string uid, string depName)
        {
            SessionUID = uid;
            userDEPNAME = depName;
            this.List = new List<FormControl>();
        }

        public FormList(int max_count)
        {
            this.column_count = max_count;
            this.List = new List<FormControl>();
        }
        public override string GetHtmlText()
        {
            StringBuilder sb = new StringBuilder();
            if (this.List != null)
            {
                Dictionary<int, string> tlist = new Dictionary<int, string>();
                foreach (FormControl c in this.List)
                {
                    if (!tlist.Keys.Contains(c.titleStyle))
                    {
                        tlist.Add(c.titleStyle, c.title);
                    }
                }
                foreach (var item in tlist)
                {
                    int i = 0;
                    //一行的列数
                    sb.Append("<div class='row'>");
                    sb.Append("<div class='col-lg-10 col-lg-offset-1'>");
                    sb.Append("<div class='panel panel-default box border primary'>");
                    sb.Append("<div class='box-title'>");
                    sb.Append("<span>" + item.Value + "</span>");
                    sb.Append("</div>");
                    sb.Append("<div class='panel-body'>");
                    sb.Append("<table class=\"table\" border='0'  cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\">");
                    foreach (FormControl c in this.List)
                    {
                        if (c.titleStyle == item.Key)
                        {
                            FieldConfig field = new FieldConfig();
                            if (Flist != null && Flist.Count > 0)
                            {
                                field = Flist.Find(config => config.fieldname.ToUpper() == c.FieldName.ToUpper());
                            }
                            c.SessionUid = SessionUID;
                            c.SessionUserDEPNAME = userDEPNAME;
                            c.fconfig = field;
                            if (i % column_count == 0)
                            {
                                sb.Append("<tr>");
                            }



                            if (c.FieldType.Contains("31") || (field != null && field.type == "hide") || c.isneedshow.ToUpper() == "FALSE")
                            {
                                if (i % column_count != 0)
                                {
                                    sb.Append("</tr>");
                                    i = i + 1;
                                }
                                sb.Append("<tr style='display:none'>");
                                sb.Append("<td>");
                                string s = string.Format("<strong>{0}</strong>", c.FieldDisName);
                                sb.Append(s);
                                sb.Append("</td>");
                                sb.Append("<td  colspan='" + (column_count * 2) + "'>");
                                s = c.GetHtmlText();
                                sb.Append(s);
                                sb.Append("</td>");
                                sb.Append("</tr>");
                                i = i + 2;
                            }
                            else
                            {
                                if (c.Length >= 800)
                                {
                                    if (i % column_count != 0)
                                    {
                                        sb.Append("</tr>");
                                        i = i + 1;
                                    }
                                    sb.Append("<tr>");
                                    sb.Append("<td>");
                                    string s = string.Empty;
                                    if (c.VALIDRULES.Contains("ISNULL") && (field == null || field.type != "novalid"))
                                    {
                                        s = string.Format("<strong>{0}<span style=\"color:red;\">*</span></strong>", c.FieldDisName);
                                    }
                                    else
                                    {
                                        s = string.Format("<strong>{0}</strong>", c.FieldDisName);
                                    }
                                    sb.Append(s);
                                    sb.Append("</td>");
                                    sb.Append("<td  colspan='" + (column_count * 2) + "'>");
                                    s = c.GetHtmlText();
                                    sb.Append(s);
                                    sb.Append("</td>");
                                    sb.Append("</tr>");
                                    i = i + 2;
                                }
                                else
                                {

                                    if (i % column_count == (column_count - 1))
                                    {
                                        sb.Append("<td>");
                                        string s = string.Empty;
                                        if (c.VALIDRULES.Contains("ISNULL") && (field == null || field.type != "novalid"))
                                        {
                                            s = string.Format("<strong>{0}<span style=\"color:red;\">*</span></strong>", c.FieldDisName);
                                        }
                                        else
                                        {
                                            s = string.Format("<strong>{0}</strong>", c.FieldDisName);
                                        }
                                        sb.Append(s);
                                        sb.Append("</td>");
                                        sb.Append("<td>");
                                        s = c.GetHtmlText();
                                        sb.Append(s);
                                        sb.Append("</td>");
                                        sb.Append("</tr>");
                                    }
                                    else
                                    {
                                        sb.Append("<td>");
                                        string s = string.Empty;
                                        if (c.VALIDRULES.Contains("ISNULL") && (field == null || field.type != "novalid"))
                                        {
                                            s = string.Format("<strong>{0}<span style=\"color:red;\">*</span></strong>", c.FieldDisName);
                                        }
                                        else
                                        {
                                            s = string.Format("<strong>{0}</strong>", c.FieldDisName);
                                        }
                                        sb.Append(s);
                                        sb.Append("</td>");
                                        sb.Append("<td>");
                                        s = c.GetHtmlText();
                                        sb.Append(s);
                                        sb.Append("</td>");
                                    }
                                    i++;
                                }
                            }

                        }
                    }
                    sb.Append("</table>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                }
            }
            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
        public override string GetHtmlTextDetail()
        {
            column_count = 3;
            StringBuilder sb = new StringBuilder();
            if (this.List != null)
            {
                Dictionary<int, string> tlist = new Dictionary<int, string>();
                foreach (FormControl c in this.List)
                {
                    if (!tlist.Keys.Contains(c.titleStyle))
                    {
                        tlist.Add(c.titleStyle, c.title);
                    }
                }
                foreach (var item in tlist)
                {
                    int i = 0;
                    //一行的列数
                    sb.Append("<div class='row'>");
                    sb.Append("<div class='col-lg-10 col-lg-offset-1'>");
                    sb.Append("<div class='panel panel-default box border primary'>");
                    sb.Append("<div class='box-title'>");
                    sb.Append("<span>" + item.Value + "</span>");
                    sb.Append("</div>");
                    sb.Append("<div class='panel-body'>");
                    sb.Append("<table class=\"my-table table\" border='0'  cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\">");
                    string fontcolor = "Orange";
                    string temp_value = "";
                    foreach (FormControl c in this.List)
                    {
                        if (c.titleStyle == item.Key)
                        {
                            temp_value = "";//table[c.FieldName] != null ? table[c.FieldName].ToString() : "";
                            c.SessionUid = SessionUID;
                            c.SessionUserDEPNAME = userDEPNAME;
                            if (i % column_count == 0)
                            {
                                sb.Append("<tr>");
                            }
                            if (c.Length >= 800)
                            {
                                if (i % column_count != 0)
                                {
                                    sb.Append("</tr>");
                                    i = i + 1;
                                }
                                sb.Append("<tr>");
                                sb.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + c.FieldDisName + "</td>\n");
                                sb.Append("<td colspan=colspan='" + (column_count * 2) + "' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n");
                                sb.Append("</tr>");
                                i = i + 2;
                            }
                            else
                            {
                                sb.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + c.FieldDisName + "</td>\n");
                                sb.Append("<td colspan=colspan='" + (column_count * 2) + "' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n");
                                if (i % column_count == (column_count - 1))
                                {
                                    sb.Append("</tr>");
                                }
                                i++;
                            }
                        }
                    }
                    sb.Append("</table>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                    sb.Append("</div>");
                }
            }
            this.HtmlText = sb.ToString();
            return this.HtmlText;
        }
    }
    
    #endregion

    #region 自开单功能类
    /// <summary>
    /// 自开单功能类
    /// </summary>
    public class Page_AddOrder : BootStrapControl
    {
        /// <summary>
        /// 用户
        /// </summary>
        public string SessionUID = "";
        /// <summary>
        /// 用户部门
        /// </summary>
        public string userDEPNAME = "";
        private string MAIN_INFO = "";
        public string INSERTORDERSQL = "";
        private string TableName = string.Empty;

        public override string GetHtmlText()
        {
            string error = "";
            try
            {
                MAIN_INFO = GetBodyContent(this.TableName, this.TableName);
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;

                Loger.Error("自开单功能类==>addOrderFunction()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                //没有异常
                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(MAIN_INFO))
                {
                    MAIN_INFO = "error!";
                }
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);
                string s_result = "";
                BtsInputButton btn1 = new BtsInputButton("开 单");
                btn1.InputID = "btnAddOrder";
                btn1.OnClick = "DefaultSave('开单')";// "$('#btn_OK').click();";
                BtsColumnedControl cc1 = new BtsColumnedControl(btn1);
                cc1.ClassName = "col-md-2";
                cc1.OffSet = "col-md-offset-4";

                BtsInputButton btn2 = new BtsInputButton("返 回");
                btn2.ClassName = "btn btn-warning";
                btn2.InputID = "btnCancel";
                btn2.OnClick = "showTableDiv();";

                BtsColumnedControl cc2 = new BtsColumnedControl(btn2);
                cc1.ClassName = "col-md-2";

                string s_btn = cc1.GetHtmlText() + cc2.GetHtmlText();
                string s_btnrow = BootStrapControl.AddDiv("row", s_btn);

                //附件添加
                int column_count = Convert.ToInt32(ConfigurationManager.AppSettings["column_count"]);
                string file = "<div class=\"row\"><div class=\"row\"><div class='col-lg-10 col-lg-offset-1'>";
                file += "<div class='panel panel-default box border primary'>";
                file += "<div class='box-title'><span>附件信息</span></div>";
                file += "<div class='panel-body'>";
                file += "<table class=\"table\" border='0'cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\"><tr><td style='border:0'  colspan='" + (column_count * 2) + "'><iframe id=\"file\"  style=\"width:700px;border:0px;\"></iframe></td></tr></table>";
                file += "</div></div></div></div></div>";
                s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + file + "<div class=\"separator\"></div>" + s_btnrow;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                s_result = BootStrapControl.AddDiv("panel", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);
                this.HtmlText = s_result;
            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }

        public string GetBodyContent(string tableName, string viewName)
        {
            FormList formList = new FormList(SessionUID, userDEPNAME);
            OracleDataBase odb = new OracleDataBase("0");
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = null;
            ArrayList dList = new ArrayList();

            if (searchHashtable != null && tableName != null)
            {
                seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(viewName) ? tableName : viewName).ToUpper()];
            }
            if (seaList != null)
            {
                StringBuilder upsql = new StringBuilder();
                for (int i = 0; i < seaList.Count; i++)
                {
                    FormControl fc = new FormControl();
                    DictionaryContent dc = (DictionaryContent)seaList[i];
                    if (!dc.style.Contains("40"))
                    {
                        continue;
                    }
                    fc.TableName = dc.tableName;
                    fc.FieldDisName = dc.fieldAliasName;
                    fc.FieldName = dc.fieldName;
                    fc.FieldType = dc.style;
                    fc.FIELDORDER = dc.colid;
                    fc.MAPINGCODE = dc.dm;
                    fc.MAPSQL = dc.mappsql;
                    fc.VALIDRULES = dc.validrules;
                    fc.SUBFIELD = dc.subfield;
                    fc.DefaultValue = dc.defaultvalue;
                    fc.DefaultType = dc.defaulttype;
                    fc.Type = dc.fieldType;
                    fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    fc.title = dc.title;
                    fc.titleStyle = dc.titleStyle;
                    formList.Add(fc);
                    upsql.AppendFormat("{0}∑", fc.FieldName + "|" + fc.FieldType + "|" + fc.IsNull + "|" + fc.MAPSQL);
                }
                INSERTORDERSQL = upsql.ToString();
            }
            string result = formList.GetHtmlText();
            return result;
        }
        /// <summary>
        /// 构造方法
        /// </summary>
        /// <param name="uid"></param>
        public Page_AddOrder(string _uid, string _depName, string _TableName)
        {
            SessionUID = _uid;
            userDEPNAME = _depName;
            this.TableName = _TableName;
        }
    } 
    #endregion

    #region 新增 修改页面的生成模板
    /// <summary>
    /// 新增 修改页面的生成模板
    /// 输入(2个参数):   表名 ;新增or修改
    /// 输出:(2个结果): 动态生成页面html文本，数据库字段名字
    /// </summary>
    public class Page_Template : BootStrapControl
    {
        //表名
        public string TableName { get; set; }
        public string TUid { get; set; }
        public string TdepName { get; set; }

        public Page_Template(string tablename, string Uid, string depName)
        {
            this.TableName = tablename;
            this.TUid = Uid;
            this.TdepName = depName;
        }
        //获取页面主要内容
        private string GetContent()
        {
            if (string.IsNullOrEmpty(this.TableName))
            {
                //这里以后可以优化，比如生成一个提示页面，提示表名输入有错等等
                return string.Empty;
            }
            string table = this.TableName;// Request.QueryString["table"];
            string view = "";
            FormList formList = new FormList(this.TUid, this.TdepName);
            string tablefields = String.Empty;
            OracleDataBase odb = new OracleDataBase("0");
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = null;
            ArrayList dList = new ArrayList();
            if (searchHashtable != null && table != null)
            {
                seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(view) ? table : view).ToUpper()];
            }
            if (seaList != null)
            {
                StringBuilder upsql = new StringBuilder();
                for (int i = 0; i < seaList.Count; i++)
                {

                    FormControl fc = new FormControl();
                    DictionaryContent dc = (DictionaryContent)seaList[i];

                    if (!dc.style.Contains("40") && !dc.style.Contains("31"))
                    {
                        continue;
                    }
                    tablefields = dc.fieldconfig;
                    fc.TableName = dc.tableName;
                    fc.FieldDisName = dc.fieldAliasName;
                    fc.FieldName = dc.fieldName;
                    fc.FieldType = dc.style;
                    fc.FIELDORDER = dc.colid;
                    fc.MAPINGCODE = dc.dm;
                    fc.MAPSQL = dc.mappsql;
                    fc.VALIDRULES = dc.validrules;
                    fc.SUBFIELD = dc.subfield;
                    fc.Type = dc.fieldType;
                    fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    fc.Nullable = dc.nullable;
                    fc.title = dc.title;
                    fc.titleStyle = dc.titleStyle;
                    fc.Updtaetable = dc.updtaetable;
                    //以下代码注意顺序，31的表示要更新到数据库，但是不要放到页面上
                    upsql.AppendFormat("{0}∑", fc.FieldName + "|" + fc.FieldType + "|" + fc.IsNull + "|" + fc.Nullable + "|" + dc.mappsql + "|" + dc.updtaetable + "|" + fc.MAPINGCODE);
                    if (dc.style.Contains("31"))
                    {
                        continue;
                    }
                    formList.Add(fc);
                }
                this.SQL_String = upsql.ToString();
            }
            formList.Flist = GetConfigs(tablefields, mainid);
            string result = formList.GetHtmlText();
            return result;
        }

        /// <summary>
        /// 获取是否需要根据某些字段来控制字段显隐或者验证
        /// </summary>
        /// <param name="tablefields"></param>
        /// <param name="mainId"></param>
        /// <returns></returns>
        public List<FieldConfig> GetConfigs(string tablefields, string mainId)
        {
            List<FieldConfig> flist = new List<FieldConfig>();
            string sql = "";
            try
            {
                //获取是否需要根据某些字段来控制字段显隐或者验证
                if (!string.IsNullOrWhiteSpace(tablefields))
                {
                    string[] fieldStrings = tablefields.Split(';');
                    string sqlwhere = fieldStrings.Aggregate("", (current, item) => current + ("'" + item + "',"));
                    sqlwhere = sqlwhere.TrimEnd(',');
                    sql = "select * from PZ_FIELDCONFIG where id in (" + sqlwhere + ")";
                    OracleDataBase odb = new OracleDataBase();
                    DataSet ds = odb.GetDataSet(sql);

                    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            //根据存储的sql获取字段值
                            sql = Convert.ToString(ds.Tables[0].Rows[i]["SQL"]) + " and " + Convert.ToString(ds.Tables[0].Rows[i]["SQLFIELD"]) + "='" + mainId + "'";
                            DataSet data = odb.GetDataSet(sql);
                            if (data != null && data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                            {
                                if (Convert.ToString(data.Tables[0].Rows[i]["title"]).ToUpper() == Convert.ToString(ds.Tables[0].Rows[i]["DEFAULTVALUE"]).ToUpper())
                                {
                                    string[] fieldnames = Convert.ToString(ds.Tables[0].Rows[i]["FIELDS"]).Split(';');
                                    foreach (string item in fieldnames)
                                    {
                                        FieldConfig fc = new FieldConfig();
                                        fc.fieldname = item;
                                        fc.result = Convert.ToString(ds.Tables[0].Rows[i]["RESULTVALUE"]);
                                        fc.type = Convert.ToString(ds.Tables[0].Rows[i]["TYPE"]);
                                        flist.Add(fc);
                                    }
                                }
                            }
                        }
                    }

                    // Session["fieldconfig"] = flist;
                }
            }
            catch (Exception ex)
            {
                Loger.Error("Ajax_GETJBXX=>GetConfigs异常,sql=" + sql, ex);
            }


            return flist;
        }

        private string GetContentDetail(string main_id)
        {
            if (string.IsNullOrEmpty(this.TableName))
            {
                //这里以后可以优化，比如生成一个提示页面，提示表名输入有错等等
                return string.Empty;
            }
            string table = this.TableName;
            string view = "";
            FormList formList = new FormList(this.TUid, this.TdepName);
            OracleDataBase odb = new OracleDataBase("0");
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = null;
            ArrayList dList = new ArrayList();
            string Sql = "select * from  V_" + TableName + " where id='" + main_id + "'";
            Hashtable dt = odb.getDBHT(Sql);
            if (searchHashtable != null && table != null)
            {
                seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(view) ? table : view).ToUpper()];
            }
            StringBuilder sb = new StringBuilder();
            if (seaList != null)
            {
                StringBuilder upsql = new StringBuilder();
                int column_count = 3;

                //一行的列数
                sb.Append("<div class='row'>");
                sb.Append("<div class='col-lg-10 col-lg-offset-1'>");
                sb.Append("<div class='panel panel-default box border primary'>");
                sb.Append("<div class='box-title'>");
                sb.Append("<span>工单详细</span>");
                sb.Append("</div>");
                sb.Append("<div class='panel-body'>");
                sb.Append("<table class=\"my-table table\" border='0'  cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\">");
                string fontcolor = "Orange";
                string temp_value = "";
                int Length = 0;
                int j = 0;
                for (int i = 0; i < seaList.Count; i++)
                {

                    DictionaryContent dc = (DictionaryContent)seaList[i];
                    if (!dc.style.Contains("40"))
                    {
                        continue;
                    }
                    temp_value = dt[dc.fieldName] != null ? dt[dc.fieldName].ToString() : ""; ;
                    Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    if (j % column_count == 0)
                    {
                        sb.Append("<tr>");
                    }
                    if (Length >= 500)
                    {
                        if (j % column_count != 0)
                        {
                            sb.Append("</tr>");
                            j = j + 1;
                        }
                        sb.Append("<tr>");
                        sb.Append("<td  class=\"td_text table-border\" style=\"color:black;\">" + dc.fieldAliasName + "</td>\n");
                        sb.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n");
                        sb.Append("</tr>");
                        j = j + 2;
                    }
                    else
                    {
                        sb.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + dc.fieldAliasName + "</td>\n");
                        sb.Append("<td class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n");
                        if (j % column_count == (column_count - 1))
                        {
                            sb.Append("</tr>");
                        }
                        j++;
                    }
                }
                sb.Append("</table>");
                sb.Append("</div>");
                sb.Append("</div>");
                sb.Append("</div>");
                sb.Append("</div>");
                this.SQL_String = upsql.ToString();
            }
            string result = sb.ToString();
            return result;
        }

        /// <summary>
        /// 根据表名及ID获取信息
        /// </summary>
        /// <param name="main_id"></param>
        /// <param name="tablename"></param>
        /// <returns></returns>
        private string GetContentDetail(string main_id, string tablename)
        {
            if (string.IsNullOrEmpty(this.TableName))
            {
                //这里以后可以优化，比如生成一个提示页面，提示表名输入有错等等
                return string.Empty;
            }
            string table = this.TableName;
            string view = "";
            FormList formList = new FormList(this.TUid, this.TdepName);
            OracleDataBase odb = new OracleDataBase("0");
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = null;
            ArrayList dList = new ArrayList();
            string Sql = "select * from  " + tablename + " where id='" + main_id + "'";
            Hashtable dt = odb.getDBHT(Sql);
            if (searchHashtable != null && table != null)
            {
                seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(view) ? table : view).ToUpper()];
            }
            StringBuilder sb = new StringBuilder();
            if (seaList != null)
            {
                StringBuilder upsql = new StringBuilder();
                int column_count = 3;

                //一行的列数
                sb.Append("<div class='row'>");
                sb.Append("<div class='col-lg-10 col-lg-offset-1'>");
                sb.Append("<div class='panel panel-default box border primary'>");
                sb.Append("<div class='box-title'>");
                sb.Append("<span>工单详细</span>");
                sb.Append("</div>");
                sb.Append("<div class='panel-body'>");
                sb.Append("<table class=\"my-table table\" border='0'  cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\">");
                string fontcolor = "Orange";
                string temp_value = "";
                int Length = 0;
                int j = 0;
                for (int i = 0; i < seaList.Count; i++)
                {

                    DictionaryContent dc = (DictionaryContent)seaList[i];
                    if (!dc.style.Contains("40"))
                    {
                        continue;
                    }
                    temp_value = dt[dc.fieldName] != null ? dt[dc.fieldName].ToString() : ""; ;
                    Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    if (j % column_count == 0)
                    {
                        sb.Append("<tr>");
                    }
                    if (Length >= 500)
                    {
                        if (j % column_count != 0)
                        {
                            sb.Append("</tr>");
                            j = j + 1;
                        }
                        sb.Append("<tr>");
                        sb.Append("<td  class=\"td_text table-border\" style=\"color:black;\">" + dc.fieldAliasName + "</td>\n");
                        sb.Append("<td colspan='5' class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n");
                        sb.Append("</tr>");
                        j = j + 2;
                    }
                    else
                    {
                        sb.Append("<td  class=\"td_text table-border\" style=\"color:black\">" + dc.fieldAliasName + "</td>\n");
                        sb.Append("<td class=\"td_value table-border\" style=\"color:" + fontcolor + "\">" + temp_value + "&nbsp;</td>\n");
                        if (j % column_count == (column_count - 1))
                        {
                            sb.Append("</tr>");
                        }
                        j++;
                    }
                }
                sb.Append("</table>");
                sb.Append("</div>");
                sb.Append("</div>");
                sb.Append("</div>");
                sb.Append("</div>");
                this.SQL_String = upsql.ToString();
            }
            string result = sb.ToString();
            return result;
        }

        public string MAIN_INFO;
        //拼接字段
        public string SQL_String = string.Empty;
        public string mainid;
        //输出页面htmltext
        public override string GetHtmlText()
        {
            string error = "";
            try
            {
                //GetBodyContent();
                MAIN_INFO = GetContent();
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;

                Loger.Error("Page_Template==>GetContent()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                //没有异常

                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(MAIN_INFO))
                {
                    MAIN_INFO = "error!";
                }
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);

                string s_result = "";

                //按钮组理论上也可以配到数据库里
                #region 按钮组
                BtsInputButton btn1 = new BtsInputButton("保 存");
                btn1.InputID = "btnSaveOK";
                btn1.OnClick = "DefaultSave('修改')";
                BtsColumnedControl cc1 = new BtsColumnedControl(btn1);
                cc1.ClassName = "col-xs-2 col-md-2 ";
                cc1.OffSet = "col-md-offset-4";
                BtsInputButton btn2 = new BtsInputButton("返 回");
                btn2.ClassName = "btn btn-warning";
                btn2.InputID = "btnCancelBack";

                btn2.OnClick = "showTableDiv();";
                BtsColumnedControl cc2 = new BtsColumnedControl(btn2);
                cc2.ClassName = "col-xs-2 col-md-2 ";

                string s_btn = cc1.GetHtmlText() + cc2.GetHtmlText();
                string s_btnrow = BootStrapControl.AddDiv("row", s_btn);
                #endregion

                //附件添加
                int column_count = Convert.ToInt32(ConfigurationManager.AppSettings["column_count"]);
                string file = "<div class=\"row\"><div class=\"row\"><div class='col-lg-10 col-lg-offset-1'>";
                file += "<div class='panel panel-default box border primary'>";
                file += "<div class='box-title'><span>附件信息</span></div>";
                file += "<div class='panel-body'>";
                file += "<table class=\"table\" border='0'cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\"><tr><td style='border:0'  colspan='" + (column_count * 2) + "'><iframe id=\"file\"  style=\"width:500px;border:0px;\"></iframe></td></tr></table>";
                file += "</div></div></div></div></div>";
                s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + file + "<div class=\"separator\"></div>" + s_btnrow;
                //再填充到panel里，比较美观
                //以后可以再优化，比如div大小，用panel或者tab或者其他bootstrap页面填充都可以做到数据库里配置
                //s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + s_btnrow;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                s_result = BootStrapControl.AddDiv("panel", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);


                this.HtmlText = s_result;

            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }
        //输出页面htmltext  --不带编辑和附件信息,用户展示
        public string GetNoEditHtmlText()
        {
            string error = "";
            try
            {
                //GetBodyContent();
                MAIN_INFO = GetContent();
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;

                Loger.Error("Page_Template==>GetContent()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                //没有异常

                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(MAIN_INFO))
                {
                    MAIN_INFO = "error!";
                }
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);

                string s_result = "";

                s_result = c_temp.HtmlText;

                //s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + s_btnrow;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                //   s_result = BootStrapControl.AddDiv("panel panel-default", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);


                this.HtmlText = s_result;

            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }
        public string GetNoEditHtmlTextDetail(string main_id)
        {
            string error = "";
            try
            {
                //GetBodyContent();
                MAIN_INFO = GetContentDetail(main_id);
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;

                Loger.Error("Page_Template==>GetContent()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                //没有异常

                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(MAIN_INFO))
                {
                    MAIN_INFO = "error!";
                }
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);

                string s_result = "";

                s_result = c_temp.HtmlText;

                //s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + s_btnrow;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                //   s_result = BootStrapControl.AddDiv("panel panel-default", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);


                this.HtmlText = s_result;

            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }

        /// <summary>
        /// 根据表名及ID获取表单信息（无需编辑）
        /// </summary>
        /// <param name="main_id"></param>
        /// <param name="tablename"></param>
        /// <returns></returns>
        public string GetNoEditHtmlTextDetail(string main_id, string tablename)
        {
            string error = "";
            try
            {
                //GetBodyContent();
                MAIN_INFO = GetContentDetail(main_id, tablename);
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;

                Loger.Error("Page_Template==>GetContent()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                //没有异常

                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(MAIN_INFO))
                {
                    MAIN_INFO = "error!";
                }
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);

                string s_result = "";

                s_result = c_temp.HtmlText;

                //s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + s_btnrow;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                //   s_result = BootStrapControl.AddDiv("panel panel-default", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);


                this.HtmlText = s_result;

            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }
    } 
    #endregion

   #region 读取模板
    public class Page_ReadTemplate : BootStrapControl
    {
        //表名
        public string TableName { get; set; }
        public string TUid { get; set; }
        public string TdepName { get; set; }

        public Page_ReadTemplate(string tablename, string Uid, string depName)
        {
            this.TableName = tablename;
            this.TUid = Uid;
            this.TdepName = depName;
        }
        //获取页面主要内容
        private string GetBodyContent()
        {
            if (string.IsNullOrEmpty(this.TableName))
            {
                //这里以后可以优化，比如生成一个提示页面，提示表名输入有错等等
                return string.Empty;
            }
            string table = this.TableName;// Request.QueryString["table"];
            string view = "";
            FormList formList = new FormList(this.TUid, this.TdepName);
            OracleDataBase odb = new OracleDataBase("0");
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = null;
            ArrayList dList = new ArrayList();
            if (searchHashtable != null && table != null)
            {
                seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(view) ? table : view).ToUpper()];
            }
            if (seaList != null)
            {
                StringBuilder upsql = new StringBuilder();
                for (int i = 0; i < seaList.Count; i++)
                {

                    FormControl fc = new FormControl();
                    DictionaryContent dc = (DictionaryContent)seaList[i];
                    if (!dc.style.Contains("40") && !dc.style.Contains("31"))
                    {
                        continue;
                    }
                    fc.TableName = dc.tableName;
                    fc.FieldDisName = dc.fieldAliasName;
                    fc.FieldName = dc.fieldName;
                    fc.FieldType = dc.style;
                    fc.FIELDORDER = dc.colid;
                    fc.MAPINGCODE = dc.dm;
                    fc.MAPSQL = dc.mappsql;
                    fc.VALIDRULES = dc.validrules;
                    fc.SUBFIELD = dc.subfield;
                    fc.Type = dc.fieldType;
                    fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    fc.Nullable = dc.nullable;
                    fc.title = dc.title;
                    fc.titleStyle = dc.titleStyle;
                    //以下代码注意顺序，31的表示要更新到数据库，但是不要放到页面上
                    upsql.AppendFormat("{0}∑", fc.FieldName + "|" + fc.FieldType + "|" + fc.IsNull + "|" + fc.Nullable + "|" + dc.mappsql);
                    if (dc.style.Contains("31"))
                    {
                        continue;
                    }
                    formList.Add(fc);
                }
                this.SQL_String = upsql.ToString();
            }
            string result = formList.GetHtmlText();
            return result;
        }
        public string Page_Info;
        //拼接字段
        public string SQL_String = string.Empty;
        //输出页面htmltext
        public override string GetHtmlText()
        {
            string error = "";
            try
            {
                Page_Info = GetBodyContent();
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;
                Loger.Error("Page_Template==>GetContent()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                //没有异常

                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(Page_Info))
                {
                    Page_Info = "error!";
                }
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", Page_Info);
                string s_result = c_temp.HtmlText;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                s_result = BootStrapControl.AddDiv("panel", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);
                this.HtmlText = s_result;
            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }

    }
   #endregion

    #region 无附件模板
    public class Page_AnnexTemplate : BootStrapControl
    {
        //表名
        public string TableName { get; set; }
        public string TUid { get; set; }
        public string TdepName { get; set; }

        public Page_AnnexTemplate(string tablename, string Uid, string depName)
        {
            this.TableName = tablename;
            this.TUid = Uid;
            this.TdepName = depName;
        }
        //获取页面主要内容
        private string GetBodyContent()
        {
            if (string.IsNullOrEmpty(this.TableName))
            {
                //这里以后可以优化，比如生成一个提示页面，提示表名输入有错等等
                return string.Empty;
            }
            string table = this.TableName;// Request.QueryString["table"];
            string view = "";
            FormList formList = new FormList(this.TUid, this.TdepName);
            OracleDataBase odb = new OracleDataBase("0");
            Hashtable searchHashtable = InitCache.xwbm_sjzd;
            ArrayList seaList = null;
            ArrayList dList = new ArrayList();
            if (searchHashtable != null && table != null)
            {
                seaList = (ArrayList)searchHashtable[(string.IsNullOrWhiteSpace(view) ? table : view).ToUpper()];
            }
            if (seaList != null)
            {
                StringBuilder upsql = new StringBuilder();
                for (int i = 0; i < seaList.Count; i++)
                {

                    FormControl fc = new FormControl();
                    DictionaryContent dc = (DictionaryContent)seaList[i];
                    if (!dc.style.Contains("40") && !dc.style.Contains("31"))
                    {
                        continue;
                    }
                    fc.TableName = dc.tableName;
                    fc.FieldDisName = dc.fieldAliasName;
                    fc.FieldName = dc.fieldName;
                    fc.FieldType = dc.style;
                    fc.FIELDORDER = dc.colid;
                    fc.MAPINGCODE = dc.dm;
                    fc.MAPSQL = dc.mappsql;
                    fc.VALIDRULES = dc.validrules;
                    fc.SUBFIELD = dc.subfield;
                    fc.Type = dc.fieldType;
                    fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    fc.Nullable = dc.nullable;
                    fc.title = dc.title;
                    fc.titleStyle = dc.titleStyle;
                    //以下代码注意顺序，31的表示要更新到数据库，但是不要放到页面上
                    upsql.AppendFormat("{0}∑", fc.FieldName + "|" + fc.FieldType + "|" + fc.IsNull + "|" + fc.Nullable + "|" + dc.mappsql);
                    if (dc.style.Contains("31"))
                    {
                        continue;
                    }
                    formList.Add(fc);
                }
                this.SQL_String = upsql.ToString();
            }
            string result = formList.GetHtmlText();
            return result;
        }
        public string Page_Info;
        //拼接字段
        public string SQL_String = string.Empty;
        //输出页面htmltext
        public override string GetHtmlText()
        {
            string error = "";
            try
            {
                Page_Info = GetBodyContent();
            }
            catch (Exception ex)
            {
                error = ex.Message + ex.StackTrace;
                Loger.Error("Page_Template==>GetContent()=====》", ex);
            }

            if (string.IsNullOrEmpty(error))
            {
                BootStrapControl c_temp = new BootStrapControl();
                if (string.IsNullOrEmpty(Page_Info))
                {
                    Page_Info = "error!";
                }
                #region 按钮组
                BtsInputButton btn1 = new BtsInputButton("保 存");
                btn1.InputID = "btnSaveOK";
                btn1.OnClick = "DefaultSave('修改')";
                BtsColumnedControl cc1 = new BtsColumnedControl(btn1);
                cc1.ClassName = "col-xs-2 col-md-2 ";
                cc1.OffSet = "col-md-offset-4";
                #endregion
                string s_btnrow = BootStrapControl.AddDiv("row", cc1.GetHtmlText());
                c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", Page_Info);
                string s_result = c_temp.HtmlText + "<div class=\"separator\"></div>" + s_btnrow;
                s_result = BootStrapControl.AddDiv("panel-body", s_result);
                s_result = BootStrapControl.AddDiv("panel", s_result);
                s_result = BootStrapControl.AddDiv("col-lg-12", s_result);
                this.HtmlText = s_result;
            }
            else
            {
                //出现异常
                BtsPage404 page404 = new BtsPage404();
                page404.Remark = "对不起，出错了...</br>error:" + error;
                page404.BackUrl = "javascript:showTableDiv();";
                this.HtmlText = page404.GetHtmlText();
            }
            return this.HtmlText;
        }
    }
    #endregion

    #region 动态页面回传参数类
    /// <summary>
    /// 动态页面回传参数类
    /// </summary>
    public class DynamicParam
    {
        public string InnerHtml = string.Empty;
        public string StrParams = string.Empty;

        public DynamicParam()
        {
        }
        public DynamicParam(string s1)
        {
            InnerHtml = s1;
        }

        public DynamicParam(string s1, string s2)
        {
            InnerHtml = s1;
            StrParams = s2;
        }
    }
    #endregion 
}
