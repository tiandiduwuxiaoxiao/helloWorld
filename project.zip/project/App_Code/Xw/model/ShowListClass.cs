﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///ShowListClass 的摘要说明
/// </summary>
public class ShowListClass
{
	public ShowListClass()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    public string name { get; set; }
    public string length { get; set; }
    public string listlenght { get; set; }
}