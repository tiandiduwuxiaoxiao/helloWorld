﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///ImageOption 的摘要说明
/// </summary>
public class ImageOption
{
	public ImageOption()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    //实体类1
   //public string alt { get; set; }//图片名
   // public string pid { get; set; }//图片id
   // public string src { get; set; }//原图地址
   // public string thumb { get; set; }//缩略图地址
    //实体类2
    public string href { get; set; }//原图地址
    public string title { get; set; }//图片名
}