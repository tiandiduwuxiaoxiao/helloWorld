﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///EChartOption 的摘要说明
/// </summary>
public class EChartOption
{
	public EChartOption()
	{
	}
    public string Title { get; set; }
    public List<string> Category { get; set; }
    public List<Series> Series { get; set; }
    public List<string> Legend { get; set; }
}