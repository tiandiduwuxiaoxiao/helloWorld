﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///MapOption 的摘要说明
/// </summary>
public class MapOption
{
	public MapOption()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    public string X { get; set; }
    public string Y { get; set; }
    public string NAME { get; set; }
}