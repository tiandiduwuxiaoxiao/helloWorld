﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///FieldConfig 的摘要说明
/// </summary>
public class FieldConfig
{
	public FieldConfig()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    public string fieldname { get; set; }//字段名
    public string type { get; set; }//类型（是否隐藏，是否验证）
    public string result { get; set; }//隐藏或验证

}