﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using log4net.Core;
using log4net.Repository.Hierarchy;
using logertest.Func;

namespace logertest
{
    public class WebLogImpl : LogImpl, IWebLog
    {
        /// <summary>
        /// The fully qualified name of this declaring type not the type of any subclass.
        /// </summary>
        private readonly static Type ThisDeclaringType = typeof(WebLogImpl);

        public WebLogImpl(ILogger logger)
            : base(logger)
        {
        }

        #region Implementation of IWebLog

        public void Info(string username,string logtype,string clientIP, string requestUrl, object message)
        {
            Info(username, logtype, clientIP, requestUrl, message, null);
        }

        public void Info(string username, string logtype, string clientIP, string requestUrl, object message, System.Exception t)
        {
            if (this.IsInfoEnabled)
            {
                LoggingEvent loggingEvent = new LoggingEvent(ThisDeclaringType, Logger.Repository, Logger.Name, Level.Info, message, t);
                loggingEvent.Properties["ClientIP"] = clientIP;
                loggingEvent.Properties["RequestUrl"] = requestUrl;
                loggingEvent.Properties["Username"] = username;
                loggingEvent.Properties["Logtype"] = logtype;
                Logger.Log(loggingEvent);
            }
        }

        public void Warn(string username, string logtype, string clientIP, string requestUrl, object message)
        {
            Warn(username, logtype, clientIP, requestUrl, message, null);
        }

        public void Warn(string username, string logtype, string clientIP, string requestUrl, object message, System.Exception t)
        {
            if (this.IsWarnEnabled)
            {
                LoggingEvent loggingEvent = new LoggingEvent(ThisDeclaringType, Logger.Repository, Logger.Name, Level.Warn, message, t);
                loggingEvent.Properties["ClientIP"] = clientIP;
                loggingEvent.Properties["RequestUrl"] = requestUrl;
                loggingEvent.Properties["Username"] = username;
                loggingEvent.Properties["Logtype"] = logtype;
                Logger.Log(loggingEvent);
            }
        }

        public void Error(string username, string logtype, string clientIP, string requestUrl, object message)
        {
            Error(username, logtype, clientIP, requestUrl, message, null);
        }

        public void Error(string username, string logtype, string clientIP, string requestUrl, object message, System.Exception t)
        {
            if (this.IsErrorEnabled)
            {
                LoggingEvent loggingEvent = new LoggingEvent(ThisDeclaringType, Logger.Repository, Logger.Name, Level.Error, message, t);
                loggingEvent.Properties["ClientIP"] = clientIP;
                loggingEvent.Properties["RequestUrl"] = requestUrl;
                loggingEvent.Properties["Username"] = username;
                loggingEvent.Properties["Logtype"] = logtype;
                Logger.Log(loggingEvent);
            }
        }

        public void Fatal(string username, string logtype, string clientIP, string requestUrl, object message)
        {
            Fatal(username, logtype, clientIP, requestUrl, null);
        }

        public void Fatal(string username, string logtype, string clientIP, string requestUrl, object message, System.Exception t)
        {
            if (this.IsFatalEnabled)
            {
                LoggingEvent loggingEvent = new LoggingEvent(ThisDeclaringType, Logger.Repository, Logger.Name, Level.Fatal, message, t);
                loggingEvent.Properties["ClientIP"] = clientIP;
                loggingEvent.Properties["RequestUrl"] = requestUrl;
                loggingEvent.Properties["Username"] = username;
                loggingEvent.Properties["Logtype"] = logtype;
                Logger.Log(loggingEvent);
            }
        }
        public void Debug(string username, string logtype, string clientIP, string requestUrl, object message)
        {
            Debug(username, logtype, clientIP, requestUrl, null);
        }

        public void Debug(string username, string logtype, string clientIP, string requestUrl, object message, System.Exception t)
        {
            if (this.IsDebugEnabled)
            {
                LoggingEvent loggingEvent = new LoggingEvent(ThisDeclaringType, Logger.Repository, Logger.Name, Level.Fatal, message, t);
                loggingEvent.Properties["ClientIP"] = clientIP;
                loggingEvent.Properties["RequestUrl"] = requestUrl;
                loggingEvent.Properties["Username"] = username;
                loggingEvent.Properties["Logtype"] = logtype;
                Logger.Log(loggingEvent);
            }
        }
        #endregion Implementation of IWebLog
    }
}