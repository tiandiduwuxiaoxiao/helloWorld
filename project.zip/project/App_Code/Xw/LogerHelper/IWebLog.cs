﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using log4net;

namespace logertest.Func
{
    public interface IWebLog : ILog
    {
        void Info(string username, string logtype, string clientIP, string requestUrl, object message);
        void Info(string username, string logtype, string clientIP, string requestUrl, object message, Exception t);

        void Warn(string username, string logtype, string clientIP, string requestUrl, object message);
        void Warn(string username, string logtype, string clientIP, string requestUrl, object message, Exception t);

        void Error(string username, string logtype, string clientIP, string requestUrl, object message);
        void Error(string username, string logtype, string clientIP, string requestUrl, object message, Exception t);

        void Fatal(string username, string logtype, string clientIP, string requestUrl, object message);
        void Fatal(string username, string logtype, string clientIP, string requestUrl, object message, Exception t);

        void Debug(string username, string logtype, string clientIP, string requestUrl, object message);
        void Debug(string username, string logtype, string clientIP, string requestUrl, object message, Exception t);

    }
}