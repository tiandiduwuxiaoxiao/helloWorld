﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Layout;
using Maticsoft.DBUtility;

namespace logertest.Func
{
    public static class Log4netHelper
    {

        //记录异常日志数据库连接字符串
        private static string _ConnectionString = PubConstant.GetConnectionString("PropDBConn");

        /// <summary>
        /// 使用SQLSERVER记录异常日志
        /// </summary>
        /// <Author>Ryanding</Author>
        /// <date>2011-05-01</date>
        public static void LoadADONetAppender()
        {
            
            LoadRollingFileAppender();
        

            log4net.Repository.Hierarchy.Hierarchy hier =
              log4net.LogManager.GetLoggerRepository() as log4net.Repository.Hierarchy.Hierarchy;

            if (hier != null)
            {
                log4net.Appender.AdoNetAppender adoAppender = new log4net.Appender.AdoNetAppender();
                adoAppender.Name = "AdoNetAppender";
                adoAppender.CommandType = CommandType.Text;
                adoAppender.BufferSize = 1;
                adoAppender.ConnectionType = "System.Data.OracleClient.OracleConnection,System.Data.OracleClient, Version=2.0.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089";
                adoAppender.ConnectionString = _ConnectionString;
                adoAppender.CommandText = @"INSERT INTO SYSTEMLOG (log_Date,log_Level,log_Logger, log_ClientIP, log_RequestUrl, log_Message, log_Exception,LOG_TYPE,LOG_CREATEBY) VALUES (:log_Date,:log_Level,:log_Logger, :log_ClientIP, :log_RequestUrl, :log_Message, :log_Exception,:LOG_TYPE,:LOG_CREATEBY)";
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_Date", DbType = System.Data.DbType.DateTime, Layout = new log4net.Layout.RawTimeStampLayout() });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_Level", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%level")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_Logger", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%logger")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_ClientIP", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%property{ClientIP}")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_RequestUrl", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%property{RequestUrl}")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_Message", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%message")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":log_Exception", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%exception")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":LOG_TYPE", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%property{Logtype}")) });
                adoAppender.AddParameter(new AdoNetAppenderParameter { ParameterName = ":LOG_CREATEBY", DbType = System.Data.DbType.String, Layout = new Layout2RawLayoutAdapter(new PatternLayout("%property{Username}")) });
                adoAppender.ActivateOptions();
                BasicConfigurator.Configure(adoAppender);
            }


        }

        /// <summary>
        /// 使用文本记录异常日志
        /// </summary>
        /// <Author>Ryanding</Author>
        /// <date>2011-05-01</date>
        public static void LoadFileAppender()
        {
            string currentPath = AppDomain.CurrentDomain.BaseDirectory;
            string txtLogPath = string.Empty;
            string iisBinPath = AppDomain.CurrentDomain.RelativeSearchPath;

            if (!string.IsNullOrEmpty(iisBinPath))
                txtLogPath = Path.Combine(iisBinPath, "ErrorLog.txt");
            else
                txtLogPath = Path.Combine(currentPath, "ErrorLog.txt");

            log4net.Repository.Hierarchy.Hierarchy hier =
             log4net.LogManager.GetLoggerRepository() as log4net.Repository.Hierarchy.Hierarchy;

            FileAppender fileAppender = new FileAppender();
            fileAppender.Name = "LogFileAppender";
            fileAppender.File = txtLogPath;
            fileAppender.AppendToFile = true;

            PatternLayout patternLayout = new PatternLayout();
            patternLayout.ConversionPattern = "记录时间：%date 线程ID:[%thread] 日志级别：%-5level 出错类：%logger property:[%property{NDC}] - 错误描述：%message%newline";
            patternLayout.ActivateOptions();
            fileAppender.Layout = patternLayout;

            //选择UTF8编码，确保中文不乱码。
            fileAppender.Encoding = Encoding.UTF8;

            fileAppender.ActivateOptions();
            BasicConfigurator.Configure(fileAppender);

        }
        /// <summary>
        /// 使用文本记录异常日志
        /// </summary>
        /// <Author>Ryanding</Author>
        /// <date>2011-05-01</date>
        public static void LoadRollingFileAppender()
        {
            log4net.Repository.Hierarchy.Hierarchy hier =
             log4net.LogManager.GetLoggerRepository() as log4net.Repository.Hierarchy.Hierarchy;

            RollingFileAppender rollingFile = new RollingFileAppender();
            rollingFile.File = "log/Penavicoxm";
            rollingFile.AppendToFile = true;
            rollingFile.RollingStyle=RollingFileAppender.RollingMode.Date;
            rollingFile.DatePattern = ".yyyyMMdd'.txt'";
            rollingFile.StaticLogFileName = false;

            PatternLayout patternLayout = new PatternLayout();
            patternLayout.ConversionPattern = "%d [%t] %-5p %c - %m%n";
            patternLayout.ActivateOptions();
            rollingFile.Layout = patternLayout;

            //选择UTF8编码，确保中文不乱码。
            rollingFile.Encoding = Encoding.UTF8;

            rollingFile.ActivateOptions();
            BasicConfigurator.Configure(rollingFile);

        }
    }
}