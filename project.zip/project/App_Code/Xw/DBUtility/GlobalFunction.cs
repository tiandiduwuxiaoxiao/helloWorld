﻿using System;
using System.IO;
using System.Text;
using System.Web;

namespace GlobalFunction
{
    /// <summary>
    ///     加密/解密/授权
    /// </summary>
    public class GlobalFunction
    {
        public delegate StringBuilder HugegisDecode(StringBuilder str);

        //解码
        public delegate StringBuilder HugegisEncode(StringBuilder str);

        public const string licenseError = "0x000001-授权文件已过期，请重新授权！";

        //解码

        /// <summary>
        ///     输出日志
        /// </summary>
        public void WriteLog(string logStr)
        {
            string time = DateTime.Now.ToString();
            string filePath = "C:\\log.txt";
            FileStream fst;
            if (!File.Exists(filePath))
                fst = new FileStream(filePath, FileMode.CreateNew);
            else
                fst = new FileStream(filePath, FileMode.Append); //追加模式
            StreamWriter stw = new StreamWriter(fst, Encoding.GetEncoding("utf-8")); //指定编码.否则将出错!
            stw.WriteLine(time + "----" + logStr);
            stw.Close();
            fst.Close();
        }

        /// <summary>
        ///     解密
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>解密字符串</returns>
        public static string Decode(string str)
        {
            //StringBuilder result = new StringBuilder();
            
            ////因为没注册 所以先注释,操蛋，因为当时加encrypt.dll的引用
            //DllInvoke dllInvoke = new DllInvoke(HttpContext.Current.Server.MapPath(@"~/bin/Encrypt.dll"));
            //HugegisDecode hugegisDecode = (HugegisDecode)dllInvoke.Invoke("HugegisDecode", typeof(HugegisDecode));
            //StringBuilder decodeBuilder = new StringBuilder(str); 
            //result = EncryptServices.HugegisDecode(str);
            return EncryptServices.HugegisDecode(str);
        }

        /// <summary>
        ///     加密
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>加密字符串</returns>
        public static string Encode(string str)
        {
            StringBuilder result = new StringBuilder();
            //DllInvoke dllInvoke = new DllInvoke(HttpContext.Current.Server.MapPath(@"~/bin/Encrypt.dll"));
            //HugegisEncode hugegisEncode = (HugegisEncode)dllInvoke.Invoke("HugegisEncode", typeof(HugegisEncode));
            //StringBuilder decodeBuilder = new StringBuilder(str); 
            //result = hugegisEncode(decodeBuilder);
            return result.ToString();
        }

        /// <summary>
        ///     授权
        /// </summary>
        /// <returns>true,false</returns>
        public static bool checkHugegisLicense()
        {
            bool result = false;
            string pFileName = HttpContext.Current.Server.MapPath(@"~/bin/hugegis.lic");
            if (!File.Exists(pFileName))
                return result;

            StreamReader pSr = new StreamReader(pFileName);
            string license = "", str = "";
            while (!pSr.EndOfStream)
            {
                str = pSr.ReadLine();
                license += str + "\n";
            }
            pSr.Close();

            if (license.Trim() == "")
                return result;

            license = license.Substring(0, 46);
            license = Decode(license);
            if (license.Length != 6)
                return result;
            string year = "20" + license.Substring(0, 2);
            string month = license.Substring(2, 2);
            string date = license.Substring(4, 2);

            DateTime pDt = DateTime.Parse(year + "-" + month + "-" + date + " 23:59:59");
            result = (DateTime.Compare(DateTime.Now, pDt) < 0);

            return result;
        }
    }
}