using System;
using System.Collections;
using System.Data;
using System.Data.OracleClient;
using hugegis.DBUtility;

namespace Maticsoft.DBUtility
{
    /// <summary>
    ///     Copyright (C) 2012 LiTianPing
    ///     ���ݷ��ʻ�����(����Oracle)
    ///     �����û������޸������Լ���Ŀ����Ҫ��
    /// </summary>
    public abstract class DbHelperOra
    {
        //���ݿ������ַ���(web.config������)�����Զ�̬����connectionString֧�ֶ����ݿ�.		
        //public static string connectionString = Decrypt.PropDBConn;

        public static string connectionString = PubConstant.GetConnectionString("PropDBConn");
        #region ���÷���

        /// <summary>
        ///     �õ�web.config������������ݿ������ַ���
        /// </summary>
        /// <param name="pSectionName">���ýڵ�</param>
        /// <returns>�����ַ���</returns>
        public static string GetConnectionString(string pSectionName)
        {
            return PubConstant.GetConnectionString(pSectionName);
        }

        /// <summary>
        ///     ��ȡ���ݿ���
        /// </summary>
        /// <param name="pSectionName">���ýڵ�</param>
        /// <returns>���ݿ���</returns>
        public static string GetConnectionStringByUserName(string pSectionName)
        {
            return PubConstant.GetConnectionStringByUserName(pSectionName);
        }

        public static int GetMaxID(string FieldName, string TableName)
        {
            string strsql = "select max(" + FieldName + ")+1 from " + TableName;
            object obj = GetSingle(strsql);
            if (obj == null)
            {
                return 1;
            }
            else
            {
                return int.Parse(obj.ToString());
            }
        }

        public static bool Exists(string strSql)
        {
            object obj = GetSingle(strSql);
            int cmdresult;
            if ((Equals(obj, null)) || (Equals(obj, DBNull.Value)))
            {
                cmdresult = 0;
            }
            else
            {
                cmdresult = int.Parse(obj.ToString());
            }
            if (cmdresult == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool Exists(string strSql, params OracleParameter[] cmdParms)
        {
            object obj = GetSingle(strSql, cmdParms);
            int cmdresult;
            if ((Equals(obj, null)) || (Equals(obj, DBNull.Value)))
            {
                cmdresult = 0;
            }
            else
            {
                cmdresult = int.Parse(obj.ToString());
            }
            if (cmdresult == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        #endregion

        #region  ִ�м�SQL���

        /// <summary>
        ///     ִ��SQL��䣬����Ӱ��ļ�¼��
        /// </summary>
        /// <param name="SQLString">SQL���</param>
        /// <returns>Ӱ��ļ�¼��</returns>
        public static int ExecuteSql(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = new OracleCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        int rows = cmd.ExecuteNonQuery();
                        return rows;
                    }
                    catch (OracleException E)
                    {
                        Loger.Error("ExecuteSql()==>SQLString:" + SQLString, E);
                        return -1;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        /// <summary>
        ///     ִ�ж���SQL��䣬ʵ�����ݿ�����
        /// </summary>
        /// <param name="SQLStringList">����SQL���</param>
        public static void ExecuteSqlTran(ArrayList SQLStringList)
        {
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                OracleTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                }
                catch (OracleException E)
                {
                    tx.Rollback();
                    Loger.Error("", E);
                }
            }
        }

        /// <summary>
        ///     ִ�д�һ���洢���̲����ĵ�SQL��䡣
        /// </summary>
        /// <param name="SQLString">SQL���</param>
        /// <param name="content">��������,����һ���ֶ��Ǹ�ʽ���ӵ����£���������ţ�����ͨ�������ʽ����</param>
        /// <returns>Ӱ��ļ�¼��</returns>
        public static int ExecuteSql(string SQLString, string content)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                OracleCommand cmd = new OracleCommand(SQLString, connection);
                OracleParameter myParameter = new OracleParameter("@content", OracleType.NVarChar);
                myParameter.Value = content;
                cmd.Parameters.Add(myParameter);
                try
                {
                    connection.Open();
                    int rows = cmd.ExecuteNonQuery();
                    return rows;
                }
                catch (OracleException E)
                {
                    Loger.Error("ExecuteSql()==>SQLString:" + SQLString, E);
                    throw new Exception(E.Message);
                }
                finally
                {
                    cmd.Dispose();
                    connection.Close();
                }
            }
        }

        /// <summary>
        ///     �����ݿ������ͼ���ʽ���ֶ�(������������Ƶ���һ��ʵ��)
        /// </summary>
        /// <param name="strSQL">SQL���</param>
        /// <param name="fs">ͼ���ֽ�,���ݿ���ֶ�����Ϊimage�����</param>
        /// <returns>Ӱ��ļ�¼��</returns>
        public static int ExecuteSqlInsertImg(string strSQL, byte[] fs)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                OracleCommand cmd = new OracleCommand(strSQL, connection);
                OracleParameter myParameter = new OracleParameter("@fs", OracleType.LongRaw);
                myParameter.Value = fs;
                cmd.Parameters.Add(myParameter);
                try
                {
                    connection.Open();
                    int rows = cmd.ExecuteNonQuery();
                    return rows;
                }
                catch (OracleException E)
                {
                    Loger.Error("ExecuteSqlInsertImg()==>strSQL" + strSQL, E);
                    throw new Exception(E.Message);
                }
                finally
                {
                    cmd.Dispose();
                    connection.Close();
                }
            }
        }

        /// <summary>
        ///     ִ��һ�������ѯ�����䣬���ز�ѯ�����object����
        /// </summary>
        /// <param name="SQLString">�����ѯ������</param>
        /// <returns>��ѯ�����object��</returns>
        public static object GetSingle(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = new OracleCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        object obj = cmd.ExecuteScalar();
                        if ((Equals(obj, null)) || (Equals(obj, DBNull.Value)))
                        {
                            return null;
                        }
                        else
                        {
                            return obj;
                        }
                    }
                    catch (OracleException e)
                    {
                        Loger.Error("GetSingle()==>SQLString:" + SQLString, e);
                        throw new Exception(e.Message);
                    }
                }
            }
        }

        /// <summary>
        ///     ִ�в�ѯ��䣬����OracleDataReader ( ע�⣺���ø÷�����һ��Ҫ��SqlDataReader����Close )
        /// </summary>
        /// <param name="strSQL">��ѯ���</param>
        /// <returns>OracleDataReader</returns>
        public static OracleDataReader ExecuteReader(string strSQL)
        {
            OracleConnection connection = new OracleConnection(connectionString);
            OracleCommand cmd = new OracleCommand(strSQL, connection);
            try
            {
                connection.Open();
                OracleDataReader myReader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                return myReader;
            }
            catch (OracleException e)
            {
                Loger.Error("ExecuteReader()==>strSQL:" + strSQL, e);
                throw new Exception(e.Message);
            }
        }

        /// <summary>
        ///     ִ�в�ѯ��䣬����DataSet
        /// </summary>
        /// <param name="SQLString">��ѯ���</param>
        /// <returns>DataSet</returns>
        public static DataSet Query(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                DataSet ds = new DataSet();
                try
                {
                    connection.Open();
                    OracleDataAdapter command = new OracleDataAdapter(SQLString, connection);
                    command.Fill(ds, "ds");
                }
                catch (OracleException ex)
                {
                    Loger.Error("Query()==>" + SQLString, ex);
                    throw new Exception("Query  SQLString:" + SQLString + "  " + ex.Message);
                }
                return ds;
            }
        }

        /// <summary>
        ///     �������ݿ��ֵ
        /// </summary>
        public static ArrayList getDBRecord(String sql)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                string[] columnName;
                try
                {
                    connection.Open();
                    OracleCommand cmd = new OracleCommand(sql, connection);
                    OracleDataReader reader = cmd.ExecuteReader();
                    int fieldcount = reader.FieldCount;
                    columnName = new string[fieldcount];
                    String[] record = new String[fieldcount];
                    ArrayList al = new ArrayList();
                    while (reader.Read())
                    {
                        record = new String[fieldcount];
                        for (int i = 0; i < fieldcount; i++)
                        {
                            record[i] = reader.GetValue(i).ToString(); //��ֵ
                            columnName[i] = reader.GetName(i); //��ǰ������
                        }
                        al.Add(record);
                    }
                    if (!reader.IsClosed)
                        reader.Close();
                    return al;
                }
                catch (OracleException ex)
                {
                    Loger.Error("getDBRecord()==>sql:" + sql, ex);
                    throw new Exception(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            return new ArrayList();
        }

        /// <summary>
        ///     �������ݿ��ֵ���ع�ϣ��ֻ����һ��
        /// </summary>
        public static Hashtable getDBHT(String sql)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                string[] columnName;
                try
                {
                    connection.Open();
                    OracleCommand cmd = new OracleCommand(sql, connection);
                    OracleDataReader reader = cmd.ExecuteReader();
                    int fieldcount = reader.FieldCount;
                    columnName = new string[fieldcount];
                    String[] record = new String[fieldcount];
                    Hashtable HT = new Hashtable();
                    if (reader.Read())
                    {
                        record = new String[fieldcount];
                        for (int i = 0; i < fieldcount; i++)
                        {
                            HT.Remove(reader.GetName(i).ToUpper());
                            HT.Add(reader.GetName(i).ToUpper(), reader.GetValue(i).ToString());
                        }
                    }
                    if (!reader.IsClosed)
                        reader.Close();
                    return HT;
                }
                catch (OracleException ex)
                {
                    Loger.Error("getDBHT()==>sql:" + sql, ex);
                    throw new Exception(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            return new Hashtable();
        }

        #endregion

        #region ִ�д�������SQL���

        /// <summary>
        ///     ִ��SQL��䣬����Ӱ��ļ�¼��
        /// </summary>
        /// <param name="SQLString">SQL���</param>
        /// <returns>Ӱ��ļ�¼��</returns>
        public static int ExecuteSql(string SQLString, params OracleParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = new OracleCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                        int rows = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        return rows;
                    }
                    catch (OracleException E)
                    {
                        Loger.Error("ExecuteSql()==>ExecuteSql:" + SQLString);
                        throw new Exception(E.Message);
                    }
                }
            }
        }


        /// <summary>
        ///     ִ�ж���SQL��䣬ʵ�����ݿ�����
        /// </summary>
        /// <param name="SQLStringList">SQL���Ĺ�ϣ����keyΪsql��䣬value�Ǹ�����OracleParameter[]��</param>
        public static void ExecuteSqlTran(Hashtable SQLStringList)
        {
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                conn.Open();
                using (OracleTransaction trans = conn.BeginTransaction())
                {
                    OracleCommand cmd = new OracleCommand();
                    try
                    {
                        //ѭ��
                        foreach (DictionaryEntry myDE in SQLStringList)
                        {
                            string cmdText = myDE.Key.ToString();
                            OracleParameter[] cmdParms = (OracleParameter[])myDE.Value;
                            PrepareCommand(cmd, conn, trans, cmdText, cmdParms);
                            int val = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            trans.Commit();
                        }
                    }
                    catch
                    {
                        trans.Rollback();
                        throw;
                    }
                }
            }
        }


        /// <summary>
        ///     ִ��һ�������ѯ�����䣬���ز�ѯ�����object����
        /// </summary>
        /// <param name="SQLString">�����ѯ������</param>
        /// <returns>��ѯ�����object��</returns>
        public static object GetSingle(string SQLString, params OracleParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = new OracleCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                        object obj = cmd.ExecuteScalar();
                        cmd.Parameters.Clear();
                        if ((Equals(obj, null)) || (Equals(obj, DBNull.Value)))
                        {
                            return null;
                        }
                        else
                        {
                            return obj;
                        }
                    }
                    catch (OracleException e)
                    {
                        Loger.Error("GetSingle()==>SQLString:" + SQLString, e);
                        throw new Exception(e.Message);
                    }
                }
            }
        }

        /// <summary>
        ///     ִ�в�ѯ��䣬����OracleDataReader ( ע�⣺���ø÷�����һ��Ҫ��SqlDataReader����Close )
        /// </summary>
        /// <param name="strSQL">��ѯ���</param>
        /// <returns>OracleDataReader</returns>
        public static OracleDataReader ExecuteReader(string SQLString, params OracleParameter[] cmdParms)
        {
            Loger.Error("ִ�е���:==>ExecuteReader()");
            OracleConnection connection = new OracleConnection(connectionString);
            Loger.Error("ִ�е���ExecuteReader()=:==connectionString==>" + connectionString);
            OracleCommand cmd = new OracleCommand();
            try
            {
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                OracleDataReader myReader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                cmd.Parameters.Clear();
                return myReader;
            }
            catch (OracleException e)
            {
                Loger.Error("ExecuteReader()==>" + SQLString, e);
                throw new Exception(e.Message);
            }
        }

        /// <summary>
        ///     ִ�в�ѯ��䣬����DataSet
        /// </summary>
        /// <param name="SQLString">��ѯ���</param>
        /// <returns>DataSet</returns>
        public static DataSet Query(string SQLString, params OracleParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                OracleCommand cmd = new OracleCommand();
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (OracleException ex)
                    {
                        Loger.Error("Query()==>" + SQLString, ex);
                        throw new Exception(ex.Message);
                    }
                    return ds;
                }
            }
        }


        private static void PrepareCommand(OracleCommand cmd, OracleConnection conn, OracleTransaction trans,
                                           string cmdText, OracleParameter[] cmdParms)
        {
            conn = new OracleConnection();
            Loger.Error("ִ�е�==>PrepareCommand()");
            conn.ConnectionString = PubConstant.GetConnectionString("PropDBConn");
            if (conn.State != ConnectionState.Open)
            {
                //if (!string.IsNullOrEmpty(conn.ConnectionString))
                //    conn.ConnectionString = connectionString;
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
                cmd.Transaction = trans;
            cmd.CommandType = CommandType.Text; //cmdType;
            if (cmdParms != null)
            {
                foreach (OracleParameter parm in cmdParms)
                    cmd.Parameters.Add(parm);
            }
        }

        #endregion

        #region �洢���̲���

        /// <summary>
        ///     ִ�д洢���� ����SqlDataReader ( ע�⣺���ø÷�����һ��Ҫ��SqlDataReader����Close )
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <returns>OracleDataReader</returns>
        public static OracleDataReader RunProcedure(string storedProcName, IDataParameter[] parameters)
        {
            OracleConnection connection = new OracleConnection(connectionString);
            OracleDataReader returnReader;
            connection.Open();
            OracleCommand command = BuildQueryCommand(connection, storedProcName, parameters);
            command.CommandType = CommandType.StoredProcedure;
            returnReader = command.ExecuteReader(CommandBehavior.CloseConnection);
            return returnReader;
        }


        /// <summary>
        ///     ִ�д洢����
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <param name="tableName">DataSet����еı���</param>
        /// <returns>DataSet</returns>
        public static DataSet RunProcedure(string storedProcName, IDataParameter[] parameters, string tableName)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                DataSet dataSet = new DataSet();
                connection.Open();
                OracleDataAdapter sqlDA = new OracleDataAdapter();
                sqlDA.SelectCommand = BuildQueryCommand(connection, storedProcName, parameters);
                sqlDA.Fill(dataSet, tableName);
                connection.Close();
                return dataSet;
            }
        }

        /// <summary>
        ///     ִ���ض��洢���̣������б���
        /// </summary>
        /// <param name="procedureName">�洢��������</param>
        /// <param name="processState">����״̬</param>
        /// <param name="acceptstation">����վ��</param>
        /// <param name="filter">�������� ��ʽ���£�and �ֶ���='�ֶ�ֵ'</param>
        /// <param name="paeSize">ÿҳ��¼��</param>
        /// <param name="indexNowPage">��ҳ���� ��0��ʼ</param>
        /// <param name="totalRows">�ܼ�¼��</param>
        /// <returns>��ҳ�����</returns>
        public static DataTable RunProcedure(string procedureName, string processState, string acceptstation,
                                             string filter, string p_missType, string orderby, int paeSize, int indexNowPage,
                                             ref int totalRows)
        {
            //��ȡ���Ӷ���
            OracleConnection connection = new OracleConnection(connectionString);
            try
            {
                //������
                connection.Open();
                //����OracleCommand����,������������Ϊ�洢����
                OracleCommand pOracleCMD = new OracleCommand(procedureName, connection);
                pOracleCMD.CommandType = CommandType.StoredProcedure;

                //���ݴ洢���̵Ĳ����������������ɲ�������
                OracleParameter p1 = new OracleParameter("rowPageSize", OracleType.Number, 10);
                OracleParameter p2 = new OracleParameter("rowPageIndex", OracleType.Number, 10);
                OracleParameter p3 = new OracleParameter("totalRows", OracleType.Number, 10);
                OracleParameter p4 = new OracleParameter("P_processState", OracleType.VarChar, 1000);
                OracleParameter p5 = new OracleParameter("P_acceptstation", OracleType.VarChar, 4000);
                OracleParameter p6 = new OracleParameter("P_filter", OracleType.VarChar, 4000);
                OracleParameter p7 = new OracleParameter("P_missType", OracleType.VarChar, 50);
                OracleParameter p8 = new OracleParameter("v_orderby", OracleType.VarChar, 4000);
                OracleParameter p9 = new OracleParameter("p_cursor", OracleType.Cursor);

                //���ò����������������,Ĭ��Ϊ����
                p1.Direction = ParameterDirection.Input;
                p2.Direction = ParameterDirection.Input;
                p3.Direction = ParameterDirection.Output;
                p4.Direction = ParameterDirection.Input;
                p5.Direction = ParameterDirection.Input;
                p6.Direction = ParameterDirection.Input;
                p7.Direction = ParameterDirection.Input;
                p8.Direction = ParameterDirection.Input;
                p9.Direction = ParameterDirection.Output;

                //��������������ֵ,����������ظ�ֵ.
                p1.Value = paeSize;
                p2.Value = indexNowPage;
                //   p3.Value = paeSize;
                p4.Value = processState;
                p5.Value = acceptstation;
                p6.Value = filter;
                p7.Value = p_missType;
                p8.Value = orderby;
                //       p3.Value = tableName;

                //���մ洢���̲���˳��Ѳ������μ��뵽OracleCommand�������������
                pOracleCMD.Parameters.Add(p1);
                pOracleCMD.Parameters.Add(p2);
                pOracleCMD.Parameters.Add(p3);
                pOracleCMD.Parameters.Add(p4);
                pOracleCMD.Parameters.Add(p5);
                pOracleCMD.Parameters.Add(p6);
                pOracleCMD.Parameters.Add(p7);
                pOracleCMD.Parameters.Add(p8);
                pOracleCMD.Parameters.Add(p9);
                //ִ��,�ѷ�ҳ���������datatable��
                OracleDataAdapter pOracleDataAdapter = new OracleDataAdapter(pOracleCMD);
                DataTable datatable = new DataTable();
                pOracleDataAdapter.Fill(datatable);

                //��ִ�н�����,�Ӵ洢�������������ȡ����Ӧ��ֵ�������ò������Թ��������
                totalRows = int.Parse(p3.Value.ToString());
                // totalPages = int.Parse(p5.Value.ToString());
                return datatable;
            }
            catch (OracleException e)
            {
                Loger.Error("RunProcedure()==>" + procedureName, e);
                throw new Exception(e.Message);
            }
            finally
            {
                //�ر�����
                connection.Close();
            }
        }

        /// <summary>
        ///     ���� OracleCommand ����(��������һ���������������һ������ֵ)
        /// </summary>
        /// <param name="connection">���ݿ�����</param>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <returns>OracleCommand</returns>
        private static OracleCommand BuildQueryCommand(OracleConnection connection, string storedProcName,
                                                       IDataParameter[] parameters)
        {
            OracleCommand command = new OracleCommand(storedProcName, connection);
            command.CommandType = CommandType.StoredProcedure;
            foreach (OracleParameter parameter in parameters)
            {
                command.Parameters.Add(parameter);
            }
            return command;
        }

        /// <summary>
        ///     ִ�д洢���̣�����Ӱ�������
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <param name="rowsAffected">Ӱ�������</param>
        /// <returns></returns>
        public static int RunProcedure(string storedProcName, IDataParameter[] parameters, out int rowsAffected)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                int result;
                connection.Open();
                OracleCommand command = BuildIntCommand(connection, storedProcName, parameters);
                rowsAffected = command.ExecuteNonQuery();
                result = (int)command.Parameters["ReturnValue"].Value;
                //Connection.Close();
                return result;
            }
        }

        /// <summary>
        ///     ���� OracleCommand ����ʵ��(��������һ������ֵ)
        /// </summary>
        /// <param name="storedProcName">�洢������</param>
        /// <param name="parameters">�洢���̲���</param>
        /// <returns>OracleCommand ����ʵ��</returns>
        private static OracleCommand BuildIntCommand(OracleConnection connection, string storedProcName,
                                                     IDataParameter[] parameters)
        {
            OracleCommand command = BuildQueryCommand(connection, storedProcName, parameters);
            command.Parameters.Add(new OracleParameter("ReturnValue",
                                                       OracleType.Int32, 4, ParameterDirection.ReturnValue,
                                                       false, 0, 0, string.Empty, DataRowVersion.Default, null));
            return command;
        }

        #endregion
    }
}