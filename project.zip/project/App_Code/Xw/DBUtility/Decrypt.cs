using Maticsoft.DBUtility;

namespace hugegis.DBUtility
{
    /// <summary>
    ///     ���������ַ�����
    /// </summary>
    public class Decrypt
    {
        /// <summary>
        ///     ҵ��
        /// </summary>
        public static string PropDBConn = PubConstant.GetConnectionString("PropDBConn"); //ҵ��

        /// <summary>
        ///     Ȩ��
        /// </summary>
        public static string AuthDBConn = PubConstant.GetConnectionString("AuthDBConn"); //Ȩ��

        /// <summary>
        ///     ����
        /// </summary>
        public static string ProcessDBConn = PubConstant.GetConnectionString("ProcessDBConn"); //����
        
        /// <summary>
        ///     ҵ��-�ۺ�
        /// </summary>
        public static string Prop_ZHDBConn = PubConstant.GetConnectionString("Prop_ZHDBConn"); //ҵ��-�ۺ�
        
        /// <summary>
        ///     ��ý��
        /// </summary>
        public static string MediaDBConn = PubConstant.GetConnectionString("MediaDBConn"); //��ý��

        /// <summary>
        ///     �켣
        /// </summary>
        public static string TrackDBConn = PubConstant.GetConnectionString("TrackDBConn"); //�켣

        //ʵ����
        public Decrypt()
        {
            PropDBConn = PubConstant.GetConnectionString("PropDBConn");
            AuthDBConn = PubConstant.GetConnectionString("AuthDBConn");
            TrackDBConn = PubConstant.GetConnectionString("TrackDBConn");
            MediaDBConn = PubConstant.GetConnectionString("MediaDBConn");
            ProcessDBConn = PubConstant.GetConnectionString("ProcessDBConn");
        }

    }
}