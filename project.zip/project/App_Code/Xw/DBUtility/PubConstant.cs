using System;
using System.Collections;
using System.Configuration;

namespace Maticsoft.DBUtility
{
    public class PubConstant
    {
        /// <summary>
        ///     ��ȡ�����ַ���
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                string _connectionString = "";
                //��ȡ�ڵ�
                Hashtable pHT = ConfigurationManager.GetSection("PropDBConn") as Hashtable;
                string pServer = pHT != null ? (pHT["Server"] != null ? pHT["Server"].ToString() : "") : "";
                string pUserName = pHT != null ? (pHT["UserID"] != null ? pHT["UserID"].ToString() : "") : "";
                string pPassWord = pHT != null ? (pHT["Password"] != null ? pHT["Password"].ToString() : "") : "";
                string pPwd = pHT != null ? (pHT["Pwd"] != null ? pHT["Pwd"].ToString() : "") : "";
                if (!pPassWord.Equals("") && !pServer.Equals("") && !pUserName.Equals(""))
                {
                    //����
                    pPassWord = getIsException(pPassWord);
                    _connectionString = "Data Source=" + pServer + ";Persist Security Info=True;User ID=" + pUserName +
                                        ";Password=" + pPassWord + ";Unicode=True";
                }

                return _connectionString;
            }
        }

        /// <summary>
        ///     �õ�web.config������������ݿ������ַ���
        /// </summary>
        /// <param name="pSectionName">���ýڵ�</param>
        /// <returns>�����ַ���</returns>
        public static string GetConnectionString(string pSectionName)
        {
            string _connectionString = "";
            //��ȡ�ڵ�
            Hashtable pHT = ConfigurationManager.GetSection(pSectionName) as Hashtable;
            string pServer = pHT != null ? (pHT["Server"] != null ? pHT["Server"].ToString() : "") : "";
            string pUserName = pHT != null ? (pHT["UserID"] != null ? pHT["UserID"].ToString() : "") : "";
            string pPassWord = pHT != null ? (pHT["Password"] != null ? pHT["Password"].ToString() : "") : "";
            if (!pPassWord.Equals("") && !pServer.Equals("") && !pUserName.Equals(""))
            {
                //����
                pPassWord = getIsException(pPassWord);
                _connectionString = "Data Source=" + pServer + ";Persist Security Info=True;User ID=" + pUserName +
                                    ";Password=" + pPassWord + ";Unicode=True";
            }

            return _connectionString;
        }

        /// <summary>
        ///     ���ܺ��ж��ַ����Ƿ����쳣
        /// </summary>
        /// <param name="pPassWord">�����ַ���</param>
        /// <returns>���ܺ��ַ���</returns>
        public static string getIsException(string pPassWord)
        {
            string result = GlobalFunction.GlobalFunction.Decode(pPassWord);
            string[] str = {"|", "?", "\t", "\n", "@", "\a", "!", " ", "\f"};
            for (int i = 0; i < str.Length; i++)
            {
                if (result.Contains(str[i]))
                {
                    result = getIsException(pPassWord);
                    break;
                }
            }
            return result;
        }

        /// <summary>
        ///     ��ȡ���ݿ���
        /// </summary>
        /// <param name="pSectionName">���ýڵ�</param>
        /// <returns>���ݿ���</returns>
        public static string GetConnectionStringByUserName(string pSectionName)
        {
            //��ȡ�ڵ�
            Hashtable pHT = ConfigurationManager.GetSection(pSectionName) as Hashtable;
            return pHT["UserID"].ToString();
        }
    }
}