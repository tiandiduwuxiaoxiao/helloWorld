﻿using System;
using System.Collections;
using System.Data;
using System.Data.OracleClient;
using hugegis.DBUtility;
using hugegis.Model;
using System.Collections.Generic;
using MyAuth.authServices;

/// <summary>
///     DAL_AuthorGlobal 的摘要说明
/// </summary>
public class DAL_AuthorGlobal
{
    public static ArrayList getResources(string uid)
    {
        ArrayList al = new ArrayList();
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string userid = "";
        while (data.Read())
        {
            object id = data.GetValue(data.GetOrdinal("id"));
            userid = Convert.ToString(id);
            object utype = data.GetValue(data.GetOrdinal("utype"));
            if (Convert.ToString(utype) != "")
            {
                oraComm.CommandText = "select * from author_role_res where roleid='" + Convert.ToString(utype) + "'";
                OracleDataReader data1 = oraComm.ExecuteReader();
                while (data1.Read())
                {
                    object resid = data1.GetValue(data1.GetOrdinal("resid"));
                    al.Add(Convert.ToString(resid));
                }
                data1.Close();
            }
        }
        if (!data.IsClosed)
            data.Close();
        oraComm.CommandText = "select * from author_user_res where userid='" + userid + "'";
        data = oraComm.ExecuteReader();
        while (data.Read())
        {
            object resid = data.GetValue(data.GetOrdinal("resid"));
            al.Add(Convert.ToString(resid));
        }
        if (!data.IsClosed)
            data.Close();

        string where = "";
        for (int i = 0; i < al.Count; i++)
        {
            string resid = (string)al[i];
            string temp = "t.id='" + resid + "'";
            where = where == "" ? temp : where + " or " + temp;
        }
        ArrayList resList = new ArrayList();
        if (al.Count != 0)
        {
            oraComm.CommandText =
                "select t.*,c.cataname from author_resource t,author_rescatalog c where t.rescatalog=c.id and (" + where +
                ") ";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object id = data.GetValue(data.GetOrdinal("id"));
                object rescatalogid = data.GetValue(data.GetOrdinal("rescatalog"));
                object resname = data.GetValue(data.GetOrdinal("resname"));
                object depid = data.GetValue(data.GetOrdinal("depid"));
                object cataname = data.GetValue(data.GetOrdinal("cataname"));
                ResourceBean rb = new ResourceBean(Convert.ToString(id), Convert.ToString(rescatalogid),
                                                   Convert.ToString(resname), Convert.ToString(depid));
                rb.rescataname = Convert.ToString(cataname);
                resList.Add(rb);
            }
            if (!data.IsClosed)
                data.Close();

            oraComm.CommandText =
                "select t.*,c.equipcataname from author_equipment t,author_equipcatalog c where t.equipcataid=c.id and (" +
                where + ") ";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object id = data.GetValue(data.GetOrdinal("id"));
                object rescatalogid = data.GetValue(data.GetOrdinal("equipcataid"));
                object resname = data.GetValue(data.GetOrdinal("EQUIPNAMEPHONENUM"));
                object depid = data.GetValue(data.GetOrdinal("depid"));
                object cataname = data.GetValue(data.GetOrdinal("equipcataname"));
                ResourceBean rb = new ResourceBean(Convert.ToString(id), Convert.ToString(rescatalogid),
                                                   Convert.ToString(resname), Convert.ToString(depid));
                rb.rescataname = Convert.ToString(cataname);
                resList.Add(rb);
            }
            if (!data.IsClosed)
                data.Close();
        }
        conn.Close();
        return resList;
    }

    public static bool isAuthor(string uid)
    {
        if (uid == "admin") return true;
        ArrayList al = getResources(uid);
        for (int i = 0; i < al.Count; i++)
        {
            ResourceBean rb = (ResourceBean)al[i];
            if (rb.resname.Contains("用户管理"))
            {
                return true;
            }
        }
        return false;
    }

    public static bool isContainRes(ArrayList al, string resid)
    {
        if (al == null) return false;
        for (int i = 0; i < al.Count; i++)
        {
            ResourceBean rb = (ResourceBean)al[i];
            if (rb.id == resid)
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    ///     获取部门、用户信息
    /// </summary>
    /// <param name="uid">用户ID</param>
    /// <returns></returns>
    public static ArrayList getAllDepartmentWithUserID(string uid)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department order by DEPDISC";
        OracleDataReader data = oraComm.ExecuteReader();
        Hashtable ht = new Hashtable();
        while (data.Read())
        {
            object id = data.GetValue(data.GetOrdinal("id"));
            object pid = data.GetValue(data.GetOrdinal("pid"));
            object depname = data.GetValue(data.GetOrdinal("depname"));
            object depdisc = data.GetValue(data.GetOrdinal("depdisc"));
            AuthorDepartmentBean adb = new AuthorDepartmentBean(Convert.ToString(id), Convert.ToString(pid),
                                                                Convert.ToString(depname), Convert.ToString(depdisc));
            if (ht[Convert.ToString(pid)] == null)
            {
                ArrayList al = new ArrayList();
                al.Add(adb);
                ht.Add(Convert.ToString(pid), al);
            }
            else
            {
                ArrayList al = (ArrayList)ht[Convert.ToString(pid)];
                al.Add(adb);
            }
        }
        if (!data.IsClosed)
            data.Close();
        string root = "0";

        if (uid != "")
        {
            oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object depid = data.GetValue(data.GetOrdinal("depid"));
                root = Convert.ToString(depid);
            }
            if (!data.IsClosed)
                data.Close();
        }
        conn.Close();

        ArrayList deps = new ArrayList();
        deps.Add(root);
        fillNode(ht, root, deps);
        return deps;
    }

    public static string getUserDepartment(string uid)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_user where cuser='" + uid + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("depid"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getPDADepartment(string pdaname)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_equipment  where relationobj='" + pdaname + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("depid"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getUserDepartmentName(string depidva)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department where id='" + depidva + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("DEPNAME"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getUserDepartmentPID(string depidva)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department where id='" + depidva + "'";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("PID"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static string getUserParentDepartmentName(string depidva)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department where id=(select PID from author_department where ID='" +
                              depidva + "')";
        OracleDataReader data = oraComm.ExecuteReader();
        string depID = "";
        while (data.Read())
        {
            object depid = data.GetValue(data.GetOrdinal("DEPNAME"));
            depID = Convert.ToString(depid);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return depID;
    }

    public static ArrayList getUserChildDepartmentName(string depidva)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department ";
        OracleDataReader data = oraComm.ExecuteReader();
        OracleDataAdapter oda = new OracleDataAdapter(oraComm);
        DataSet ds = new DataSet();
        oda.Fill(ds);
        DataView dv = ds.Tables[0].DefaultView;
        dv.RowFilter = "PID='" + depidva + "'";
        ArrayList list = new ArrayList();
        foreach (DataRowView row in dv)
        {
            list.Add(row["DEPNAME"]);
            getUserChildDepartmentList(dv, row["ID"].ToString(), list);
        }
        if (!data.IsClosed)
            data.Close();
        conn.Close();
        return list;
    }

    public static void getUserChildDepartmentList(DataView dv1, string childid, ArrayList listva)
    {
        DataView dv = new DataView(dv1.Table);
        dv.RowFilter = "PID='" + childid + "'";

        foreach (DataRowView row in dv)
        {
            listva.Add(row["DEPNAME"]);
            getUserChildDepartmentList(dv, row["id"].ToString(), listva);
        }
    }

    public static ArrayList getAllDepartmentWithUid(string uid)
    {
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();
        oraComm.CommandText = "select * from author_department order by DEPDISC";
        OracleDataReader data = oraComm.ExecuteReader();
        Hashtable ht = new Hashtable();
        while (data.Read())
        {
            object id = data.GetValue(data.GetOrdinal("id"));
            object pid = data.GetValue(data.GetOrdinal("pid"));
            object depname = data.GetValue(data.GetOrdinal("depname"));
            object depdisc = data.GetValue(data.GetOrdinal("depdisc"));
            AuthorDepartmentBean adb = new AuthorDepartmentBean(Convert.ToString(id), Convert.ToString(pid),
                                                                Convert.ToString(depname), Convert.ToString(depdisc));
            if (ht[Convert.ToString(pid)] == null)
            {
                ArrayList al = new ArrayList();
                al.Add(adb);
                ht.Add(Convert.ToString(pid), al);
            }
            else
            {
                ArrayList al = (ArrayList)ht[Convert.ToString(pid)];
                al.Add(adb);
            }
        }
        if (!data.IsClosed)
            data.Close();

        string root = "0";

        if (uid != "")
        {
            oraComm.CommandText = "select * from author_user where id='" + uid + "'";
            data = oraComm.ExecuteReader();
            while (data.Read())
            {
                object depid = data.GetValue(data.GetOrdinal("depid"));
                root = Convert.ToString(depid);
            }
            if (!data.IsClosed)
                data.Close();
        }

        conn.Close();

        ArrayList deps = new ArrayList();
        deps.Add(root);
        fillNode(ht, root, deps);
        return deps;
    }

    public static void fillNode(Hashtable ht, string key, ArrayList deps)
    {
        if (ht[key] != null)
        {
            ArrayList al = (ArrayList)ht[key];
            for (int i = 0; i < al.Count; i++)
            {
                AuthorDepartmentBean adb = (AuthorDepartmentBean)al[i];
                deps.Add(adb.id);
                if (ht[adb.id] != null)
                {
                    fillNode(ht, adb.id, deps);
                }
            }
        }
    }

    public static ArrayList getResourceWithUserid(string uid)
    {
        ArrayList deps = getAllDepartmentWithUserID(uid);
        string whereDepStr = "";
        for (int i = 0; i < deps.Count; i++)
        {
            string tempStr = "depid='" + Convert.ToString(deps[i]) + "'";
            whereDepStr = whereDepStr == "" ? tempStr : whereDepStr + " or " + tempStr;
        }

        ArrayList al = new ArrayList();
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);
        conn.Open();
        OracleCommand oraComm = conn.CreateCommand();


        oraComm.CommandText =
            "select * from author_equipment equipment,author_equipcatalog equipcatalog where equipment.equipcataid=equipcatalog.id  and (" +
            whereDepStr + ")";
        OracleDataReader data = oraComm.ExecuteReader();
        while (data.Read())
        {
            object resname = data.GetValue(data.GetOrdinal("equipname"));

            al.Add(resname);
        }
        if (!data.IsClosed)
            data.Close();

        conn.Close();

        return al;
    }

    /// <summary>
    /// 根据用户ID获取当前用户下的所有右侧菜单
    /// </summary>
    /// <param name="userId">用户ID</param>
    /// <returns>返回值List(Model_PZ_MENUCONFIG)（菜单实体类）</returns>
    public static List<Model_PZ_MENUCONFIG> GetMenuCongif(string userId, string pid)
    {
        OracleConnection conn = new OracleConnection(Decrypt.PropDBConn);
        try
        {
            //创建实体和集合
            Model_PZ_MENUCONFIG menuConfig = null;
            List<Model_PZ_MENUCONFIG> listEntity = new List<Model_PZ_MENUCONFIG>();

            //获取角色ID
            string roleId = GetRoleId(userId);
            //打开数据库连接获取取数据
            conn.Open();
            string sql = string.Format(@" SELECT M.ID,M.ASIACODE,M.ASIANAME,M.ISCREATE,M.NODELEVEL,M.PARENTCODE,M.PICDIC,M.SORTED,M.SQLCOUNT,M.TIP,M.ISVISIBLE  FROM pz_menuconfig M WHERE 1=1 and ISVISIBLE='{0}' and PARENTCODE='{1}' order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), pid);
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            DataTable dtMenuConfig = new DataTable();
            data.Fill(dtMenuConfig);

            //遍历数据
            foreach (DataRow dr in dtMenuConfig.Rows)
            {
                menuConfig = new Model_PZ_MENUCONFIG();
                //获取关系pz_rt_rolemenu：RTID主键
                menuConfig.ID = dr["ID"].ToString();
                //menuConfig.RTID = dr["RTID"].ToString();
                menuConfig.ASIACODE = dr["ASIACODE"].ToString();
                menuConfig.ASIANAME = dr["ASIANAME"].ToString();
                menuConfig.ISCREATE = dr["ISCREATE"].ToString();
                menuConfig.NODELEVEL = dr["NODELEVEL"].ToString();
                menuConfig.PARENTCODE = dr["PARENTCODE"].ToString();
                menuConfig.PICDIC = dr["PICDIC"].ToString();
                //   menuConfig.PROCESSID = dr["PROCESSID"].ToString();
                //   menuConfig.PROCESSNODENAME = dr["PROCESSNODENAME"].ToString();
                menuConfig.SORTED = ConvertUtil.ToInt32(dr["SORTED"]);
                menuConfig.SQLCOUNT = dr["SQLCOUNT"].ToString();
                menuConfig.TIP = dr["TIP"].ToString();
                menuConfig.ISVISIBLE = dr["ISVISIBLE"].ToString();

                listEntity.Add(menuConfig);
            }
            return listEntity;
        }
        catch (Exception)
        {

            return new List<Model_PZ_MENUCONFIG>();
        }
        finally
        {
            conn.Close();
        }


    }

    /// <summary>
    /// 根据用户ID获取当前用户下的所有右侧菜单
    /// </summary>
    /// <param name="userId">用户ID</param>
    /// <returns>返回值List(Model_PZ_MENUCONFIG)（菜单实体类）</returns>
    public static string GetOrderNumber(string sql, string type)
    {
        OracleConnection conn = new OracleConnection(Decrypt.PropDBConn);
        if (type == "1")
        {
            conn = new OracleConnection(Decrypt.Prop_ZHDBConn);
        }
        string SCount = "0";
        try
        {
            //打开数据库连接获取取数据
            conn.Open();
            OracleCommand Cmd = new OracleCommand(sql, conn);
            SCount = Cmd.ExecuteScalar().ToString().Trim();
            if (SCount == "")
                SCount = "0";
        }
        catch (Exception ex)
        {
            return "0";
        }
        finally
        {
            conn.Close();
        }
        return SCount;
    }

    /// <summary>
    /// 根据用户ID获取当前用户下的所有右侧菜单
    /// </summary>
    /// <param name="userId">用户ID</param>
    /// <returns>返回值List(Model_PZ_MENUCONFIG)（菜单实体类）</returns>
    public static List<Model_PZ_MENUCONFIG> GetMenuCongifC(string userId, string pid, string type)
    {
        OracleConnection conn = new OracleConnection(Decrypt.PropDBConn);
        if (type == "1")
        {
            conn = new OracleConnection(Decrypt.Prop_ZHDBConn);
        }
        try
        {
            //创建实体和集合
            Model_PZ_MENUCONFIG menuConfig = null;
            List<Model_PZ_MENUCONFIG> listEntity = new List<Model_PZ_MENUCONFIG>();

            //获取角色ID
            string roleId = GetRoleId(userId);
            //打开数据库连接获取取数据
            conn.Open();
            string sql = string.Format(@" SELECT M.ID,M.ASIACODE,M.ASIANAME,M.ISCREATE,M.NODELEVEL,M.PARENTCODE,M.PICDIC,M.SORTED,M.SQLCOUNT,M.TIP,M.ISVISIBLE  FROM pz_menuconfig M WHERE 1=1 and ISVISIBLE='{0}' and PARENTCODE='{1}' order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), pid);
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            DataTable dtMenuConfig = new DataTable();
            data.Fill(dtMenuConfig);

            //遍历数据
            foreach (DataRow dr in dtMenuConfig.Rows)
            {
                menuConfig = new Model_PZ_MENUCONFIG();
                //获取关系pz_rt_rolemenu：RTID主键
                menuConfig.ID = dr["ID"].ToString();
                //menuConfig.RTID = dr["RTID"].ToString();
                menuConfig.ASIACODE = dr["ASIACODE"].ToString();
                menuConfig.ASIANAME = dr["ASIANAME"].ToString();
                menuConfig.ISCREATE = dr["ISCREATE"].ToString();
                menuConfig.NODELEVEL = dr["NODELEVEL"].ToString();
                menuConfig.PARENTCODE = dr["PARENTCODE"].ToString();
                menuConfig.PICDIC = dr["PICDIC"].ToString();
                //   menuConfig.PROCESSID = dr["PROCESSID"].ToString();
                //   menuConfig.PROCESSNODENAME = dr["PROCESSNODENAME"].ToString();
                menuConfig.SORTED = ConvertUtil.ToInt32(dr["SORTED"]);
                menuConfig.SQLCOUNT = dr["SQLCOUNT"].ToString();
                menuConfig.TIP = dr["TIP"].ToString();
                menuConfig.ISVISIBLE = dr["ISVISIBLE"].ToString();

                listEntity.Add(menuConfig);
            }
            return listEntity;
        }
        catch (Exception)
        {

            return new List<Model_PZ_MENUCONFIG>();
        }
        finally
        {
            conn.Close();
        }


    }

    /// <summary>
    /// 根据用户ID获取当前用户下的所有右侧报表
    /// </summary>
    /// <param name="userId">用户ID</param>
    /// <returns>返回值List(Model_PZ_MENUCONFIG)（菜单实体类）</returns>
    public static List<Model_PZ_MENUCONFIG> GetMenuCongif(string userId, string shoulizhandian, string pid, string type)
    {
        OracleConnection conn = new OracleConnection(Decrypt.PropDBConn);
        if (type == "1")
        {
            conn = new OracleConnection(Decrypt.Prop_ZHDBConn);
        }
        try
        {
            //创建实体和集合
            Model_PZ_MENUCONFIG menuConfig = null;
            List<Model_PZ_MENUCONFIG> listEntity = new List<Model_PZ_MENUCONFIG>();

            //获取角色ID
            string roleId = GetRoleId(userId);
            //打开数据库连接获取取数据
            conn.Open();
            string sql = string.Format(@" SELECT M.*  FROM pz_menuconfig M WHERE 1=1 and ISVISIBLE='{0}' and PARENTCODE='{1}' and asianame in ({2}) order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), pid, shoulizhandian);
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            DataTable dtMenuConfig = new DataTable();
            data.Fill(dtMenuConfig);

            //遍历数据
            foreach (DataRow dr in dtMenuConfig.Rows)
            {
                menuConfig = new Model_PZ_MENUCONFIG();
                //获取关系pz_rt_rolemenu：RTID主键
                menuConfig.ID = dr["ID"].ToString();
                //menuConfig.RTID = dr["RTID"].ToString();
                menuConfig.ASIACODE = dr["ASIACODE"].ToString();
                menuConfig.ASIANAME = dr["ASIANAME"].ToString();
                menuConfig.ISCREATE = dr["ISCREATE"].ToString();
                menuConfig.NODELEVEL = dr["NODELEVEL"].ToString();
                menuConfig.PARENTCODE = dr["PARENTCODE"].ToString();
                menuConfig.PICDIC = dr["PICDIC"].ToString();
                //  menuConfig.PROCESSID = dr["PROCESSID"].ToString();
                // menuConfig.PROCESSNODENAME = dr["PROCESSNODENAME"].ToString();
                menuConfig.SORTED = ConvertUtil.ToInt32(dr["SORTED"]);
                menuConfig.SQLCOUNT = dr["SQLCOUNT"].ToString();
                menuConfig.TIP = dr["TIP"].ToString();
                menuConfig.ISVISIBLE = dr["ISVISIBLE"].ToString();

                listEntity.Add(menuConfig);
            }
            return listEntity;
        }
        catch (Exception)
        {

            return new List<Model_PZ_MENUCONFIG>();
        }
        finally
        {
            conn.Close();
        }


    }

    /// <summary>
    /// 根据用户ID获取当前用户下的所有右侧报表
    /// </summary>
    /// <param name="userId">用户ID</param>
    /// <returns>返回值List(Model_PZ_MENUCONFIG)（菜单实体类）</returns>
    public static List<Model_PZ_MENUCONFIG> GetMenuCongif(string userId, string shoulizhandian, string pid)
    {
        OracleConnection conn = new OracleConnection(Decrypt.PropDBConn);
        try
        {
            //创建实体和集合
            Model_PZ_MENUCONFIG menuConfig = null;
            List<Model_PZ_MENUCONFIG> listEntity = new List<Model_PZ_MENUCONFIG>();

            //获取角色ID
            string roleId = GetRoleId(userId);
            //打开数据库连接获取取数据
            conn.Open();
            string sql = string.Format(@" SELECT M.*  FROM pz_menuconfig M WHERE 1=1 and ISVISIBLE='{0}' and PARENTCODE='{1}' and asianame in ({2}) order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), pid, shoulizhandian);
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            DataTable dtMenuConfig = new DataTable();
            data.Fill(dtMenuConfig);

            //遍历数据
            foreach (DataRow dr in dtMenuConfig.Rows)
            {
                menuConfig = new Model_PZ_MENUCONFIG();
                //获取关系pz_rt_rolemenu：RTID主键
                menuConfig.ID = dr["ID"].ToString();
                //menuConfig.RTID = dr["RTID"].ToString();
                menuConfig.ASIACODE = dr["ASIACODE"].ToString();
                menuConfig.ASIANAME = dr["ASIANAME"].ToString();
                menuConfig.ISCREATE = dr["ISCREATE"].ToString();
                menuConfig.NODELEVEL = dr["NODELEVEL"].ToString();
                menuConfig.PARENTCODE = dr["PARENTCODE"].ToString();
                menuConfig.PICDIC = dr["PICDIC"].ToString();
                //  menuConfig.PROCESSID = dr["PROCESSID"].ToString();
                // menuConfig.PROCESSNODENAME = dr["PROCESSNODENAME"].ToString();
                menuConfig.SORTED = ConvertUtil.ToInt32(dr["SORTED"]);
                menuConfig.SQLCOUNT = dr["SQLCOUNT"].ToString();
                menuConfig.TIP = dr["TIP"].ToString();
                menuConfig.ISVISIBLE = dr["ISVISIBLE"].ToString();

                listEntity.Add(menuConfig);
            }
            return listEntity;
        }
        catch (Exception)
        {

            return new List<Model_PZ_MENUCONFIG>();
        }
        finally
        {
            conn.Close();
        }


    }

    public static List<Mode_Report_Left> GetMenuReport(string userId, string pid, string type)
    {
        OracleConnection conn = new OracleConnection(Decrypt.PropDBConn);
        try
        {
            //创建实体和集合
            Mode_Report_Left menuConfig = null;
            List<Mode_Report_Left> listEntity = new List<Mode_Report_Left>();
            //获取角色ID
            string roleId = GetRoleId(userId);
            //打开数据库连接获取取数据
            conn.Open();
            string sql = string.Format(@" SELECT M.*  FROM PZ_REPORT M WHERE 1=1 and ISVISIBLE='{0}' and PARENTCODE='{1}' and type='{2}'  order by sorted ", Convert.ToInt32(Globals.IsStatus.Effective), pid, type);
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            DataTable dtMenuConfig = new DataTable();
            data.Fill(dtMenuConfig);

            //遍历数据
            foreach (DataRow dr in dtMenuConfig.Rows)
            {
                menuConfig = new Mode_Report_Left();
                //获取关系pz_rt_rolemenu：RTID主键
                menuConfig.ID = dr["ID"].ToString();
                //menuConfig.RTID = dr["RTID"].ToString();
                menuConfig.ASIANAME = dr["ASIANAME"].ToString();
                menuConfig.PARENTCODE = dr["PARENTCODE"].ToString();
                menuConfig.SORTED = ConvertUtil.ToInt32(dr["SORTED"]);
                menuConfig.PROCENAME = Convert.ToString(dr["PARENTCODE"]);
                menuConfig.TIP = dr["TIP"].ToString();
                menuConfig.ISVISIBLE = dr["ISVISIBLE"].ToString();

                listEntity.Add(menuConfig);
            }
            return listEntity;
        }
        catch (Exception)
        {

            return new List<Mode_Report_Left>();
        }
        finally
        {
            conn.Close();
        }


    }
    /// <summary>
    /// 获取角色ID
    /// </summary>
    /// <param name="userId">用户号</param>
    /// <returns></returns>
    private static string GetRoleId(string userId)
    {
        //        string sql = string.Format(@" SELECT r.resid FROM author_user_res r
        //                        INNER JOIN author_user u ON u.id=r.userid
        //                        WHERE u.cuser='{0}'", userId);
        string sql = string.Format(@" SELECT u.UTYPE FROM author_user  u
                        WHERE u.cuser='{0}'", userId);
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);

        try
        {
            DataTable dt = new DataTable();
            conn.Open();
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            data.Fill(dt);
            if (dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            return string.Empty;
        }
        catch (Exception)
        {
            return string.Empty;
        }
        finally
        {
            conn.Close();
        }
    }

    /// <summary>
    /// 获取角色名称
    /// </summary>
    /// <param name="userId">用户号</param>
    /// <returns></returns>
    public static string GetRoleName(string userId)
    {
        string sql = string.Format(@" SELECT b.rolename FROM author_user a inner join author_role b on a.utype = b.id
                        WHERE a.cuser='{0}'", userId);
        OracleConnection conn = new OracleConnection(Decrypt.AuthDBConn);

        try
        {
            DataTable dt = new DataTable();
            conn.Open();
            OracleDataAdapter data = new OracleDataAdapter(sql, conn);
            data.Fill(dt);
            if (dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            return string.Empty;
        }
        catch (Exception)
        {
            return string.Empty;

        }
        finally
        {
            conn.Close();

        }


    }

    /// <summary>
    ///     根据资源父类获取下面所有的子级资源
    /// </summary>
    /// <param name="myresult"></param>
    /// <param name="operationID"></param>
    /// <param name="resourceCategoryName"></param>
    /// <returns></returns>
    public static ArrayList GetAuthResourceNameByResourceCategoryName(WSPermissionResult myresult, string operationID,
                                                                      string resourceCategoryName)
    {
        if (myresult == null) return null;
        WSPermissionItem[] permissions = myresult.permissions;
        if (permissions == null) return null;
        ArrayList al = new ArrayList();
        for (int i = 0; i < permissions.Length; i++)
        {
            WSPermissionItem permission = permissions[i];
            if (permission.operationBid.ToUpper() == operationID.ToUpper() &&
                permission.resourceCategoryName == resourceCategoryName)
            {
                al.Add(permission.resourceName);
            }
        }
        return al;
    }

}