﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using hugegis.Model;

namespace BasicXwWebservice.Hugegis.function
{
    public class GetMenu
    {
        private IEnumerable<MyAuth.authServices.WSPermissionItem> resItem = null;
        public GetMenu(IEnumerable<MyAuth.authServices.WSPermissionItem> res)
        {
            resItem = res;
        }

        /// <summary>
        /// 获取二级菜单
        /// </summary>
        /// <param name="temp"></param>
        public StringBuilder GetTreeNode(string uid)
        {
            StringBuilder temp = new StringBuilder();
            StringBuilder noderoot = new StringBuilder();
            GetTreeChildNode(noderoot, "0", uid);
            temp.Append(noderoot);
            return temp;
        }

        /// <summary>
        /// 获取三级菜单
        /// </summary>
        /// <param name="root"></param>
        /// <param name="_pid">一级节点编号</param>
        protected void GetTreeChildNode(StringBuilder root, string _pid, string uid)
        {
            StringBuilder menu = new StringBuilder();
            string defSelected = string.Empty;// 获取页面默认选中
            int layIndex = 0;//一级菜单索引
            string MenuBadge = Convert.ToString(ConfigurationManager.AppSettings["MenuBadge"]);
            string MapMenu = Convert.ToString(ConfigurationManager.AppSettings["MapMenu"]);
            System.Collections.ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid);

            string shoulizhandian = PublicFunction.ConvertArrayListToString(list);
            List<Model_PZ_MENUCONFIG> AllLay = GetListByAuthor(uid, shoulizhandian, "0");
            int i_temp = 0;
            foreach (Model_PZ_MENUCONFIG node in AllLay)
            {
                int j_temp = 0;
                string layShow = "<li class=\"has-sub\">";// 选中第二级的项，默认第一项 如果上次选中过则记录上次的
                if (layIndex == 0)
                {
                    layShow = "<li class=\"has-sub active\">";
                }
                int layCount = AllLay.Count;//获取一级菜单的总数
                string layText = node.ASIANAME;
                menu.Append(string.Format(layShow + "<a href=\"javascript:;\" class=\"\" ><i class=\"fa fa-table fa-fw\"></i> <span class=\"menu-text\">" + layText + "</span><span class=\"arrow open\"></span><span class=\"selected\"></span></a>"));
                menu.Append(string.Format("<ul class=\"sub\">"));
                //角色和左侧菜单表主键
                string rtID = string.Empty;
                int childNoedIndex = 0;//二级菜单索引
                foreach (Model_PZ_MENUCONFIG childNode in GetListByAuthor(uid, node.ASIACODE))
                {
                    if (!MapMenu.Contains(childNode.ASIANAME))
                    {
                        continue;
                    }
                    //默认选中二级第一项
                    var nodename = childNode.ASIANAME;
                    var res = resItem.Where(it => it.resourceName == nodename);
                    if (res.Any() || !resItem.Any())
                    {
                        defSelected = childNoedIndex == 0 ? childNode.ASIACODE : "";
                        rtID = childNode.ID;
                        string childNode_id = childNode.ASIACODE;
                        string childeNode_trid = childNode.RTID;
                        string childNode_SpanText = GetOrderNumber(ConvertUtil.ToString(childNode.SQLCOUNT), childNode.PARENTCODE, uid).ToString();//工单数目
                        string childNode_num = string.Format("(<span class=\"processItem\" id=\"lb_{0}\" runat=\"server\">{1}</span>)", childNode.ASIACODE, childNode_SpanText);
                        string childNode_img = !string.IsNullOrEmpty(childNode.PICDIC) ? string.Format("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"{0}\" align=\"absmiddle\"/>", childNode.PICDIC) : " ";
                        string childNode_iscreate = childNode.ISCREATE;//是否点击工单top部门生成操作按钮
                        string childNode_isadd = GetOrderType(node.ASIANAME);// "1";//自开单类型
                        string childNode_class = defSelected == childNode.ASIACODE ? "state_select" : "state";//默认选中二级第一项
                        //menu.Append(string.Format("<td id=\"lay{0}_{1}\" class='{5}' style='vertical-align: middle; display: block;' onclick=\"javascript:showstate(this.id,'{2}','{3}','{4}','{6}','{7}')\" onmouseover='bgCOver(this);' onmouseout='bgCOut(this);' >", layIndex.ToString(), childNoedIndex.ToString(), childNode_iscreate, childNode_isadd, rtID, childNode_class, childNode.ASIANAME, layText));

                        string SpanText = "(" + childNode_SpanText + ")";
                        if (MenuBadge.Contains(childNode.ASIANAME))
                        {
                            SpanText = "<span class='badge'>" + childNode_SpanText + "</span>";
                        }
                        if (i_temp == 0 && j_temp == 0)
                        {
                            menu.Append(string.Format("<li><a class=\"\"  id=\"" + childNode.ID + "\"  href=\"javascript:refreshTable('{0}','{4}')\"><img src='" + childNode.PICDIC + "' />&nbsp;&nbsp;<span class=\"sub-menu-text\" id=\"first_li\">" + childNode.ASIANAME + SpanText + "</span></a></li>", uid.ToString(), childNoedIndex.ToString(), childNode_iscreate, childNode_isadd, rtID, childNode_class, childNode.ASIANAME, layText));
                        }
                        else
                        {
                            menu.Append(string.Format("<li><a class=\"\" id=\"" + childNode.ID + "\"  href=\"javascript:refreshTable('{0}','{4}')\"><img src='" + childNode.PICDIC + "' />&nbsp;&nbsp;<span class=\"sub-menu-text\">" + childNode.ASIANAME + SpanText + "</span></span></a></li>", uid.ToString(), childNoedIndex.ToString(), childNode_iscreate, childNode_isadd, rtID, childNode_class, childNode.ASIANAME, layText));
                        }

                        childNoedIndex++;//菜单子项索引自增


                        j_temp++;
                    }
                }


                menu.Append("</ul></li>");
                i_temp++;
                layIndex++;//lay索引自增
            }


            root.Append(menu.ToString());
        }

        /// <summary>
        /// 获取二级菜单
        /// </summary>
        /// <param name="temp"></param>
        public StringBuilder GetTreeNode(string uid, string type)
        {
            StringBuilder temp = new StringBuilder();
            StringBuilder noderoot = new StringBuilder();
            GetTreeChildNode(noderoot, "0", uid, type);
            temp.Append(noderoot);
            return temp;
        }

        /// <summary>
        /// 获取三级菜单
        /// </summary>
        /// <param name="root"></param>
        /// <param name="_pid">一级节点编号</param>
        protected void GetTreeChildNode(StringBuilder root, string _pid, string uid, string type)
        {
            StringBuilder menu = new StringBuilder();
            string defSelected = string.Empty;// 获取页面默认选中
            int layIndex = 0;//一级菜单索引
            //string MenuBadge = Convert.ToString(ConfigurationManager.AppSettings["MenuBadge"]);
            //string MapMenu = Convert.ToString(ConfigurationManager.AppSettings["MapMenu"]);
            System.Collections.ArrayList list = PublicFunction.GetAcceptstationInfoForDIsp(uid, type);

            string shoulizhandian = PublicFunction.ConvertArrayListToString(list);
            List<Model_PZ_MENUCONFIG> AllLay = GetListByAuthor(uid, shoulizhandian, "0", type);
            int i_temp = 0;
            foreach (Model_PZ_MENUCONFIG node in AllLay)
            {
                int j_temp = 0;
                string layShow = "<li class=\"has-sub\">";// 选中第二级的项，默认第一项 如果上次选中过则记录上次的
                if (layIndex == 0)
                {
                    layShow = "<li class=\"has-sub active\">";
                }
                int layCount = AllLay.Count;//获取一级菜单的总数
                string layText = node.ASIANAME;
                menu.Append(string.Format(layShow + "<a href=\"javascript:;\" class=\"\" ><i class=\"fa fa-table fa-fw\"></i> <span class=\"menu-text\">" + layText + "</span><span class=\"arrow open\"></span><span class=\"selected\"></span></a>"));
                menu.Append(string.Format("<ul class=\"sub\">"));
                //角色和左侧菜单表主键
                string rtID = string.Empty;
                int childNoedIndex = 0;//二级菜单索引
                foreach (Model_PZ_MENUCONFIG childNode in GetListByAuthorC(uid, node.ASIACODE, type))
                {
                    //if (!MapMenu.Contains(childNode.ASIANAME))
                    //{
                    //    continue;
                    //}
                    //默认选中二级第一项
                    var nodename = childNode.ASIANAME;
                    var res = resItem.Where(it => it.resourceName == nodename);
                    if (res.Any() || !resItem.Any())
                    {
                        defSelected = childNoedIndex == 0 ? childNode.ASIACODE : "";
                        rtID = childNode.ID;
                        string childNode_id = childNode.ASIACODE;
                        string childeNode_trid = childNode.RTID;
                        string childNode_SpanText = GetOrderNumber(ConvertUtil.ToString(childNode.SQLCOUNT), childNode.PARENTCODE, uid, type).ToString();//工单数目
                        string childNode_num = string.Format("(<span class=\"processItem\" id=\"lb_{0}\" runat=\"server\">{1}</span>)", childNode.ASIACODE, childNode_SpanText);
                        string childNode_img = !string.IsNullOrEmpty(childNode.PICDIC) ? string.Format("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"{0}\" align=\"absmiddle\"/>", childNode.PICDIC) : " ";
                        string childNode_iscreate = childNode.ISCREATE;//是否点击工单top部门生成操作按钮
                        string childNode_isadd = GetOrderType(node.ASIANAME);// "1";//自开单类型
                        string childNode_class = defSelected == childNode.ASIACODE ? "state_select" : "state";//默认选中二级第一项
                        //menu.Append(string.Format("<td id=\"lay{0}_{1}\" class='{5}' style='vertical-align: middle; display: block;' onclick=\"javascript:showstate(this.id,'{2}','{3}','{4}','{6}','{7}')\" onmouseover='bgCOver(this);' onmouseout='bgCOut(this);' >", layIndex.ToString(), childNoedIndex.ToString(), childNode_iscreate, childNode_isadd, rtID, childNode_class, childNode.ASIANAME, layText));

                        string SpanText = "(" + childNode_SpanText + ")";
                        //if (MenuBadge.Contains(childNode.ASIANAME))
                        //{
                        //    SpanText = "<span class='badge'>" + childNode_SpanText + "</span>";
                        //}
                        if (i_temp == 0 && j_temp == 0)
                        {
                            menu.Append(string.Format("<li><a class=\"\"  id=\"" + childNode.ID + "\"  href=\"javascript:refreshTable('{0}','{4}')\"><img src='" + childNode.PICDIC + "' />&nbsp;&nbsp;<span class=\"sub-menu-text\" id=\"first_li\">" + childNode.ASIANAME + SpanText + "</span></a></li>", uid.ToString(), childNoedIndex.ToString(), childNode_iscreate, childNode_isadd, rtID, childNode_class, childNode.ASIANAME, layText));
                        }
                        else
                        {
                            menu.Append(string.Format("<li><a class=\"\" id=\"" + childNode.ID + "\"  href=\"javascript:refreshTable('{0}','{4}')\"><img src='" + childNode.PICDIC + "' />&nbsp;&nbsp;<span class=\"sub-menu-text\">" + childNode.ASIANAME + SpanText + "</span></span></a></li>", uid.ToString(), childNoedIndex.ToString(), childNode_iscreate, childNode_isadd, rtID, childNode_class, childNode.ASIANAME, layText));
                        }

                        childNoedIndex++;//菜单子项索引自增


                        j_temp++;
                    }
                }


                menu.Append("</ul></li>");
                i_temp++;
                layIndex++;//lay索引自增
            }


            root.Append(menu.ToString());
        }


        /// <summary>
        /// 获取类型（抢修0，巡检1，听漏2） 
        /// </summary>
        /// <param name="asianame"></param>
        /// <returns></returns>
        private string GetOrderType(string asianame)
        {
            string type = "0";
            if (asianame.Equals("管网巡检"))
            {
                type = "1";
            }
            else if (asianame.Equals("管网听漏"))
            {
                type = "2";
            }
            return type;
        }
        /// <summary>
        /// 根据pid 过滤 受理站点 获取当前状态下该受理站点 工单数目
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="pid"></param>
        /// <returns></returns>
        protected string GetOrderNumber(string sql, string pid, string cuser, string type)
        {
            if (string.IsNullOrEmpty(sql))
                return "0";
            return DAL_AuthorGlobal.GetOrderNumber(sql, type);
        }
        /// <summary>
        /// 根据pid 过滤 受理站点 获取当前状态下该受理站点 工单数目
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="pid"></param>
        /// <returns></returns>
        protected int GetOrderNumber(string sql, string pid, string cuser)
        {
            if (string.IsNullOrEmpty(sql))
                return 0;
            StringBuilder str_sql = new StringBuilder();
            str_sql.Append(ConfigurationManager.AppSettings["Left_Count"]);
            str_sql.Append(sql);
            //如果配置的菜单，没有划分权限 如 总调度 大类 ，权限站点就用办事处的
            //string resourceCategoryName = !string.IsNullOrEmpty(pid) ? bll_left.GetAsianameByID(pid).ToString() : "";
            //ArrayList list = DAL_AuthorGlobal.GetAuthResourceNameByResourceCategoryName(permissionResult, authorType, resourceCategoryName);
            //string acceptstation = ConvertArrayListToString(list);
            //if (!string.IsNullOrEmpty(acceptstation))
            //{
            //    str_sql.Append(string.Format(" AND ACCEPTSTATION IN ({0})", acceptstation));
            //}
            hugegis.BLL.BLL_WebPage.BLL_Left bll_left = new hugegis.BLL.BLL_WebPage.BLL_Left();
            return bll_left.GetOrderNumber(string.Format(str_sql.ToString(), cuser));
        }
        /// <summary>
        ///  根据权限 获取 菜单类
        /// </summary>
        /// <returns></returns>
        protected List<hugegis.Model.Model_PZ_MENUCONFIG> GetListByAuthor(string uid, string _pid)
        {
            return DAL_AuthorGlobal.GetMenuCongif(uid, _pid);
        }
        /// <summary>
        ///  根据权限 获取 菜单类
        /// </summary>
        /// <returns></returns>
        protected List<hugegis.Model.Model_PZ_MENUCONFIG> GetListByAuthorC(string uid, string _pid, string type)
        {
            return DAL_AuthorGlobal.GetMenuCongifC(uid, _pid, type);
        }
        /// <summary>
        ///  根据权限 获取 菜单类
        /// </summary>
        /// <returns></returns>
        protected List<hugegis.Model.Model_PZ_MENUCONFIG> GetListByAuthor(string uid, string shoulizhandian, string _pid, string type)
        {
            return DAL_AuthorGlobal.GetMenuCongif(uid, shoulizhandian, _pid, type);
        }
        /// <summary>
        ///  根据权限 获取 菜单类
        /// </summary>
        /// <returns></returns>
        protected List<hugegis.Model.Model_PZ_MENUCONFIG> GetListByAuthor(string uid, string shoulizhandian, string _pid)
        {
            return DAL_AuthorGlobal.GetMenuCongif(uid, shoulizhandian, _pid);
        }
    }
}