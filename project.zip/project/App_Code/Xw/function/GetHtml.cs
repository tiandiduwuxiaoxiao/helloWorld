﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using OrderFunction;

/// <summary>
///GetHtml 的摘要说明
/// </summary>
public class GetHtml
{
    private int column_count = 3;
    public GetHtml()
    {
        //
        //TODO: 在此处添加构造函数逻辑
        //
    }

    public string GetBodyContent(string tablename, List<string> containList)
    {
        //获取需要用于搜索的字段
        List<FormControl> flist = GetFormLists(tablename, containList);
        StringBuilder sb = new StringBuilder();
        if (flist!=null)
        {
            int i = 0;
            sb.Append("<div class='row'>");
            sb.Append("<div class='col-lg-12 col-lg-offset-0'>");
            sb.Append("<table class=\"table\" border='0'  cellspacing='0' cellpadding='0' id=\"tbinput\"  align=\"center\">");
            foreach (FormControl c in flist)
            {
                if (i % column_count == 0)
                {
                    sb.Append("<tr>");
                }
                if (i % column_count == (column_count - 1))
                {
                    sb.Append("<td style='width:10%'>");
                    string s = string.Format("<strong>{0}：</strong>", c.FieldDisName);
                    sb.Append(s);
                    sb.Append("</td>");
                    sb.Append("<td style='width:23%'>");
                    s = c.GetSearchHtmlText(c);
                    sb.Append(s);
                    sb.Append("</td>");
                    sb.Append("</tr>");
                }
                else
                {
                    sb.Append("<td style='width:10%'>");
                    string s = string.Format("<strong>{0}：</strong>", c.FieldDisName);
                    sb.Append(s);
                    sb.Append("</td>");
                    sb.Append("<td style='width:23%'>");
                    s = c.GetSearchHtmlText(c);
                    sb.Append(s);
                    sb.Append("</td>");
                }
                i++;
            }
            sb.Append("</table>");
            sb.Append("</div>");
            sb.Append("</div>");    
        }
       
        return sb.ToString();
    }

    public List<FormControl> GetFormLists(string tablename,List<string> containList)
    {
        List<FormControl> flist = new List<FormControl>();
        Hashtable searchHashtable = InitCache.xwbm_sjzd;
        ArrayList seaList = null;
        if (searchHashtable != null && tablename != null)
        {
            seaList = (ArrayList)searchHashtable[tablename.ToUpper()];
        }
        if (seaList != null)
        {
            StringBuilder upsql = new StringBuilder();
            for (int i = 0; i < seaList.Count; i++)
            {
                FormControl fc = new FormControl();
                DictionaryContent dc = (DictionaryContent)seaList[i];
                for (int j = 0; j < containList.Count; j++)
                {
                    if (!dc.style.Contains(containList[j]))
                    {
                        continue;
                    }
                    fc.TableName = dc.tableName;
                    fc.FieldDisName = dc.fieldAliasName;
                    fc.FieldName = dc.fieldName;
                    fc.FieldType = dc.style;
                    fc.FIELDORDER = dc.colid;
                    fc.MAPINGCODE = dc.dm;
                    fc.MAPSQL = dc.mappsql;
                    fc.VALIDRULES = dc.validrules;
                    fc.SUBFIELD = dc.subfield;
                    fc.Type = dc.fieldType;
                    fc.Length = (dc.fieldLength == "" ? 0 : Convert.ToInt32(dc.fieldLength));
                    flist.Add(fc);
                }
            }
        }

        return flist;
    }

}