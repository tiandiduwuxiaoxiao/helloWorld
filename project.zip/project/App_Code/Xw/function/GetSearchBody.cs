﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BootStrapControls;

/// <summary>
///GetSearchBody 的摘要说明
/// </summary>
public class GetSearchBody
{
	public GetSearchBody()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}

    /// <summary>
    /// 获取搜索页面
    /// </summary>
    /// <param name="tablename">表名</param>
    /// <returns></returns>
    public string GetSearchHtml(string tablename)
    {
        string returnStr = "";
        string error = "";
        string MAIN_INFO = "";

        GetHtml html = new GetHtml();
        try
        {
            MAIN_INFO = html.GetBodyContent(tablename.ToUpper(), Config.GetSearchCodeList());
        }
        catch (Exception ex)
        {
            error = ex.Message + ex.StackTrace;

            Loger.Error("获取搜索页面类GetSearchBody==>GetSearchHtml()=====》", ex);
        }

        if (string.IsNullOrEmpty(error))
        {
            //没有异常

            BootStrapControl c_temp = new BootStrapControl();
            if (string.IsNullOrEmpty(MAIN_INFO))
            {
                MAIN_INFO = "error!";
            }
            c_temp.HtmlText = string.Format("<div class=\"row\">{0}</div>", MAIN_INFO);

            string s_result = "";

            BtsInputButton btn1 = new BtsInputButton("搜索");
            btn1.InputID = "btnSearch";
            btn1.OnClick = "DetailSearch();";
            BtsColumnedControl cc1 = new BtsColumnedControl(btn1);
            cc1.ClassName = "col-md-2 fa fa-search";
            cc1.OffSet = "col-md-offset-4";

            BtsInputButton btn2 = new BtsInputButton("重置");
            btn2.ClassName = "btn btn-warning";
            btn2.InputID = "btnReset";
            btn2.OnClick = "resetSearch();";
            //btn2.OnClick = "showTableDiv();";
            BtsColumnedControl cc2 = new BtsColumnedControl(btn2);
            cc1.ClassName = "col-md-2";

            string s_btn = cc1.GetHtmlText() + cc2.GetHtmlText();
            string s_btnrow = BootStrapControl.AddDiv("row", s_btn);

       
            s_result = c_temp.HtmlText  + s_btnrow;
            //s_result = BootStrapControl.AddDiv("panel-body", s_result);
            //s_result = BootStrapControl.AddDiv("panel panel-default", s_result);
            s_result = BootStrapControl.AddDiv("col-lg-12", s_result);
            returnStr = s_result;
        }
        else
        {
            //出现异常
            BtsPage404 page404 = new BtsPage404();
            page404.Remark = "对不起，出错了...</br>error:" + error;
            page404.BackUrl = "javascript:showTableDiv();";
            returnStr = page404.GetHtmlText();
        }
        return returnStr;
    }
}