﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using BasicXwWebservice.Hugegis.function;
using MyAuth.authServices;

/// <summary>
/// Summary description for GetZhMenu
/// </summary>
public class GetZhMenu
{
    public GetZhMenu()
    {
    }
    public string getMenu(string uid,string type)
    {
        WSPermissionResult permissionResult = Global.getPermission(uid);
        StringBuilder temp = new StringBuilder();
        if (permissionResult != null)
        {
            IEnumerable<WSPermissionItem> resItem = permissionResult.permissions.Where(it => it.resourceCategoryName == "权限菜单");
            GetMenu menu = new GetMenu(resItem);
            temp = menu.GetTreeNode(uid, type);
        }
        return temp.ToString();
    }
}