﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///Location 的摘要说明
/// </summary>
public class Location
{
    public string lat { get; set; }
    public string lng { get; set; }
}