﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///baiduResult 的摘要说明
/// </summary>
public class baiduResult<T>
{
    public baiduResult()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    public string status { get; set; }
    public string message { get; set; }
    public List<T> result { get; set; }
}