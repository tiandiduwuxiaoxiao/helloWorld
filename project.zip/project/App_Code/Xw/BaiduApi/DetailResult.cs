﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///DetailResult 的摘要说明
/// </summary>
public class DetailResult<T>
{
	public string name { get; set; }
    public T location { get; set; }
    public string uid { get; set; }
    public string city { get; set; }
    public string district { get; set; }
    public string business { get; set; }
    public string cityid { get; set; }
}