﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// xlgctjBean 的摘要说明
/// </summary>
public class xlgctjBean
{
    public string xltjId;
    public string REPORTTYPE;//反映类别
    public string REPORTCONTENT;//反映内容
    public string REPORTAREA;//反映区名--TZ_MAIN
    public string MISSIONBH;//工作单号--TZ_MAIN
    public string HAPPENADDR;
    public string ACCEPTTIME;//接报时间--TZ_MAIN
    public string KGSJ;//开工时间--TZ_DXWXZY
    public string EXECUTIVETIME;//修复日期
    public string ISINTIME;//处理及时--TZ_MAIN
    public string ISZKD;//是否自开单--TZ_MAIN
    public string LSXZ;//漏水性质--TZ_DXWXZY
    public string CZ;//材质--TZ_DXWXZY
    public string LSSB;//修漏类别--TZ_DXWXZY
    public string XLHYCL;//修理耗用材料--TZ_DAXIUCLD
    public string LMXZ;//路面性质--TZ_DXWXZY
    public string SGD;//施工队
    public string EXECUTIVEPEOPLE;//领班人--TZ_MAIN
    public string XLRSTR;//修理人--TZ_MAIN
    public string EXECUTIVEREMARK;//备注--TZ_MAIN
    public string KJ;//口径
    public string EXECUTIVECONTENT;//处理内容
    public string occurreason;//发生原因
    public string resolvent;//解决措施
    public string YHTYPE;//养护分类
    public string p_ACCEPTSTATION;//管理所
    public string ACCEPTSTATION;//养护站点
    public string CUSTOMSERVICEID;//客服编码

    public xlgctjBean()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    /// <summary>
    /// 口径拆分 水表，格林、开关
    /// </summary>
    /// <param name="KJSTR"></param>
    /// <param name="spstrnum"></param>
    public static string SplitStr_KJ(xlgctjBean tempxlgctjBean, string KJSTR, int spstrnum)
    {
        if (tempxlgctjBean.REPORTTYPE == "套室表")
        {
            if (KJSTR.Split(',').Length >= 2)
                return KJSTR.Split(',')[spstrnum];
        }
        else if (tempxlgctjBean.REPORTTYPE == "水管设备" || tempxlgctjBean.REPORTTYPE == "水管问题")
        {
            return tempxlgctjBean.KJ;
        }
        return "";
    }
}
