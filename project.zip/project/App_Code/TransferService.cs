﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Net;

/// <summary>
/// Summary description for TransferService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class TransferService : System.Web.Services.WebService
{
    public TransferService()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    /// <summary>
    /// 通用查询，根据完整的查询语句和表名
    /// </summary>
    /// <param name="ConnSection">指定库</param>
    /// <param name="SQL">查询语句</param>
    /// <returns>返回json字符串</returns>
    [WebMethod(Description = "指定库SQL查询")]
    public string CommonSelect(string ConnSection, string SQL)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.CommonSelect(ConnSection, SQL);
    }

    [WebMethod(Description = "获取SCADA实时数据 tagName：标签名称 模拟值：'TM_CS_Z27_FL141_Flow'")]
    public string getScadaRealTimeData(string tagName)
    {
        WebReference.BusinessDataQuery bdq = new WebReference.BusinessDataQuery();
        return bdq.getScadaRealTimeData(tagName);
    }
    [WebMethod(Description = "获取SCADA历史数据 tagName：标签名称 startTime：开始时间 endTime：结束时间")]
    public string getScadaHistoryData(string tagName, string startTime, string endTime)
    {
        WebReference.BusinessDataQuery bdq = new WebReference.BusinessDataQuery();
        return bdq.getScadaHistoryData(tagName, startTime, endTime);
    }

    /// <summary>
    /// 通用查询，根据完整的查询语句和表名
    /// </summary>
    /// <param name="SQL">SQL语句</param>
    /// <param name="TableName">西文表名</param>
    /// <returns></returns>
    [WebMethod(Description = "通用查询")]
    public string AllTableSelect(string SQL, string TableName)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.AllTableSelect(SQL, TableName);
    }

    /// <summary>
    /// 获取某个库的字典信息
    /// </summary>
    /// <param name="ConnSection">指定库</param>
    /// <returns></returns>
    [WebMethod(Description = "获取指定库的字典信息")]
    public string GetAllDictByTableSpace(string ConnSection)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.GetAllDictByTableSpace(ConnSection);
    }

    /// <summary>
    /// 返回指定表的字典信息
    /// </summary>
    /// <param name="TableName">西文表名</param>
    /// <returns>表的字典信息xml</returns>
    [WebMethod(Description = "返回指定表的字典信息")]
    public string GetDictByTableName(string TableName)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.GetDictByTableName(TableName);
    }

    /// <summary>
    /// 空间查询初始化
    /// </summary>
    /// <returns></returns>
    [WebMethod(Description = "空间查询初始化")]
    public string SpatialQueryInit()
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.SpatialQueryInit();
    }

    /// <summary>
    /// 增删改通用方法，支持多语句及事务回滚机制（用；隔开）
    /// </summary>
    /// <param name="SQL">SQL语句</param>
    /// <returns></returns>
    [WebMethod(Description = "增删改通用")]
    public string IorDorUBySql(string ConnSection, string SQL)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.IorDorUBySql(ConnSection, SQL);
    }

    /// <summary>
    /// 汇总统计（SQL语句需含两个字段：First-SBLB，Second-统计类型）
    /// </summary>
    /// <param name="SQL">SQL语句</param>
    /// <returns></returns>
    [WebMethod(Description = "汇总统计")]
    public string ObjectStatistic(string SQL)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.ObjectStatistic(SQL);
    }

    /// <summary>
    /// 根据SQL语句获取数据库中BLOB文件
    /// </summary>
    /// <param name="ConnSection">数据库名称</param>
    /// <param name="SQL">查询的SQL语句,返回字段只能为BLOB字段</param>
    /// <param name="FileName">需要保持的文件名</param>
    /// <returns>返回BLOB字段对应的文件</returns>
    [WebMethod(Description = "根据SQL语句获取数据库中BLOB文件")]
    public string GetFileWithSQL(string ConnSection, string SQL, string FileName)
    {
        WebTransferService.CommonService cs = new WebTransferService.CommonService();
        return cs.GetFileWithSQL(ConnSection, SQL, FileName);
    }

    /// <summary>
    /// 获取IP
    /// </summary>
    /// <returns>客户端IP地址</returns>
    [WebMethod(Description = "查询IP")]
    public string GetClientIp()
    {
        string userHostAddress = "";
        //直接读取REMOTE_ADDR获取客户端IP地址
        if (string.IsNullOrEmpty(userHostAddress))
        {
            userHostAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }
        //失败，则利用Request.UserHostAddress属性获取IP地址，但此时无法确定该IP是客户端IP还是代理IP
        if (string.IsNullOrEmpty(userHostAddress))
        {
            userHostAddress = HttpContext.Current.Request.UserHostAddress;
        }
        //最后判断获取是否成功
        if (!string.IsNullOrEmpty(userHostAddress))
        {
            return userHostAddress;
        }
        return "127.0.0.1";
    }

    /// <summary>
    /// 查询
    /// </summary>
    /// <param name="LayerNames">图层名数组</param>
    /// <param name="SQL">查询条件</param>
    /// <returns></returns>
    [WebMethod(Description = "查图形属性(根据SQL)")]
    public string Identify(string LayerNames, string SQL)
    {
        WebTransferService.IdentifyService Identifys = new WebTransferService.IdentifyService();
        return Identifys.Identify(LayerNames, SQL);
    }

    [WebMethod(Description = "导出通用查询结果")]
    public string ExportExcelByCommQuery(string SQL, string tableName)
    {
        WebTransferService.ExporExcelService exporE = new WebTransferService.ExporExcelService();
        return exporE.ExportExcelByCommQuery(SQL, tableName);
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sblbStr">查询对象的SBLB字符串，用英文逗号分隔</param>
    /// <param name="spWhere">空间查询条件，必须是已在前台通过CommonSDESQL处理过的</param>
    /// <param name="layerViewRel">格式为"图层名称1":"物化视图名称1","图层名称2":"物化视图名称2",...</param>
    /// <returns></returns>
    [WebMethod(Description = "导出空间查询结果（XML格式的Excel）")]
    public string ExportExcelWithSpatial(string sblbStr, string spWhere, string layerViewRel)
    {
        WebTransferService.ExporExcelService exporE = new WebTransferService.ExporExcelService();
        return exporE.ExportExcelWithSpatial(sblbStr, spWhere, layerViewRel);
    }

    /// <summary>
    /// 查询用水量
    /// </summary>
    /// <param name="userID">用户编号</param>
    /// <param name="beginDate">开始时间</param>
    /// <param name="endDate">结束时间</param>
    /// <returns></returns>
    [WebMethod(Description = "查询用水量")]
    public string getCSMSRealTimeHisData(string userID, string beginDate, string endDate)
    {
        WebTransferService.BusinessDataQuery bdq = new WebTransferService.BusinessDataQuery();
        return bdq.getCSMSRealTimeHisData(userID, beginDate, endDate);
    }

    /// <summary>
    /// 施工停水分析
    /// </summary>
    /// <param name="xyStr">施工点坐标，可为多个，格式为：x1,y1;x2,y2</param>
    /// <param name="gjzs">要忽略的阀门关键字，格式为gjz1,gjz2</param>
    /// <param name="optType">是否考虑水源,1为不考虑，2为考虑</param>
    /// <returns></returns>
    [WebMethod(Description = "施工停水分析")]
    public string BestSolution(string xyStr, string gjzs, int optType)
    {
        WebTransferService.NetAnalysis ns = new WebTransferService.NetAnalysis();
        return ns.BestSolution(xyStr, gjzs, optType);
    }
    /// <summary>
    /// 关阀分析
    /// </summary>
    /// <param name="gjzs">阀门关键字，格式为gjz1,gjz2</param>
    /// <returns></returns>
    [WebMethod(Description = "关阀分析")]
    public string SwitchValve(string gjzStr)
    {
        WebTransferService.NetAnalysis ns = new WebTransferService.NetAnalysis();
        return ns.SwitchValve(gjzStr);
    }
    /// <summary>
    /// 返回PDA列表
    /// </summary>
    /// <returns>返回PDA列表</returns>
    [WebMethod(Description = "返回PDA列表")]
    public string GetPDAList()
    {
        WebTransferService.PDAServices cs = new WebTransferService.PDAServices();
        return cs.GetPDAList();
    }

    /// <summary>
    /// 返回PDA历史轨迹
    /// </summary>
    /// <param name="PDAID">PDAID</param>
    /// <param name="BeginTime">开始时间</param>
    /// <param name="EndTime">结束时间</param>
    /// <param name="ConnSection">指定库连接</param>
    /// <returns></returns>
    [WebMethod(Description = "返回PDA历史轨迹,可以有多个PDA人员，PDAID参数格式：1 或者 1,2")]
    public string GetPDATrackposList(string PDAID, string BeginTime, string EndTime, string ConnSection)
    {
        WebTransferService.PDAServices pdaS = new WebTransferService.PDAServices();
        return pdaS.GetPDATrackposList(PDAID, BeginTime, EndTime, ConnSection);
    }

    /// <summary>
    /// 获取CAD导出图层
    /// </summary>
    /// <returns>返回CAD导出图层</returns>
    [WebMethod(Description = "返回图片名称")]
    public string InitPrintLayers()
    {
        WebTransferService.ExportCADService cs = new WebTransferService.ExportCADService();
        return cs.InitCADLayers();
    }

    /// <summary>
    /// 获取CAD导出图层
    /// </summary>
    /// <returns>返回CAD导出图层</returns>
    [WebMethod(Description = "返回执行结果")]
    public bool ExportCADBySelectedLayers(string Coordinates, string DxfName, string SelectedLayers)
    {
        WebTransferService.ExportCADService cs = new WebTransferService.ExportCADService();
        return cs.ExportCADBySelectedLayers(Coordinates, DxfName, SelectedLayers);
    }

    /// <summary>
    /// 获取CAD导出图层
    /// </summary>
    /// <returns>返回CAD导出图层</returns>
    [WebMethod(Description = "返回执行结果")]
    public bool ExportCAD(string Coordinates, string DxfName)
    {
        WebTransferService.ExportCADService cs = new WebTransferService.ExportCADService();
        return cs.ExportCAD(Coordinates, DxfName);
    }

    /// <summary>
    /// 生成横剖面
    /// </summary>
    /// <returns>生成横剖面</returns>
    [WebMethod(Description = "")]
    public string GetProfilePicData(double x1, double y1, double x2, double y2)
    {
        WebTransferService.ProfileService cs = new WebTransferService.ProfileService();
        return cs.GetProfilePicData(x1, y1, x2, y2);
    }

    /// <summary>
    /// 经纬度转地方坐标
    /// </summary>
    /// <returns>经纬度转地方坐标</returns>
    [WebMethod(Description = "返回地方坐标")]
    public string WGS84ToXY(double x, double y)
    {
        WebTransferService.CoordinateConvert cs = new WebTransferService.CoordinateConvert();
        return cs.WGS84ToXY(x.ToString(), y.ToString());
    }

    /// <summary>
    /// 地方坐标转经纬度
    /// </summary>
    /// <returns>地方坐标转经纬度</returns>
    [WebMethod(Description = "返回经纬度")]
    public string XYToWGS84(double x, double y)
    {
        WebTransferService.CoordinateConvert cs = new WebTransferService.CoordinateConvert();
        return cs.XYToWGS84(x.ToString(), y.ToString());
    }

    [WebMethod]
    public object Login(string uid, string pwd)
    {
        userinfo mUser = new userinfo();
        try
        {
            var resourcename = "all";
            WebTransferService.AuthService cs = new WebTransferService.AuthService();
            var ss = cs.getPermission(uid, pwd);
            if (ss.user.userType != "超级管理员")
            {
                if (ss.permissions != null)
                {
                    for (int i = 0; i < ss.permissions.Length; i++)
                    {
                        resourcename += ss.permissions[i].resourceName + ",";
                    }
                }
            }
            mUser.user = uid;
            mUser.password = pwd;
            mUser.realname = ss.user.realName;
            mUser.usertype = ss.user.userType;
            mUser.resourcename = resourcename;
            mUser.succeed = ss.success;
            return mUser;
        }
        catch (Exception ex)
        {
        }
        return null;
    }

    public class userinfo
    {
        public string user { get; set; }
        public string password { get; set; }
        public string resourcename { get; set; }
        public string realname { get; set; }
        public string usertype { get; set; }
        public bool succeed { get; set; }
    }

    #region 现维
    /// <summary>
    /// 获取详细
    /// </summary>
    /// <param name="ID"></param>
    /// <returns></returns>
    [WebMethod]
    public string GetDetailByIdForMap(string ID, string UID)
    {
        BasicXwService.BusinessDataXwSoapClient client = new BasicXwService.BusinessDataXwSoapClient();
        return client.GetDetailByIdForMap(ID, UID, false);
    }
    #endregion

    /// <summary>
    /// 部门树获取
    /// </summary>
    /// <returns>部门树xml数据</returns>
    [WebMethod(Description = "返回地方坐标")]
    public string CompanyTreeQuery(string userType)
    {
        WebTransferService.CompanyQueryService cqs = new WebTransferService.CompanyQueryService();
        return cqs.GetCompanyTreeByUserName(userType);
    }
}
