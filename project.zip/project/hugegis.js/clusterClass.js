﻿define([
    'dojo/_base/declare',
    'dijit/_TemplatedMixin',
    'dijit/_WidgetsInTemplateMixin',
    'dijit/_WidgetBase',
    'dojo/on',
    'dojo/_base/lang',
    'dojo/_base/array',
    "esri/layers/GraphicsLayer",
    "esri/geometry/Point",
    'esri/geometry/Polyline',
    './ClusterLayer',
    "esri/graphic",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/SimpleFillSymbol",
    "esri/symbols/PictureMarkerSymbol",
    "esri/renderers/ClassBreaksRenderer"
],
function (declare, _TemplatedMixin, _WidgetsInTemplateMixin, _WidgetBase, on, lang, array, GraphicsLayer, Point,
    Polyline, ClusterLayer, graphic, SimpleMarkerSymbol, SimpleFillSymbol, PictureMarkerSymbol, ClassBreaksRenderer) {
    return declare(null, {
        map: null,                    //顶层地图
        clusterGraphicsLayer: null,   //聚类展示的图层
        clusterPointsArray: [],       //聚类展示的点集
        clusterDistance: 0,           //聚类展示的距离
        parentWidget: null,           //父组件

        constructor: function () {
            this.clusterPointsArray = arguments[0] ? arguments[0] : [];
            this.clusterDistance = arguments[1] ? arguments[1] : 100;//默认给100
            this.parentWidget = arguments[2] ? arguments[2] : null;
            this.map = window._widgetManager.map;
            this.clusterDisplay();
        },
        //聚类展示
        clusterDisplay: function () {
            var currentLayer = this.map.getLayer('clusterLayerID');
            try {
                if (currentLayer) {
                    this.map.removeLayer(currentLayer);
                }
            } catch (err) {
                console.error(err.toString());
            }
            finally {
                var data = array.map(this.clusterPointsArray, function (item) {
                    if (item.X && item.Y) {
                        return {
                            'x': Number(item.X),
                            'y': Number(item.Y),
                            'jobNumber': item.ID || item.id ? item.ID || item.id : null//现维需求
                        };
                    } else if (item.x && item.y) {
                        return {
                            'x': Number(item.x),
                            'y': Number(item.y),
                            'jobNumber': item.ID || item.id ? item.ID || item.id : null
                        };
                    }

                });
                this.clusterGraphicsLayer = new ClusterLayer({
                    'data': data,
                    "distance": this.clusterDistance,
                    "id": "clusterLayerID",
                    "labelColor": "#fff",
                    "labelOffset": 10,
                    "resolution": this.map.extent.getWidth() / this.map.width,
                    "singleColor": "#888",
                    "singleTemplate": null,
                    "spatialReference": this.map.spatialReference
                });
                var defaultSym = new SimpleMarkerSymbol().setSize(4);
                var renderer = new ClassBreaksRenderer(defaultSym, "clusterCount");
                var iconUrl = require.toUrl('hugegis');
                //8种颜色区分
                var a = new PictureMarkerSymbol(iconUrl + "/images/cluster/redPoint.png", 15, 15).setOffset(0, 0);
                var b = new PictureMarkerSymbol(iconUrl + "/images/cluster/b.png", 44, 44).setOffset(0, 15);
                var c = new PictureMarkerSymbol(iconUrl + "/images/cluster/c.png", 55, 55).setOffset(0, 15);
                var d = new PictureMarkerSymbol(iconUrl + "/images/cluster/d.png", 66, 66).setOffset(0, 15);
                var e = new PictureMarkerSymbol(iconUrl + "/images/cluster/e.png", 72, 72).setOffset(0, 15);
                var f = new PictureMarkerSymbol(iconUrl + "/images/cluster/f.png", 72, 72).setOffset(0, 15);
                var g = new PictureMarkerSymbol(iconUrl + "/images/cluster/g.png", 72, 72).setOffset(0, 15);
                var h = new PictureMarkerSymbol(iconUrl + "/images/cluster/h.png", 72, 72).setOffset(0, 15);
                //颜色分配
                renderer.addBreak(0, 1, a);//0~1确定为a
                var count = this.clusterPointsArray.length - 1;
                if (count < 77) {
                    renderer.addBreak(2, 6, b);
                    renderer.addBreak(7, 16, c);
                    renderer.addBreak(17, 24, d);
                    renderer.addBreak(25, 34, e);
                    renderer.addBreak(35, 50, f);
                    renderer.addBreak(51, 62, g);
                    renderer.addBreak(63, 77, h);
                } else {
                    var num = parseInt(count / 7);
                    renderer.addBreak(2, num * 1 + 1, b);
                    renderer.addBreak(num * 1 + 2, num * 2 + 1, c);
                    renderer.addBreak(num * 2 + 2, num * 3 + 1, d);
                    renderer.addBreak(num * 3 + 2, num * 4 + 1, e);
                    renderer.addBreak(num * 4 + 2, num * 5 + 1, f);
                    renderer.addBreak(num * 5 + 2, num * 6 + 1, g);
                    renderer.addBreak(num * 6 + 2, count + 1, h);
                }

                this.clusterGraphicsLayer.setRenderer(renderer);
                this.map.addLayer(this.clusterGraphicsLayer);
                this.clusterGraphicsLayer.refresh();
                this.clusterGraphicsLayer.on('click', lang.hitch(this, this.onClick));
                this.clusterGraphicsLayer.on('mouse-over', lang.hitch(this, this.onMouseOver));
                this.clusterGraphicsLayer.on('mouse-out', lang.hitch(this, this.onMouseOut));
            }
        },
        //隐藏
        hide: function () {
            if (this.clusterGraphicsLayer) {
                this.clusterGraphicsLayer.hide();
                this.clusterGraphicsLayer.refresh();
            }
        },
        //显示
        show: function () {
            if (this.clusterGraphicsLayer) {
                this.clusterGraphicsLayer.show();
                this.clusterGraphicsLayer.refresh();
            }
        },
        //清除
        clear: function () {
            if (this.clusterGraphicsLayer) {
                this.map.removeLayer(this.clusterGraphicsLayer);
            }
        },
        //点击
        onClick: function (e) {
            if (this.parentWidget) {
                if (this.parentWidget.clusterClickEvent) {
                    this.parentWidget.clusterClickEvent(e)
                } else {
                    console.warn('调用的方法不存在!');
                }
            }
        },
        //mouseOver
        onMouseOver: function (e) {
            //e.target.href.animVal = require.toUrl('hugegis') + "/images/point/l_0.png";
        },
        onMouseOut: function (e) {

        }
    })
});