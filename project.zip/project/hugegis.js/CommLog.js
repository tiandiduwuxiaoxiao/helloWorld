﻿define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/request/xhr",
    "dojo/query",
    "dojo/string"
    ],
    function (declare, array, lang, xhr, query, string) {
        return declare(null, {
            logHis: [],
            sysType: 1,
            ip: "",

            commitLog: function (user, opr, uid) {
                if (uid == "") {
                    uid = this.guid();
                }
                if (this.appConfig.SysType) {
                    this.sysType = this.appConfig.SysType;
                }
                var thisTemp = this;
                var today = new Date(),
                year = today.getFullYear(),
                month = today.getMonth() + 1,
                day = today.getDate(),
                hour = today.getHours(),
                minute = today.getMinutes(),
                second = today.getSeconds(),
                time = year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
                var tmpDateStr = "to_date('" + time + "','yyyy-mm-dd hh24:mi:ss')"
                var sql = "insert into OPERATIONLOG (USERNAME,LOGTIME,MENO,TYPE,IP) values ('" + user + "'," + tmpDateStr + ",'" + opr + "','" + this.sysType + "','" + this.ip + "')";
                var url = window.path + this.appConfig.services.CommonServiceURL + "/IorDorUBySql";
                var myname = dojo.toJson({ "ConnSection": "PropDBConn", "SQL": sql });
                var xhrArgs = {
                    url: url,
                    handleAs: "json",
                    headers: { "Content-Type": "application/json" },
                    postData: myname,
                    load: function (response) {
                        var Data = response.d;
                        if (Data) {
                            thisTemp.logHis.push({
                                id: uid,
                                user: user,
                                date: tmpDateStr,
                                value: opr,
                                type: thisTemp.sysType
                            });
                        }
                    },
                    error: function (error) {
                    }
                };
                dojo.xhrPost(xhrArgs);

            },
            cancelLog: function (uid) {
                var thisTemp = this;
                var index = this.getLog(uid);
                var temp = this.logHis[index];
                var sql = "delete from OPERATIONLOG where USERNAME='" + temp.user + "'" + " and LOGTIME = " + temp.date + " and MENO = '" + temp.value + "'" + " and TYPE = '" + temp.type + "'" + " and IP = '" + this.ip + "'";
                var url = window.path + this.appConfig.services.CommonServiceURL + "/IorDorUBySql";
                var myname = dojo.toJson({ "ConnSection": "PropDBConn", "SQL": sql });
                var xhrArgs = {
                    url: url,
                    handleAs: "json",
                    headers: { "Content-Type": "application/json" },
                    postData: myname,
                    load: function (response) {
                        var Data = response.d;
                        if (Data) {
                            thisTemp.logHis.splice(index, 1);
                        }
                    },
                    error: function (error) {
                    }
                };
                dojo.xhrPost(xhrArgs);

            },
            guid: function () {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },
            getIP: function () {
                var thisTemp = this;
                var url = window.path + this.appConfig.services.CommonServiceURL + "/GetClientIp";
                var xhrArgs = {
                    url: url,
                    handleAs: "json",
                    headers: { "Content-Type": "application/json" },
                    load: function (response) {
                        var Data = response.d;
                        if (Data) {
                            thisTemp.ip = Data;
                            thisTemp.commitLog(window.uid, "打开H5展示系统", "");
                        }
                    },
                    error: function (error) {
                    }
                };
                dojo.xhrPost(xhrArgs);
            },
            getLog: function (id) {
                for (var i = 0; i < this.logHis.length; i++) {
                    if (this.logHis[i].id == id) {
                        return i;
                    }
                }
            }
        });
    });