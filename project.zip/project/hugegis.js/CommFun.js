define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/query",
    "dojo/string",
  'dojo/request/xhr',
    'hugegis/HashTable'
    ],
    function (declare, array, lang, query, string, xhr, HashTable) {
        return declare(null, {
            dict_PropDBConn: null,
            sblb_PropDBConn: null,
            xyCoordinate: null,
            wgsCoordinate: null,

            getPermissions: function (value) {
                if (window.resname == "all" || !window._widgetManager.appConfig.usePermission) {
                    return true;
                }
                var userRes = window.resname;
                if (userRes.indexOf(value) >= 0) {
                    return true;
                }
                return false;
            },

            transferWGS84ToXY: function (x, y) {
                this.xyCoordinate = null;
                var thisTemp = this;
                var URL = window.path + this.appConfig.services.CoordinateTransServiceURL + "/WGS84ToXY";
                var myname = dojo.toJson({ "jd": x, "wd": y });
                var xhrArgs = {
                    url: URL,
                    handleAs: "json",
                    headers: { "Content-Type": "application/json" },
                    postData: myname,
                    load: function (response) {
                        var myData = dojo.fromJson(response.d);
                        thisTemp.xyCoordinate = myData[0];
                    },
                    error: function (error) {
                        alert("�ֵ����ѯ����!");
                    }
                };
                dojo.xhrPost(xhrArgs);
            },

            transferXYToWGS84: function (x, y) {
                this.wgsCoordinate = null;
                var thisTemp = this;
                var URL = window.path + this.appConfig.services.CoordinateTransServiceURL + "/XYToWGS84";
                var myname = dojo.toJson({ "x": x, "y": y });
                var xhrArgs = {
                    url: URL,
                    handleAs: "json",
                    headers: { "Content-Type": "application/json" },
                    postData: myname,
                    load: function (response) {
                        thisTemp.wgsCoordinate = response.d;
                    },
                    error: function (error) {
                        alert("�ֵ����ѯ����!");
                    }
                };
                dojo.xhrPost(xhrArgs);
            },

            supportPreserve3D: function() {
                var docElement = document.documentElement;
                var support = this.supportCSS('perspective');
                var body = document.body;
                if(support){
                    var style = document.createElement('style');
                    style.type = 'text/css';
                    style.innerHTML = '@media (transform-3d),(-webkit-transform-3d){#css3_3d_test{left:9px;position:absolute;height:3px;}}';
                    body.appendChild(style);
                    var div = document.createElement('div');
                    div.id = 'css3_3d_test';
                    body.appendChild(div);

                    support = div.offsetLeft === 9 && div.offsetHeight === 3;

                }
                return support;
            },

            supportCSS: function(prop) {
               var div = document.createElement('div'),
                  vendors = 'Khtml Ms O Moz Webkit'.split(' '),
                  len = vendors.length;
 
                if ( prop in div.style ) return true;
 
                prop = prop.replace(/^[a-z]/, function(val) {
                    return val.toUpperCase();
                });
 
                while(len--) {
                    if ( vendors[len] + prop in div.style ) {
                    // browser supports box-shadow. Do what you need.
                    // Or use a bang (!) to test if the browser doesn't.
                    return true;
                    } 
                }
                return false;
            },

        });
    });