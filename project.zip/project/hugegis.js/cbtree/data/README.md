#### Deprecated Stores ####

This directory contains cbtree Stores and add-ons based on the legacy dojo/data store. These stores are deprecated and will be removed with the release of dojo 2.0. Please refer to cbtree/store for new implementations based on the dojo/store API.
