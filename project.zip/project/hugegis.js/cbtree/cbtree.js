//>>built
require({
    cache: {
        "dijit/tree/_dndSelector": function () {
            define("dijit/tree/_dndSelector", "dojo/_base/array,dojo/_base/connect,dojo/_base/declare,dojo/_base/Deferred,dojo/_base/kernel,dojo/_base/lang,dojo/cookie,dojo/mouse,dojo/on,dojo/touch,./_dndContainer".split(","), function (j, m, h, f, c, e, d, b, a, k, n) {
                return h("dijit.tree._dndSelector", n, {
                    constructor: function () {
                        this.selection = {}; this.anchor = null; if (!this.cookieName && this.tree.id) this.cookieName = this.tree.id + "SaveSelectedCookie"; this.events.push(a(this.tree.domNode,
                        k.press, e.hitch(this, "onMouseDown")), a(this.tree.domNode, k.release, e.hitch(this, "onMouseUp")), a(this.tree.domNode, k.move, e.hitch(this, "onMouseMove")))
                    }, singular: !1, getSelectedTreeNodes: function () { var a = [], b = this.selection, k; for (k in b) a.push(b[k]); return a }, selectNone: function () { this.setSelection([]); return this }, destroy: function () { this.inherited(arguments); this.selection = this.anchor = null }, addTreeNode: function (a, b) { this.setSelection(this.getSelectedTreeNodes().concat([a])); if (b) this.anchor = a; return a },
                    removeTreeNode: function (a) { this.setSelection(this._setDifference(this.getSelectedTreeNodes(), [a])); return a }, isTreeNodeSelected: function (a) { return a.id && !!this.selection[a.id] }, setSelection: function (a) { var b = this.getSelectedTreeNodes(); j.forEach(this._setDifference(b, a), e.hitch(this, function (a) { a.setSelected(!1); this.anchor == a && delete this.anchor; delete this.selection[a.id] })); j.forEach(this._setDifference(a, b), e.hitch(this, function (a) { a.setSelected(!0); this.selection[a.id] = a })); this._updateSelectionProperties() },
                    _setDifference: function (a, b) { j.forEach(b, function (a) { a.__exclude__ = !0 }); var k = j.filter(a, function (a) { return !a.__exclude__ }); j.forEach(b, function (a) { delete a.__exclude__ }); return k }, _updateSelectionProperties: function () {
                        var a = this.getSelectedTreeNodes(), b = [], k = [], c = []; j.forEach(a, function (a) { var g = a.getTreePath(), d = this.tree.model; k.push(a); b.push(g); g = j.map(g, function (a) { return d.getIdentity(a) }, this); c.push(g.join("/")) }, this); a = j.map(k, function (a) { return a.item }); this.tree._set("paths", b); this.tree._set("path",
                        b[0] || []); this.tree._set("selectedNodes", k); this.tree._set("selectedNode", k[0] || null); this.tree._set("selectedItems", a); this.tree._set("selectedItem", a[0] || null); this.tree.persist && 0 < c.length && d(this.cookieName, c.join(","), { expires: 365 })
                    }, _getSavedPaths: function () { var a = this.tree; if (a.persist && a.dndController.cookieName) { var b = []; (a = d(a.dndController.cookieName)) && (b = j.map(a.split(","), function (a) { return a.split("/") })); return b } }, onMouseDown: function (a) {
                        if (!(!this.current || this.tree.isExpandoNode(a.target,
                        this.current) || "touchstart" != a.type && !b.isLeft(a))) { var k = this.current, c = m.isCopyKey(a), d = k.id; !this.singular && !a.shiftKey && this.selection[d] ? this._doDeselect = !0 : (this._doDeselect = !1, this.userSelect(k, c, a.shiftKey)) }
                    }, onMouseUp: function (a) { if (this._doDeselect) this._doDeselect = !1, this.userSelect(this.current, m.isCopyKey(a), a.shiftKey) }, onMouseMove: function () { this._doDeselect = !1 }, _compareNodes: function (a, b) {
                        if (a === b) return 0; if ("sourceIndex" in document.documentElement) return a.sourceIndex - b.sourceIndex;
                        if ("compareDocumentPosition" in document.documentElement) return a.compareDocumentPosition(b) & 2 ? 1 : -1; if (document.createRange) { var k = doc.createRange(); k.setStartBefore(a); var c = doc.createRange(); c.setStartBefore(b); return k.compareBoundaryPoints(k.END_TO_END, c) } throw Error("dijit.tree._compareNodes don't know how to compare two different nodes in this browser");
                    }, userSelect: function (a, b, k) {
                        if (this.singular) this.anchor == a && b ? this.selectNone() : (this.setSelection([a]), this.anchor = a); else if (k && this.anchor) {
                            k =
                            this.anchor; 0 > this._compareNodes(this.anchor.rowNode, a.rowNode) ? b = k : (b = a, a = k); for (k = []; b != a;) k.push(b), b = this.tree._getNextNode(b); k.push(a); this.setSelection(k)
                        } else this.selection[a.id] && b ? this.removeTreeNode(a) : b ? this.addTreeNode(a, !0) : (this.setSelection([a]), this.anchor = a)
                    }, getItem: function (a) { return { data: this.selection[a], type: ["treeNode"] } }, forInSelectedItems: function (a, b) { var b = b || c.global, k; for (k in this.selection) a.call(b, this.getItem(k), k, this) }
                })
            })
        }, "dijit/tree/TreeStoreModel": function () {
            define("dijit/tree/TreeStoreModel",
            ["dojo/_base/array", "dojo/aspect", "dojo/_base/declare", "dojo/_base/lang"], function (j, m, h, f) {
                return h("dijit.tree.TreeStoreModel", null, {
                    store: null, childrenAttrs: ["children"], newItemIdAttr: "id", labelAttr: "", root: null, query: null, deferItemLoadingUntilExpand: !1, constructor: function (c) {
                        f.mixin(this, c); this.connects = []; c = this.store; if (!c.getFeatures()["dojo.data.api.Identity"]) throw Error("dijit.tree.TreeStoreModel: store must support dojo.data.Identity"); if (c.getFeatures()["dojo.data.api.Notification"]) this.connects =
                        this.connects.concat([m.after(c, "onNew", f.hitch(this, "onNewItem"), !0), m.after(c, "onDelete", f.hitch(this, "onDeleteItem"), !0), m.after(c, "onSet", f.hitch(this, "onSetItem"), !0)])
                    }, destroy: function () { for (var c; c = this.connects.pop() ;) c.remove() }, getRoot: function (c, e) {
                        this.root ? c(this.root) : this.store.fetch({
                            query: this.query, onComplete: f.hitch(this, function (d) { if (1 != d.length) throw Error("dijit.tree.TreeStoreModel: root query returned " + d.length + " items, but must return exactly one"); this.root = d[0]; c(this.root) }),
                            onError: e
                        })
                    }, mayHaveChildren: function (c) { return j.some(this.childrenAttrs, function (e) { return this.store.hasAttribute(c, e) }, this) }, getChildren: function (c, e, d) {
                        var b = this.store; if (b.isItemLoaded(c)) {
                            for (var a = [], k = 0; k < this.childrenAttrs.length; k++) var n = b.getValues(c, this.childrenAttrs[k]), a = a.concat(n); var g = 0; this.deferItemLoadingUntilExpand || j.forEach(a, function (a) { b.isItemLoaded(a) || g++ }); 0 == g ? e(a) : j.forEach(a, function (k, c) {
                                b.isItemLoaded(k) || b.loadItem({
                                    item: k, onItem: function (l) {
                                        a[c] = l; 0 == --g &&
                                        e(a)
                                    }, onError: d
                                })
                            })
                        } else { var p = f.hitch(this, arguments.callee); b.loadItem({ item: c, onItem: function (a) { p(a, e, d) }, onError: d }) }
                    }, isItem: function (c) { return this.store.isItem(c) }, fetchItemByIdentity: function (c) { this.store.fetchItemByIdentity(c) }, getIdentity: function (c) { return this.store.getIdentity(c) }, getLabel: function (c) { return this.labelAttr ? this.store.getValue(c, this.labelAttr) : this.store.getLabel(c) }, newItem: function (c, e, d) {
                        var b = { parent: e, attribute: this.childrenAttrs[0] }, a; this.newItemIdAttr && c[this.newItemIdAttr] ?
                        this.fetchItemByIdentity({ identity: c[this.newItemIdAttr], scope: this, onItem: function (k) { k ? this.pasteItem(k, null, e, !0, d) : (a = this.store.newItem(c, b)) && void 0 != d && this.pasteItem(a, e, e, !1, d) } }) : (a = this.store.newItem(c, b)) && void 0 != d && this.pasteItem(a, e, e, !1, d)
                    }, pasteItem: function (c, e, d, b, a) {
                        var k = this.store, n = this.childrenAttrs[0]; e && j.forEach(this.childrenAttrs, function (a) { if (k.containsValue(e, a, c)) { if (!b) { var g = j.filter(k.getValues(e, a), function (a) { return a != c }); k.setValues(e, a, g) } n = a } }); if (d) if ("number" ==
                        typeof a) { var g = k.getValues(d, n).slice(); g.splice(a, 0, c); k.setValues(d, n, g) } else k.setValues(d, n, k.getValues(d, n).concat(c))
                    }, onChange: function () { }, onChildrenChange: function () { }, onDelete: function () { }, onNewItem: function (c, e) { e && this.getChildren(e.item, f.hitch(this, function (c) { this.onChildrenChange(e.item, c) })) }, onDeleteItem: function (c) { this.onDelete(c) }, onSetItem: function (c, e) { if (-1 != j.indexOf(this.childrenAttrs, e)) this.getChildren(c, f.hitch(this, function (d) { this.onChildrenChange(c, d) })); else this.onChange(c) }
                })
            })
        },
        "dojo/uacss": function () {
            define("dojo/uacss", ["./dom-geometry", "./_base/lang", "./ready", "./sniff", "./_base/window"], function (j, m, h, f, c) {
                var e = c.doc.documentElement, d = f("ie"), b = f("opera"), a = Math.floor, k = f("ff"), c = j.boxModel.replace(/-/, ""), d = { dj_ie: d, dj_ie6: 6 == a(d), dj_ie7: 7 == a(d), dj_ie8: 8 == a(d), dj_ie9: 9 == a(d), dj_quirks: f("quirks"), dj_iequirks: d && f("quirks"), dj_opera: b, dj_khtml: f("khtml"), dj_webkit: f("webkit"), dj_safari: f("safari"), dj_chrome: f("chrome"), dj_gecko: f("mozilla"), dj_ff3: 3 == a(k) }; d["dj_" +
                c] = !0; var n = "", g; for (g in d) d[g] && (n += g + " "); e.className = m.trim(e.className + " " + n); h(90, function () { if (!j.isBodyLtr()) { var a = "dj_rtl dijitRtl " + n.replace(/ /g, "-rtl "); e.className = m.trim(e.className + " " + a + "dj_rtl dijitRtl " + n.replace(/ /g, "-rtl ")) } }); return f
            })
        }, "cbtree/store/ObjectStore": function () {
            define("cbtree/store/ObjectStore", "module,dojo/_base/declare,dojo/_base/lang,dojo/store/util/QueryResults,./Hierarchy,../Evented,../errors/createError!../errors/CBTErrors.json".split(","), function (j, m,
            h, f, c, e, d) {
                var b = d(j.id); return m([c, e], {
                    eventable: !0, add: function (a, b) { var c = this.inherited(arguments); void 0 != c && this.emit("new", { type: "new", detail: { item: a } }); return c }, put: function (a, k) { var c = this._getObjectId(a, k), g = this._indexId[c], d, e = !1; if (0 <= g) { if (k && !1 === k.overwrite) throw new b("ItemExist", "put"); d = this._data[g]; e = !0 } c = this._writeObject(c, a, g, k); e ? this.emit("change", { type: "change", detail: { item: a, oldItem: d } }) : this.emit("new", { type: "new", detail: { item: a } }); return c }, remove: function (a) {
                        var b =
                        this.get(a); if (b) { var c = this.inherited(arguments); c && this.emit("delete", { type: "delete", detail: { item: b } }); return c } return !1
                    }
                })
            })
        }, "cbtree/store/extensions/CORS": function () {
            define("cbtree/store/extensions/CORS", "module,dojo/_base/lang,dojo/Deferred,dojo/request,dojo/request/handlers,../Memory,../../errors/createError!../../errors/CBTErrors.json".split(","), function (j, m, h, f, c, e, d) {
                var b = d(j.id); e.extend({
                    timeout: null, _xhrGet: function (a, k, d) {
                        var d = m.mixin({ timeout: this.timeout }, d), g = null; if (/^https?\:\/\//i.test(a)) if ("undefined" !==
                        typeof XDomainRequest) { var e = new XDomainRequest, q = new h(e.abort); if (e) { e.onprogress = function () { }; e.onload = function () { var a = c({ text: e.responseText, options: { handleAs: k } }).data; q.resolve(a) }; e.onerror = function () { q.reject(new b("RequestError", "_xhrGet", "Failed to load: " + a)) }; e.ontimeout = function () { q.reject(new b("RequestError", "_xhrGet", "Timeout loading: " + a)) }; if (d.timeout && 0 < d.timeout) e.timeout = d.timeout; e.open("get", a); e.send(); return q.promise } } else g = { "X-Requested-With": null }; return f(this.url,
                        { method: "GET", handleAs: k, headers: g, timeout: d.timeout, preventCache: !0 })
                    }
                }); return !0
            })
        }, "cbtree/errors/createError": function () {
            define("cbtree/errors/createError", ["dojo/_base/lang", "dojo/request", "../util/shim/Array"], function (j, m) {
                function h(a) { switch (Object.prototype.toString.call(a)) { case "[object Array]": a.forEach(h); break; case "[object Object]": var k; a: { var c; for (k in a) if (/\W/.test(k) || !(c = a[k]) || !c.text) { k = !1; break a } k = !0 } k && (b = j.mixin(b, a)) } } function f(a, k) {
                    var c = (a || "").replace(/Error$/, ""),
                    g = c + "Error", d = { type: g, text: "", code: 0 }; c && (d = j.mixin(d, b[g] || b[c] || e)); d.text = k || d.text; return d
                } function c(a, b) {
                    function c(b, k, d) {
                        var l = a + (k ? g + k + "()" : ""), e; if (b instanceof Error) { for (e in b) b.hasOwnProperty(e) && (this[e] = b[e]); e = { type: b.name, code: b.code || 0, text: d || b.message } } else e = f(b, d); if (2 < arguments.length) { var n = Array.prototype.slice.call(arguments, 3); e.text = e.text.replace(/\%\{(\d+)\}/g, function (a, l) { return void 0 != n[l] ? n[l] : a }) } this.message = (l.length ? l + ": " : "") + e.text; this.code = e.code; this.name =
                        e.type
                    } var g = a ? "::" : "", a = a || ""; h(b || {}); c.prototype = Error(); return c.prototype.constructor = c
                } var e = { text: "Undefined error", code: 0 }, d = {}, b = {}; c.normalize = function (a, b) { var c = a.split("!"), c = c.map(function (a) { return /^\./.test(a) ? b(a) : a }); return c.join("!") }; c.load = function (a, b, e) { function g() { 0 == --p && e(c) } var a = a.split("!"), p = a.length; a.forEach(function (a) { a = b.toUrl(a); a in d ? g() : (m(a, { handleAs: "json" }).then(function (a) { h(a); g() }, function () { g() }), d[a] = !0) }) }; return c
            })
        }, "dojo/text": function () {
            define("dojo/text",
            ["./_base/kernel", "require", "./has", "./_base/xhr"], function (j, m, h, f) {
                var c; c = function (a, b, g) { f("GET", { url: a, sync: !!b, load: g, headers: j.config.textPluginHeaders || {} }) }; var e = {}, d = function (a) { if (a) { var a = a.replace(/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im, ""), b = a.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im); b && (a = b[1]) } else a = ""; return a }, b = {}, a = {}; j.cache = function (a, b, g) {
                    var p; "string" == typeof a ? /\//.test(a) ? (p = a, g = b) : p = m.toUrl(a.replace(/\./g, "/") + (b ? "/" + b : "")) : (p = a + "", g = b); a = void 0 !=
                    g && "string" != typeof g ? g.value : g; g = g && g.sanitize; if ("string" == typeof a) return e[p] = a, g ? d(a) : a; if (null === a) return delete e[p], null; p in e || c(p, !0, function (a) { e[p] = a }); return g ? d(e[p]) : e[p]
                }; return {
                    dynamic: !0, normalize: function (a, b) { var g = a.split("!"), c = g[0]; return (/^\./.test(c) ? b(c) : c) + (g[1] ? "!" + g[1] : "") }, load: function (k, n, g) {
                        var k = k.split("!"), f = 1 < k.length, q = k[0], o = n.toUrl(k[0]), k = "url:" + o, l = b, r = function (a) { g(f ? d(a) : a) }; q in e ? l = e[q] : k in n.cache ? l = n.cache[k] : o in e && (l = e[o]); if (l === b) if (a[o]) a[o].push(r);
                        else { var h = a[o] = [r]; c(o, !n.async, function (b) { e[q] = e[o] = b; for (var l = 0; l < h.length;) h[l++](b); delete a[o] }) } else r(l)
                    }
                }
            })
        }, "cbtree/models/StoreModel-API": function () {
            define("cbtree/models/StoreModel-API", ["dojo/_base/array", "dojo/_base/lang", "dojo/has", "./TreeStoreModel"], function (j, m, h, f) {
                h.add("cbtree-storeModel-API", !0); m.extend(f, {
                    _checkOrUncheck: function (c, e, d, b, a) {
                        var k = 0, n = 0; this.fetchItemsWithChecked(c, function (a) {
                            j.forEach(a, function (a) {
                                this.store.getValue(a, this.checkedAttr) != e && (this._ItemCheckedSetter(a,
                                e), n += 1); k += 1
                            }, this); d && d.call(b ? b : this, k, n)
                        }, this, a)
                    }, _ItemCheckedGetter: function (c) { return this.getChecked(c) }, _ItemCheckedSetter: function (c, e) { this.setChecked(c, e) }, _ItemIdentityGetter: function (c) { if (this.store.isItem(c)) return this.store.getIdentity(c); if (c === this.root) return this.root.id; throw new TypeError(this.moduleName + "::getIdentity(): invalid item specified."); }, _ItemIdentitySetter: function () { throw Error(this.moduleName + "::setItemAttr(): Identity attribute cannot be changed"); }, _ItemLabelGetter: function (c) {
                        return c !==
                        this.root ? this.labelAttr ? this.store.getValue(c, this.labelAttr) : this.store.getLabel(c) : this.root.label
                    }, _ItemLabelSetter: function (c, e) { var d = this.get("labelAttr"); if (d) { if (d != this.store.getIdentifierAttr()) return this.store.setValue(c, d, e); throw Error(this.moduleName + "::setItemAttr(): Label attribute {" + d + "} cannot be changed"); } }, _ItemParentsGetter: function (c) { return this.getParents(c) }, getItemAttr: function (c, e) {
                        var d = e == this.checkedAttr ? "checked" : e; if (this.isItem(c) || c === this.root) {
                            var b = this._getFuncNames("Item",
                            d); return m.isFunction(this[b.get]) ? this[b.get](c) : c === this.root && this.hasFakeRoot ? this.root[d] : this.store.getValue(c, d)
                        } throw Error(this.moduleName + "::getItemAttr(): argument is not a valid store item.");
                    }, setItemAttr: function (c, e, d) {
                        if (this._writeEnabled) {
                            e = e == this.checkedAttr ? "checked" : e; if (this.isItem(c)) { var b = this._getFuncNames("Item", e); return m.isFunction(this[b.set]) ? this[b.set](c, d) : this.store.setValue(c, e, d) } throw Error(this.moduleName + "::setItemAttr(): argument is not a valid store item.");
                        } throw Error(this.moduleName + "::setItemAttr(): store is not write enabled.");
                    }, fetchItem: function (c, e) { var d = this.store.getIdentifierAttr(), b = this._anyToQuery(c, e); if (b) return b[d] != this.root.id ? this.store.itemExist(b) : this.root }, fetchItemsWithChecked: function (c, e, d, b) {
                        var c = this._anyToQuery(c, null), a = [], b = void 0 !== b ? b : !0, d = d || this; if (m.isObject(c)) this.store.fetch({
                            query: c, queryOptions: { deep: !0, storeOnly: b }, onItem: function (b) {
                                this.store.hasAttribute(b, this.checkedAttr) ? a.push(b) : this.checkedAll &&
                                (this.setChecked(b, this.checkedState), a.push(b))
                            }, onComplete: function () { e && e.call(d, a) }, onError: this.onError, scope: this
                        }); else throw Error(this.moduleName + "::fetchItemsWithChecked(): query must be of type object.");
                    }, isRootItem: function (c) { return c !== this.root ? this.store.isRootItem(c) : !0 }, addReference: function (c, e, d) { this.store.addReference(c, e, d || this.childrenAttrs[0]) && this._updateCheckedParent(c) }, attachToRoot: function (c) { c !== this.root && this.store.attachToRoot(c) }, check: function (c, e, d, b) {
                        this.checkedStrict &&
                        (b = !0); this._checkOrUncheck(c, !0, e, d, b)
                    }, detachFromRoot: function (c) { c !== this.root && this.store.detachFromRoot(c) }, newReferenceItem: function (c, e, d) { (c = this.newItem(c, e, d)) && this.store.attachToRoot(c); return c }, removeReference: function (c, e, d) { this.store.removeReference(c, e, d || this.childrenAttrs[0]) && this.getChildren(e, m.hitch(this, function (b) { b.length && this._updateCheckedParent(b[0]) })) }, uncheck: function (c, e, d, b) { this.checkedStrict && (b = !0); this._checkOrUncheck(c, !1, e, d, b) }, _anyToQuery: function (c, e) {
                        var d =
                        this.store.getIdentifierAttr(); if (d) { var b = e ? e : d, a = {}; if (m.isString(c)) return a[d] = c, a; if (m.isObject(c)) return m.mixin(a, c), c[b] && (a[d] = c[b]), a } return null
                    }, _getFuncNames: function (c, e) { if (m.isString(e)) { var d = e.replace(/^[a-z]|-[a-zA-Z]/g, function (b) { return b.charAt(b.length - 1).toUpperCase() }); return { set: "_" + c + d + "Setter", get: "_" + c + d + "Getter" } } throw Error(this.moduleName + "::_getFuncNames(): get" + c + "/set" + c + " attribute name must be of type string."); }
                })
            })
        }, "dijit/hccss": function () {
            define("dijit/hccss",
            ["dojo/dom-class", "dojo/hccss", "dojo/ready", "dojo/_base/window"], function (j, m, h, f) { h(90, function () { m("highcontrast") && j.add(f.body(), "dijit_a11y") }); return m })
        }, "cbtree/util/QueryEngine": function () {
            define("cbtree/util/QueryEngine", ["module", "../errors/createError!../errors/CBTErrors.json", "./shim/Array"], function (j, m) {
                function h(a, b, c) {
                    return b ? b.test ? a.some(function (a) { return b.test(a) }) : b instanceof Array ? b.every(function (b) { b = c && b.toLowerCase ? b.toLowerCase() : b; return h(a, b, c) }) : c ? a.some(function (a) {
                        a =
                        c && a.toLowerCase ? a.toLowerCase() : a; return a == b
                    }) : -1 != a.indexOf(b) : !1
                } function f(a, b) { for (var c = a.split("."), g, d = 0; b && (g = c[d++]) ;) b = g in b ? b[g] : void 0; return b } function c(a) { if (a) for (var b in a) if (/\./.test(b)) return !0; return !1 } function e(a, b, c) { c && b && !b.test && (b = b.toLowerCase ? b.toLowerCase() : b, a = a.toLowerCase ? a.toLowerCase() : a); return b == a ? !0 : a instanceof Array ? h(a, b, c) : b && b.test ? b.test(a) : b instanceof Array ? d(a, b, c) : !1 } function d(a, b, c) { return b.some(function (b) { return e(a, b, c) }) } var b = m(j.id); return function (a,
                k) {
                    function d(a, b) { var a = a || [], c = k && k.sort, g = b ? a : a.filter(p), e = c; c && ("function" != typeof e && (e = function (a, b) { var l, g, d, k; for (l = 0; g = c[l]; l++) if (d = g.property || g.attribute, k = f(d, a), d = f(d, b), g.ignoreCase && (k = k && k.toLowerCase ? k.toLowerCase() : k, d = d && d.toLowerCase ? d.toLowerCase() : d), k != d) return !!g.descending == (null == k || k > d) ? -1 : 1; return 0 }), g.sort(e)); if (k && (k.start || k.count)) e = g.length, g = g.slice(k.start || 0, (k.start || 0) + (k.count || Infinity)), g.total = e; return g } var g = k && !!k.ignoreCase, p = function () { }, q = !1; switch (typeof a) {
                        case "undefined": case "object": q =
                        c(a); p = function (b) { var l, c, d; for (l in a) if (d = a[l], c = q ? f(l, b) : b[l], !e(c, d, g) && !("function" == typeof d && d(c, l, b))) return !1; return !0 }; break; case "string": if (!this[a] || "function" != typeof this[a]) throw new b("MethodMissing", "QueryEngine", "No filter function " + a + " was found in store"); p = this[a]; break; case "function": p = a; break; default: throw new b("InvalidType", "QueryEngine", "Can not query with a " + typeof a);
                    } d.matches = p; return d
                }
            })
        }, "dijit/_Contained": function () {
            define("dijit/_Contained", ["dojo/_base/declare",
            "./registry"], function (j, m) { return j("dijit._Contained", null, { _getSibling: function (h) { var f = this.domNode; do f = f[h + "Sibling"]; while (f && 1 != f.nodeType); return f && m.byNode(f) }, getPreviousSibling: function () { return this._getSibling("previous") }, getNextSibling: function () { return this._getSibling("next") }, getIndexInParent: function () { var h = this.getParent(); return !h || !h.getIndexOfChild ? -1 : h.getIndexOfChild(this) } }) })
        }, "dojo/request/default": function () {
            define("dojo/request/default", ["exports", "require", "../has"],
            function (j, m, h) { var f = h("config-requestProvider"); f || (f = "./xhr"); j.getPlatformDefaultId = function () { return "./xhr" }; j.load = function (c, e, d) { m(["platform" == c ? "./xhr" : f], function (b) { d(b) }) } })
        }, "dijit/form/ToggleButton": function () {
            define("dijit/form/ToggleButton", ["dojo/_base/declare", "dojo/_base/kernel", "./Button", "./_ToggleButtonMixin"], function (j, m, h, f) {
                return j("dijit.form.ToggleButton", [h, f], {
                    baseClass: "dijitToggleButton", setChecked: function (c) {
                        m.deprecated("setChecked(" + c + ") is deprecated. Use set('checked'," +
                        c + ") instead.", "", "2.0"); this.set("checked", c)
                    }
                })
            })
        }, "cbtree/data/util/sorter": function () {
            define("cbtree/data/util/sorter", ["dojo/_base/declare", "dojo/_base/lang"], function (j, m) {
                return j(null, {
                    constructor: function (h) { var f; this.sortArgm = []; if (m.isArray(h)) for (f = 0; f < h.length; f++) { var c = h[f]; c.attribute && this.sortArgm.push({ attribute: c.attribute, descending: c.descending ? -1 : 1, ignoreCase: c.ignoreCase || !1 }) } }, _compare: function (h, f) {
                        var c, e, d, b, a; for (a = 0; a < this.sortArgm.length; a++) if (c = this.sortArgm[a].attribute,
                        e = this.sortArgm[a].descending, d = this.sortArgm[a].ignoreCase, b = null === h[c] ? void 0 : h[c], c = null === f[c] ? void 0 : f[c], d && m.isString(b) && m.isString(c) && (b = b.toLowerCase(), c = c.toLowerCase()), b != c) { if (null == c || b > c) return 1 * e; if (null == b || b < c) return -1 * e } return 0
                    }, sortFunction: function () { return m.hitch(this, this._compare) }
                })
            })
        }, "dijit/_Container": function () {
            define("dijit/_Container", ["dojo/_base/array", "dojo/_base/declare", "dojo/dom-construct"], function (j, m, h) {
                return m("dijit._Container", null, {
                    buildRendering: function () {
                        this.inherited(arguments);
                        if (!this.containerNode) this.containerNode = this.domNode
                    }, addChild: function (f, c) { var e = this.containerNode; if (c && "number" == typeof c) { var d = this.getChildren(); if (d && d.length >= c) e = d[c - 1].domNode, c = "after" } h.place(f.domNode, e, c); this._started && !f._started && f.startup() }, removeChild: function (f) { "number" == typeof f && (f = this.getChildren()[f]); if (f) (f = f.domNode) && f.parentNode && f.parentNode.removeChild(f) }, hasChildren: function () { return 0 < this.getChildren().length }, _getSiblingOfChild: function (f, c) {
                        var e = this.getChildren(),
                        d = j.indexOf(this.getChildren(), f); return e[d + c]
                    }, getIndexOfChild: function (f) { return j.indexOf(this.getChildren(), f) }
                })
            })
        }, "cbtree/Evented": function () {
            define("cbtree/Evented", ["dojo/aspect", "dojo/on"], function (j, m) {
                return function () {
                    this.on = function (h, f) {
                        function c(c, d) { var b = c.constructor, a = b._onMap; if (!a) { var a = b._onMap = {}, k; for (k in b.prototype) /^on/.test(k) && (a[k.replace(/^on/, "").toLowerCase()] = k) } return a[d.toLowerCase()] || "on" + d } return m.parse(this, h, f, function (e, d) {
                            return j.after(e, c(e, d),
                            f, !0)
                        })
                    }; this.emit = function (h, f) { var c = [this]; if (!f.type) f.type = h; c.push.apply(c, arguments); return m.emit.apply(m, c) }
                }
            })
        }, "cbtree/store/Memory": function () {
            define("cbtree/store/Memory", "module,dojo/_base/declare,dojo/_base/lang,dojo/Deferred,dojo/request,dojo/Stateful,dojo/request/handlers,dojo/store/util/QueryResults,../errors/createError!../errors/CBTErrors.json,../util/QueryEngine,../util/shim/Array".split(","), function (j, m, h, f, c, e, d, b, a, k) {
                function n(a) {
                    if (a.response) switch (a.response.status) {
                        case 404: a.message =
                        a.response.url.match(/[^?#]*/)[0], a.name = "NotFoundError"
                    } return a
                } function g(a) { throw new p("ReadOnly", "set", "property [" + a + "] is READ-ONLY"); } var p = a(j.id); return m([e], {
                    autoLoad: !0, clearOnClose: !1, data: null, dataHandler: null, defaultProperties: null, filter: null, handleAs: null, idProperty: "id", queryEngine: k, url: null, state: "closed", total: 0, _indexStore: !0, constructor: function (a) {
                        this._loadDeferred = new f(this._loadReset); this._storeReady = new f; this._loadPending = !1; this._data = []; this._indexId = {}; this.state =
                        "waitOnLoad"; this.total = 0; m.safeMixin(this, a); if (this.handleAs && this.dataHandler) { var a = this.dataHandler.handler || this.dataHandler, b = this.dataHandler.options, l, c; switch (typeof a) { case "function": if (a = new a, "function" != typeof a.handler) { c = this.dataHandler; a = void 0; break } case "object": c = a.handler; l = a.set; break; default: throw new p("InvalidType", "constructor", "handler must be a function"); } c && (d.register(this.handleAs, a ? h.hitch(a, c) : c), a && b && (l ? l.call(a, b) : h.mixin(a, b))) } !this.data && !this.url && this.autoLoad &&
                        this.set("data", [])
                    }, destroy: function () { this._data.forEach(function (a) { a._destoyed = !0 }); this._destroyed = !0; this._indexId = {}; this._data = [] }, _autoLoadSetter: function (a) { this.autoLoad = !!a }, _dataSetter: function (a) { this.autoLoad ? this.load({ data: a }) : this.data = a }, _eventableSetter: function () { g("eventable") }, _hierarchicalSetter: function () { g("hierarchical") }, _idPropertySetter: function (a) { this._indexStore = !!a; this.idProperty = a }, _urlSetter: function (a) {
                        if ("string" == typeof a) this.autoLoad ? this.load({ url: a }) : this.url =
                        a; else throw new p("InvalidType", "_urlSetter", "URL property must be of type string");
                    }, _anyToObject: function (a, b) { if (a) { var b = b || !1, l; switch (typeof a) { case "string": case "number": l = a; break; case "object": if (b) { if (!this.isItem(a)) throw new p("InvalidObject", "_anyToObject"); return a } l = this.getIdentity(a); break; default: return } return this.get(l) } }, _applyDefaults: function (a, b) {
                        if (this.defaultProperties) for (var l in this.defaultProperties) b[l] = b[l] || this.defaultProperties[l]; this.idProperty && (b[this.idProperty] =
                        a)
                    }, _getObjectId: function (a, b) { var l; l = b && "id" in b ? b.id : this.getIdentity(a); if (null === l || void 0 === l) l = Math.random(); return l }, _indexData: function () { if (this._indexStore) { var a = this.idProperty, b = this._indexId = {}, l = this._data, c; for (c = 0; c < l.length; c++) b[l[c][a]] = c } }, _loadError: function (a, b) { this._loadReset(a); b.reject(new p(n(a), "load")); return b.promise }, _loadData: function (a, b) {
                        if (!b.isFulfilled()) {
                            var l, c, g, d; this._indexId = {}; this._data = []; this.data = null; a = a || []; if (a instanceof Array) try {
                                for (g = 0; g <
                                a.length; g++) l = a[g], c = this._getObjectId(l), d = this._indexId[c] || -1, 0 <= d ? console.warn(new p("ItemExist", "_loadData", "Object with ID: [" + c + "] already exist")) : this._writeObject(c, l, d); this._indexData(); this._storeReady.resolve(!0); this.state = "active"; b.resolve(!0)
                            } catch (k) { this._loadError(k, b) } else this._loadError(new p("InvalidData", "_loadData"), b); this._loadPending = !1
                        } return b.promise
                    }, _loadReset: function () {
                        this._loadDeferred = new f(this._loadReset); this._loadPending = !1; this.url = this.data = this.handleAs =
                        null; this.state = "closed"
                    }, _writeObject: function (a, b, l) { -1 < l ? this._data[l] = b : (this._applyDefaults(a, b), this._indexStore ? this._indexId[a] = this._data.push(b) - 1 : this._data.push(b), this.total = this._data.length); return a }, _xhrGet: function (a, b) { return c(this.url, { method: "GET", handleAs: b, preventCache: !0 }) }, add: function (a, b) { var l = this._getObjectId(a, b), c = this._indexId[l]; if (0 <= c) throw new p("ItemExist", "add"); return this._writeObject(l, a, c, b) }, close: function (a) {
                        this._loadDeferred.isFulfilled() || (this._loadDeferred.then(null,
                        function () { }), this._loadDeferred.cancel(new p("RequestCancel", "close", "load request was canceled"))); if (this._storeReady.isFulfilled()) this._storeReady = new f; if (a = !(!a && !this.clearOnClose)) this._loadReset(), this._indexId = {}, this._data = [], this.total = 0; this.onClose(a, this.total)
                    }, get: function (a) { return this._data[this._indexId[a]] }, getIdentity: function (a) { if (a && this.idProperty) return a[this.idProperty] }, isItem: function (a) { return a && "object" == typeof a ? a == this.get(this.getIdentity(a)) : !1 }, load: function (a) {
                        var b =
                        ["data", "filter", "handleAs", "url"], l = this._loadDeferred; if (!this._loadPending && !l.isFulfilled()) {
                            if (a) for (var c in a) -1 != b.indexOf(c) && (this[c] = a[c]); if (this.data || this.url) {
                                var g = this.filter ? k(this.filter) : function (a) { return a }, e = this; this.state = "loading"; this._loadPending = !0; if (this.data) { try { if (this.handleAs) this.data = d({ text: this.data, options: { handleAs: this.handleAs } }).data; this._loadData(g(this.data), l) } catch (n) { return e._loadError(n, l) } this.url = null } else {
                                    if (!this.handleAs) this.handleAs = "json";
                                    this._xhrGet(this.url, this.handleAs, null).then(function (a) { e._loadData(g(a), l) }, function (a) { e._loadError(a, l) })
                                }
                            }
                        } else if (a && (a.url || a.data)) return a = new f, this._loadPending ? a.reject(new p("RequestPending", "load")) : a.reject(new p("Access", "load", "store already loaded")); return l.promise
                    }, put: function (a, b) { var l = this._getObjectId(a, b), c = this._indexId[l]; if (0 <= c && b && !1 === b.overwrite) throw new p("ItemExist", "put"); return this._writeObject(l, a, c, b) }, query: function (a, c) {
                        var l = this; return b(this._storeReady.then(function () {
                            return l.queryEngine(a,
                            c)(l._data, !1)
                        }))
                    }, ready: function (a, b, l) { return a || b ? this._storeReady.then(a ? h.hitch(l || this, a) : null, b ? h.hitch(l || this, b) : null) : this._storeReady.promise }, remove: function (a) { a = this._indexId[a]; return 0 <= a ? (this._data.splice(a, 1), this._indexData(), this.total = this._data.length, !0) : !1 }, toString: function () { return "[object MemoryStore]" }, onClose: function () { }
                })
            })
        }, "dijit/a11yclick": function () {
            define("dijit/a11yclick", "dojo/on,dojo/_base/array,dojo/keys,dojo/_base/declare,dojo/has,dojo/_base/unload,dojo/_base/window".split(","),
            function (j, m, h, f, c, e, d) {
                function b(a) { return (a.keyCode === h.ENTER || a.keyCode === h.SPACE) && !a.ctrlKey && !a.shiftKey && !a.altKey && !a.metaKey } var a = null; c("dom-addeventlistener") ? d.doc.addEventListener("keydown", function (b) { a = b.target }, !0) : function () { var b = function (b) { a = b.srcElement }; d.doc.attachEvent("onkeydown", b); e.addOnWindowUnload(function () { d.doc.detachEvent("onkeydown", b) }) }(); return function (d, e) {
                    if (/input|button/i.test(d.nodeName)) return j(d, "click", e); var g = [j(d, "keydown", function (c) {
                        if (b(c)) a =
                        c.target, c.preventDefault()
                    }), j(d, "keyup", function (c) { b(c) && c.target == a && (a = null, j.emit(c.target, "click", { cancelable: !0, bubbles: !0 })) }), j(d, "click", function (a) { e.call(this, a) })]; if (c("touch")) { var f; g.push(j(d, "touchend", function (a) { var b = a.target; f = setTimeout(function () { f = null; j.emit(b, "click", { cancelable: !0, bubbles: !0 }) }, 600) }), j(d, "click", function () { f && clearTimeout(f) })) } return { remove: function () { m.forEach(g, function (a) { a.remove() }); f && (clearTimeout(f), f = null) } }
                }
            })
        }, "url:cbtree/templates/cbtreeNode.html": '<div class="dijitTreeNode" role="presentation">\n\t<div data-dojo-attach-point="rowNode" class="dijitTreeRow" role="presentation">\n\t\t<div data-dojo-attach-point="indentNode" class="dijitInline"></div>\n\t\t<img src="${_blankGif}" alt="" data-dojo-attach-point="expandoNode" class="dijitTreeExpando" role="presentation" />\n\t\t<span data-dojo-attach-point="expandoNodeText" class="dijitExpandoText" role="presentation"></span>\n\t\t<span data-dojo-attach-point="checkBoxNode" class="cbtreeCheckBox" role="presentation"></span>\n\t\t<span data-dojo-attach-point="contentNode" class="dijitTreeContent" role="presentation">\n\t\t\t<img src="${_blankGif}" alt="" data-dojo-attach-point="iconNode" class="dijitIcon dijitTreeIcon" role="presentation"/>\n\t\t\t<span data-dojo-attach-point="labelNode,focusNode" class="dijitTreeLabel" role="treeitem" tabindex="-1" aria-selected="false"></span>\n\t\t</span>\n\t</div>\n\t<div data-dojo-attach-point="containerNode" class="dijitTreeNodeContainer" role="presentation" style="display: none;"></div>\n</div>\n',
        "cbtree/store/extensions/_Path": function () {
            define("cbtree/store/extensions/_Path", ["module", "../../errors/createError!../../errors/CBTErrors.json"], function (j, m) {
                function h(c, b, a) { var c = c.segments(), k = b.segments(), b = []; c.length && k.length && (!1 == a && (c[0] === k[0] && (c.shift(), k.shift()), c[c.length - 1] === k[k.length - 1] && (c.pop(), k.pop())), b = c.filter(function (a) { return -1 != k.indexOf(a) })); return b } function f(d, b) {
                    var a = d.split(b || "/"); this.contains = function (b) {
                        return b ? "function" == typeof b.test ? b.test(d) : -1 !=
                        a.indexOf(b) : !1
                    }; this.intersect = function (a, b) { if (a instanceof f) return h(this, a, b); throw new c("InvalidType", "intersect"); }; this.segments = function () { return a.slice(0) }; e(this, "string", { value: d, enumerable: !0, writable: !1 }); e(this, "length", { value: a.length, enumerable: !1 })
                } var c = m(j.id), e = Object.defineProperty || function (c, b, a) { if (void 0 == c[b]) c[b] = a.value }; return f
            })
        }, "dojo/cookie": function () {
            define("dojo/cookie", ["./_base/kernel", "./regexp"], function (j, m) {
                j.cookie = function (h, f, c) {
                    var e = document.cookie,
                    d; if (1 == arguments.length) d = (d = e.match(RegExp("(?:^|; )" + m.escapeString(h) + "=([^;]*)"))) ? decodeURIComponent(d[1]) : void 0; else { c = c || {}; e = c.expires; if ("number" == typeof e) { var b = new Date; b.setTime(b.getTime() + 864E5 * e); e = c.expires = b } if (e && e.toUTCString) c.expires = e.toUTCString(); var f = encodeURIComponent(f), e = h + "=" + f, a; for (a in c) e += "; " + a, b = c[a], !0 !== b && (e += "=" + b); document.cookie = e } return d
                }; j.cookie.isSupported = function () {
                    if (!("cookieEnabled" in navigator)) this("__djCookieTest__", "CookiesAllowed"), navigator.cookieEnabled =
                    "CookiesAllowed" == this("__djCookieTest__"), navigator.cookieEnabled && this("__djCookieTest__", "", { expires: -1 }); return navigator.cookieEnabled
                }; return j.cookie
            })
        }, "cbtree/data/util/filter": function () {
            define("cbtree/data/util/filter", ["dojo/_base/lang"], function () {
                return {
                    patternToRegExp: function (j, m) {
                        if ("(" == j.charAt(0) && ")" == j.charAt(j.length - 1)) var h = j.substr(1, j.length - 2); else {
                            for (var h = "^", f = null, c = 0; c < j.length; c++) switch (f = j.charAt(c), f) {
                                case "\\": h += f; c++; h += j.charAt(c); break; case "*": h += ".*"; break;
                                case "?": h += "."; break; case "$": case "^": case "/": case "+": case ".": case "|": case "(": case ")": case "{": case "}": case "[": case "]": h += "\\"; default: h += f
                            } h += "$"
                        } return m ? RegExp(h, "mi") : RegExp(h, "m")
                    }
                }
            })
        }, "dojo/fx": function () {
            define("dojo/fx", "./_base/lang,./Evented,./_base/kernel,./_base/array,./_base/connect,./_base/fx,./dom,./dom-style,./dom-geometry,./ready,require".split(","), function (j, m, h, f, c, e, d, b, a, k, n) {
                h.isAsync || k(0, function () { n(["./fx/Toggler"]) }); var h = h.fx = {}, k = {
                    _fire: function (a, b) {
                        this[a] &&
                        this[a].apply(this, b || []); return this
                    }
                }, g = function (a) { this._index = -1; this._animations = a || []; this._current = this._onAnimateCtx = this._onEndCtx = null; this.duration = 0; f.forEach(this._animations, function (a) { this.duration += a.duration; a.delay && (this.duration += a.delay) }, this) }; g.prototype = new m; j.extend(g, {
                    _onAnimate: function () { this._fire("onAnimate", arguments) }, _onEnd: function () {
                        c.disconnect(this._onAnimateCtx); c.disconnect(this._onEndCtx); this._onAnimateCtx = this._onEndCtx = null; this._index + 1 == this._animations.length ?
                        this._fire("onEnd") : (this._current = this._animations[++this._index], this._onAnimateCtx = c.connect(this._current, "onAnimate", this, "_onAnimate"), this._onEndCtx = c.connect(this._current, "onEnd", this, "_onEnd"), this._current.play(0, !0))
                    }, play: function (a, b) {
                        if (!this._current) this._current = this._animations[this._index = 0]; if (!b && "playing" == this._current.status()) return this; var l = c.connect(this._current, "beforeBegin", this, function () { this._fire("beforeBegin") }), g = c.connect(this._current, "onBegin", this, function (a) {
                            this._fire("onBegin",
                            arguments)
                        }), d = c.connect(this._current, "onPlay", this, function (a) { this._fire("onPlay", arguments); c.disconnect(l); c.disconnect(g); c.disconnect(d) }); this._onAnimateCtx && c.disconnect(this._onAnimateCtx); this._onAnimateCtx = c.connect(this._current, "onAnimate", this, "_onAnimate"); this._onEndCtx && c.disconnect(this._onEndCtx); this._onEndCtx = c.connect(this._current, "onEnd", this, "_onEnd"); this._current.play.apply(this._current, arguments); return this
                    }, pause: function () {
                        if (this._current) {
                            var a = c.connect(this._current,
                            "onPause", this, function (b) { this._fire("onPause", arguments); c.disconnect(a) }); this._current.pause()
                        } return this
                    }, gotoPercent: function (a, b) { this.pause(); var l = this.duration * a; this._current = null; f.some(this._animations, function (a) { if (a.duration <= l) return this._current = a, !0; l -= a.duration; return !1 }); this._current && this._current.gotoPercent(l / this._current.duration, b); return this }, stop: function (a) {
                        if (this._current) {
                            if (a) {
                                for (; this._index + 1 < this._animations.length; ++this._index) this._animations[this._index].stop(!0);
                                this._current = this._animations[this._index]
                            } var b = c.connect(this._current, "onStop", this, function (a) { this._fire("onStop", arguments); c.disconnect(b) }); this._current.stop()
                        } return this
                    }, status: function () { return this._current ? this._current.status() : "stopped" }, destroy: function () { this._onAnimateCtx && c.disconnect(this._onAnimateCtx); this._onEndCtx && c.disconnect(this._onEndCtx) }
                }); j.extend(g, k); h.chain = function (a) { return new g(a) }; var p = function (a) {
                    this._animations = a || []; this._connects = []; this.duration = this._finished =
                    0; f.forEach(a, function (a) { var b = a.duration; a.delay && (b += a.delay); if (this.duration < b) this.duration = b; this._connects.push(c.connect(a, "onEnd", this, "_onEnd")) }, this); this._pseudoAnimation = new e.Animation({ curve: [0, 1], duration: this.duration }); var b = this; f.forEach("beforeBegin,onBegin,onPlay,onAnimate,onPause,onStop,onEnd".split(","), function (a) { b._connects.push(c.connect(b._pseudoAnimation, a, function () { b._fire(a, arguments) })) })
                }; j.extend(p, {
                    _doAction: function (a, b) {
                        f.forEach(this._animations, function (l) {
                            l[a].apply(l,
                            b)
                        }); return this
                    }, _onEnd: function () { ++this._finished > this._animations.length && this._fire("onEnd") }, _call: function (a, b) { var l = this._pseudoAnimation; l[a].apply(l, b) }, play: function (a, b) { this._finished = 0; this._doAction("play", arguments); this._call("play", arguments); return this }, pause: function () { this._doAction("pause", arguments); this._call("pause", arguments); return this }, gotoPercent: function (a, b) {
                        var l = this.duration * a; f.forEach(this._animations, function (a) { a.gotoPercent(a.duration < l ? 1 : l / a.duration, b) });
                        this._call("gotoPercent", arguments); return this
                    }, stop: function (a) { this._doAction("stop", arguments); this._call("stop", arguments); return this }, status: function () { return this._pseudoAnimation.status() }, destroy: function () { f.forEach(this._connects, c.disconnect) }
                }); j.extend(p, k); h.combine = function (a) { return new p(a) }; h.wipeIn = function (a) {
                    var g = a.node = d.byId(a.node), l = g.style, k, a = e.animateProperty(j.mixin({
                        properties: {
                            height: {
                                start: function () {
                                    k = l.overflow; l.overflow = "hidden"; if ("hidden" == l.visibility || "none" ==
                                    l.display) return l.height = "1px", l.display = "", l.visibility = "", 1; var a = b.get(g, "height"); return Math.max(a, 1)
                                }, end: function () { return g.scrollHeight }
                            }
                        }
                    }, a)), f = function () { l.height = "auto"; l.overflow = k }; c.connect(a, "onStop", f); c.connect(a, "onEnd", f); return a
                }; h.wipeOut = function (a) {
                    var b = (a.node = d.byId(a.node)).style, l, a = e.animateProperty(j.mixin({ properties: { height: { end: 1 } } }, a)); c.connect(a, "beforeBegin", function () { l = b.overflow; b.overflow = "hidden"; b.display = "" }); var g = function () {
                        b.overflow = l; b.height = "auto";
                        b.display = "none"
                    }; c.connect(a, "onStop", g); c.connect(a, "onEnd", g); return a
                }; h.slideTo = function (g) {
                    var k = null, l = null, f = function (c) { return function () { var g = b.getComputedStyle(c), d = g.position; k = "absolute" == d ? c.offsetTop : parseInt(g.top) || 0; l = "absolute" == d ? c.offsetLeft : parseInt(g.left) || 0; if ("absolute" != d && "relative" != d) g = a.position(c, !0), k = g.y, l = g.x, c.style.position = "absolute", c.style.top = k + "px", c.style.left = l + "px" } }(g.node = d.byId(g.node)); f(); g = e.animateProperty(j.mixin({
                        properties: {
                            top: g.top || 0, left: g.left ||
                            0
                        }
                    }, g)); c.connect(g, "beforeBegin", g, f); return g
                }; return h
            })
        }, "dijit/Tree": function () {
            require({
                cache: {
                    "url:dijit/templates/TreeNode.html": '<div class="dijitTreeNode" role="presentation"\n\t><div data-dojo-attach-point="rowNode" class="dijitTreeRow dijitInline" role="presentation"\n\t\t><div data-dojo-attach-point="indentNode" class="dijitInline"></div\n\t\t><img src="${_blankGif}" alt="" data-dojo-attach-point="expandoNode" class="dijitTreeExpando" role="presentation"\n\t\t/><span data-dojo-attach-point="expandoNodeText" class="dijitExpandoText" role="presentation"\n\t\t></span\n\t\t><span data-dojo-attach-point="contentNode"\n\t\t\tclass="dijitTreeContent" role="presentation">\n\t\t\t<img src="${_blankGif}" alt="" data-dojo-attach-point="iconNode" class="dijitIcon dijitTreeIcon" role="presentation"\n\t\t\t/><span data-dojo-attach-point="labelNode" class="dijitTreeLabel" role="treeitem" tabindex="-1" aria-selected="false"></span>\n\t\t</span\n\t></div>\n\t<div data-dojo-attach-point="containerNode" class="dijitTreeContainer" role="presentation" style="display: none;"></div>\n</div>\n',
                    "url:dijit/templates/Tree.html": '<div class="dijitTree dijitTreeContainer" role="tree">\n\t<div class="dijitInline dijitTreeIndent" style="position: absolute; top: -9999px" data-dojo-attach-point="indentDetector"></div>\n</div>\n'
                }
            }); define("dijit/Tree", "dojo/_base/array,dojo/_base/connect,dojo/cookie,dojo/_base/declare,dojo/Deferred,dojo/DeferredList,dojo/dom,dojo/dom-class,dojo/dom-geometry,dojo/dom-style,dojo/_base/event,dojo/errors/create,dojo/fx,dojo/_base/kernel,dojo/keys,dojo/_base/lang,dojo/on,dojo/topic,dojo/touch,dojo/when,./focus,./registry,./_base/manager,./_Widget,./_TemplatedMixin,./_Container,./_Contained,./_CssStateMixin,dojo/text!./templates/TreeNode.html,dojo/text!./templates/Tree.html,./tree/TreeStoreModel,./tree/ForestStoreModel,./tree/_dndSelector".split(","),
            function (j, m, h, f, c, e, d, b, a, k, n, g, p, q, o, l, r, v, t, x, z, u, B, s, w, y, C, A, F, G, J, H, I) {
                var c = f(c, { addCallback: function (a) { this.then(a) }, addErrback: function (a) { this.then(null, a) } }), E = f("dijit._TreeNode", [s, w, y, C, A], {
                    item: null, isTreeNode: !0, label: "", _setLabelAttr: { node: "labelNode", type: "innerText" }, isExpandable: null, isExpanded: !1, state: "UNCHECKED", templateString: F, baseClass: "dijitTreeNode", cssStateNodes: { rowNode: "dijitTreeRow" }, _setTooltipAttr: { node: "rowNode", type: "attribute", attribute: "title" }, buildRendering: function () {
                        this.inherited(arguments);
                        this._setExpando(); this._updateItemClasses(this.item); this.isExpandable && this.labelNode.setAttribute("aria-expanded", this.isExpanded); this.setSelected(!1)
                    }, _setIndentAttr: function (a) { var b = Math.max(a, 0) * this.tree._nodePixelIndent + "px"; k.set(this.domNode, "backgroundPosition", b + " 0px"); k.set(this.indentNode, this.isLeftToRight() ? "paddingLeft" : "paddingRight", b); j.forEach(this.getChildren(), function (b) { b.set("indent", a + 1) }); this._set("indent", a) }, markProcessing: function () { this.state = "LOADING"; this._setExpando(!0) },
                    unmarkProcessing: function () { this._setExpando(!1) }, _updateItemClasses: function (a) { var b = this.tree, l = b.model; b._v10Compat && a === l.root && (a = null); this._applyClassAndStyle(a, "icon", "Icon"); this._applyClassAndStyle(a, "label", "Label"); this._applyClassAndStyle(a, "row", "Row"); this.tree._startPaint(!0) }, _applyClassAndStyle: function (a, l, c) {
                        var g = "_" + l + "Class", l = l + "Node", d = this[g]; this[g] = this.tree["get" + c + "Class"](a, this.isExpanded); b.replace(this[l], this[g] || "", d || ""); k.set(this[l], this.tree["get" + c + "Style"](a,
                        this.isExpanded) || {})
                    }, _updateLayout: function () { var a = this.getParent(); !a || !a.rowNode || "none" == a.rowNode.style.display ? b.add(this.domNode, "dijitTreeIsRoot") : b.toggle(this.domNode, "dijitTreeIsLast", !this.getNextSibling()) }, _setExpando: function (a) { var l = ["dijitTreeExpandoLoading", "dijitTreeExpandoOpened", "dijitTreeExpandoClosed", "dijitTreeExpandoLeaf"], a = a ? 0 : this.isExpandable ? this.isExpanded ? 1 : 2 : 3; b.replace(this.expandoNode, l[a], l); this.expandoNodeText.innerHTML = ["*", "-", "+", "*"][a] }, expand: function () {
                        if (this._expandDeferred) return this._expandDeferred;
                        this._collapseDeferred && (this._collapseDeferred.cancel(), delete this._collapseDeferred); this.isExpanded = !0; this.labelNode.setAttribute("aria-expanded", "true"); (this.tree.showRoot || this !== this.tree.rootNode) && this.containerNode.setAttribute("role", "group"); b.add(this.contentNode, "dijitTreeContentExpanded"); this._setExpando(); this._updateItemClasses(this.item); this == this.tree.rootNode && this.tree.showRoot && this.tree.domNode.setAttribute("aria-expanded", "true"); var a, l = p.wipeIn({
                            node: this.containerNode,
                            duration: B.defaultDuration, onEnd: function () { a.resolve(!0) }
                        }); a = this._expandDeferred = new c(function () { l.stop() }); l.play(); return a
                    }, collapse: function () {
                        if (this._collapseDeferred) return this._collapseDeferred; this._expandDeferred && (this._expandDeferred.cancel(), delete this._expandDeferred); this.isExpanded = !1; this.labelNode.setAttribute("aria-expanded", "false"); this == this.tree.rootNode && this.tree.showRoot && this.tree.domNode.setAttribute("aria-expanded", "false"); b.remove(this.contentNode, "dijitTreeContentExpanded");
                        this._setExpando(); this._updateItemClasses(this.item); var a, l = p.wipeOut({ node: this.containerNode, duration: B.defaultDuration, onEnd: function () { a.resolve(!0) } }); a = this._collapseDeferred = new c(function () { l.stop() }); l.play(); return a
                    }, indent: 0, setChildItems: function (a) {
                        var b = this.tree, l = b.model, c = [], g = this.getChildren(); j.forEach(g, function (a) { y.prototype.removeChild.call(this, a) }, this); this.defer(function () {
                            j.forEach(g, function (a) {
                                if (!a._destroyed && !a.getParent()) {
                                    b.dndController.removeTreeNode(a); var c =
                                    l.getIdentity(a.item), g = b._itemNodesMap[c]; 1 == g.length ? delete b._itemNodesMap[c] : (c = j.indexOf(g, a), -1 != c && g.splice(c, 1)); a.destroyRecursive()
                                }
                            })
                        }); this.state = "LOADED"; a && 0 < a.length ? (this.isExpandable = !0, j.forEach(a, function (a) {
                            var g = l.getIdentity(a), d = b._itemNodesMap[g], k; if (d) for (var e = 0; e < d.length; e++) if (d[e] && !d[e].getParent()) { k = d[e]; k.set("indent", this.indent + 1); break } k || (k = this.tree._createTreeNode({
                                item: a, tree: b, isExpandable: l.mayHaveChildren(a), label: b.getLabel(a), tooltip: b.getTooltip(a),
                                ownerDocument: b.ownerDocument, dir: b.dir, lang: b.lang, textDir: b.textDir, indent: this.indent + 1
                            }), d ? d.push(k) : b._itemNodesMap[g] = [k]); this.addChild(k); (this.tree.autoExpand || this.tree._state(k)) && c.push(b._expandNode(k))
                        }, this), j.forEach(this.getChildren(), function (a) { a._updateLayout() })) : this.isExpandable = !1; this._setExpando && this._setExpando(!1); this._updateItemClasses(this.item); if (this == b.rootNode) (a = this.tree.showRoot ? this : this.getChildren()[0]) ? (a.setFocusable(!0), b.lastFocused = a) : b.domNode.setAttribute("tabIndex",
                        "0"); a = new e(c); this.tree._startPaint(a); return a
                    }, getTreePath: function () { for (var a = this, b = []; a && a !== this.tree.rootNode;) b.unshift(a.item), a = a.getParent(); b.unshift(this.tree.rootNode.item); return b }, getIdentity: function () { return this.tree.model.getIdentity(this.item) }, removeChild: function (a) { this.inherited(arguments); var b = this.getChildren(); if (0 == b.length) this.isExpandable = !1, this.collapse(); j.forEach(b, function (a) { a._updateLayout() }) }, makeExpandable: function () { this.isExpandable = !0; this._setExpando(!1) },
                    setSelected: function (a) { this.labelNode.setAttribute("aria-selected", a ? "true" : "false"); b.toggle(this.rowNode, "dijitTreeRowSelected", a) }, setFocusable: function (a) { this.labelNode.setAttribute("tabIndex", a ? "0" : "-1") }, _setTextDirAttr: function (a) { if (a && (this.textDir != a || !this._created)) this._set("textDir", a), this.applyTextDir(this.labelNode, this.labelNode.innerText || this.labelNode.textContent || ""), j.forEach(this.getChildren(), function (b) { b.set("textDir", a) }, this) }
                }), D = f("dijit.Tree", [s, w], {
                    store: null, model: null,
                    query: null, label: "", showRoot: !0, childrenAttr: ["children"], paths: [], path: [], selectedItems: null, selectedItem: null, openOnClick: !1, openOnDblClick: !1, templateString: G, persist: !0, autoExpand: !1, dndController: I, dndParams: "onDndDrop,itemCreator,onDndCancel,checkAcceptance,checkItemAcceptance,dragThreshold,betweenThreshold".split(","), onDndDrop: null, itemCreator: null, onDndCancel: null, checkAcceptance: null, checkItemAcceptance: null, dragThreshold: 5, betweenThreshold: 0, _nodePixelIndent: 19, _publish: function (a, b) {
                        v.publish(this.id,
                        l.mixin({ tree: this, event: a }, b || {}))
                    }, postMixInProperties: function () { this.tree = this; if (this.autoExpand) this.persist = !1; this._itemNodesMap = {}; if (!this.cookieName && this.id) this.cookieName = this.id + "SaveStateCookie"; this.pendingCommandsDeferred = this.expandChildrenDeferred = new c; this.inherited(arguments) }, postCreate: function () {
                        this._initState(); var a = this; this.own(r(this.domNode, r.selector(".dijitTreeNode", t.enter), function (b) { a._onNodeMouseEnter(u.byNode(this), b) }), r(this.domNode, r.selector(".dijitTreeNode",
                        t.leave), function (b) { a._onNodeMouseLeave(u.byNode(this), b) }), r(this.domNode, r.selector(".dijitTreeNode", "click"), function (b) { a._onClick(u.byNode(this), b) }), r(this.domNode, r.selector(".dijitTreeNode", "dblclick"), function (b) { a._onDblClick(u.byNode(this), b) }), r(this.domNode, r.selector(".dijitTreeNode", "keypress"), function (b) { a._onKeyPress(u.byNode(this), b) }), r(this.domNode, r.selector(".dijitTreeNode", "keydown"), function (b) { a._onKeyDown(u.byNode(this), b) }), r(this.domNode, r.selector(".dijitTreeRow", "focusin"),
                        function (b) { a._onNodeFocus(u.getEnclosingWidget(this), b) })); this.model || this._store2model(); this.connect(this.model, "onChange", "_onItemChange"); this.connect(this.model, "onChildrenChange", "_onItemChildrenChange"); this.connect(this.model, "onDelete", "_onItemDelete"); this.inherited(arguments); if (this.dndController) {
                            if (l.isString(this.dndController)) this.dndController = l.getObject(this.dndController); for (var b = {}, c = 0; c < this.dndParams.length; c++) this[this.dndParams[c]] && (b[this.dndParams[c]] = this[this.dndParams[c]]);
                            this.dndController = new this.dndController(this, b)
                        } this._load(); !this.params.path && !this.params.paths && this.persist && this.set("paths", this.dndController._getSavedPaths()); this.onLoadDeferred = this.pendingCommandsDeferred; this.onLoadDeferred.then(l.hitch(this, "onLoad"))
                    }, _store2model: function () {
                        this._v10Compat = !0; q.deprecated("Tree: from version 2.0, should specify a model object rather than a store/query"); var a = { id: this.id + "_ForestStoreModel", store: this.store, query: this.query, childrenAttrs: this.childrenAttr };
                        if (this.params.mayHaveChildren) a.mayHaveChildren = l.hitch(this, "mayHaveChildren"); if (this.params.getItemChildren) a.getChildren = l.hitch(this, function (a, b, l) { this.getItemChildren(this._v10Compat && a === this.model.root ? null : a, b, l) }); this.model = new H(a); this.showRoot = Boolean(this.label)
                    }, onLoad: function () { }, _load: function () {
                        this.model.getRoot(l.hitch(this, function (a) {
                            var b = this.rootNode = this.tree._createTreeNode({
                                item: a, tree: this, isExpandable: !0, label: this.label || this.getLabel(a), textDir: this.textDir, indent: this.showRoot ?
                                0 : -1
                            }); this.showRoot ? this.domNode.setAttribute("aria-multiselectable", !this.dndController.singular) : (b.rowNode.style.display = "none", this.domNode.setAttribute("role", "presentation"), this.domNode.removeAttribute("aria-expanded"), this.domNode.removeAttribute("aria-multiselectable"), b.labelNode.setAttribute("role", "presentation"), b.containerNode.setAttribute("role", "tree"), b.containerNode.setAttribute("aria-expanded", "true"), b.containerNode.setAttribute("aria-multiselectable", !this.dndController.singular));
                            this.domNode.appendChild(b.domNode); a = this.model.getIdentity(a); this._itemNodesMap[a] ? this._itemNodesMap[a].push(b) : this._itemNodesMap[a] = [b]; b._updateLayout(); this._expandNode(b).then(l.hitch(this, function () { this.expandChildrenDeferred.resolve(!0) }))
                        }), l.hitch(this, function (a) { console.error(this, ": error loading root: ", a) }))
                    }, getNodesByItem: function (a) { return !a ? [] : [].concat(this._itemNodesMap[l.isString(a) ? a : this.model.getIdentity(a)]) }, _setSelectedItemAttr: function (a) {
                        this.set("selectedItems",
                        [a])
                    }, _setSelectedItemsAttr: function (a) { var b = this; return this.pendingCommandsDeferred = this.pendingCommandsDeferred.then(l.hitch(this, function () { var c = j.map(a, function (a) { return !a || l.isString(a) ? a : b.model.getIdentity(a) }), g = []; j.forEach(c, function (a) { g = g.concat(b._itemNodesMap[a] || []) }); this.set("selectedNodes", g) })) }, _setPathAttr: function (a) { return a.length ? this.set("paths", [a]) : this.set("paths", []) }, _setPathsAttr: function (a) {
                        function b(a, l, c) {
                            var d = a.shift(), k = j.filter(l, function (a) {
                                return a.getIdentity() ==
                                d
                            })[0]; k ? a.length ? g._expandNode(k).then(function () { b(a, k.getChildren(), c) }) : c.resolve(k) : c.reject(new D.PathError("Could not expand path at " + d))
                        } var g = this; return this.pendingCommandsDeferred = this.pendingCommandsDeferred.then(function () { return new e(j.map(a, function (a) { var d = new c, a = j.map(a, function (a) { return l.isString(a) ? a : g.model.getIdentity(a) }); a.length ? b(a, [g.rootNode], d) : d.reject(new D.PathError("Empty path")); return d })) }).then(function (a) {
                            g.set("selectedNodes", j.map(j.filter(a, function (a) { return a[0] }),
                            function (a) { return a[1] }))
                        })
                    }, _setSelectedNodeAttr: function (a) { this.set("selectedNodes", [a]) }, _setSelectedNodesAttr: function (a) { this.dndController.setSelection(a) }, expandAll: function () { function a(l) { var c = new dojo.Deferred; b._expandNode(l).then(function () { var b = j.filter(l.getChildren() || [], function (a) { return a.isExpandable }), b = j.map(b, a); (new dojo.DeferredList(b)).then(function () { c.resolve(!0) }) }); return c } var b = this; return a(this.rootNode) }, collapseAll: function () {
                        function a(l) {
                            var c = new dojo.Deferred;
                            c.label = "collapseAllDeferred"; var g = j.filter(l.getChildren() || [], function (a) { return a.isExpandable }), g = j.map(g, a); (new dojo.DeferredList(g)).then(function () { !l.isExpanded || l == b.rootNode && !b.showRoot ? c.resolve(!0) : b._collapseNode(l).then(function () { c.resolve(!0) }) }); return c
                        } var b = this; return a(this.rootNode)
                    }, mayHaveChildren: function () { }, getItemChildren: function () { }, getLabel: function (a) { return this.model.getLabel(a) }, getIconClass: function (a, b) {
                        return !a || this.model.mayHaveChildren(a) ? b ? "dijitFolderOpened" :
                        "dijitFolderClosed" : "dijitLeaf"
                    }, getLabelClass: function () { }, getRowClass: function () { }, getIconStyle: function () { }, getLabelStyle: function () { }, getRowStyle: function () { }, getTooltip: function () { return "" }, _onKeyPress: function (a, b) { if (!(32 >= b.charCode) && !b.altKey && !b.ctrlKey && !b.shiftKey && !b.metaKey) { var l = String.fromCharCode(b.charCode); this._onLetterKeyNav({ node: a, key: l.toLowerCase() }); n.stop(b) } }, _onKeyDown: function (a, b) {
                        var l = b.keyCode, c = this._keyHandlerMap; if (!c) c = {}, c[o.ENTER] = c[o.SPACE] = c[" "] = "_onEnterKey",
                        c[this.isLeftToRight() ? o.LEFT_ARROW : o.RIGHT_ARROW] = "_onLeftArrow", c[this.isLeftToRight() ? o.RIGHT_ARROW : o.LEFT_ARROW] = "_onRightArrow", c[o.UP_ARROW] = "_onUpArrow", c[o.DOWN_ARROW] = "_onDownArrow", c[o.HOME] = "_onHomeKey", c[o.END] = "_onEndKey", this._keyHandlerMap = c; this._keyHandlerMap[l] && (this._curSearch && (this._curSearch.timer.remove(), delete this._curSearch), this[this._keyHandlerMap[l]]({ node: a, item: a.item, evt: b }), n.stop(b))
                    }, _onEnterKey: function (a) {
                        this._publish("execute", { item: a.item, node: a.node }); this.dndController.userSelect(a.node,
                        m.isCopyKey(a.evt), a.evt.shiftKey); this.onClick(a.item, a.node, a.evt)
                    }, _onDownArrow: function (a) { (a = this._getNextNode(a.node)) && a.isTreeNode && this.focusNode(a) }, _onUpArrow: function (a) { var a = a.node, b = a.getPreviousSibling(); if (b) for (a = b; a.isExpandable && a.isExpanded && a.hasChildren() ;) a = a.getChildren(), a = a[a.length - 1]; else if (b = a.getParent(), this.showRoot || b !== this.rootNode) a = b; a && a.isTreeNode && this.focusNode(a) }, _onRightArrow: function (a) {
                        a = a.node; a.isExpandable && !a.isExpanded ? this._expandNode(a) : a.hasChildren() &&
                        (a = a.getChildren()[0]) && a.isTreeNode && this.focusNode(a)
                    }, _onLeftArrow: function (a) { a = a.node; a.isExpandable && a.isExpanded ? this._collapseNode(a) : (a = a.getParent()) && a.isTreeNode && (this.showRoot || a !== this.rootNode) && this.focusNode(a) }, _onHomeKey: function () { var a = this._getRootOrFirstNode(); a && this.focusNode(a) }, _onEndKey: function () { for (var a = this.rootNode; a.isExpanded;) a = a.getChildren(), a = a[a.length - 1]; a && a.isTreeNode && this.focusNode(a) }, multiCharSearchDuration: 250, _onLetterKeyNav: function (a) {
                        var b = this._curSearch;
                        b ? (b.pattern += a.key, b.timer.remove()) : b = this._curSearch = { pattern: a.key, startNode: a.node }; b.timer = this.defer(function () { delete this._curSearch }, this.multiCharSearchDuration); a = b.startNode; do (a = this._getNextNode(a)) || (a = this._getRootOrFirstNode()); while (a !== b.startNode && a.label.toLowerCase().substr(0, b.pattern.length) != b.pattern); a && a.isTreeNode && a !== b.startNode && this.focusNode(a)
                    }, isExpandoNode: function (a, b) { return d.isDescendant(a, b.expandoNode) }, _onClick: function (a, b) {
                        var l = this.isExpandoNode(b.target,
                        a); this.openOnClick && a.isExpandable || l ? a.isExpandable && this._onExpandoClick({ node: a }) : (this._publish("execute", { item: a.item, node: a, evt: b }), this.onClick(a.item, a, b), this.focusNode(a)); n.stop(b)
                    }, _onDblClick: function (a, b) { var l = b.target, l = l == a.expandoNode || l == a.expandoNodeText; this.openOnDblClick && a.isExpandable || l ? a.isExpandable && this._onExpandoClick({ node: a }) : (this._publish("execute", { item: a.item, node: a, evt: b }), this.onDblClick(a.item, a, b), this.focusNode(a)); n.stop(b) }, _onExpandoClick: function (a) {
                        a =
                        a.node; this.focusNode(a); a.isExpanded ? this._collapseNode(a) : this._expandNode(a)
                    }, onClick: function () { }, onDblClick: function () { }, onOpen: function () { }, onClose: function () { }, _getNextNode: function (a) { if (a.isExpandable && a.isExpanded && a.hasChildren()) return a.getChildren()[0]; for (; a && a.isTreeNode;) { var b = a.getNextSibling(); if (b) return b; a = a.getParent() } return null }, _getRootOrFirstNode: function () { return this.showRoot ? this.rootNode : this.rootNode.getChildren()[0] }, _collapseNode: function (a) {
                        a._expandNodeDeferred &&
                        delete a._expandNodeDeferred; if ("LOADING" != a.state && a.isExpanded) { var b = a.collapse(); this.onClose(a.item, a); this._state(a, !1); this._startPaint(b); return b }
                    }, _expandNode: function (a) {
                        var b = new c; if (a._expandNodeDeferred) return a._expandNodeDeferred; var g = this.model, d = a.item, k = this; if (!a._loadDeferred) a.markProcessing(), a._loadDeferred = new c, g.getChildren(d, function (b) { a.unmarkProcessing(); a.setChildItems(b).then(function () { a._loadDeferred.resolve(b) }) }, function (b) {
                            console.error(k, ": error loading " +
                            a.label + " children: ", b); a._loadDeferred.reject(b)
                        }); a._loadDeferred.then(l.hitch(this, function () { a.expand().then(function () { b.resolve(!0) }); this.onOpen(a.item, a); this._state(a, !0) })); this._startPaint(b); return b
                    }, focusNode: function (a) { z.focus(a.labelNode) }, _onNodeFocus: function (a) { if (a && a != this.lastFocused) this.lastFocused && !this.lastFocused._destroyed && this.lastFocused.setFocusable(!1), a.setFocusable(!0), this.lastFocused = a }, _onNodeMouseEnter: function () { }, _onNodeMouseLeave: function () { }, _onItemChange: function (a) {
                        var b =
                        this._itemNodesMap[this.model.getIdentity(a)]; if (b) { var l = this.getLabel(a), c = this.getTooltip(a); j.forEach(b, function (b) { b.set({ item: a, label: l, tooltip: c }); b._updateItemClasses(a) }) }
                    }, _onItemChildrenChange: function (a, b) { var l = this._itemNodesMap[this.model.getIdentity(a)]; l && j.forEach(l, function (a) { a.setChildItems(b) }) }, _onItemDelete: function (a) {
                        var a = this.model.getIdentity(a), b = this._itemNodesMap[a]; b && (j.forEach(b, function (a) {
                            this.dndController.removeTreeNode(a); var b = a.getParent(); b && b.removeChild(a);
                            a.destroyRecursive()
                        }, this), delete this._itemNodesMap[a])
                    }, _initState: function () { this._openedNodes = {}; if (this.persist && this.cookieName) { var a = h(this.cookieName); a && j.forEach(a.split(","), function (a) { this._openedNodes[a] = !0 }, this) } }, _state: function (a, b) {
                        if (!this.persist) return !1; var l = j.map(a.getTreePath(), function (a) { return this.model.getIdentity(a) }, this).join("/"); if (1 === arguments.length) return this._openedNodes[l]; b ? this._openedNodes[l] = !0 : delete this._openedNodes[l]; if (this.persist && this.cookieName) {
                            var l =
                            [], c; for (c in this._openedNodes) l.push(c); h(this.cookieName, l.join(","), { expires: 365 })
                        }
                    }, destroy: function () { this._curSearch && (this._curSearch.timer.remove(), delete this._curSearch); this.rootNode && this.rootNode.destroyRecursive(); this.dndController && !l.isString(this.dndController) && this.dndController.destroy(); this.rootNode = null; this.inherited(arguments) }, destroyRecursive: function () { this.destroy() }, resize: function (b) {
                        b && a.setMarginBox(this.domNode, b); this._nodePixelIndent = a.position(this.tree.indentDetector).w ||
                        this._nodePixelIndent; this.expandChildrenDeferred.then(l.hitch(this, function () { this.rootNode.set("indent", this.showRoot ? 0 : -1); this._adjustWidths() }))
                    }, _outstandingPaintOperations: 0, _startPaint: function (a) {
                        this._outstandingPaintOperations++; this._adjustWidthsTimer && (this._adjustWidthsTimer.remove(), delete this._adjustWidthsTimer); var b = l.hitch(this, function () { this._outstandingPaintOperations--; if (0 >= this._outstandingPaintOperations && !this._adjustWidthsTimer && this._started) this._adjustWidthsTimer = this.defer("_adjustWidths") });
                        x(a, b, b)
                    }, _adjustWidths: function () { function b(a) { var g = a.rowNode; g.style.width = "auto"; l = Math.max(l, g.clientWidth); c.push(g); a.isExpanded && j.forEach(a.getChildren(), b) } this._adjustWidthsTimer && (this._adjustWidthsTimer.remove(), delete this._adjustWidthsTimer); var l = 0, c = []; b(this.rootNode); l = Math.max(l, a.getContentBox(this.domNode).w); j.forEach(c, function (a) { a.style.width = l + "px" }) }, _createTreeNode: function (a) { return new E(a) }, _setTextDirAttr: function (a) {
                        a && this.textDir != a && (this._set("textDir", a), this.rootNode.set("textDir",
                        a))
                    }
                }); D.PathError = g("TreePathError"); D._TreeNode = E; return D
            })
        }, "cbtree/model/_base/BaseStoreModel": function () {
            define("cbtree/model/_base/BaseStoreModel", "module,dojo/_base/declare,dojo/_base/lang,dojo/aspect,dojo/Deferred,dojo/promise/all,dojo/promise/Promise,dojo/Stateful,dojo/when,./Parents,./Prologue,../../Evented,../../errors/createError!../../errors/CBTErrors.json,../../util/shim/Array".split(","), function (j, m, h, f, c, e, d, b, a, k, n, g, p) {
                function q() { return !0 } var o = p(j.id); return m([g, b], {
                    iconAttr: "",
                    labelAttr: "name", labelType: "text", parentProperty: "parent", query: null, options: null, rootLabel: null, store: null, state: "created", root: null, _forest: !1, _loadRequested: !1, constructor: function (a) {
                        this._childrenCache = {}; this._objectCache = {}; this._obsHandles = {}; this._methods = {}; this._forest = this._eventable = !1; this._loadOptions = null; this._resetPending = this._observable = this._monitored = this._loadRequested = !1; this._writeEnabled = !0; this._evtHandles = { remove: function () { } }; this._modelReady = new c; this._storeReady = new c;
                        m.safeMixin(this, a); var b = this.store; if (!b) throw new o("ParameterMissing", "constructor", "Store parameter is required"); b.parentProperty ? this.parentProperty = b.parentProperty : b.parentProperty = this.parentProperty; "add,put,get,load,hasChildren,getChildren,getParents,addParent,query,removeParent,queryEngine,notify,emit,dispatchEvent,isItem,ready".split(",").forEach(function (a) {
                            if ("function" == typeof b[a]) switch (this._methods[a] = b[a], a) {
                                case "add": !0 !== b.hierarchical && f.before(b, "add", n); break; case "dispatchEvent": case "emit": if (!0 ===
                                b.eventable) this._evtHandles = b.on("change, delete, new", h.hitch(this, this._onStoreEvent)), this._observable = !1, this._eventable = !0; break; case "notify": if (!this._eventable) this._observable = !0; break; case "put": !0 !== b.hierarchical && f.before(b, "put", n)
                            } else switch (a) {
                                case "getChildren": if ("function" == typeof b.query) b.getChildren = new Function(["object", "options"], "return this.query({" + this.parentProperty + ": this.getIdentity(object)}, options);"); else throw new o("MethodMissing", "constructor", "store MUST support getChildren() or query() method");
                                    break; case "isItem": b.isItem = function (a) { return a && "object" == typeof a ? a == this.get(this.getIdentity(a)) : !1 }; break; case "get": throw new o("MethodMissing", "constructor", "store MUST support the get() method"); case "hasChildren": case "load": case "ready": this._methods[a] = q; break; case "put": this._writeEnabled = !1
                            }
                        }, this); this._monitored = this._eventable || this._observable; f.after(b, "onClose", h.hitch(this, "_onStoreClosed"), !0)
                    }, postscript: function () { this.inherited(arguments); this._loadStore(this._loadOptions) },
                    _parentPropertySetter: function (a) { if ("string" == typeof a) { if (/\./.test(a)) throw new o("InvalidType", "set", "parentProperty can not be a dot separated string"); } else throw new o("InvalidType", "set", "parentProperty value must be a string"); return this.checkedAttr }, destroy: function () { for (var a in this._childrenCache) this._deleteCacheEntry(a); this._evtHandles.remove(); this._childrenCache = {}; this._objectCache = {}; this.store = void 0 }, getChildren: function () { throw new o("AbstractOnly", "getChildren"); }, getIcon: function (a) {
                        if (this.iconAttr) return this._getProp(this.iconAttr,
                        a)
                    }, getIdentity: function (a) { return this.store.getIdentity(a) }, getLabel: function (a) { return a === this.root && this.rootLabel ? this.rootLabel : this._getProp(this.labelAttr, a) }, getParents: function (b) { var g = new c, d = []; if (b) if (this._methods.getParents) a(this.store.getParents(b), function (a) { g.resolve(a || []) }, g.reject); else { var f = []; (new k(b, this.parentProperty)).forEach(function (b) { if (b = this.store.get(b)) a(b, function (a) { a && d.push(a) }), f.push(b) }, this); e(f).always(function () { g.resolve(d) }) } else g.resolve(d); return g.promise },
                    getRoot: function (b, c) { var g = this; if (this.root) a(this._storeReady, function () { b(g.root) }); else if (this._methods.query) a(this._storeReady, function () { var d = g.store.query(g.query, g.options); a(d, function (a) { if (1 != a.length) throw new o("InvalidResponse", "getRoot", "Root query returned %{0} items, but must return exactly one", a.length); g.root = a[0]; d.observe && d.observe(function (a, b, l) { b == l && g._onChange(a, null) }, !0); b(g.root) }, c) }, c); else throw new o("MethodMissing", "getRoot", "store has no query() method"); },
                    isItem: function (a) { return this.store.isItem(a) }, mayHaveChildren: function (a) { var b = this._methods.hasChildren, c = this._childrenCache[this.getIdentity(a)]; return c && !(c instanceof d) ? !!c.length : b.call(this.store, a) }, isChildOf: function (a, b) { return b && a ? (new k(a, this.parentProperty)).contains(this.getIdentity(b)) : !1 }, deleteItem: function (b, c) {
                        function g(b) {
                            var l = d.getIdentity(b); if (l && (c && d.getChildren(b, function (a) { a.forEach(g) }), d._forest && b == d.root ? d._onDeleteItem(b) : (l = d.store.remove(l), d._monitored ||
                            a(l, function () { d._onDeleteItem(b) })), b == d.root)) d.root = null
                        } var b = b instanceof Array ? b : [b], d = this; b.forEach(g)
                    }, ready: function (a, b, c) { return a || b ? this._modelReady.then(a ? h.hitch(c || this, a) : null, b ? h.hitch(c || this, b) : null) : this._modelReady.promise }, newItem: function (b, c, g, d) {
                        var e = c[this.parentProperty] instanceof Array, f = this.getIdentity(b), n = this, p, c = this._forest && c == this.root ? void 0 : c; if (void 0 != f) return p = a(this.store.get(f), function (h) {
                            if (h) {
                                var q = new k(h, n.parentProperty); e ? (q.add(n.getIdentity(c),
                                !0), h[n.parentProperty] = q.toValue(), f = n.store.put(h), n._monitored || a(f, function () { n._childrenChanged(c) })) : n.getParents(h).then(function (a) { a.length && n.pasteItem(h, a[0], c, !1, g, d) }); return h
                            } p = n.store.put(b, { parent: c, before: d }); return a(p, function (b) { return a(n.store.get(b), function (b) { b && (n._monitored || a(p, function () { n._onNewItem(b) })); return b }) })
                        }); p = this.store.put(b, { parent: c, before: d }); return a(p, function (b) {
                            return a(n.store.get(b), function (b) {
                                if (b) {
                                    if (c == this.root) n.onRootChange(b, "new"); this._monitored ||
                                    a(p, function () { n._onNewItem(b) })
                                } return b
                            })
                        })
                    }, pasteItem: function (b, c, g, d, e, f) { var n = new k(b, this.parentProperty), p = this.getIdentity(g), h = this.getIdentity(c), q = [g], j = this; if (h != p) { var o = c == this.root, g = g == this.root; d || (q.push(c), n.remove(h)); if (g || o) this.onRootChange(b, g ? "attach" : "detach"); (!this._forest || !g) && n.add(p) } b[this.parentProperty] = n.toValue(); c = this.store.put(b, { before: f }); (!this._monitored || this._eventable && f) && a(c, function () { j._childrenChanged(q) }); this.onPasteItem(b, e, f) }, _onChange: function (a,
                    b) { var c = this.getIdentity(a); if (b = b || this._objectCache[c]) { for (var g in b) g in a ? b[g] != a[g] && this._onSetItem(a, g, b[g], a[g]) : this._onSetItem(a, g, b[g], void 0); for (g in a) g in b || this._onSetItem(a, g, void 0, a[g]) } this._objectCache[c] = h.mixin(null, a) }, _onChildrenChange: function (a, b) { this.onChildrenChange(a, b) }, _onDeleteItem: function (b) {
                        var c = this.getIdentity(b), g = this; a(this.store.get(c), function (a) { a || delete g._objectCache[c] }, function () { delete g._objectCache[c] }); this._deleteCacheEntry(c); this.onDelete(b);
                        this.getParents(b).then(function (a) { if (g.isChildOf(b, g.root)) g.onRootChange(b, "delete"); g._childrenChanged(a) })
                    }, _onNewItem: function (a) { var b = this; this.getParents(a).then(function (c) { if (b.isChildOf(a, b.root)) b.onRootChange(a, "new"); b._childrenChanged(c) }) }, _onSetItem: function (a, b, c, g) {
                        var d = this.parentProperty; if (b === d) {
                            var e = new k(g, d), f = new k(c, d), n = this, p = []; e.forEach(function (a) { !f.contains(a) && n._objectCache[a] && p.push(n._objectCache[a]) }); f.forEach(function (a) {
                                !e.contains(a) && n._objectCache[a] &&
                                p.push(n._objectCache[a])
                            }); p.length && (n._childrenChanged(p), this.onChange(a, b, g, c))
                        } else this.onChange(a, b, g, c); return !0
                    }, _onStoreClosed: function (a, b) {
                        if (!this._resetPending) {
                            if (!b || !a) { for (var g in this._childrenCache) this._deleteCacheEntry(g); this._childrenCache = {}; this._objectCache = {} } if (a) {
                                var d = this; this._modelReady.isFulfilled() || this._modelReady.cancel(new o("RequestCancel", "_onStoreClosed")); this._modelReady = new c; this._storeReady = new c; this._loadRequested = !1; this._resetPending = !0; this.state =
                                "reset"; this.onReset(); if (!this._forest) this.root = null; this._loadStore().then(function () { d._resetPending = !1 })
                            }
                        }
                    }, _onStoreEvent: function (b) { var c = b; if (b.detail) c = b.detail; switch (b.type) { case "change": this._onChange(c.item, null); c.from && c.from != c.at && a(this.getParents(c.item), h.hitch(this, "_childrenChanged")); break; case "close": this._onStoreClose(c.count, c.cleared); break; case "delete": this._onDeleteItem(c.item); break; case "new": this._onNewItem(c.item) } }, onChange: function () { }, onChildrenChange: function () { },
                    onPasteItem: function () { }, onDelete: function () { }, onReset: function () { }, onRootChange: function () { }, _childrenChanged: function (a) { var b, c = this; (a = a instanceof Array ? a : [a]) && a.length && a.forEach(function (a) { b = c.getIdentity(a); c._deleteCacheEntry(b); c.getChildren(a, function (b) { c._onChildrenChange(a, b.slice(0)) }, function (a) { console.error(a) }) }) }, _deleteCacheEntry: function (a) { if (this._childrenCache[a]) { var b = this._obsHandles[a]; b && b.remove(); delete this._childrenCache[a]; delete this._obsHandles[a] } }, _getChildren: function (b,
                    g, d, k) {
                        var e = this.getIdentity(b), f = this, n = null; if (b && void 0 != e) {
                            if (this._observable && this._childrenCache[e]) { a(this._childrenCache[e], d, k); return } f._childrenCache[e] = n = g.call(f, b, e); this._objectCache[e] || (this._objectCache[e] = h.mixin(null, b)); a(n, function (a) { a.forEach(function (a) { f._objectCache[f.getIdentity(a)] = h.mixin(null, a) }); f._childrenCache[e] = a }); this._observable && n.observe && (b = n.observe(function (b, c, g) {
                                -1 == g ? a(n, h.hitch(f, "_onDeleteItem", b)) : -1 == c ? a(n, h.hitch(f, "_onNewItem", b)) : c == g ? a(n, h.hitch(f,
                                "_onChange", b, null)) : a(n, function (a) { Array.prototype.slice.call(a) })
                            }, !0), this._obsHandles[e] = b)
                        } else n = new c, n.reject(new o("ParameterMissing", "_getChildren", "No parent object or Id")); a(n, d, k)
                    }, _getProp: function (a, b) { for (var c = a.split("."), g, d = 0; b && (g = c[d++]) ;) b = g in b ? b[g] : void 0; return b }, _loadStore: function (b) {
                        if (!this._loadRequested) {
                            var c = this._methods.ready, g = this._methods.load, d = this; this._loadRequested = !0; this.state = "loading"; b = [g.call(this.store, b), c.call(this.store)]; this._loadPromise =
                            e(b).always(function () { return a(c.call(d.store), function () { d._storeReady.resolve(); d._validateStore().then(function () { d._modelReady.resolve(); d.state = "active" }, function (a) { d._modelReady.reject(a); d.state = "in-active" }); return !0 }, function (a) { d._modelReady.reject(a); d._storeReady.reject(a) }) })
                        } return this._loadPromise
                    }, _setProp: function (a, b, c) { var a = a.split("."), g = a.pop(); if (a.length) for (var d, k = 0; b && (d = a[k++]) ;) b = d in b ? b[d] : b[d] = {}; return b[g] = c }, _setValue: function (b, c, g) {
                        if (b[c] !== g) if (this._writeEnabled) {
                            var d =
                            h.mixin(null, b), k = null, e = this; this._setProp(c, b, g); k = this.store.put(b, { overwrite: !0 }); this._monitored || a(k, function () { e._onChange(b, d) })
                        } else throw new o("AccessError", "_setValue", "store is not writable."); return g
                    }, _updateChildrenCache: function (b, c, g) { var d = this.getIdentity(c), k = this; return a(this._childrenCache[d], function (a) { var a = a || [], c = a.indexOf(g), e = a.total || 0; "add" == b || "attach" == b ? -1 == c && (a.push(g), e++) : -1 < c && (a.splice(c, 1), e--); a.total = e; return k._childrenCache[d] = a }) }, _validateStore: function () { return (new c).resolve() }
                })
            })
        },
        "dijit/form/_FormWidgetMixin": function () {
            define("dijit/form/_FormWidgetMixin", "dojo/_base/array,dojo/_base/declare,dojo/dom-attr,dojo/dom-style,dojo/_base/lang,dojo/mouse,dojo/sniff,dojo/window,../a11y".split(","), function (j, m, h, f, c, e, d, b, a) {
                return m("dijit.form._FormWidgetMixin", null, {
                    name: "", alt: "", value: "", type: "text", tabIndex: "0", _setTabIndexAttr: "focusNode", disabled: !1, intermediateChanges: !1, scrollOnFocus: !0, _setIdAttr: "focusNode", _setDisabledAttr: function (b) {
                        this._set("disabled", b); h.set(this.focusNode,
                        "disabled", b); this.valueNode && h.set(this.valueNode, "disabled", b); this.focusNode.setAttribute("aria-disabled", b ? "true" : "false"); b ? (this._set("hovering", !1), this._set("active", !1), b = "tabIndex" in this.attributeMap ? this.attributeMap.tabIndex : "_setTabIndexAttr" in this ? this._setTabIndexAttr : "focusNode", j.forEach(c.isArray(b) ? b : [b], function (b) { b = this[b]; d("webkit") || a.hasDefaultTabStop(b) ? b.setAttribute("tabIndex", "-1") : b.removeAttribute("tabIndex") }, this)) : "" != this.tabIndex && this.set("tabIndex", this.tabIndex)
                    },
                    _onFocus: function (a) { if ("mouse" == a && this.isFocusable()) var c = this.connect(this.focusNode, "onfocus", function () { this.disconnect(g); this.disconnect(c) }), g = this.connect(this.ownerDocumentBody, "onmouseup", function () { this.disconnect(g); this.disconnect(c); this.focused && this.focus() }); this.scrollOnFocus && this.defer(function () { b.scrollIntoView(this.domNode) }); this.inherited(arguments) }, isFocusable: function () { return !this.disabled && this.focusNode && "none" != f.get(this.domNode, "display") }, focus: function () {
                        if (!this.disabled &&
                        this.focusNode.focus) try { this.focusNode.focus() } catch (a) { }
                    }, compare: function (a, b) { return "number" == typeof a && "number" == typeof b ? isNaN(a) && isNaN(b) ? 0 : a - b : a > b ? 1 : a < b ? -1 : 0 }, onChange: function () { }, _onChangeActive: !1, _handleOnChange: function (a, b) {
                        if (void 0 == this._lastValueReported && (null === b || !this._onChangeActive)) this._resetValue = this._lastValueReported = a; this._pendingOnChange = this._pendingOnChange || typeof a != typeof this._lastValueReported || 0 != this.compare(a, this._lastValueReported); if ((this.intermediateChanges ||
                        b || void 0 === b) && this._pendingOnChange) if (this._lastValueReported = a, this._pendingOnChange = !1, this._onChangeActive) this._onChangeHandle && this._onChangeHandle.remove(), this._onChangeHandle = this.defer(function () { this._onChangeHandle = null; this.onChange(a) })
                    }, create: function () { this.inherited(arguments); this._onChangeActive = !0 }, destroy: function () { this._onChangeHandle && (this._onChangeHandle.remove(), this.onChange(this._lastValueReported)); this.inherited(arguments) }
                })
            })
        }, "cbtree/CheckBox": function () {
            define("cbtree/CheckBox",
            ["dijit/form/CheckBox", "dojo/_base/declare", "dojo/_base/event", "dojo/dom-attr"], function (j, m, h, f) {
                return m([j], {
                    baseClass: "cbtreeCheckBox", toggleState: { mixed: !0, "true": !1, "false": !0 }, multiState: !0, _getCheckedAttr: function () { return this.checked }, _onClick: function (c) { return !this.readOnly && !this.disabled ? (this.toggle(), this.onClick(c)) : h.stop(c) }, _setCheckedAttr: function (c, e) {
                        var d = c, b; if ("mixed" !== d || !this.multiState) d = d ? !0 : !1; b = "mixed" == d ? d : d ? "true" : "false"; this._set("checked", d); f.set(this.focusNode ||
                        this.domNode, "checked", d); (this.focusNode || this.domNode).setAttribute("aria-checked", b); this._handleOnChange(d, e); return d
                    }, _setValueAttr: function (c) { if ("string" == typeof c) this.value = c, f.set(this.focusNode, "value", c) }, toggle: function () { var c = this.get("checked"); !this.readOnly && !this.disabled && (c = this.toggleState[c.toString()], c = this._setCheckedAttr(void 0 !== c ? c : !0)); return c }
                })
            })
        }, "cbtree/store/handlers/arcGisHandler": function () {
            define("cbtree/store/handlers/arcGisHandler", ["dojo/_base/lang", "../../util/QueryEngine",
            "../../util/shim/Array"], function (j, m) {
                function h(c) { return c.replace(/(^|\W)([a-z])/g, function (c) { return c.toUpperCase() }) } function f(c, e) { for (var d = c.split("."), b, a = 0; e && (b = d[a++]) ;) e = b in e ? e[b] : void 0; return e } return function (c) {
                    var e = this; this._query = function (c) { return c }; this.symbol = this.template = null; this.type = "POI"; this._querySetter = function (c, b) { this._query = m(c, b) }; this.handler = function (c) {
                        var b = c ? c.text || c.data : null, a = []; if (b) {
                            var c = e._query(b.results), b = h(b.value), k = b.toLowerCase(); if (c &&
                            c.length) { var n = { attributes: { Addr_Type: f("feature.attributes.Addr_Type", c[0]) || e.type } }; a.push({ id: k, name: b, parent: null, type: "parent", features: n }); c.forEach(function (b) { var c = j.clone(b); c.feature.attributes.name = b.name; c.feature.setInfoTemplate(e.template); c.feature.setSymbol(e.symbol); c.parent = k; c.type = "child"; a.push(c) }) }
                        } return a
                    }; this.set = function (c, b) {
                        if (c) {
                            if ("object" == typeof c) for (var a in c) this.set(a, c[a]); a = this["_" + c + "Setter"]; "function" == typeof a ? a.apply(this, Array.prototype.slice.call(arguments,
                            1)) : this[c] = b
                        }
                    }; c && this.set(c)
                }
            })
        }, "cbtree/store/Hierarchy": function () {
            define("cbtree/store/Hierarchy", "module,dojo/_base/declare,dojo/_base/lang,dojo/store/util/QueryResults,./Natural,../errors/createError!../errors/CBTErrors.json".split(","), function (j, m, h, f, c, e) {
                var d = e(j.id); return m([c], {
                    indexChildren: !0, multiParented: "auto", parentProperty: "parent", hierarchical: !0, _indexParent: {}, _indexChild: {}, constructor: function () { this.indexChildren = this._indexStore ? this.indexChildren : !1 }, destroy: function () {
                        this._indexParent =
                        {}; this._indexChild = {}; this.inherited(arguments)
                    }, _getParentArray: function (b) { b = b[this.parentProperty]; return void 0 != b ? this.multiParented ? b : [b] : [] }, _getParentIds: function (b, a) { var c = []; a && (a = a instanceof Array ? a : [a], a.forEach(function (a) { switch (typeof a) { case "object": a = this.getIdentity(a); case "string": case "number": void 0 != a && a != b && -1 == c.indexOf(a) && c.push(a); break; default: throw new d("InvalidType", "_getParentId"); } }, this)); return c }, _loadData: function (b) {
                        this._indexParent = {}; this._indexChild =
                        {}; if (b instanceof Array && "auto" == this.multiParented) this.multiParented = b.some(function (a) { return a[this.parentProperty] instanceof Array }, this); this.inherited(arguments)
                    }, _parentIdsChanged: function (b, a) { return b.length == a.length ? !a.every(function (a) { return -1 != b.indexOf(a) }) : !0 }, _setParentType: function (b) {
                        if (!0 === this.multiParented) b instanceof Array || (b = b ? [b] : []); else if (!1 === this.multiParented) b instanceof Array && (b = b.length ? b[0] : void 0); else if ("auto" === this.multiParented) this.multiParented = b instanceof
                        Array; return b
                    }, _updateHierarchy: function (b, a) {
                        if (this.indexChildren) {
                            var c = this.getIdentity(b), d = this._indexParent[c] || [], g = this._getParentArray(b), e = this._parentIdsChanged(g, d); e && d.forEach(function (a) { if (-1 == g.indexOf(a)) { var c = this._indexChild[a], l = c.indexOf(b); -1 < l && (c.splice(l, 1), 0 == c.length && delete this._indexChild[a]) } }, this); if (e || a) g.forEach(function (c) { var g = this._indexChild[c] || []; a ? this._insertBefore(g, b, a) : -1 == g.indexOf(b) && g.push(b); this._indexChild[c] = g }, this), this._indexParent[c] =
                            g.slice(0), g.length || delete this._indexParent[c]
                        }
                    }, _validParents: function (b) { return this._getParentArray(b).every(function (a) { return this._indexId[a] }, this) }, _writeObject: function (b, a, c, d) { var g, e; d && (d.parent && (a[this.parentProperty] = this._getParentIds(b, d.parent)), d.before && (g = this._anyToObject(d.before))); a[this.parentProperty] = this._setParentType(a[this.parentProperty]); e = this.inherited(arguments); this._updateHierarchy(a, g); return e }, addParent: function (b, a) {
                        var c = this._getParentIds(this.getIdentity(b),
                        a); if (c.length) { var d = h.clone(b), g = this._getParentArray(d); c.forEach(function (a) { -1 == g.indexOf(a) && g.unshift(a) }); d[this.parentProperty] = this._setParentType(g); this.put(d); return !0 } return !1
                    }, close: function (b) { if (b || this.clearOnClose) this._indexParent = {}, this._indexChild = {}; this.inherited(arguments) }, getChildren: function (b, a) { var c = this.getIdentity(b), d = {}, g; this.indexChildren && (g = (this._indexChild[c] || []).slice(0)); d[this.parentProperty] = c; return this.query(d, a, g) }, getParents: function (b) {
                        if (b) {
                            var a =
                            []; this._getParentArray(b).forEach(function (b) { (b = this.get(b)) && a.push(b) }, this); return a
                        }
                    }, hasChildren: function (b) { var a = this.getIdentity(b); return this.indexChildren ? !!(this._indexChild[a] || []).length : this._data.some(function (b) { return -1 != this._getParentArray(b).indexOf(a) }, this) }, query: function (b, a) {
                        var c = 3 == arguments.length ? arguments[2] : null, d = c || this._data, g = this; return this._loadDeferred.isFulfilled() || c ? f(this.queryEngine(b, a)(d, !!c)) : f(this._loadDeferred.then(function () {
                            return g.queryEngine(b,
                            a)(g._data, !1)
                        }))
                    }, remove: function (b) { b = this._indexId[b]; if (0 <= b) { var a = this._data[b], c = a[this.parentProperty]; a[this.parentProperty] = void 0; this._updateHierarchy(a, null); this._data.splice(b, 1); this._indexData(); a[this.parentProperty] = c; return !0 } return !1 }, removeParent: function (b, a) { var c = this._getParentIds(this.getIdentity(b), a); if (c.length) { var d = h.clone(b), g = this._getParentArray(d), g = g.filter(function (a) { return -1 == c.indexOf(a) }); d[this.parentProperty] = this._setParentType(g); this.put(d); return !0 } return !1 },
                    toString: function () { return "[object HierarchyStore]" }
                })
            })
        }, "cbtree/models/TreeStoreModel": function () {
            define("cbtree/models/TreeStoreModel", "dojo/_base/array,dojo/_base/declare,dojo/_base/lang,dojo/aspect,dojo/has,dojo/json,dojo/Stateful,./ItemWriteStoreEX".split(","), function (j, m, h, f, c, e, d) {
                return m([d], {
                    checkedAll: !0, checkedState: !1, checkedRoot: !1, checkedStrict: !0, checkedAttr: "checked", childrenAttrs: ["children"], deferItemLoadingUntilExpand: !1, enabledAttr: "", excludeChildrenAttrs: null, iconAttr: "", labelAttr: "",
                    multiState: !0, newItemIdAttr: "id", normalize: !0, query: null, store: null, moduleName: "cbTree/models/TreeStoreModel", hasFakeRoot: !1, root: null, _checkedChildrenAttrs: null, _queryAttrs: [], _validateStore: !0, _validating: 0, constructor: function (b) {
                        m.safeMixin(this, b); this.connects = []; b = this.store; if (!b.getFeatures()["dojo.data.api.Identity"]) throw Error(this.moduleName + "constructor(): store must support dojo.data.Identity"); c.add("tree-model-getChecked", 1); b.getFeatures()["dojo.data.api.Write"] ? (c.add("tree-model-setChecked",
                        1), this._writeEnabled = !0) : (console.warn(this.moduleName + "::constructor(): store is not write enabled."), this._writeEnabled = !1); if (b.getFeatures()["dojo.data.api.Notification"]) this.connects = this.connects.concat([f.after(b, "onLoad", h.hitch(this, "onStoreLoaded"), !0), f.after(b, "onNew", h.hitch(this, "onNewItem"), !0), f.after(b, "onDelete", h.hitch(this, "onDeleteItem"), !0), f.after(b, "onSet", h.hitch(this, "onSetItem"), !0), f.after(b, "onRoot", h.hitch(this, "onRootChange"), !0)]); this._checkedChildrenAttrs = this._diffArrays(this.childrenAttrs,
                        this.excludeChildrenAttrs); if (this.query) for (var a in this.query) this._queryAttrs.push(a); dojo.deprecated("{cbtree/models/TreeStoreModel}", "Migrate to the new models in cbtree/model/", "2.0")
                    }, destroy: function () { for (var b; b = this.connects.pop() ;) b.remove(); this.store = null }, _checkedStrictSetter: function (b) { b = b ? !0 : !1; if (this.checkedStrict !== b) (this.checkedStrict = b) && this.getRoot(h.hitch(this, function (a) { this.getChildren(a, h.hitch(this, function (b) { this._validateChildren(a, b) })) })); return this.checkedStrict },
                    _enabledAttrSetter: function (b) { if (h.isString(b)) { if (this.enabledAttr !== b) throw Error(this.moduleName + "::set(): enabledAttr property is read-only."); } else throw Error(this.moduleName + "::set(): enabledAttr value must be a string"); return this.enabledAttr }, _labelAttrGetter: function () { return this.getLabelAttr() }, _labelAttrSetter: function (b) { return this.setLabelAttr(b) }, _querySetter: function (b) {
                        if (h.isObject(b)) { if (this.query !== b) this.query = b, this._requeryTop(); return this.query } throw Error(this.moduleName +
                        "::set(): query argument must be of type object");
                    }, getChildren: function (b, a, c, d) {
                        var g = this.store, e = this; if (g.isItemLoaded(b)) {
                            var f = [], o, l; if (d) { var r = h.isArray(d) ? d : [d]; for (l = 0; l < r.length; l++) o = g.getValues(b, r[l]), f = f.concat(o) } else for (l = 0; l < this.childrenAttrs.length; l++) o = g.getValues(b, this.childrenAttrs[l]), f = f.concat(o); var m = 0; this.deferItemLoadingUntilExpand || j.forEach(f, function (a) { g.isItemLoaded(a) || m++ }); 0 == m ? a(f) : j.forEach(f, function (b, d) {
                                g.isItemLoaded(b) || g.loadItem(e._mixinFetch({
                                    item: b,
                                    onItem: function (b) { f[d] = b; 0 == --m && a(f) }, onError: c
                                }))
                            })
                        } else { var t = h.hitch(this, arguments.callee); g.loadItem(e._mixinFetch({ item: b, onItem: function (b) { t(b, a, c) }, onError: c })) }
                    }, getParents: function (b) { if (b) return this.store.getParents(b) }, getRoot: function (b, a) {
                        this.root ? b(this.root) : this.store.fetch(this._mixinFetch({
                            query: this.query, onComplete: h.hitch(this, function (a) {
                                if (1 != a.length) throw Error(this.moduleName + ": query " + e.stringify(this.query) + " returned " + a.length + " items, but must return exactly one item");
                                this.root = a[0]; b(this.root)
                            }), onError: a
                        }))
                    }, mayHaveChildren: function (b) { return j.some(this.childrenAttrs, function (a) { return this.store.hasAttribute(b, a) }, this) }, _getCompositeState: function (b) { var a = !1, c = !1, d = !1, g, e; j.some(b, function (b) { e = this.getChecked(b); d |= "mixed" == e; switch (e) { case !0: a = !0; break; case !1: c = !0 } return d }, this); if (d || a || c) g = (d |= !(a ^ c)) ? "mixed" : a ? !0 : !1; return g }, _normalizeState: function (b, a) {
                        return "boolean" == typeof a ? a : this.multiState && "mixed" == a ? this.normalize && !this.mayHaveChildren(b) ?
                        !0 : a : a ? !0 : !1
                    }, _setChecked: function (b, a) {
                        var c = !1, d; d = this._normalizeState(b, a); c = d != a; if (this.store.isItem(b)) { var g = this.store.getValue(b, this.checkedAttr); if ((void 0 !== g || this.checkedAll) && (g != d || c)) return this.store.setValue(b, this.checkedAttr, d), !0 } else if (b === this.root && this.hasFakeRoot) { if (this.checkedRoot && (this.root[this.checkedAttr] != d || c)) return this.root[this.checkedAttr] = d, this.onChange(b, this.checkedAttr, d), !0 } else throw new TypeError(this.moduleName + "::_setChecked(): invalid item specified.");
                        return !1
                    }, _updateCheckedChild: function (b, a) { this._setChecked(b, a); this.mayHaveChildren(b) && this.getChildren(b, h.hitch(this, function (b) { j.forEach(b, function (b) { this._updateCheckedChild(b, a) }, this) }), this.onError, this._checkedChildrenAttrs) }, _updateCheckedParent: function (b, a) {
                        if (this.checkedStrict && b) {
                            var c = this.getParents(b), d = this.getChecked(b), g; j.forEach(c, function (c) {
                                this.isChildOf(c, b) && (d !== this.getChecked(c) || a) && this.getChildren(c, h.hitch(this, function (a) {
                                    g = this._getCompositeState(a); void 0 !==
                                    g && this._setChecked(c, g)
                                }), this.onError, this._checkedChildrenAttrs)
                            }, this)
                        }
                    }, _validateChildren: function (b, a, c) {
                        var d; this._validating += 1; a = h.isArray(a) ? a : [a]; j.forEach(a, function (a) { this.mayHaveChildren(a) ? this.getChildren(a, h.hitch(this, function (b) { this._validateChildren(a, b, c) }), this.onError, c) : (d = this.getChecked(a)) && "boolean" !== typeof d && (a[this.checkedAttr] = [this._normalizeState(a, d)]) }, this); a = this._getCompositeState(a); d = this.getChecked(b); void 0 !== d && void 0 !== a && this._setChecked(b, a); this._validating -=
                        1; this._validating || (this.store.setValidated(!0), this.onDataValidated())
                    }, getChecked: function (b) {
                        var a; if (!this.excludeChildrenAttrs || !this.isMemberOf(b, this.excludeChildrenAttrs)) {
                            if (this.store.isItem(b)) { if (a = this.store.getValue(b, this.checkedAttr), void 0 === a && this.checkedAll) return this._setChecked(b, this.checkedState), this.checkedState } else if (b === this.root && this.hasFakeRoot) { if (this.checkedRoot) return this.root[this.checkedAttr] } else throw new TypeError(this.moduleName + "::getChecked(): invalid item specified.");
                            return a
                        }
                    }, getEnabled: function (b) { var a = !0; if (this.enabledAttr) if (this.store.isItem(b)) a = this.store.getValue(b, this.enabledAttr); else if (b === this.root) a = b[this.enabledAttr]; else throw new TypeError(this.moduleName + "::getEnabled(): invalid item specified."); return void 0 === a || Boolean(a) }, getItemState: function (b) { return { checked: this.getChecked(b), enabled: this.getEnabled(b) } }, setChecked: function (b, a) { this.checkedStrict ? this._updateCheckedChild(b, a) : this._setChecked(b, a) }, setEnabled: function (b, a) {
                        if (this.enabledAttr) {
                            if (this.store.isItem(b)) return this.store.setValue(b,
                            this.enabledAttr, Boolean(a)); if (b === this.root) return this.root[this.enabledAttr] = Boolean(a); throw new TypeError(this.moduleName + "::setEnabled(): invalid item specified.");
                        }
                    }, validateData: function () {
                        this.checkedStrict ? this.store.isValidated() ? (this.hasFakeRoot && this.getChildren(this.root, h.hitch(this, function (b) { this._updateCheckedParent(b[0], !0) }), this.onError, this._checkedChildrenAttrs), this.onDataValidated()) : this.store.loadStore({
                            onComplete: function () {
                                c("tree-model-setChecked") ? this._validateStore &&
                                this.getRoot(h.hitch(this, function (b) { this.getChildren(b, h.hitch(this, function (a) { this._validateChildren(b, a, this._checkedChildrenAttrs) }), this.onError) }), this.onError) : console.warn(this.moduleName + "::validateData(): store is not write enabled.")
                            }, onError: function () { }, scope: this
                        }) : this.store.setValidated(!1)
                    }, fetchItemByIdentity: function (b) { this.store.fetchItemByIdentity(b) }, getIcon: function (b) { if (this.iconAttr) return this.store.getValue(b, this.iconAttr) }, getIdentity: function (b) { return this.store.getIdentity(b) },
                    getLabel: function (b) { if (this.labelAttr) return this.store.getValue(b, this.labelAttr); this.setLabelAttr(this.getLabelAttr()); return this.store.getLabel(b) }, isItem: function (b) { return this.store.isItem(b) }, isTreeRootChild: function (b) { if (this.root) return this.isChildOf(this.root, b) }, isChildOf: function (b, a) { var c; for (c = 0; c < this.childrenAttrs.length; c++) if (-1 !== j.indexOf(b[this.childrenAttrs[c]], a)) return !0; return !1 }, isMemberOf: function (b, a) {
                        if (this.isItem(b)) {
                            var c = this.getParents(b), d = a ? h.isArray(a) ? a :
                            [a] : [], g = !1, e; j.some(c, function (a) { for (e = 0; e < d.length; e++) if (-1 != j.indexOf(a[d[e]], b)) return g = !0 }, this)
                        } return g
                    }, deleteItem: function (b) { return this.store.deleteItem(b) }, newItem: function (b, a, c, d) { var d = { parent: a, attribute: d ? d : this.childrenAttrs[0] }, g; this._mapIdentifierAttr(b, !1); try { (g = this.store.itemExist(b)) ? this.pasteItem(g, null, a, !0, c) : (g = this.store.newItem(b, d)) && void 0 != c && this.pasteItem(g, a, a, !1, c) } catch (e) { throw Error(this.moduleName + "::newItem(): " + e); } return g }, pasteItem: function (b, a,
                    c, d, g, e) { var f = e ? e : this.childrenAttrs[0], h = this.store; a && j.forEach(this.childrenAttrs, function (c) { h.containsValue(a, c, b) && (d || h.removeReference(b, a, c), f = c) }, this); c && h.addReference(b, c, f, g) }, getLabelAttr: function () { if (!this.labelAttr) { var b = this.store.getLabelAttributes(); b && this.setLabelAttr(b[0]) } return this.labelAttr }, setLabelAttr: function (b) { if (h.isString(b) && b.length) { if (this.labelAttr !== b) { var a = this.labelAttr; this.labelAttr = b; this.onLabelChange(a, b) } return this.labelAttr } }, onChange: function () { },
                    onChildrenChange: function () { }, onDataValidated: function () { }, onDelete: function () { }, onLabelChange: function () { }, onNewItem: function (b, a) { a && this.getChildren(a.item, h.hitch(this, function (b) { this.onChildrenChange(a.item, b) })); this._updateCheckedParent(b, !0) }, onDeleteItem: function (b) { this.onDelete(b) }, onError: function (b) { console.error(this, b) }, onSetItem: function (b, a, c, d) {
                        -1 != j.indexOf(this.childrenAttrs, a) ? this.getChildren(b, h.hitch(this, function (a) {
                            a[0] ? this._updateCheckedParent(a[0], !0) : this._setChecked(b,
                            this.checkedState); this.onChildrenChange(b, a)
                        })) : (a == this.checkedAttr && this._updateCheckedParent(b, !1), this.onChange(b, a, d))
                    }, onStoreLoaded: function () { this.getLabelAttr() }, onRootChange: function () { }, _mapIdentifierAttr: function (b, a) { var c = this.store.getIdentifierAttr(); if (c && !b[c] && this.newItemIdAttr && b[this.newItemIdAttr]) return b[c] = b[this.newItemIdAttr], a && delete b[this.newItemIdAttr], !0; if (this.checkedAll && void 0 === b[this.checkedAttr]) b[this.checkedAttr] = this.checkedState; return !1 }, _diffArrays: function (b,
                    a) { var c = a ? h.isArray(a) ? a : [a] : [], d = b.slice(0), g, e; if (d.length && c.length) for (e = 0; e < c.length; e++) g = j.indexOf(d, c[e]), -1 != g && d.splice(g, 1); return d }, _mixinFetch: function (b) { return b }
                })
            })
        }, "dojo/Stateful": function () {
            define("dojo/Stateful", ["./_base/declare", "./_base/lang", "./_base/array", "dojo/when"], function (j, m, h, f) {
                return j("dojo.Stateful", null, {
                    _attrPairNames: {}, _getAttrNames: function (c) { var e = this._attrPairNames; return e[c] ? e[c] : e[c] = { s: "_" + c + "Setter", g: "_" + c + "Getter" } }, postscript: function (c) {
                        c &&
                        this.set(c)
                    }, _get: function (c, e) { return "function" === typeof this[e.g] ? this[e.g]() : this[c] }, get: function (c) { return this._get(c, this._getAttrNames(c)) }, set: function (c, e) {
                        if ("object" === typeof c) { for (var d in c) c.hasOwnProperty(d) && "_watchCallbacks" != d && this.set(d, c[d]); return this } d = this._getAttrNames(c); var b = this._get(c, d); d = this[d.s]; var a; "function" === typeof d ? a = d.apply(this, Array.prototype.slice.call(arguments, 1)) : this[c] = e; if (this._watchCallbacks) {
                            var k = this; f(a, function () {
                                k._watchCallbacks(c, b,
                                e)
                            })
                        } return this
                    }, _changeAttrValue: function (c, e) { var d = this.get(c); this[c] = e; this._watchCallbacks && this._watchCallbacks(c, d, e); return this }, watch: function (c, e) {
                        var d = this._watchCallbacks; if (!d) var b = this, d = this._watchCallbacks = function (a, c, e, k) { var f = function (d) { if (d) for (var d = d.slice(), k = 0, f = d.length; k < f; k++) d[k].call(b, a, c, e) }; f(d["_" + a]); k || f(d["*"]) }; !e && "function" === typeof c ? (e = c, c = "*") : c = "_" + c; var a = d[c]; "object" !== typeof a && (a = d[c] = []); a.push(e); var k = {}; k.unwatch = k.remove = function () {
                            var b =
                            h.indexOf(a, e); -1 < b && a.splice(b, 1)
                        }; return k
                    }
                })
            })
        }, "cbtree/model/TreeStoreModel": function () { define("cbtree/model/TreeStoreModel", ["dojo/_base/declare", "dojo/_base/lang", "dojo/when", "./_base/CheckedStoreModel"], function (j, m, h, f) { return j([f], { getChildren: function (c, e, d) { this._getChildren(c, function (b) { return this.store.getChildren(b, this.options) }, e, d) }, toString: function () { return "[object TreeStoreModel]" } }) }) }, "url:dijit/templates/Tree.html": '<div class="dijitTree dijitTreeContainer" role="tree">\n\t<div class="dijitInline dijitTreeIndent" style="position: absolute; top: -9999px" data-dojo-attach-point="indentDetector"></div>\n</div>\n',
        "dijit/_CssStateMixin": function () {
            define("dijit/_CssStateMixin", "dojo/_base/array,dojo/_base/declare,dojo/dom,dojo/dom-class,dojo/has,dojo/_base/lang,dojo/on,dojo/ready,dojo/_base/window,./registry".split(","), function (j, m, h, f, c, e, d, b, a, k) {
                m = m("dijit._CssStateMixin", [], {
                    cssStateNodes: {}, hovering: !1, active: !1, _applyAttributes: function () {
                        this.inherited(arguments); j.forEach("disabled,readOnly,checked,selected,focused,state,hovering,active,_opened".split(","), function (a) { this.watch(a, e.hitch(this, "_setStateClass")) },
                        this); for (var a in this.cssStateNodes) this._trackMouseState(this[a], this.cssStateNodes[a]); this._trackMouseState(this.domNode, this.baseClass); this._setStateClass()
                    }, _cssMouseEvent: function (a) { if (!this.disabled) switch (a.type) { case "mouseover": this._set("hovering", !0); this._set("active", this._mouseDown); break; case "mouseout": this._set("hovering", !1); this._set("active", !1); break; case "mousedown": case "touchstart": this._set("active", !0); break; case "mouseup": case "touchend": this._set("active", !1) } }, _setStateClass: function () {
                        function a(c) {
                            b =
                            b.concat(j.map(b, function (a) { return a + c }), "dijit" + c)
                        } var b = this.baseClass.split(" "); this.isLeftToRight() || a("Rtl"); var c = "mixed" == this.checked ? "Mixed" : this.checked ? "Checked" : ""; this.checked && a(c); this.state && a(this.state); this.selected && a("Selected"); this._opened && a("Opened"); this.disabled ? a("Disabled") : this.readOnly ? a("ReadOnly") : this.active ? a("Active") : this.hovering && a("Hover"); this.focused && a("Focused"); var c = this.stateNode || this.domNode, d = {}; j.forEach(c.className.split(" "), function (a) {
                            d[a] =
                            !0
                        }); "_stateClasses" in this && j.forEach(this._stateClasses, function (a) { delete d[a] }); j.forEach(b, function (a) { d[a] = !0 }); var e = [], l; for (l in d) e.push(l); c.className = e.join(" "); this._stateClasses = b
                    }, _subnodeCssMouseEvent: function (a, b, c) {
                        function d(c) { f.toggle(a, b + "Active", c) } if (!this.disabled && !this.readOnly) switch (c.type) {
                            case "mouseover": f.toggle(a, b + "Hover", !0); break; case "mouseout": f.toggle(a, b + "Hover", !1); d(!1); break; case "mousedown": case "touchstart": d(!0); break; case "mouseup": case "touchend": d(!1);
                                break; case "focus": case "focusin": f.toggle(a, b + "Focused", !0); break; case "blur": case "focusout": f.toggle(a, b + "Focused", !1)
                        }
                    }, _trackMouseState: function (a, b) { a._cssState = b }
                }); b(function () {
                    function b(a) { if (!h.isDescendant(a.relatedTarget, a.target)) for (var c = a.target; c && c != a.relatedTarget; c = c.parentNode) if (c._cssState) { var d = k.getEnclosingWidget(c); d && (c == d.domNode ? d._cssMouseEvent(a) : d._subnodeCssMouseEvent(c, c._cssState, a)) } } function g(a) { a.target = a.srcElement; b(a) } var e = a.body(), f = (c("touch") ? [] : ["mouseover",
                    "mouseout"]).concat(["mousedown", "touchstart", "mouseup", "touchend"]); j.forEach(f, function (a) { e.addEventListener ? e.addEventListener(a, b, !0) : e.attachEvent("on" + a, g) }); d(e, "focusin, focusout", function (a) { var b = a.target; b._cssState && !b.getAttribute("widgetId") && k.getEnclosingWidget(b)._subnodeCssMouseEvent(b, b._cssState, a) })
                }); return m
            })
        }, "cbtree/store/handlers/csvHandler": function () {
            define("cbtree/store/handlers/csvHandler", [], function () {
                function j(c) {
                    var e, d; for (e = 0; e < c.length; e++) (d = c[e]) && "string" ==
                    typeof d ? (d = d.trim().replace(/(^[A-Z])|([\s-_]+[A-Z,a-z])/g, function (b, a, c, d) { return d ? b.toUpperCase().replace(/[\s-_]*/, "") : b.toLowerCase() }), /^\d/.test(d) && (c[e] = "$" + d)) : c[e] = "$column" + e; return c
                } function m(c, e) { var d = {}, b; for (b = 0; b < c.length; b++) d[c[b]] = e[b]; return d } function h(c, e) {
                    var d = c.split(e), b = "", a = "", f = [], n, g = 1; for (n = 0; n < d.length; n++) b += a + d[n], b.occuranceOf('"') % 2 ? a = e : (f.push(b), b = a = "", g++); if (b.length) throw d = new TypeError("Unterminated quoted string at substr: " + g + " {" + d[g - 1] + "}"), d.name =
                    "SyntaxError", d; return f
                } function f(c, e) { var d, b; d = !1; b = c.trim(); var a = c; /^".*"$/.test(b) && (a = b.replace(/^"|"$/g, "").replace(/""/g, '"'), b = a.trim(), d = !0); if (d) { if (d = b.match(/^\[(.*)\]$/)) { a = []; if (b = d[1]) { b = h(b, ","); for (d = 0; d < b.length; d++) a.push(f(b[d], e)) } return a } } else { if (/^[+-]?(((0|[1-9][0-9]*)(\.[0-9]+)?)|\.[0-9]+)([eE][-+]?[0-9]+)?$/.test(b)) return parseFloat(b); if ("true" == b || "false" == b) return "true" == b } return e ? b : a } if (!String.prototype.trim) String.prototype.trim = function () {
                    return this.replace(/^\s+|\s+$/g,
                    "")
                }; if (!String.prototype.occuranceOf) String.prototype.occuranceOf = function (c) { return (this.length - this.replace(RegExp(c, "g"), "").length) / c.length }; return function (c) {
                    var e = this; this.delimiter = ","; this.newline = "\r\n"; this.trim = !1; this.fieldNames = null; this.handler = function (c) {
                        var b = [], a = [], k, n; if (400 <= c.status) return c; for (var g = h(c.data || c.text, e.newline), c = 0; c < g.length; c++) if (k = g[c].trim()) {
                            k = h(k, e.delimiter); for (n = 0; n < k.length; n++) b.push(f(k[n], e.trim)); e.fieldNames ? a.push(m(e.fieldNames, b)) : e.fieldNames =
                            j(b); b = []
                        } return a
                    }; this.set = function (c, b) { if (c) { if ("object" == typeof c) for (var a in c) this.set(a, c[a]); this[c] = b } }; c && this.set(c)
                }
            })
        }, "cbtree/store/extensions/Ancestry": function () {
            define("cbtree/store/extensions/Ancestry", ["./_Path", "./_PathList", "../Natural", "../Hierarchy"], function (j, m, h, f) {
                function c(c, b) { var a = c.getIdentity(b), e = [], e = {}; c.indexChildren ? e = (c._indexChild[a] || []).slice(0) : (e[c.parentProperty] = a, e = c.query(e)); return e } function e(c) { for (var b in c) if (c.hasOwnProperty(b)) return !1; return !0 }
                f.extend({
                    analyze: function (c) { var b = 0 < c ? c : 0, a = 0, f = {}; (this._data || []).some(function (c) { this._getParentArray(c).filter(function (a) { return !this.get(a) }, this).forEach(function (b) { var d, e = this.getIdentity(c); (d = f[b]) ? d.push(e) : (d = [e], a++); f[b] = d }, this); return b && b <= a }, this); return !e(f) ? f : null }, getAncestors: function (c, b) {
                        function a(b, c, d) { b.getParents(c).forEach(function (c) { -1 == d.indexOf(c) && (d.push(c), a(b, c, d)) }); return d } if (c = this._anyToObject(c)) {
                            var e = a(this, c, []); !0 === b && (e = e.map(this.getIdentity,
                            this)); return e
                        }
                    }, getDescendants: function (d, b) { function a(b, d, e) { c(b, d).forEach(function (c) { -1 == e.indexOf(c) && (e.push(c), a(b, c, e)) }); return e } if (d = this._anyToObject(d)) { var e = a(this, d, []); !0 === b && (e = e.map(this.getIdentity, this)); return e } }, getPaths: function (c, b) { function a(b, c, d) { b = f.getParents(b); b.length ? b.forEach(function (b) { var g = f.getIdentity(b) + e + c; d = a(b, g, d) }) : (d = d || new m, d.push(new j(c, e))); return d } var c = this._anyToObject(c), e = b || "/", f = this; if (c) return a(c, this.getIdentity(c), null) }, getSiblings: function (d,
                    b) { var d = this._anyToObject(d), a = []; if (d) return this.getParents(d).forEach(function (b) { c(this, b).forEach(function (b) { b != d && -1 == a.indexOf(b) && a.push(b) }) }, this), !0 === b && (a = a.map(this.getIdentity, this)), a }, isAncestorOf: function (c, b) { function a(b, c, d) { d = b.getParents(d); return -1 == d.indexOf(c) ? d.some(function (d) { return a(b, c, d) }, this) : !0 } c = this._anyToObject(c); return (b = this._anyToObject(b)) && c ? a(this, c, b) : !1 }, isChildOf: function (c, b) {
                        b = this._anyToObject(b); c = this._anyToObject(c); if (b && c) {
                            var a = this._getParentArray(c),
                            e = this.getIdentity(b); return -1 != a.indexOf(e)
                        } return !1
                    }, isDescendantOf: function (c, b) { return this.isAncestorOf(b, c) }, isSiblingOf: function (c, b) { var b = this._anyToObject(b), c = this._anyToObject(c), a = this.getSiblings(b); return a ? -1 != a.indexOf(c) : !1 }
                }); h.extend({ isBefore: function (c, b) { var a = this._anyToObject(c), e = this._anyToObject(b); return a && e ? (a = this._data.indexOf(a), e = this._data.indexOf(e), a < e) : !1 } }); return !0
            })
        }, "dojo/string": function () {
            define("dojo/string", ["./_base/kernel", "./_base/lang"], function (j,
            m) {
                var h = {}; m.setObject("dojo.string", h); h.rep = function (f, c) { if (0 >= c || !f) return ""; for (var e = []; ;) { c & 1 && e.push(f); if (!(c >>= 1)) break; f += f } return e.join("") }; h.pad = function (f, c, e, d) { e || (e = "0"); f = "" + f; c = h.rep(e, Math.ceil((c - f.length) / e.length)); return d ? f + c : c + f }; h.substitute = function (f, c, e, d) { d = d || j.global; e = e ? m.hitch(d, e) : function (b) { return b }; return f.replace(/\$\{([^\s\:\}]+)(?:\:([^\s\:\}]+))?\}/g, function (b, a, f) { b = m.getObject(a, !1, c); f && (b = m.getObject(f, !1, d).call(d, b, a)); return e(b, a).toString() }) };
                h.trim = String.prototype.trim ? m.trim : function (f) { for (var f = f.replace(/^\s+/, ""), c = f.length - 1; 0 <= c; c--) if (/\S/.test(f.charAt(c))) { f = f.substring(0, c + 1); break } return f }; return h
            })
        }, "dijit/form/Button": function () {
            require({ cache: { "url:dijit/form/templates/Button.html": '<span class="dijit dijitReset dijitInline" role="presentation"\n\t><span class="dijitReset dijitInline dijitButtonNode"\n\t\tdata-dojo-attach-event="ondijitclick:_onClick" role="presentation"\n\t\t><span class="dijitReset dijitStretch dijitButtonContents"\n\t\t\tdata-dojo-attach-point="titleNode,focusNode"\n\t\t\trole="button" aria-labelledby="${id}_label"\n\t\t\t><span class="dijitReset dijitInline dijitIcon" data-dojo-attach-point="iconNode"></span\n\t\t\t><span class="dijitReset dijitToggleButtonIconChar">&#x25CF;</span\n\t\t\t><span class="dijitReset dijitInline dijitButtonText"\n\t\t\t\tid="${id}_label"\n\t\t\t\tdata-dojo-attach-point="containerNode"\n\t\t\t></span\n\t\t></span\n\t></span\n\t><input ${!nameAttrSetting} type="${type}" value="${value}" class="dijitOffScreen"\n\t\ttabIndex="-1" role="presentation" data-dojo-attach-point="valueNode"\n/></span>\n' } });
            define("dijit/form/Button", "require,dojo/_base/declare,dojo/dom-class,dojo/has,dojo/_base/kernel,dojo/_base/lang,dojo/ready,./_FormWidget,./_ButtonMixin,dojo/text!./templates/Button.html".split(","), function (j, m, h, f, c, e, d, b, a, k) {
                f("dijit-legacy-requires") && d(0, function () { j(["dijit/form/DropDownButton", "dijit/form/ComboButton", "dijit/form/ToggleButton"]) }); return m("dijit.form.Button", [b, a], {
                    showLabel: !0, iconClass: "dijitNoIcon", _setIconClassAttr: { node: "iconNode", type: "class" }, baseClass: "dijitButton",
                    templateString: k, _setValueAttr: "valueNode", _onClick: function (a) { var b = this.inherited(arguments); b && this.valueNode && (this.valueNode.click(), a.preventDefault(), a.stopPropagation()); return b }, _fillContent: function (a) { if (a && (!this.params || !("label" in this.params))) if (a = e.trim(a.innerHTML)) this.label = a }, _setShowLabelAttr: function (a) { this.containerNode && h.toggle(this.containerNode, "dijitDisplayNone", !a); this._set("showLabel", a) }, setLabel: function (a) {
                        c.deprecated("dijit.form.Button.setLabel() is deprecated.  Use set('label', ...) instead.",
                        "", "2.0"); this.set("label", a)
                    }, _setLabelAttr: function (a) { this.inherited(arguments); if (!this.showLabel && !("title" in this.params)) this.titleNode.title = e.trim(this.containerNode.innerText || this.containerNode.textContent || "") }
                })
            })
        }, "dijit/registry": function () {
            define("dijit/registry", ["dojo/_base/array", "dojo/sniff", "dojo/_base/unload", "dojo/_base/window", "./main"], function (j, m, h, f, c) {
                var e = {}, d = {}, b = {
                    length: 0, add: function (a) {
                        if (d[a.id]) throw Error("Tried to register widget with id==" + a.id + " but that id is already registered");
                        d[a.id] = a; this.length++
                    }, remove: function (a) { d[a] && (delete d[a], this.length--) }, byId: function (a) { return "string" == typeof a ? d[a] : a }, byNode: function (a) { return d[a.getAttribute("widgetId")] }, toArray: function () { var a = [], b; for (b in d) a.push(d[b]); return a }, getUniqueId: function (a) { var b; do b = a + "_" + (a in e ? ++e[a] : e[a] = 0); while (d[b]); return "dijit" == c._scopeName ? b : c._scopeName + "_" + b }, findWidgets: function (a, b) {
                        function c(a) {
                            for (a = a.firstChild; a; a = a.nextSibling) if (1 == a.nodeType) {
                                var e = a.getAttribute("widgetId");
                                e ? (e = d[e]) && g.push(e) : a !== b && c(a)
                            }
                        } var g = []; c(a); return g
                    }, _destroyAll: function () { c._curFocus = null; c._prevFocus = null; c._activeStack = []; j.forEach(b.findWidgets(f.body()), function (a) { a._destroyed || (a.destroyRecursive ? a.destroyRecursive() : a.destroy && a.destroy()) }) }, getEnclosingWidget: function (a) { for (; a;) { var b = a.getAttribute && a.getAttribute("widgetId"); if (b) return d[b]; a = a.parentNode } return null }, _hash: d
                }; return c.registry = b
            })
        }, "dijit/Destroyable": function () {
            define("dijit/Destroyable", ["dojo/_base/array",
            "dojo/aspect", "dojo/_base/declare"], function (j, m, h) { return h("dijit.Destroyable", null, { destroy: function () { this._destroyed = !0 }, own: function () { j.forEach(arguments, function (f) { var c = "destroyRecursive" in f ? "destroyRecursive" : "destroy" in f ? "destroy" : "remove", e = m.before(this, "destroy", function (d) { f[c](d) }); m.after(f, c, function () { e.remove() }, !0) }, this); return arguments } }) })
        }, "dijit/_base/manager": function () {
            define("dijit/_base/manager", ["dojo/_base/array", "dojo/_base/config", "dojo/_base/lang", "../registry",
            "../main"], function (j, m, h, f, c) { var e = {}; j.forEach("byId,getUniqueId,findWidgets,_destroyAll,byNode,getEnclosingWidget".split(","), function (c) { e[c] = f[c] }); h.mixin(e, { defaultDuration: m.defaultDuration || 200 }); h.mixin(c, e); return c })
        }, "dojo/request": function () { define("dojo/request", ["./request/default!"], function (j) { return j }) }, "cbtree/extensions/TreeStyling": function () {
            define("cbtree/extensions/TreeStyling", "module,dojo/_base/lang,dojo/aspect,dojo/dom-class,dojo/dom-prop,dojo/dom-style,dijit/Tree,../errors/createError!../errors/CBTErrors.json".split(","),
            function (j, m, h, f, c, e, d, b) {
                function a(a) { for (var b in a) if (a.hasOwnProperty(b)) return !1; return !0 } function k(a) { return a && "[object Object]" == Object.prototype.toString.call(a) } var n = b(j.id); d._TreeNode.extend({
                    _applyClassAndStyle: function (b, d) {
                        var k, h, l, n, j; l = d + "Class"; n = d + "Style"; j = d + "Node"; k = c.get(this[j], "className"); h = this.tree.get(l, this.item, this.isExpanded, this) || k; k !== h && (f.replace(this[j], h, k || ""), this[l] = h); k = a(this[n]) ? this.tree.get(n, this.item, this.isExpanded) || {} : this[n]; e.set(this[j], k);
                        this[n] = k
                    }, _set_icon_Attr: function (a) { if (a.iconClass) this._set_iconClass_Attr(a.iconClass), this.icon = a }, _set_iconClass_Attr: function (a) { a && a !== this.iconClass && (f.replace(this.iconNode, a, this.iconClass || ""), this._applyClassAndStyle(this.item, "icon")) }, _set_styling_Attr: function () { this._updateItemClasses(this.item) }, _setIconStyleAttr: function (a) { this.iconStyle = a; this._applyClassAndStyle(this.item, "icon") }, _setLabelStyleAttr: function (a) { this.labelStyle = a; this._applyClassAndStyle(this.item, "label") },
                    _setRowStyleAttr: function (a) { this.rowStyle = a; this._applyClassAndStyle(this.item, "row") }
                }); d.extend({
                    _hasStyling: !0, _icon: null, _iconAttr: null, _itemStyleMap: {}, _itemAttr: ["icon", "label", "row"], _typeAttr: ["Class", "Style"], _dijitIconClasses: ["dijitFolderOpened", "dijitFolderClosed", "dijitLeaf"], iconClass: "", _getBaseClass: function (a) {
                        var a = a ? c.get(a.iconNode, "className") : "", b, d; b = ""; a = m.trim(a).split(/\s+/); if (a[0]) {
                            for (d = 0; d < this._dijitIconClasses.length; d++) b = a.indexOf(this._dijitIconClasses[d]), -1 !=
                            b && a.splice(b, 1); b = a.toString()
                        } return b.replace(/,/g, " ")
                    }, _getClassOrStyle: function (a, b, c) { if (-1 != this._itemAttr.indexOf(b) && -1 != this._typeAttr.indexOf(c)) return this._getItemStyling(a)[b][b + c]; throw new n("InvalidProperty", "getClassOrStyle"); }, _getHasTreeSytlingAttr: function () { return this._hasStyling }, _getItemStyling: function (a) {
                        this._connected || this._connectModel(); if (m.isObject(a)) {
                            var a = a ? this.model.getIdentity(a) : "__DEFAULT", b = this._itemStyleMap[a]; if (!b) {
                                b = this._getTreeStyling(); if (this._icon) b.icon =
                                this._icon; this._itemStyleMap[a] = b
                            } return b
                        } throw new n("InvalidType", "getItemStyling");
                    }, _getTreeStyling: function () { var b = this._itemStyleMap.__DEFAULT || {}; if (a(b)) this._itemAttr.forEach(function (a) { b[a] = this._initStyleElement(a) }, this), b.defStyle = !0; return m.clone(b) }, _initStyleElement: function (a) { var b = {}; this._typeAttr.forEach(function (c) { b[a + c] = null }, this); return b }, _setAllItems: function (a, b, c, d) {
                        var a = a ? a instanceof Array ? a : this._object2Array(a) : [], l; a.unshift(null); for (l in this._itemStyleMap) a[0] =
                        this._itemStyleMap[l], b.apply(d || this, Array.prototype.slice.call(a, 0)); c && c.apply(d || this, Array.prototype.slice.call(a, 1))
                    }, _setAttrClass: function (a, b, c, d) {
                        if ("string" === typeof c) {
                            if (-1 != this._itemAttr.indexOf(b)) { var l = m.trim(c).split(/\s+/); if (l[0]) { if (a) { var e = this._getItemStyling(a); e[b][b + "Class"] = c; e[b].baseClass = l[0]; delete e.defStyle; d && d.call(this, a, b, c, l[0]); return e[b] } this._setAllItems([b, c, l[0]], function (a, b, c, d) { a[b][b + "Class"] = c; a[b].baseClass = d; delete a.defStyle }, d, this) } return null } throw new n("InvalidProperty",
                            "setItemClass");
                        } throw new n("InavlidType", "setItemClass");
                    }, _setAttrClassSet: function (a, b, c) { a ? this._setAttrClass(a, b, c, function (a, b, c) { this._setStyling(a, "_styling_", c) }) : this._setAttrClass(null, b, c, function (a, b) { this._setTreeNodes(this.rootNode, { _styling_: b }) }) }, _setAttrStyle: function (a, b, c, d) {
                        if (m.isObject(c)) {
                            if (-1 != this._itemAttr.indexOf(b)) {
                                if (a) { var e = this._getItemStyling(a); e[b][b + "Style"] = c; d && d.call(this, a, b, c); return e[b] } this._setAllItems([b, c], function (a, b, c) { a[b][b + "Style"] = c }, d, this);
                                return null
                            } throw new n("InvalidProperty", "setItemStyle");
                        } throw new n("InvalidType", "setItemStyle");
                    }, _setAttrStyleSet: function (a, b, c) { var d = {}; this._connected || this._connectModel(); a ? this._setAttrStyle(a, b, c, function (a, b, c) { this._setStyling(a, b + "Style", c) }) : this._setAttrStyle(null, b, c, function (a, b) { d[a + "Style"] = b; this._setTreeNodes(this.rootNode, d) }) }, _setStyling: function (a, b, c) { var a = this._itemNodesMap[this.model.getIdentity(a)], d = {}; a && (d[b] = c, a.forEach(function (a) { a.set(d) }, this)) }, _getIconAttr: function (a) {
                        var b =
                        this._getItemStyling(a); if (b.defStyle && this._iconAttr) { if (b = this.model.getIcon(a)) return b = this._setIconAttr(b, a) } else return b.icon
                    }, _getIconClassAttr: function (a, b, c) { return this.getIconClass(a, b, c) }, _getIconStyleAttr: function (a, b) { return this.getIconStyle(a, b) }, _getLabelClassAttr: function (a, b, c) { return this.getLabelClass(a, b, c) }, _getLabelStyleAttr: function (a, b) { return this.getLabelStyle(a, b) }, _getRowClassAttr: function (a, b, c) { return this.getRowClass(a, b, c) }, _getRowStyleAttr: function (a, b) {
                        return this.getRowStyle(a,
                        b)
                    }, _setIconAttr: function (a, b) { var c = this._icon2Object(a); if (c) if (b) { var d = this._getItemStyling(b); d.icon = c; delete d.defStyle; this._setStyling(b, "_icon_", c) } else this._setAllItems([c], function (a, b) { a.icon = b; delete a.defStyle }, function (a) { this._setTreeNodes(this.rootNode, { _icon_: a }) }, this), this._icon = c; return c }, _setIconClassAttr: function (a, b) { return this._setAttrClassSet(b, "icon", a) }, _setIconStyleAttr: function (a, b) { return this._setAttrStyleSet(b, "icon", a) }, _setLabelClassAttr: function (a, b) {
                        return this._setAttrClassSet(b,
                        "label", a)
                    }, _setLabelStyleAttr: function (a, b) { return this._setAttrStyleSet(b, "label", a) }, _setRowClassAttr: function (a, b) { return this._setAttrClassSet(b, "row", a) }, _setRowStyleAttr: function (a, b) { return this._setAttrStyleSet(b, "row", a) }, _setValueToIconMapAttr: function (b) {
                        if (k(b)) {
                            var c, d, e = {}; for (c in b) if (k(b[c])) if (e = b[c], a(e)) e["*"] = null, b[c] = e; else for (d in e) "*" == e[d] && (e[d] = null); else if (b[c] instanceof Array) b[c].length ? b[c].forEach(function (a) { e[a] = a }, this) : e["*"] = null, b[c] = e; else if ("*" != b[c]) throw new n("InvalidType",
                            "_setValueToIconMap", "invalid property value type");
                        } else b = null; return this._valueToIconMap = b
                    }, _modelIconUpdate: function (a, b, c) { a = this._getItemStyling(a); if (c = this._icon2Object(c)) a.icon = c, delete a.defStyle; return c }, _valueToIcon: function (a) {
                        if (a && this._valueToIconMap) {
                            var b, c, d, e; for (b in this._valueToIconMap) if (c = this._valueToIconMap[b], d = m.getObject(b, !1, a)) if (d in c ? e = c[d] || d : "*" in c && (e = c["*"] || d), e) {
                                switch (typeof e) {
                                    case "string": case "object": break; case "function": if ((e = e.call(this, a, b, d)) &&
                                    !k(e) && "string" != typeof e) throw new n("InvalidResponse", "_valueToIcon"); break; default: e = null
                                } if (e) return e = this._icon2Object(e), e = this._wcToValue(e, d)
                            }
                        }
                    }, _wcToValue: function (a, b) { if (!k(a)) return a && "function" == typeof a.replace ? a.replace(/\*/g, b) : a; var c, d = a.constructor(); for (c in a) d[c] = this._wcToValue(a[c], b); return d }, getIconClass: function (a, b, c) {
                        var d, e = a, f, k; if (!e && this.rootNode) e = this.rootNode.item, c = this.rootNode, b = this.rootNode.isExpanded; a = e ? this.model.mayHaveChildren(e) : !1; this._valueToIconMap &&
                        (d = this._valueToIcon(e)); if (!d || !d.iconClass) d = this._getItemStyling(e).icon; if (!d || !d.iconClass) return b = !e || a ? b ? "dijitFolderOpened" : "dijitFolderClosed" : "dijitLeaf", (f = this._getBaseClass(c)) ? f + " " + b : b; e = d.iconClass; f = d.baseClass; k = d.indent; if (d.fixed) e += " " + d.fixed; else if (c) { b = f + (a ? b ? "Expanded" : "Collapsed" : "Terminal"); if (void 0 !== k && !1 !== k && (!0 === k || k >= c.indent)) b += " " + b + "_" + c.indent; e += " " + b } return e
                    }, getIconStyle: function (a) {
                        var b = this._getClassOrStyle(a, "icon", "Style"); return b = (a = this._valueToIconMap ?
                        this._valueToIcon(a) : null) && a.iconStyle || b
                    }, getLabelClass: function (a) { return this._getClassOrStyle(a, "label", "Class") }, getLabelStyle: function (a) { return this._getClassOrStyle(a, "label", "Style") }, getRowClass: function (a) { return this._getClassOrStyle(a, "row", "Class") }, getRowStyle: function (a) { return this._getClassOrStyle(a, "row", "Style") }, get: function (a) { var b = this[this._getAttrNames(a).g]; return "function" === typeof b ? b.apply(this, Array.prototype.slice.call(arguments, 1)) : this[a] }, _connectModel: function () {
                        var a =
                        this.model; this._connected = !0; this._itemStyleMap = {}; this._getItemStyling(null); if (a) {
                            if (a.iconAttr) !a.getIcon || "function" != typeof a.getIcon ? (console.warn(new n("MethodMissing", "_connectModel", "model property 'iconAttr' set but method getIcon() is missing.")), this._iconAttr = null) : this._iconAttr = this.model.iconAttr; this.mapEventToAttr && "function" === typeof this.mapEventToAttr && this.mapEventToAttr(null, this._iconAttr, "_icon_", this._modelIconUpdate); h.after(this.model, "onDelete", m.hitch(this, "_onStyleDelete"),
                            !0)
                        }
                    }, _icon2Object: function (a) {
                        var b, c, d; if (a) {
                            if (k(a)) { if (a.iconClass && (c = m.trim(a.iconClass).split(/\s+/), c[0])) { d = this._initStyleElement("icon"); d.baseClass = c[0]; d.indent = !0; for (b in a) d[b] = a[b]; return d } throw new n("ParameterMissing", "_icon2Object", "required property 'iconClass' is missing or empty"); } if ("string" === typeof a && a.length) { if (c = m.trim(a).split(/\s+/), c[0]) return d = this._initStyleElement("icon"), d.baseClass = c[0], d.iconClass = a, d.indent = !0, d } else throw new n("InvalidType", "_icon2Object",
                            "icon must be an object or string");
                        } return null
                    }, _object2Array: function (a) { var b = [], c; if (!(a instanceof Array)) { if (m.isObject(a)) for (c in a) b.push(a[c]); else b.push(a); return b } return a }, _onStyleDelete: function (a) { delete this._itemStyleMap[this.model.getIdentity(a)] }, _setTreeNodes: function (a, b) { a && m.isObject(b) && (a.set(b), a.getChildren().forEach(function (a) { this._setTreeNodes(a, b) }, this)) }
                })
            })
        }, "dijit/a11y": function () {
            define("dijit/a11y", "dojo/_base/array,dojo/_base/config,dojo/_base/declare,dojo/dom,dojo/dom-attr,dojo/dom-style,dojo/sniff,./main".split(","),
            function (j, m, h, f, c, e, d, b) {
                var a = b._isElementShown = function (a) { var b = e.get(a); return "hidden" != b.visibility && "collapsed" != b.visibility && "none" != b.display && "hidden" != c.get(a, "type") }; b.hasDefaultTabStop = function (a) {
                    switch (a.nodeName.toLowerCase()) {
                        case "a": return c.has(a, "href"); case "area": case "button": case "input": case "object": case "select": case "textarea": return !0; case "iframe": var b; try { var d = a.contentDocument; if ("designMode" in d && "on" == d.designMode) return !0; b = d.body } catch (e) { try { b = a.contentWindow.document.body } catch (f) { return !1 } } return b &&
                        ("true" == b.contentEditable || b.firstChild && "true" == b.firstChild.contentEditable); default: return "true" == a.contentEditable
                    }
                }; var k = b.isTabNavigable = function (a) { return c.get(a, "disabled") ? !1 : c.has(a, "tabIndex") ? 0 <= c.get(a, "tabIndex") : b.hasDefaultTabStop(a) }; b._getTabNavigable = function (b) {
                    function e(a) { return a && "input" == a.tagName.toLowerCase() && a.type && "radio" == a.type.toLowerCase() && a.name && a.name.toLowerCase() } var f, h, j, l, r, m, t = {}, x = function (b) {
                        for (b = b.firstChild; b; b = b.nextSibling) if (!(1 != b.nodeType ||
                        d("ie") && "HTML" !== b.scopeName || !a(b))) { if (k(b)) { var n = +c.get(b, "tabIndex"); if (!c.has(b, "tabIndex") || 0 == n) f || (f = b), h = b; else if (0 < n) { if (!j || n < l) l = n, j = b; if (!r || n >= m) m = n, r = b } n = e(b); c.get(b, "checked") && n && (t[n] = b) } "SELECT" != b.nodeName.toUpperCase() && x(b) }
                    }; a(b) && x(b); return { first: t[e(f)] || f, last: t[e(h)] || h, lowest: t[e(j)] || j, highest: t[e(r)] || r }
                }; b.getFirstInTabbingOrder = function (a, c) { var d = b._getTabNavigable(f.byId(a, c)); return d.lowest ? d.lowest : d.first }; b.getLastInTabbingOrder = function (a, c) {
                    var d = b._getTabNavigable(f.byId(a,
                    c)); return d.last ? d.last : d.highest
                }; return { hasDefaultTabStop: b.hasDefaultTabStop, isTabNavigable: b.isTabNavigable, _getTabNavigable: b._getTabNavigable, getFirstInTabbingOrder: b.getFirstInTabbingOrder, getLastInTabbingOrder: b.getLastInTabbingOrder }
            })
        }, "url:dijit/form/templates/Button.html": '<span class="dijit dijitReset dijitInline" role="presentation"\n\t><span class="dijitReset dijitInline dijitButtonNode"\n\t\tdata-dojo-attach-event="ondijitclick:_onClick" role="presentation"\n\t\t><span class="dijitReset dijitStretch dijitButtonContents"\n\t\t\tdata-dojo-attach-point="titleNode,focusNode"\n\t\t\trole="button" aria-labelledby="${id}_label"\n\t\t\t><span class="dijitReset dijitInline dijitIcon" data-dojo-attach-point="iconNode"></span\n\t\t\t><span class="dijitReset dijitToggleButtonIconChar">&#x25CF;</span\n\t\t\t><span class="dijitReset dijitInline dijitButtonText"\n\t\t\t\tid="${id}_label"\n\t\t\t\tdata-dojo-attach-point="containerNode"\n\t\t\t></span\n\t\t></span\n\t></span\n\t><input ${!nameAttrSetting} type="${type}" value="${value}" class="dijitOffScreen"\n\t\ttabIndex="-1" role="presentation" data-dojo-attach-point="valueNode"\n/></span>\n',
        "dojo/DeferredList": function () {
            define("dojo/DeferredList", ["./_base/kernel", "./_base/Deferred", "./_base/array"], function (j, m, h) {
                j.DeferredList = function (f, c, e, d) { var b = []; m.call(this); var a = this; 0 === f.length && !c && this.resolve([0, []]); var k = 0; h.forEach(f, function (h, g) { function j(c, d) { b[g] = [c, d]; k++; k === f.length && a.resolve(b) } h.then(function (b) { c ? a.resolve([g, b]) : j(!0, b) }, function (b) { e ? a.reject(b) : j(!1, b); if (d) return null; throw b; }) }) }; j.DeferredList.prototype = new m; j.DeferredList.prototype.gatherResults =
                function (f) { f = new j.DeferredList(f, !1, !0, !1); f.addCallback(function (c) { var e = []; h.forEach(c, function (c) { e.push(c[1]) }); return e }); return f }; return j.DeferredList
            })
        }, "dijit/form/CheckBox": function () {
            require({ cache: { "url:dijit/form/templates/CheckBox.html": '<div class="dijit dijitReset dijitInline" role="presentation"\n\t><input\n\t \t${!nameAttrSetting} type="${type}" ${checkedAttrSetting}\n\t\tclass="dijitReset dijitCheckBoxInput"\n\t\tdata-dojo-attach-point="focusNode"\n\t \tdata-dojo-attach-event="onclick:_onClick"\n/></div>\n' } });
            define("dijit/form/CheckBox", "require,dojo/_base/declare,dojo/dom-attr,dojo/has,dojo/query,dojo/ready,./ToggleButton,./_CheckBoxMixin,dojo/text!./templates/CheckBox.html,dojo/NodeList-dom".split(","), function (j, m, h, f, c, e, d, b, a) {
                f("dijit-legacy-requires") && e(0, function () { j(["dijit/form/RadioButton"]) }); return m("dijit.form.CheckBox", [d, b], {
                    templateString: a, baseClass: "dijitCheckBox", _setValueAttr: function (a, b) {
                        "string" == typeof a && (this.inherited(arguments), a = !0); this._created && this.set("checked", a,
                        b)
                    }, _getValueAttr: function () { return this.checked ? this.value : !1 }, _setIconClassAttr: null, postMixInProperties: function () { this.inherited(arguments); this.checkedAttrSetting = this.checked ? "checked" : "" }, _fillContent: function () { }, _onFocus: function () { this.id && c("label[for='" + this.id + "']").addClass("dijitFocusedLabel"); this.inherited(arguments) }, _onBlur: function () { this.id && c("label[for='" + this.id + "']").removeClass("dijitFocusedLabel"); this.inherited(arguments) }
                })
            })
        }, "cbtree/model/_base/Parents": function () {
            define("cbtree/model/_base/Parents",
            ["../../util/shim/Array"], function () {
                return function (j, m) {
                    function h(f) { Array.prototype.splice.call(this, 0, this.length); f instanceof Array ? f.forEach(function (c, e) { this[e] = c; this.length++ }, this) : (h.call(this, [f]), this.multiple = !1, this.length = 1) } m = m || "parent"; this.multiple = !0; this.length = 0; this.input = null; this.add = function (f, c) { if (void 0 != f) return !this.contains(f) ? (c || this.multiple ? (this[this.length++] = f, this.multiple = 1 < this.length) : this.set(f), !0) : !1 }; this.contains = function (f) {
                        return Array.prototype.some.call(this,
                        function (c) { return c === f })
                    }; this.forEach = function (f, c) { Array.prototype.forEach.call(this, f, c) }; this.remove = function (f) { return Array.prototype.some.call(this, function (c, e) { if (c === f) return Array.prototype.splice.call(this, e, 1), !0 }, this) }; this.set = function (f) { Array.prototype.splice.call(this, 0, this.length); this[0] = f; this.length = 1; return !0 }; this.toValue = function () { return this.multiple ? Array.prototype.slice.call(this) : this[0] }; if (void 0 != j) {
                        if (j instanceof Array) this.input = j; else if ("object" === typeof j) this.input =
                        j[m]; else if ("string" === typeof j) { if (this.input = j.split(/\s*,\s*/), 1 == this.input.length) this.input = j } else this.input = j; void 0 != this.input ? h.call(this, this.input) : this.multiple = !1
                    }
                }
            })
        }, "dojo/regexp": function () {
            define("dojo/regexp", ["./_base/kernel", "./_base/lang"], function (j, m) {
                var h = {}; m.setObject("dojo.regexp", h); h.escapeString = function (f, c) { return f.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, function (e) { return c && -1 != c.indexOf(e) ? e : "\\" + e }) }; h.buildGroupRE = function (f, c, e) {
                    if (!(f instanceof Array)) return c(f);
                    for (var d = [], b = 0; b < f.length; b++) d.push(c(f[b])); return h.group(d.join("|"), e)
                }; h.group = function (f, c) { return "(" + (c ? "?:" : "") + f + ")" }; return h
            })
        }, "cbtree/model/StoreModel-EXT": function () {
            define("cbtree/model/StoreModel-EXT", "module,dojo/_base/lang,dojo/when,./_base/BaseStoreModel,./_base/Parents,../errors/createError!../errors/CBTErrors.json,../util/QueryEngine".split(","), function (j, m, h, f, c, e) {
                var d = e(j.id); f.extend({
                    _checkOrUncheck: function (b, a, c, d) {
                        var e = 0, f = 0; this.fetchItemsWithChecked(b, function (b) {
                            b.forEach(function (b) {
                                b[this.checkedAttr] !=
                                a && (this.setChecked(b, a), f += 1); e += 1
                            }, this); c && c.call(d || this, e, f)
                        }, this, this.checkedStrict ? !0 : !1)
                    }, fetchItem: function (b, a, c) { b = this._anyToQuery(b, null); c = c || this; b && a && h(this.store.query(b), function (b) { b = Array.prototype.slice.call(b); a.call(c, b.length ? b[0] : void 0) }) }, fetchItemsWithChecked: function (b, a, c, e) {
                        var b = this._anyToQuery(b, null), f = [], e = void 0 !== e ? !!e : !0, j = this, c = c || this; if ("[object Object]" == Object.prototype.toString.call(b)) h(this.store.query(b, { cacheOnly: e }), function (b) {
                            b.forEach(function (a) {
                                j.checkedAttr in
                                a ? f.push(a) : j.checkedAll && (j.setChecked(a, this.checkedState), f.push(a))
                            }); a && a.call(c, f)
                        }, this.onError); else throw new d("InvalidObject", "fetchItemsWithChecked", "query must be of type object");
                    }, isRootItem: function (b) { return this.isChildOf(b, this.root) }, check: function (b, a, c, d) { this._checkOrUncheck(b, !0, a, c, d) }, uncheck: function (b, a, c, d) { this._checkOrUncheck(b, !1, a, c, d) }, _changeParents: function (b, a, e) {
                        var f = this; if (b && a) {
                            var g = this.getIdentity(a), j = this.getIdentity(b), m = this._forest && this.root.id ==
                            j; j && g && !m && h(this.store.get(j), function (m) {
                                if (m) { var l = f.isChildOf(m, f.root), r = new c(m, f.parentProperty); if (f._forest && f.root.id == g) { if (r.multiple || (m[f.parentProperty] = void 0, this.store.put(m)), !l && "attach" == e || l && "detach" == e) m = f._updateChildrenCache(e, a, b), h(m, function () { f.onRootChange(b, e); f._childrenChanged(f.root) }) } else r[e](g) && (m[f.parentProperty] = r.toValue(), j = f.store.put(m), f._monitored || h(j, function () { f._childrenChanged(a) })) } else throw new d("InvalidObject", "addParent", "Item [" + j + "] is not a valid store item");
                            })
                        }
                    }, addParent: function (b, a) { if ("string" == typeof a) { var c = this; h(this.store.get(a), function (a) { c._changeParents(b, a, "attach") }) } else this._changeParents(b, a, "attach") }, removeParent: function (b, a) { if ("string" == typeof a) { var c = this; h(this.store.get(a), function (a) { c._changeParents(b, a, "detach") }) } else this._changeParents(b, a, "detach") }, _anyToQuery: function (b, a) {
                        var c = this.store.idProperty; if (c) {
                            var d = a || c, e = {}; "string" == typeof b ? e[c] = b : b && "[object Object]" == Object.prototype.toString.call(b) ? (m.mixin(e,
                            b), d in b && (e[c] = b[d])) : e[c] = /.*/; return e
                        } return null
                    }
                }); return !0
            })
        }, "cbtree/util/IE8_Event": function () {
            define("cbtree/util/IE8_Event", function () {
                return function (j, m, h, f) {
                    this.currentTarget = this.target = j; this.eventPhase = 2; this.bubbles = !(!h || !h.bubbles); this.cancelable = !(!h || !h.cancelable); this.defaultPrevented = this.isTrusted = !1; this.ieEventObject = f; this.type = m; this.stopPropagation = this.stopImmediatePropagation = function () { f.cancelBubble = !0 }; this.preventDefault = function () {
                        f.returnValue = !1; this.defaultPrevented =
                        !0
                    }
                }
            })
        }, "dijit/form/_CheckBoxMixin": function () {
            define("dijit/form/_CheckBoxMixin", ["dojo/_base/declare", "dojo/dom-attr", "dojo/_base/event"], function (j, m, h) {
                return j("dijit.form._CheckBoxMixin", null, {
                    type: "checkbox", value: "on", readOnly: !1, _aria_attr: "aria-checked", _setReadOnlyAttr: function (f) { this._set("readOnly", f); m.set(this.focusNode, "readOnly", f); this.focusNode.setAttribute("aria-readonly", f) }, _setLabelAttr: void 0, _getSubmitValue: function (f) { return !f && 0 !== f ? "on" : f }, _setValueAttr: function (f) {
                        f =
                        this._getSubmitValue(f); this._set("value", f); m.set(this.focusNode, "value", f)
                    }, reset: function () { this.inherited(arguments); this._set("value", this.params.value || "on"); m.set(this.focusNode, "value", this.value) }, _onClick: function (f) { return this.readOnly ? (h.stop(f), !1) : this.inherited(arguments) }
                })
            })
        }, "dijit/_Widget": function () {
            define("dijit/_Widget", "dojo/aspect,dojo/_base/config,dojo/_base/connect,dojo/_base/declare,dojo/has,dojo/_base/kernel,dojo/_base/lang,dojo/query,dojo/ready,./registry,./_WidgetBase,./_OnDijitClickMixin,./_FocusMixin,dojo/uacss,./hccss".split(","),
            function (j, m, h, f, c, e, d, b, a, k, n, g, p) {
                function q() { } function o(a) { return function (b, c, e, f) { return b && "string" == typeof c && b[c] == q ? b.on(c.substring(2).toLowerCase(), d.hitch(e, f)) : a.apply(h, arguments) } } j.around(h, "connect", o); e.connect && j.around(e, "connect", o); j = f("dijit._Widget", [n, g, p], {
                    onClick: q, onDblClick: q, onKeyDown: q, onKeyPress: q, onKeyUp: q, onMouseDown: q, onMouseMove: q, onMouseOut: q, onMouseOver: q, onMouseLeave: q, onMouseEnter: q, onMouseUp: q, constructor: function (a) {
                        this._toConnect = {}; for (var b in a) this[b] ===
                        q && (this._toConnect[b.replace(/^on/, "").toLowerCase()] = a[b], delete a[b])
                    }, postCreate: function () { this.inherited(arguments); for (var a in this._toConnect) this.on(a, this._toConnect[a]); delete this._toConnect }, on: function (a, b) { return this[this._onMap(a)] === q ? h.connect(this.domNode, a.toLowerCase(), this, b) : this.inherited(arguments) }, _setFocusedAttr: function (a) { this._focused = a; this._set("focused", a) }, setAttribute: function (a, b) {
                        e.deprecated(this.declaredClass + "::setAttribute(attr, value) is deprecated. Use set() instead.",
                        "", "2.0"); this.set(a, b)
                    }, attr: function (a, b) { if (m.isDebug) { var c = arguments.callee._ach || (arguments.callee._ach = {}), d = (arguments.callee.caller || "unknown caller").toString(); c[d] || (e.deprecated(this.declaredClass + "::attr() is deprecated. Use get() or set() instead, called from " + d, "", "2.0"), c[d] = !0) } return 2 <= arguments.length || "object" === typeof a ? this.set.apply(this, arguments) : this.get(a) }, getDescendants: function () {
                        e.deprecated(this.declaredClass + "::getDescendants() is deprecated. Use getChildren() instead.",
                        "", "2.0"); return this.containerNode ? b("[widgetId]", this.containerNode).map(k.byNode) : []
                    }, _onShow: function () { this.onShow() }, onShow: function () { }, onHide: function () { }, onClose: function () { return !0 }
                }); c("dijit-legacy-requires") && a(0, function () { require(["dijit/_base"]) }); return j
            })
        }, "dojo/cache": function () { define("dojo/cache", ["./_base/kernel", "./text"], function (j) { return j.cache }) }, "dijit/_FocusMixin": function () {
            define("dijit/_FocusMixin", ["./focus", "./_WidgetBase", "dojo/_base/declare", "dojo/_base/lang"],
            function (j, m, h, f) { f.extend(m, { focused: !1, onFocus: function () { }, onBlur: function () { }, _onFocus: function () { this.onFocus() }, _onBlur: function () { this.onBlur() } }); return h("dijit._FocusMixin", null, { _focusManager: j }) })
        }, "dijit/_OnDijitClickMixin": function () {
            define("dijit/_OnDijitClickMixin", "dojo/on,dojo/_base/array,dojo/keys,dojo/_base/declare,dojo/has,dojo/_base/unload,dojo/_base/window,./a11yclick".split(","), function (j, m, h, f, c, e, d, b) {
                j = f("dijit._OnDijitClickMixin", null, {
                    connect: function (a, c, d) {
                        return this.inherited(arguments,
                        [a, "ondijitclick" == c ? b : c, d])
                    }
                }); j.a11yclick = b; return j
            })
        }, "cbtree/store/FileStore": function () {
            define("cbtree/store/FileStore", "module,dojo/_base/declare,dojo/_base/lang,dojo/Deferred,dojo/Evented,dojo/json,dojo/request,dojo/Stateful,dojo/store/util/QueryResults,dojo/when,../errors/createError!../errors/CBTErrors.json,../util/Mutex,../util/QueryEngine,../util/shim/Array".split(","), function (j, m, h, f, c, e, d, b, a, k, n, g, p) {
                function q(a) { var b = a.lastIndexOf("/"); if (-1 != b) return a.slice(0, b) } function o(a) {
                    var b;
                    a.directory ? b = "fileIconDIR" : (b = a.name.lastIndexOf("."), 0 < b ? (b = a.name.substr(b + 1).toLowerCase(), b = b.replace(/[a-z]/, function (a) { return a.toUpperCase() }), b = "fileIcon" + b) : b = "fileIconUnknown"); a[v] = b + " fileIcon"
                } var l = n(j.id), r = "_EX", v = "icon"; return m([c, b], {
                    autoLoad: !1, authToken: null, basePath: ".", defaultProperties: {}, options: [], preventCache: !1, sort: [], queryEngine: p, url: "", _localOptions: ["iconClass", "dirsOnly"], _rootName: ".", _reservedProp: "name,size,modified,directory,icon,path".split(","), constructor: function () {
                        this._loaded =
                        new f; this._storeLoaded = this._loadInProgress = !1; this._mutex = new g; this._childIndex = {}; this._primIndex = {}; this._data = []
                    }, _basePathSetter: function (a) { if ("string" === typeof a) a = a.replace(/\\/g, "/").split("/"), a = a.filter(function (a) { return !!a.length && "." != a }), a.unshift("."), this.basePath = a.join("/"); else throw new l("InvalidType", "basePathSetter", "basePath property must be a string"); }, _dataSetter: function () { throw new l("InvalidAccess", "_dataSetter", "data property is not allowed"); }, _defaultPropertiesSetter: function (a) {
                        if (a &&
                        h.isObject(a)) for (var b in a) { if (-1 != this._reservedProp.indexOf(b)) throw new l("InvalidAccess", "_defaultPropertiesSetter", "No default allowed for property '" + b + "'"); } else throw new l("InvalidType", "_defaultPropertiesSetter", "defaultProperties must be an object");
                    }, _sortSetter: function (a) {
                        a = a instanceof Array ? a : [a]; a.forEach(function (a) {
                            if (h.isObject(a)) { if (!("attribute" in a)) throw new l("PropertyMissing", "_sortSetter", "[attribute] property missing in sort object"); } else throw new l("InvalidType",
                            "_sortSetter", "sort property must be an Array of objects");
                        }); return this.sort = a
                    }, _optionsSetter: function (a) { if (!(a instanceof Array)) { if ("string" !== typeof a) throw new l("InvalidType", "_optionSetter", "Options must be a keyword string or an array of keywords."); a = a.split(",") } return this.options = a.filter(function (a) { return -1 != this._localOptions.indexOf(a) ? (this["_option" + a.replace(/[a-z]/, function (a) { return a.toUpperCase() })] = !0, !1) : !0 }, this) }, _urlSetter: function (a, b) {
                        b = !(!b && !this.autoLoad); if ("string" ===
                        typeof a) return (this._url = a) && !0 === b && this.load(), this._url; throw new l("InvalidType", "_urlSetter", "URL must be of type string");
                    }, _deleteFromStore: function (a) {
                        function b(a) { a.directory && (a.children && a.children.forEach(b), a[r] = !1); var a = g.getIdentity(a), c = l[d[a]], f, k; if (c && (f = e[c.parent])) -1 != (k = f.indexOf(c)) && f.splice(k, 1); delete l[d[a]]; delete e[a] } var c = a.items, d = this._primIndex, e = this._childIndex, l = this._data, g = this, k; return c && c.length ? this._mutex.aquire(function () {
                            c.forEach(b); this._data = l.filter(function () { return !0 });
                            this._primIndex = {}; for (k = 0; k < this._data.length; k++) this._primIndex[this._data[k].path] = k; this._mutex.release(!0)
                        }, this) : (new f).resolve(!1)
                    }, _fetchFromServer: function (a, b, c) { var c = c || new f, a = { path: a }, d = this; if (b) a.queryOptions = b; this._xhrRequest("GET", this._url, a).then(function (a) { k(d._updateFileStore(a), c.resolve, c.reject) }, function (a) { if (a.response) switch (a.response.status) { case 404: a.message = "404 Object Not Found", a.name = "NetworkError" } c.reject(a) }); return c }, _fetchFromStore: function (a) { return this._data[this._primIndex[a]] },
                    _resyncStore: function (a) { function b(a) { if (a.directory) a.children = e._childIndex[e.getIdentity(a)], a.children.forEach(function (a) { b(a) }); return a } var c = { total: 1, status: 200, items: [] }, d = a.parent, e = this; c.items.push(b(a)); this._deleteFromStore(c); this._fetchFromServer(d).then(null, function (a) { switch (a.response.status) { case 404: case 410: e.remove(d) } }) }, _updateFileStore: function (a) {
                        function b(a, c) {
                            var d, l; a && a.forEach(function (a) {
                                d = e.getIdentity(a); (l = c.some(function (a) { return d === e.getIdentity(a) })) || e.remove(d,
                                !0)
                            })
                        } function c(a, d) {
                            var l = e.getIdentity(a), f = e._fetchFromStore(l), g = a.children, k = q(a.path), j; a.parent = k; delete a.children; delete a.oldPath; if (f) f.directory && a[r] && b(e._childIndex[l], g), a = h.mixin(f, a); else { for (j in e.defaultProperties) a[j] = a[j] || e.defaultProperties[j]; e._optionIconClass && o(a) } f ? (k = e._primIndex[l], e._data[k] = a) : (k = e._data.push(a) - 1, e._primIndex[l] = k); (function (a) { var b = e._childIndex[a.parent] || []; -1 == b.indexOf(a) && (b.push(a), e._childIndex[a.parent] = b) })(a); e._storeLoaded && d && (f ||
                            (e._data[k] = h.delegate(a, { _placeHolder: !0 })), e.put(a, { overwrite: !0, _server: !0 })); g && g.forEach(function (a) { c(a, !1) }); return a
                        } var d = [], e = this; if (a && a.items) { var f = a.items; return this._mutex.aquire(function () { f.forEach(function (a) { e.getIdentity(a) && d.push(c(a, !0)) }); this._mutex.release(d) }, this) } throw new l("InvalidResponse", "_updateFileStore");
                    }, _xhrRequest: function (a, b, c) {
                        var l = { method: a, preventCache: this.preventCache, handleAs: "json" }, c = h.mixin(c, { authToken: this.authToken, basePath: this.basePath }),
                        f = "", g, k; switch (a) { case "POST": l.data = { basePath: this.basePath, path: c.path, newValue: c.newValue }; break; case "GET": c.options = this.options; case "DELETE": for (g in c) if ((k = c[g]) && (!(k instanceof Array) || k.length)) f += "&" + g + "=" + e.stringify(k) } if (f.length) l.query = f; return d(b, l)
                    }, add: function () { throw new l("InvalidAccess", "add", "operation not allowed, use get() and put() instead"); }, get: function (a, b) {
                        var c = this._data[this._primIndex[a]]; if (!c && !b) { if (!this._loadInProgress) return this._fetchFromServer(a, this.options).promise } else if (c &&
                        c._placeHolder) return (new f).reject(new l("NotFound", "get")); return (new f).resolve(c)
                    }, getChildren: function (b, c) { var d = this.getIdentity(b), e = { parent: d }, l = this, f = []; if (this.sort) c ? c.sort = c.sort || this.sort : c = { sort: this.sort }; return d && b.directory ? !b[r] ? (f = l._fetchFromServer(d), f.then(function () { return l.query(e, c, l._childIndex[d]) }, function (a) { switch (a.response.status) { case 404: case 410: l._resyncStore(b); break; default: return a } return l.query(e, c, l._childIndex[d]) })) : l.query(e, c, l._childIndex[d]) : a(f) },
                    getIdentity: function (a) { return a.path }, isItem: function (a) { return a && "object" == typeof a ? a == this.get(this.getIdentity(a)) : !1 }, load: function (a) { var a = { deep: a ? !!a.all : !1 }, b = this._loaded, c = this; if (!this._storeLoaded && !this._loadInProgress) this._loadInProgress = !0, b = this._fetchFromServer(null, a, this._loaded), b.then(function () { c.emit("load", { type: "load", store: c }); c._loadInProgress = !1; c._storeLoaded = !0 }, function (a) { c.emit("error", { type: "load", error: a, store: c }) }); return b.promise }, put: function (a, b) {
                        var c = this.getIdentity(a);
                        if (c) { var d = this._primIndex, e = this._data; if (c in d) e[d[c]] = a; else if (b && !0 === b._server) d[c] = e.push(a) - 1; else throw new l("NotFound", "put"); return c } throw new l("InvalidObject", "put");
                    }, query: function (b, c, d) {
                        var b = b || { name: this._rootName }, e = void 0 != d ? d : this._data, l = this; if (this._optionDirsOnly && !b.directory) b.directory = !0; if (this.sort) c ? c.sort = c.sort || this.sort : c = { sort: this.sort }; return !this._storeLoaded ? (this._loadInProgress || this.loadStore(), k(this._loaded, function () { return a(l.queryEngine(b, c)(e)) })) :
                        a(l.queryEngine(b, c)(e))
                    }, ready: function (a, b) { return this._loaded.then(a, b) }, remove: function (a, b) { var c = new f, d = this; this.get(a).then(function (a) { (b ? (new f).resolve({ total: 1, status: 200, items: [a] }) : d._xhrRequest("DELETE", d._url, { path: a.path })).then(function (a) { k(d._deleteFromStore(a), c.resolve, c.reject) }, function (b) { switch (b.response.status) { case 404: case 410: d._resyncStore(a); c.resolve(!1); break; default: c.reject(b) } }) }, c.reject); return c.promise }, rename: function (a, b) {
                        var c = new f, d = this; if (b && "string" ===
                        typeof b) { var e = this.getIdentity(a); this.get(e).then(function (a) { d._xhrRequest("POST", d._url, { path: a.path, newValue: b }).then(function (a) { d._updateFileStore(a); d.remove(e, !0); c.resolve(b) }, function (b) { switch (b.response.status) { case 404: case 410: d._resyncStore(a); c.reject(new l("NotFound", "rename", "Object nolonger exist")); break; default: c.reject(b) } }) }, c.reject); return c.promise } return c.reject(new l("InvalidPath", "rename"))
                    }
                })
            })
        }, "cbtree/util/shim/Array": function () {
            define("cbtree/util/shim/Array", [],
            function () {
                if (!Array.prototype.every) Array.prototype.every = function (j, m) { if (null == this) throw new TypeError; var h = Object(this), f = h.length >>> 0; if ("function" != typeof j) throw new TypeError; for (var c = 0; c < f; c++) if (c in h && !j.call(m, h[c], c, h)) return !1; return !0 }; if (!Array.prototype.filter) Array.prototype.filter = function (j, m) { if (null == this) throw new TypeError; var h = Object(this), f = h.length >>> 0; if ("function" != typeof j) throw new TypeError; for (var c = [], e = 0; e < f; e++) if (e in h) { var d = h[e]; j.call(m, d, e, h) && c.push(d) } return c };
                if (!Array.prototype.forEach) Array.prototype.forEach = function (j, m) { var h, f; if (null == this) throw new TypeError("this is null or not defined"); var c = Object(this), e = c.length >>> 0; if ("[object Function]" !== {}.toString.call(j)) throw new TypeError(j + " is not a function"); m && (h = m); for (f = 0; f < e;) { var d; Object.prototype.hasOwnProperty.call(c, f) && (d = c[f], j.call(h, d, f, c)); f++ } }; if (!Array.prototype.indexOf) Array.prototype.indexOf = function (j) {
                    if (null == this) throw new TypeError; var m = Object(this), h = m.length >>> 0; if (0 ===
                    h) return -1; var f = 0; 1 < arguments.length && (f = Number(arguments[1]), f != f ? f = 0 : 0 != f && Infinity != f && -Infinity != f && (f = (0 < f || -1) * Math.floor(Math.abs(f)))); if (f >= h) return -1; for (f = 0 <= f ? f : Math.max(h - Math.abs(f), 0) ; f < h; f++) if (f in m && m[f] === j) return f; return -1
                }; if (!Array.prototype.lastIndexOf) Array.prototype.lastIndexOf = function (j) {
                    if (null == this) throw new TypeError; var m = Object(this), h = m.length >>> 0; if (0 === h) return -1; var f = h; 1 < arguments.length && (f = Number(arguments[1]), f != f ? f = 0 : 0 != f && f != 1 / 0 && f != -(1 / 0) && (f = (0 < f || -1) *
                    Math.floor(Math.abs(f)))); for (h = 0 <= f ? Math.min(f, h - 1) : h - Math.abs(f) ; 0 <= h; h--) if (h in m && m[h] === j) return h; return -1
                }; if (!Array.prototype.map) Array.prototype.map = function (j, m) { if (null == this) throw new TypeError(" this is null or not defined"); var h, f, c, e = Object(this), d = e.length >>> 0; if ("[object Function]" != {}.toString.call(j)) throw new TypeError(j + " is not a function"); m && (h = m); f = Array(d); for (c = 0; c < d;) { var b; c in e && (b = e[c], b = j.call(h, b, c, e), f[c] = b); c++ } return f }; if (!Array.prototype.some) Array.prototype.some =
                function (j, m) { if (null == this) throw new TypeError; var h = Object(this), f = h.length >>> 0; if ("function" != typeof j) throw new TypeError; for (var c = 0; c < f; c++) if (c in h && j.call(m, h[c], c, h)) return !0; return !1 }
            })
        }, "cbtree/model/ForestStoreModel": function () {
            define("cbtree/model/ForestStoreModel", "module,dojo/_base/declare,dojo/_base/lang,dojo/Deferred,dojo/when,./_base/CheckedStoreModel,../errors/createError!../errors/CBTErrors.json".split(","), function (j, m, h, f, c, e, d) {
                var b = d(j.id); return m([e], {
                    rootId: "$root$", rootLabel: "ROOT",
                    constructor: function () { var a = { id: this.rootId, root: !0 }, c = this.store; a[this.checkedAttr] = this.checkedState; a[this.labelAttr] = this.rootLabel || this.rootId; if (this._methods.queryEngine) this._rootQuery = c.queryEngine(this.query); else throw new b("MethodMissing", "_createForestRoot", "store has no query engine"); this._forest = !0; this.root = a }, getChildren: function (a, b, c) { this._getChildren(a, function (a) { return a == this.root ? this.store.query(this.query, this.options) : this.store.getChildren(a, this.options) }, b, c) },
                    getParents: function (a) { if (a && a != this.root) { var b = this; return this.inherited(arguments).then(function (c) { b.isChildOf(a, b.root) && c.push(b.root); return c }) } return (new f).resolve([]) }, mayHaveChildren: function (a) { return a && a == this.root ? !!this._childrenCache[this.getIdentity(a)] : this.inherited(arguments) }, getIdentity: function (a) { return a == this.root ? this.root.id : this.store.getIdentity(a) }, isChildOf: function (a, b) {
                        return b && a ? b == this.root ? this._rootQuery.matches ? this._rootQuery.matches(a) : !!this._rootQuery([a]).length :
                        this.inherited(arguments) : !1
                    }, _setValue: function (a, b, c) { if (a[b] !== c) if (a == this.root) { var d = h.mixin(null, a); a[b] = c; this._onChange(a, d) } else this.inherited(arguments); return c }, _onSetItem: function (a, b, d, e) { if (this.query && b in this.query) { var f = this; c(this._childrenCache[this.root.id], function (b) { var b = b ? b.indexOf(a) : -1, d = f.isChildOf(a, f.root); if (d != -1 < b) { var e = d ? "attach" : "detach", b = f._updateChildrenCache(e, f.root, a); c(b, function () { f.onRootChange(a, e); f._childrenChanged(f.root) }) } }) } this.inherited(arguments) },
                    toString: function () { return "[object ForestStoreModel]" }
                })
            })
        }, "dijit/form/_ToggleButtonMixin": function () {
            define("dijit/form/_ToggleButtonMixin", ["dojo/_base/declare", "dojo/dom-attr"], function (j, m) {
                return j("dijit.form._ToggleButtonMixin", null, {
                    checked: !1, _aria_attr: "aria-pressed", _onClick: function (h) { var f = this.checked; this._set("checked", !f); var c = this.inherited(arguments); this.set("checked", c ? this.checked : f); return c }, _setCheckedAttr: function (h, f) {
                        this._set("checked", h); m.set(this.focusNode || this.domNode,
                        "checked", h); (this.focusNode || this.domNode).setAttribute(this._aria_attr, h ? "true" : "false"); this._handleOnChange(h, f)
                    }, reset: function () { this._hasBeenBlurred = !1; this.set("checked", this.params.checked || !1) }
                })
            })
        }, "dijit/focus": function () {
            define("dijit/focus", "dojo/aspect,dojo/_base/declare,dojo/dom,dojo/dom-attr,dojo/dom-construct,dojo/Evented,dojo/_base/lang,dojo/on,dojo/ready,dojo/sniff,dojo/Stateful,dojo/_base/unload,dojo/_base/window,dojo/window,./a11y,./registry,./main".split(","), function (j, m, h,
            f, c, e, d, b, a, k, n, g, p, q, o, l, r) {
                var v = new (m([n, e], {
                    curNode: null, activeStack: [], constructor: function () { var a = d.hitch(this, function (a) { h.isDescendant(this.curNode, a) && this.set("curNode", null); h.isDescendant(this.prevNode, a) && this.set("prevNode", null) }); j.before(c, "empty", a); j.before(c, "destroy", a) }, registerIframe: function (a) { return this.registerWin(a.contentWindow, a) }, registerWin: function (a, b) {
                        var c = this, d = function (a) {
                            c._justMouseDowned = !0; setTimeout(function () { c._justMouseDowned = !1 }, 0); if (!k("ie") ||
                            !a || !(a.srcElement && null == a.srcElement.parentNode)) c._onTouchNode(b || a.target || a.srcElement, "mouse")
                        }, e = k("ie") ? a.document.documentElement : a.document; if (e) {
                            if (k("ie")) {
                                a.document.body.attachEvent("onmousedown", d); var l = function (a) { var d = a.srcElement.tagName.toLowerCase(); "#document" == d || "body" == d || (o.isTabNavigable(a.srcElement) ? c._onFocusNode(b || a.srcElement) : c._onTouchNode(b || a.srcElement)) }; e.attachEvent("onfocusin", l); var f = function (a) { c._onBlurNode(b || a.srcElement) }; e.attachEvent("onfocusout",
                                f); return { remove: function () { a.document.detachEvent("onmousedown", d); e.detachEvent("onfocusin", l); e.detachEvent("onfocusout", f); e = null } }
                            } e.body.addEventListener("mousedown", d, !0); e.body.addEventListener("touchstart", d, !0); var g = function (a) { c._onFocusNode(b || a.target) }; e.addEventListener("focus", g, !0); var h = function (a) { c._onBlurNode(b || a.target) }; e.addEventListener("blur", h, !0); return {
                                remove: function () {
                                    e.body.removeEventListener("mousedown", d, !0); e.body.removeEventListener("touchstart", d, !0); e.removeEventListener("focus",
                                    g, !0); e.removeEventListener("blur", h, !0); e = null
                                }
                            }
                        }
                    }, _onBlurNode: function () { this._clearFocusTimer && clearTimeout(this._clearFocusTimer); this._clearFocusTimer = setTimeout(d.hitch(this, function () { this.set("prevNode", this.curNode); this.set("curNode", null) }), 0); if (!this._justMouseDowned) this._clearActiveWidgetsTimer && clearTimeout(this._clearActiveWidgetsTimer), this._clearActiveWidgetsTimer = setTimeout(d.hitch(this, function () { delete this._clearActiveWidgetsTimer; this._setStack([]) }), 0) }, _onTouchNode: function (a,
                    b) { this._clearActiveWidgetsTimer && (clearTimeout(this._clearActiveWidgetsTimer), delete this._clearActiveWidgetsTimer); var c = []; try { for (; a;) { var d = f.get(a, "dijitPopupParent"); if (d) a = l.byId(d).domNode; else if (a.tagName && "body" == a.tagName.toLowerCase()) { if (a === p.body()) break; a = q.get(a.ownerDocument).frameElement } else { var e = a.getAttribute && a.getAttribute("widgetId"), g = e && l.byId(e); g && !("mouse" == b && g.get("disabled")) && c.unshift(e); a = a.parentNode } } } catch (k) { } this._setStack(c, b) }, _onFocusNode: function (a) {
                        a &&
                        9 != a.nodeType && (this._clearFocusTimer && (clearTimeout(this._clearFocusTimer), delete this._clearFocusTimer), this._onTouchNode(a), a != this.curNode && (this.set("prevNode", this.curNode), this.set("curNode", a)))
                    }, _setStack: function (a, b) {
                        var c = this.activeStack; this.set("activeStack", a); for (var d = 0; d < Math.min(c.length, a.length) && !(c[d] != a[d]) ; d++); for (var e, f = c.length - 1; f >= d; f--) if (e = l.byId(c[f])) e._hasBeenBlurred = !0, e.set("focused", !1), e._focusManager == this && e._onBlur(b), this.emit("widget-blur", e, b); for (f =
                        d; f < a.length; f++) if (e = l.byId(a[f])) e.set("focused", !0), e._focusManager == this && e._onFocus(b), this.emit("widget-focus", e, b)
                    }, focus: function (a) { if (a) try { a.focus() } catch (b) { } }
                })); a(function () { var a = v.registerWin(q.get(p.doc)); k("ie") && g.addOnWindowUnload(function () { a && (a.remove(), a = null) }) }); r.focus = function (a) { v.focus(a) }; for (var t in v) /^_/.test(t) || (r.focus[t] = "function" == typeof v[t] ? d.hitch(v, t) : v[t]); v.watch(function (a, b, c) { r.focus[a] = c }); return v
            })
        }, "cbtree/store/Natural": function () {
            define("cbtree/store/Natural",
            ["dojo/_base/declare", "./Memory"], function (j, m) { return j([m], { _insertBefore: function (h, f, c) { var e = h.length; c && (e = h.indexOf(c), -1 != e && (c = h.indexOf(f), -1 != c && (e = e > c ? e - 1 : e, h.splice(c, 1)))); h.splice(e, 0, f); return e }, _writeObject: function (h, f, c, e) { if (e && e.before) { var d = this._anyToObject(e.before); if (!c || -1 == c) this._applyDefaults(h, f), this.total++; this._insertBefore(this._data, f, d); this._indexData(); return h } return this.inherited(arguments) }, toString: function () { return "[object NaturalStore]" } }) })
        }, "cbtree/model/_base/Prologue": function () {
            define("cbtree/model/_base/Prologue",
            [], function () { return function (j, m) { if (m && m.parent && !0 !== this.hierarchical) { var h = this.parentProperty, f = this.getIdentity(j), c = m.parent, e, d = [], b; if (c instanceof Array) for (b = 0; b < c.length; b++) { if (e = this.getIdentity(c[b])) e != f && -1 == d.indexOf(e) && (d ? d.push(e) : d = [e]) } else (e = this.getIdentity(c)) ? e != f && (d = e) : d = void 0; j[h] = d } } })
        }, "cbtree/data/FileStore": function () {
            define("cbtree/data/FileStore", "dojo/_base/array,dojo/_base/declare,dojo/_base/json,dojo/_base/lang,dojo/_base/window,dojo/_base/xhr,dojo/Evented,./util/filter,./util/sorter".split(","),
            function (j, m, h, f, c, e, d, b, a) {
                var k = "_S", n = "_SR", g = "_PRM", p = "_EX", q = "children", o = "path"; return m([d], {
                    constructor: function (a) {
                        this._features = { "dojo.data.api.Read": !0, "dojo.data.api.Write": !0, "dojo.data.api.Identity": !0, "dojo.data.api.Notification": !0 }; this._closePending = this._loadFinished = this._loadInProgress = !1; this._requestQueue = []; this._authToken = null; this._itemsByIdentity = {}; this._allFileItems = []; this._privateAttrs = [k, g, p, n]; this._readOnlyAttrs = ["name", "size", "modified", "directory", "icon", q, o];
                        this._rootDir = null; this._rootId = "."; for (var b in a) this.set(b, a[b]); dojo.deprecated("{cbtree/data/FileStore}", "Migrate to cbtree/store/FileStore", "2.0")
                    }, authToken: null, basePath: ".", cache: !1, clearOnClose: !1, failOk: !1, options: [], url: "", urlPreventCache: !1, moduleName: "cbTree/store/FileStore", _addIconClass: !1, _labelAttr: "name", _validated: !1, _assertIsItem: function (a) { if (!this.isItem(a)) throw Error(this.moduleName + "::_assertIsItem(): Invalid item argument."); }, _assertIsAttribute: function (a, b) {
                        if ("string" !==
                        typeof a) throw Error(this.moduleName + "::" + b + "(): Invalid attribute argument.");
                    }, _assertSupport: function (a) { throw Error(this.moduleName + "::" + a + "(): Function not supported on a File Store."); }, _containsValue: function (a, b, c, d) { return "undefined" !== typeof a[b] ? j.some(this.getValues(a, b), function (a) { if (null !== a && !f.isObject(a) && d) { if (a.toString().match(d)) return !0 } else if (c === a) return !0 }) : !1 === c || void 0 === c }, _deleteFromServer: function (a) {
                        var b = a.scope || c.global, d = a.item, f = this.getPath(d), g = this; if (this._loadInProgress) this._queueRequest({
                            args: a,
                            func: this._deleteFromServer, scope: g
                        }); else { this._loadInProgress = !0; var k = this._requestToArgs("DELETE", { path: f }), f = e.del(k), h; f.addCallback(function (c) { try { h = g._updateFileStore("DELETE", c, a), g._loadInProgress = !1, a.onComplete && a.onComplete.call(b, h) } catch (d) { g._loadInProgress = !1, a.onError ? a.onError.call(b, d) : console.error(d) } g._handleQueuedRequest() }); f.addErrback(function (c) { g._loadInProgress = !1; switch (k.status) { case 404: case 410: g._resyncStore(d, !0); break; default: a.onError && a.onError.call(b, c, k.status) } g._handleQueuedRequest() }) }
                    },
                    _deleteFromStore: function (a, b) { var c = a[o], d = this.getValue(a, g), e = this.getValues(d, q), f = []; if (a.directory) { var h = this.getValues(a, q), j, n; for (n = 0; n < h.length; n++) j = this._deleteFromStore(h[n], !1), f = f.concat(j); a[p] = !1 } this._removeArrayElement(this._allFileItems, a); this._removeArrayElement(e, a); delete this._itemsByIdentity[c]; a[k] = null; a.deleted = !0; f.push(a); this._setValues(d, q, e, b); this.onDelete(a); return f }, _fetchFinal: function (d, e) {
                        function f(c, d) {
                            var e = (c.queryOptions || {}).ignoreCase || !1, l = c.query ||
                            null, g = []; if (d) { if (l) { var h = {}, j, n, m, r; for (m in l) r = l[m], "string" === typeof r ? h[m] = b.patternToRegExp(r, e) : r instanceof RegExp && (h[m] = r); for (e = 0; e < d.length; ++e) { n = d[e]; j = !0; for (m in l) if (r = l[m], !k._containsValue(n, m, r, h[m])) { j = !1; break } j && g.push(n) } } else g = d.slice(0); g.length && c.sort && (l = new a(c.sort), g.sort(l.sortFunction())); l = c.start ? c.start : 0; h = c.count && isFinite(c.count) ? c.count : g.length; if (l || h !== g.length) g = g.slice(l, l + h); return g } return null
                        } var g = d.scope || c.global, k = this, h = [], j = 0; d.abort = function () {
                            this.aborted =
                            !0
                        }; d.store = this; if (!0 !== d.aborted) { j = (h = f(d, e)) ? h.length : -1; d.onBegin && d.onBegin.call(g, j, d); if (d.onItem && 0 < j) for (i = 0; i < j && !0 !== d.aborted; i++) d.onItem.call(g, h[i], d); d.onComplete && (d.onItem || d.aborted || 0 > j ? d.onComplete.call(g, null, d) : d.onComplete.call(g, h, d)) } d.onAbort && d.aborted && d.onAbort.call(g, d)
                    }, _getItemsArray: function (a) { return a && a.deep ? this._allFileItems : this._rootDir[q] }, _getItemByIdentity: function (a) {
                        var b = null; this._itemsByIdentity && Object.hasOwnProperty.call(this._itemsByIdentity, a) &&
                        (b = this._itemsByIdentity[a]); return b
                    }, _handleQueuedRequest: function () { for (var a, b; 0 < this._requestQueue.length && !this._loadInProgress;) b = this._requestQueue.shift(), a = b.func, a.call(b.scope, b.args) }, _isPrivateAttr: function (a) { for (var b in this._privateAttrs) if (a == this._privateAttrs[b]) return !0; return !1 }, _isReadOnlyAttr: function (a) { for (var b in this._readOnlyAttrs) if (a == this._readOnlyAttrs[b]) return !0; return !1 }, _queueRequest: function (a) {
                        this._closePending ? (a = a.args, a.closePending = !0, this._fetchFinal(a,
                        null)) : this._requestQueue.push(a)
                    }, _removeArrayElement: function (a, b) { var c = j.indexOf(a, b); return -1 != c ? (a.splice(c, 1), !0) : !1 }, _renameItem: function (a) {
                        var b = a.scope || c.global, d = a.item, f = this.getPath(d), g = this; if (this._loadInProgress) this._queueRequest({ args: a, func: this._renameItem, scope: g }); else {
                            this._loadInProgress = !0; var k = a.newValue, h = this._requestToArgs("POST", { path: f, newValue: k }), f = e.post(h); f.addCallback(function (c) {
                                try {
                                    g._updateFileStore("POST", c, a), g._loadInProgress = !1, a.onItem && a.onItem.call(b,
                                    g._getItemByIdentity(k))
                                } catch (d) { if (g._loadInProgress = !1, a.onError) a.onError(d); else console.error(d) } g._handleQueuedRequest()
                            }); f.addErrback(function (c) { g._loadInProgress = !1; switch (h.status) { case 404: case 410: g._resyncStore(d) } a.onError && a.onError.call(b, c, h.status); g._handleQueuedRequest() })
                        }
                    }, _requestToArgs: function (a, b) {
                        var c = {}, d = null, d = !1; if (this.basePath) c.basePath = this.basePath; if (b.path) c.path = b.path; if (this.authToken) c.authToken = h.toJson(this.authToken); if (b.sync) d = b.sync; switch (a) {
                            case "GET": if (b.queryOptions) c.queryOptions =
                            h.toJson(b.queryOptions); if (this.options && this.options.length) c.options = h.toJson(this.options); break; case "POST": if (b.newValue) c.newValue = b.newValue
                        } return d = { url: this.url, handleAs: "json", content: c, preventCache: this.urlPreventCache, handle: function (a, b) { this.status = b.xhr.status }, failOk: this.failOk, status: 200, sync: d }
                    }, _resyncStore: function () {
                        var a = this.getParents(item)[0]; if (a) this.loadItem({ item: a, forceLoad: !0 }); else {
                            if (item === this._rootDir) throw Error(this.moduleName + "::_resyncStore(): Store root directory failed to reload.");
                            throw Error(this.moduleName + "::_resyncStore(): File Store is corrupt.");
                        }
                    }, _setAuthTokenAttr: function (a) { if (f.isObject(a)) this.authToken = a; return !1 }, _setOptionsAttr: function (a) { if (f.isArray(a)) this.options = a; else if (f.isString(a)) this.options = a.split(","); else throw Error(this.moduleName + "::_setOptionsAttr(): Options must be a comma separated string of keywords or an array of keyword strings."); for (a = 0; a < this.options.length; a++) if ("iconClass" === this.options[a]) this._addIconClass = !0; return this.options },
                    _setValue: function (a, b, c, d) { var e; e = a[b]; a[b] = c; if (d) this.onSet(a, b, e, c); return !0 }, _setValues: function (a, b, c, d) { var e; e = this.getValues(a, b); if (f.isArray(c)) 0 === c.length && b !== q ? (delete a[b], c = void 0) : a[b] = c.slice(0, c.length); else throw Error(this.moduleName + "::setValues(): newValues not an array"); if (d) this.onSet(a, b, e, c); return !0 }, _updateFileStore: function (b, c) {
                        function d(a) { var b = []; (a = s._getItemByIdentity(a)) && (b = s._deleteFromStore(a, !0)); return b } function e(a) {
                            var b = s._getItemByIdentity(a); if (!b) if (b =
                            s._rootDir) { var a = a.split("/"), c = ".", d = null; for (A = 0; A < a.length; A++) "." !== a[A] && (c = c + "/" + a[A], (d = s._getItemByIdentity(c)) ? b = d : (d = { name: a[A], path: c, directory: !0, size: 0 }, d[q] = [], d[p] = !1, b = h(d, b, !0))) } else return h(null, null, !1), e(a); return b
                        } function f(a, b, c) { var d = !1, e = {}, g, l; for (l in b) if (l != q && l != p && (g = b[l], !(l in a) || a[l] !== g && (!(l in e) || e[l] !== g))) { d = a[l]; a[l] = g; if (c) s.onSet(a, l, d, g); d = !0 } return d } function h(a, b, c) {
                            if (b) {
                                var d = s.getIdentity(a); if (!s._getItemByIdentity(d)) {
                                    var e = s.getValues(b, q),
                                    f = s.getValues(b, q); a[k] = s; a[g] = b; s._addIconClass && j(a); s._itemsByIdentity[d] = a; s._allFileItems.push(a); f.push(a); s._setValues(b, q, f, !1); s._loadFinished && c && (c = { item: b, attribute: q, oldValue: e, newValue: f }, s.onNew(a, !b[n] ? c : null)); return a
                                } throw Error(s.moduleName + "::_updateFileStore:newFile(): item [" + a.path + "] already exist.");
                            } if (!s._rootDir) return a = { name: s._rootId, path: s._rootId, directory: !0 }, a[k] = s, a[q] = [], a[p] = !1, a[n] = !0, s._addIconClass && j(a), s._itemsByIdentity[s._rootId] = a, s._allFileItems.push(a),
                            s._rootDir = a; throw Error(s.moduleName + "::_updateFileStore:newFile(): item has no parent.");
                        } function j(a) { var b; a.directory ? b = "fileIconDIR" : (b = a.name.lastIndexOf("."), 0 < b ? (b = a.name.substr(b + 1).toLowerCase(), b = b.replace(/^[a-z]|-[a-zA-Z]/g, function (a) { return a.charAt(a.length - 1).toUpperCase() }), b = "fileIcon" + b) : b = "fileIconUnknown"); a.icon = b + " fileIcon" } function m(a, b) {
                            var c = a[o], d = a.oldPath; if (d && d !== c) {
                                var g = s._getItemByIdentity(d); if (g) s._deleteFromStore(g, !0), delete a.oldPath; else throw Error(s.moduleName +
                                "::_updateFileStore:updateFile(): Unable to resolve [" + d + "].");
                            } b || (d = c.lastIndexOf("/"), d = c.substr(0, d) || c, b = e(d)); if ((d = s._getItemByIdentity(c)) && d.directory !== a.directory) s._deleteFromStore(d, !0), d = null; d ? f(d, a, !0) : a.directory ? (d = e(c), f(d, a, !1)) : d = h(a, b, !0); if (d.directory && a[p]) {
                                var c = d, g = a[q], l = !1, k, j, n = s.getValues(c, q), r = s.getValues(c, q), w = []; for (j = 0; j < g.length; j++) k = m(g[j], c), s._removeArrayElement(r, k), w.push(k); if (0 < r.length) { for (k = r.shift() ; k;) s._deleteFromStore(k, !1), k = r.shift(); l = !0 } n.length !=
                                w.length && (l = !0); if (l && s._loadFinished) s.onSet(c, q, n, w); c[p] = !0
                            } return d
                        } var s = this; if (c) { var w = c.items, y, C = [], A; if (w) { 1 < w.length && (y = new a([{ attribute: o }]), w.sort(y.sortFunction())); for (A = 0; A < w.length; A++) if (y = s.getIdentity(w[A])) switch (b) { case "DELETE": y = d(y); C = C.concat(y); break; case "GET": case "POST": y = m(w[A], null), C.push(y) } this._loadFinished = !0; return C } } throw Error(this.moduleName + "::_updateFileStore(): Empty or malformed server response.");
                    }, attachToRoot: function (a) {
                        this._assertIsItem(a); this.renameItem(a,
                        this._rootId + "/" + a.name)
                    }, close: function (a) { if (this._loadInProgress) this._queueRequest({ args: a, func: this.close, scope: this }), this._closePending = !0; else { if (this.clearOnClose) this._closePending = !0, this._queuedFetches = [], this._itemsByIdentity = {}, this._allFileItems = [], this._rootDir = null, this._validated = this._loadInProgress = this._loadFinished = !1; this.onClose(this.clearOnClose); this._closePending = !1 } }, containsValue: function (a, c, d) {
                        var e = void 0; "string" === typeof d && (e = b.patternToRegExp(d, !1)); return this._containsValue(a,
                        c, d, e)
                    }, deleteItem: function (a, b, d, e, f) { f = f || c.global; this._assertIsItem(a); if (!(b && !0 !== b.call(f, a))) return a = { item: a, onComplete: d, onError: e, scope: f }, this._deleteFromServer(a), a }, fetch: function (a) {
                        var b = a.scope || c.global, d = a.queryOptions || null, f = d ? d.storeOnly : !1, g = this; if ((this.cache || f) && this._loadFinished) this._fetchFinal(a, this._getItemsArray(d)); else if (this._loadInProgress) this._queueRequest({ args: a, func: this.fetch, scope: g }); else {
                            this._loadInProgress = !0; var k = this._requestToArgs("GET", a), f = e.get(k);
                            f.addCallback(function (c) { try { g._updateFileStore("GET", c, a), g._loadInProgress = !1, g._fetchFinal(a, g._getItemsArray(d)) } catch (e) { g._loadInProgress = !1, a.onError ? a.onError.call(b, e) : console.error(e) } g._handleQueuedRequest() }); f.addErrback(function (c) { g._loadInProgress = !1; a.onError ? a.onError.call(b, c, k.status) : console.error(c); g._handleQueuedRequest() })
                        } a.abort = function () { this.aborted = !0 }; return a
                    }, fetchChildren: function (a) {
                        var b = a.item || this._rootDir, c = this; this._assertIsItem(b); !this.isItemLoaded(b) ||
                        a.forceLoad ? this.loadItem({ item: b, forceLoad: a.forceLoad, onError: a.onError, onItem: function (b) { c._fetchFinal(a, b[q]) } }) : this._fetchFinal(a, b[q]); a.abort = function () { this.aborted = !0 }; return a
                    }, fetchItemByIdentity: function (a) {
                        var b = a.scope || c.global, d = a.identity || a[o], f = a.queryOptions || null, f = f ? f.storeOnly : !1, g = this, k; k = this._getItemByIdentity(d); if ((this.cache || f) && this._loadFinished && k) a.onItem && a.onItem.call(b, k); else if (this._loadInProgress) this._queueRequest({
                            args: a, func: this.fetchItemByIdentity,
                            scope: g
                        }); else { this._loadInProgress = !0; var h = this._requestToArgs("GET", { path: d }), f = e.get(h); f.addCallback(function (c) { try { g._updateFileStore("GET", c, a), g._loadInProgress = !1, a.onItem && (k = g._getItemByIdentity(d), a.onItem.call(b, k)) } catch (e) { g._loadInProgress = !1, a.onError ? a.onError.call(b, e) : console.error(e) } g._handleQueuedRequest() }); f.addErrback(function (c) { g._loadInProgress = !1; switch (h.status) { case 404: case 410: k && g._resyncStore(k); default: a.onError && a.onError.call(b, c, h.status) } g._handleQueuedRequest() }) }
                    },
                    getAttributes: function (a) { this._assertIsItem(a); var b = [], c; for (c in a) this._isPrivateAttr(c) || b.push(c); return b }, getDirectory: function (a) { this._assertIsItem(a); if (a = this.getValue(a, g)) return this.getPath(a) }, getFeatures: function () { return this._features }, getIdentity: function (a) { if (a) return a[o] }, getIdentifierAttr: function () { return o }, getIdentityAttributes: function () { return [o] }, getLabel: function (a) { if (this._labelAttr && this.isItem(a)) return this.getValue(a, this._labelAttr) }, getLabelAttributes: function () {
                        return this._labelAttr ?
                        [this._labelAttr] : null
                    }, getParents: function (a) { if (a) return a[g] == this._rootDir ? [] : this.getValues(a, g) }, getPath: function (a) { this._assertIsItem(a); return a[o] }, getValue: function (a, b, c) { a = this.getValues(a, b); return 0 < a.length ? a[0] : c }, getValues: function (a, b) { var c = []; this._assertIsItem(a); this._assertIsAttribute(b, "getValues"); void 0 !== a[b] && (c = f.isArray(a[b]) ? a[b] : [a[b]]); return c.slice(0) }, hasAttribute: function (a, b) { this._assertIsItem(a); this._assertIsAttribute(b, "hasAttribute"); return b in a }, isItem: function (a) {
                        return a &&
                        a[k] === this && this._itemsByIdentity[a[o]] === a ? !0 : !1
                    }, isItemLoaded: function (a) { var b = this.isItem(a); b && a.directory && !a[p] && (b = !1); return b }, isRootItem: function (a) { this._assertIsItem(a); return (a = this.getValue(a, g)) && a[n] ? !0 : !1 }, isValidated: function () { return this._validated }, loadItem: function (a) {
                        var b = a.forceLoad || !1, d = a.scope || c.global, f = a.item, g = this; if (this.isItem(f) && !(!0 !== b && this.isItemLoaded(f))) {
                            var k = this.getIdentity(f); if (this._loadInProgress) this._queueRequest({ args: a, func: this.loadItem, scope: g });
                            else { this._loadInProgress = !0; var h = this._requestToArgs("GET", { path: k }), b = e.get(h); b.addCallback(function (b) { try { g._updateFileStore("GET", b, a), g._loadInProgress = !1, a.onItem && (f = g._getItemByIdentity(k), a.onItem.call(d, f)) } catch (c) { if (g._loadInProgress = !1, a.onError) a.onError(c); else console.error(c) } g._handleQueuedRequest() }); b.addErrback(function (b) { g._loadInProgress = !1; if (f !== g._rootDir) switch (h.status) { case 404: case 410: g._resyncStore(f) } a.onError && a.onError.call(d, b, h.status); g._handleQueuedRequest() }) }
                        }
                    },
                    loadStore: function (a) { function b(a, c) { var d = c.loadArgs || null, f = d.scope; e.onLoad(a); d && d.onComplete && d.onComplete.call(f, a) } var d = a.scope || c.global, e = this; if (this._loadFinished) onComplete && onComplete.call(d, this._allFileItems.length); else if (this._loadInProgress) this._queueRequest({ args: a, func: this.loadStore, scope: e }); else { a = { queryOptions: { deep: !0 }, loadArgs: a, onBegin: b, onError: a.onError, scope: this }; try { this.fetch(a) } catch (f) { if (onError) onError.call(d, f); else throw f; } } }, renameItem: function (a, b, d, e,
                    g) { g = g || c.global; this._assertIsItem(a); this._assertIsAttribute(b, "renameItem"); a != this._rootDir && (a[o] !== b ? this._renameItem({ item: a, newValue: b, onItem: d, onError: e, scope: g }) : f.isFunction(d) && d.call(g, a)) }, set: function (a, b) { if (f.isString(a)) { var c = "_set" + a.replace(/^[a-z]|-[a-zA-Z]/g, function (a) { return a.charAt(a.length - 1).toUpperCase() }) + "Attr"; if (f.isFunction(this[c])) return this[c](b); if (void 0 !== this[a]) return this[a] = b, this[a] } throw Error(this.moduleName + "::set(): Invalid attribute"); }, setValidated: function (a) {
                        this._validated =
                        Boolean(a)
                    }, setValue: function (a, b, c) { this._assertIsItem(a); this._assertIsAttribute(b, "setValue"); if ("undefined" === typeof c) throw Error(this.moduleName + "::setValue(): newValue is undefined"); if (b !== o) { if (this._isReadOnlyAttr(b) || this._isPrivateAttr(b)) throw Error(this.moduleName + "::setValue(): attribute [" + b + "] is private or read-only"); return this._setValue(a, b, c, !0) } a[o] !== c && this._renameItem({ item: a, newValue: c }) }, setValues: function (a, b, c) {
                        this._assertIsItem(a); this._assertIsAttribute(b, "setValues");
                        if ("undefined" === typeof c) throw Error(this.moduleName + "::setValue(): newValue is undefined"); if (this._isReadOnlyAttr(b) || this._isPrivateAttr(b)) throw Error(this.moduleName + "::setValues(): attribute [" + b + "] is private or read-only"); return this._setValues(a, b, c, !0)
                    }, unsetAttribute: function (a, b) { return this.setValues(a, b, []) }, onClose: function () { }, onDelete: function (a) { var b = a[g]; if (b && b[n]) this.onRoot(a, "delete") }, onLoad: function () { }, onNew: function (a) { if (this.isRootItem(a)) this.onRoot(a, "new") }, onRoot: function () { },
                    onSet: function () { }, isDirty: function () { return !1 }, newItem: function () { this._assertSupport("newItem") }, revert: function () { }, save: function () { }, addReference: function () { this._assertSupport("addReference") }, detachFromRoot: function () { this._assertSupport("detachFromRoot") }, itemExist: function (a) { if ("object" != typeof a) throw Error(this.moduleName + "::itemExist(): argument is not an object."); a = a[o]; if ("undefined" === typeof a) throw Error(this.moduleName + "::itemExist(): argument does not include an identity."); return this._getItemByIdentity(a) },
                    removeReference: function () { this._assertSupport("removeReference") }
                })
            })
        }, "dijit/main": function () { define("dijit/main", ["dojo/_base/kernel"], function (j) { return j.dijit }) }, "cbtree/store/extensions/_PathList": function () {
            define("cbtree/store/extensions/_PathList", ["module", "./_Path", "../../errors/createError!../../errors/CBTErrors.json"], function (j, m, h) {
                function f() {
                    var a = []; Array.prototype.slice.call(arguments).forEach(function (b) {
                        if ("string" === typeof b || b instanceof String) a.push(new m(b)); else if (b instanceof
                        m) a.push(b); else if (b instanceof Array) a = a.concat(f.apply(this, b)); else if (b instanceof e) a = a.concat(f.apply(this, Array.prototype.slice.call(b))); else throw new d("InvalidType", "argsToPaths");
                    }); return a
                } function c(a, b, c, d) { var e = []; a.forEach(function (a) { d && b.shift(); b.forEach(function (b) { a.intersect(b, c).forEach(function (a) { -1 == e.indexOf(a) && e.push(a) }) }) }); return e } function e() {
                    this.contains = function (a) {
                        if (null != this && a) return this.some(function (b) { if (b.contains(a)) return !0 }); throw new d("InvalidType",
                        "contains");
                    }; this.intersect = function (a, b) { if (null != this) { var e, g = !1; arguments.length && ("boolean" == typeof a ? b = !!arguments[0] : e = f(a)); e || (e = Array.prototype.slice.call(this, 0), g = !0); return c(this, e, b, g) } throw new d("InvalidType", "intersect"); }; this.segments = function () { if (null != this) { var a = []; this.forEach(function (b) { b.segments().forEach(function (b) { -1 == a.indexOf(b) && a.push(b) }) }); return a } throw new d("InvalidType", "segments"); }; this.filter = function (a, b) {
                        if (null != this && "function" == typeof a) {
                            var c = new e,
                            f = Object(this), h, j; for (h = 0; h < f.length; h++) h in f && (j = f[h], a.call(b, j, h, f) && c.add(j)); return c
                        } throw new d("InvalidType", "filter");
                    }; this.forEach = function (a, b) { if (null != this && "function" == typeof a) for (var c = Object(this), e = 0, e = 0; e < c.length; e++) e in c && a.call(b, c[e], e, c); else throw new d("InvalidType", "forEach"); }; this.push = function () {
                        if (0 < arguments.length) {
                            var a = f.apply(this, arguments); 0 < a.length && a.forEach(function (a, b) { Object.defineProperty(this, this.length + b, { value: a, enumerable: !0, writable: !1 }); this.length++ },
                            this)
                        }
                    }; this.some = function (a, b) { if (null != this && "function" == typeof a) { for (var c = Object(this), e = 0, e = 0; e < c.length; e++) if (e in c && a.call(b, c[e], e, c)) return !0; return !1 } throw new d("InvalidType", "some"); }; b(this, "length", { writable: !0, enumerable: !1 }); b(this, "filter", { writable: !1, enumerable: !1 }); b(this, "forEach", { writable: !1, enumerable: !1 }); b(this, "some", { writable: !1, enumerable: !1 }); b(this, "push", { writable: !1, enumerable: !1 }); this.length = 0; this.push.apply(this, arguments)
                } var d = h(j.id), b = Object.defineProperty ||
                function (a, b, c) { if (void 0 == a[b]) a[b] = c.value }; return e
            })
        }, "dijit/form/_ButtonMixin": function () {
            define("dijit/form/_ButtonMixin", ["dojo/_base/declare", "dojo/dom", "dojo/_base/event", "../registry"], function (j, m, h, f) {
                return j("dijit.form._ButtonMixin", null, {
                    label: "", type: "button", _onClick: function (c) {
                        if (this.disabled) return h.stop(c), !1; var e = !1 === this.onClick(c); if (!e && "submit" == this.type && !(this.valueNode || this.focusNode).form) for (var d = this.domNode; d.parentNode; d = d.parentNode) {
                            var b = f.byNode(d); if (b &&
                            "function" == typeof b._onSubmit) { b._onSubmit(c); e = !0; break }
                        } e && c.preventDefault(); return !e
                    }, postCreate: function () { this.inherited(arguments); m.setSelectable(this.focusNode, !1) }, onClick: function () { return !0 }, _setLabelAttr: function (c) { this._set("label", c); (this.containerNode || this.focusNode).innerHTML = c }
                })
            })
        }, "cbtree/store/Eventable": function () {
            define("cbtree/store/Eventable", ["dojo/_base/lang", "dojo/Deferred", "dojo/when", "../util/Mutex", "../Evented"], function (j, m, h, f, c) {
                return function (e) {
                    function d(a,
                    c) { e[a] && "function" === typeof e[a] && (b[a] = e[a], e[a] = c) } var b = {}, a = new f; if ("function" == typeof e.emit && !0 === e.eventable) return e; e = j.delegate(e, new c); e.eventable = !0; d("add", function (c, d) { var f = b.add.apply(e, arguments); h(f, function (a) { a && e.emit("new", { type: "new", detail: { item: c } }) }, a.onError); return f }); d("put", function (c, d) {
                        var f = arguments; return a.aquire(function () {
                            h(e.get(e.getIdentity(c)), function (d) {
                                var m = j.mixin(null, d), n = b.put.apply(e, f); h(n, function (b) {
                                    a.release(b); d ? e.emit("change", {
                                        type: "change",
                                        detail: { item: c, oldItem: m }
                                    }) : e.emit("new", { type: "new", detail: { item: c } })
                                }, a.onError)
                            }, function () { var d = b.put.apply(e, f); h(d, function (b) { a.release(b); e.emit("new", { type: "new", detail: { item: c } }) }, a.onError) })
                        })
                    }); d("remove", function (c, d) { var f = arguments; return a.aquire(function () { h(e.get(c), function (c) { var d = c ? j.mixin({}, c) : null, c = b.remove.apply(e, f); h(c, function (b) { a.release(b); d && e.emit("delete", { type: "delete", detail: { item: d } }) }) }, a.onError) }) }); return e
                }
            })
        }, "dijit/form/_FormWidget": function () {
            define("dijit/form/_FormWidget",
            "dojo/_base/declare,dojo/has,dojo/_base/kernel,dojo/ready,../_Widget,../_CssStateMixin,../_TemplatedMixin,./_FormWidgetMixin".split(","), function (j, m, h, f, c, e, d, b) {
                m("dijit-legacy-requires") && f(0, function () { require(["dijit/form/_FormValueWidget"]) }); return j("dijit.form._FormWidget", [c, d, e, b], {
                    setDisabled: function (a) { h.deprecated("setDisabled(" + a + ") is deprecated. Use set('disabled'," + a + ") instead.", "", "2.0"); this.set("disabled", a) }, setValue: function (a) {
                        h.deprecated("dijit.form._FormWidget:setValue(" +
                        a + ") is deprecated.  Use set('value'," + a + ") instead.", "", "2.0"); this.set("value", a)
                    }, getValue: function () { h.deprecated(this.declaredClass + "::getValue() is deprecated. Use get('value') instead.", "", "2.0"); return this.get("value") }, postMixInProperties: function () { this.nameAttrSetting = this.name ? 'name="' + this.name.replace(/"/g, "&quot;") + '"' : ""; this.inherited(arguments) }, _setTypeAttr: null
                })
            })
        }, "url:dijit/templates/TreeNode.html": '<div class="dijitTreeNode" role="presentation"\n\t><div data-dojo-attach-point="rowNode" class="dijitTreeRow dijitInline" role="presentation"\n\t\t><div data-dojo-attach-point="indentNode" class="dijitInline"></div\n\t\t><img src="${_blankGif}" alt="" data-dojo-attach-point="expandoNode" class="dijitTreeExpando" role="presentation"\n\t\t/><span data-dojo-attach-point="expandoNodeText" class="dijitExpandoText" role="presentation"\n\t\t></span\n\t\t><span data-dojo-attach-point="contentNode"\n\t\t\tclass="dijitTreeContent" role="presentation">\n\t\t\t<img src="${_blankGif}" alt="" data-dojo-attach-point="iconNode" class="dijitIcon dijitTreeIcon" role="presentation"\n\t\t\t/><span data-dojo-attach-point="labelNode" class="dijitTreeLabel" role="treeitem" tabindex="-1" aria-selected="false"></span>\n\t\t</span\n\t></div>\n\t<div data-dojo-attach-point="containerNode" class="dijitTreeContainer" role="presentation" style="display: none;"></div>\n</div>\n',
        "dijit/tree/_dndContainer": function () {
            define("dijit/tree/_dndContainer", "dojo/aspect,dojo/_base/declare,dojo/dom-class,dojo/_base/event,dojo/_base/lang,dojo/on,dojo/touch".split(","), function (j, m, h, f, c, e, d) {
                return m("dijit.tree._dndContainer", null, {
                    constructor: function (b, a) {
                        this.tree = b; this.node = b.domNode; c.mixin(this, a); this.current = null; this.containerState = ""; h.add(this.node, "dojoDndContainer"); this.events = [e(this.node, d.enter, c.hitch(this, "onOverEvent")), e(this.node, d.leave, c.hitch(this, "onOutEvent")),
                        j.after(this.tree, "_onNodeMouseEnter", c.hitch(this, "onMouseOver"), !0), j.after(this.tree, "_onNodeMouseLeave", c.hitch(this, "onMouseOut"), !0), e(this.node, "dragstart", c.hitch(f, "stop")), e(this.node, "selectstart", c.hitch(f, "stop"))]
                    }, destroy: function () { for (var b; b = this.events.pop() ;) b.remove(); this.node = this.parent = null }, onMouseOver: function (b) { this.current = b }, onMouseOut: function () { this.current = null }, _changeState: function (b, a) {
                        var c = "dojoDnd" + b, d = b.toLowerCase() + "State"; h.replace(this.node, c + a, c + this[d]);
                        this[d] = a
                    }, _addItemClass: function (b, a) { h.add(b, "dojoDndItem" + a) }, _removeItemClass: function (b, a) { h.remove(b, "dojoDndItem" + a) }, onOverEvent: function () { this._changeState("Container", "Over") }, onOutEvent: function () { this._changeState("Container", "") }
                })
            })
        }, "dijit/tree/dndSource": function () {
            define("dijit/tree/dndSource", "dojo/_base/array,dojo/_base/connect,dojo/_base/declare,dojo/dom-class,dojo/dom-geometry,dojo/_base/lang,dojo/on,dojo/touch,dojo/topic,dojo/dnd/Manager,./_dndSelector".split(","), function (j,
            m, h, f, c, e, d, b, a, k, n) {
                return h("dijit.tree.dndSource", n, {
                    isSource: !0, accept: ["text", "treeNode"], copyOnly: !1, dragThreshold: 5, betweenThreshold: 0, generateText: !0, constructor: function (b, c) {
                        c || (c = {}); e.mixin(this, c); var d = c.accept instanceof Array ? c.accept : ["text", "treeNode"]; this.accept = null; if (d.length) { this.accept = {}; for (var k = 0; k < d.length; ++k) this.accept[d[k]] = 1 } this.mouseDown = this.isDragging = !1; this.targetBox = this.targetAnchor = null; this.dropPosition = ""; this._lastY = this._lastX = 0; this.sourceState = "";
                        this.isSource && f.add(this.node, "dojoDndSource"); this.targetState = ""; this.accept && f.add(this.node, "dojoDndTarget"); this.topics = [a.subscribe("/dnd/source/over", e.hitch(this, "onDndSourceOver")), a.subscribe("/dnd/start", e.hitch(this, "onDndStart")), a.subscribe("/dnd/drop", e.hitch(this, "onDndDrop")), a.subscribe("/dnd/cancel", e.hitch(this, "onDndCancel"))]
                    }, checkAcceptance: function () { return !0 }, copyState: function (a) { return this.copyOnly || a }, destroy: function () {
                        this.inherited(arguments); for (var a; a = this.topics.pop() ;) a.remove();
                        this.targetAnchor = null
                    }, _onDragMouse: function (a, b) {
                        var d = k.manager(), e = this.targetAnchor, f = this.current, h = this.dropPosition, j = "Over"; if (f && 0 < this.betweenThreshold) { if (!this.targetBox || e != f) this.targetBox = c.position(f.rowNode, !0); a.pageY - this.targetBox.y <= this.betweenThreshold ? j = "Before" : a.pageY - this.targetBox.y >= this.targetBox.h - this.betweenThreshold && (j = "After") } if (b || f != e || j != h) {
                            e && this._removeItemClass(e.rowNode, h); f && this._addItemClass(f.rowNode, j); if (f) if (f == this.tree.rootNode && "Over" != j) d.canDrop(!1);
                            else { e = !1; if (d.source == this) for (var m in this.selection) if (this.selection[m].item === f.item) { e = !0; break } e ? d.canDrop(!1) : this.checkItemAcceptance(f.rowNode, d.source, j.toLowerCase()) && !this._isParentChildDrop(d.source, f.rowNode) ? d.canDrop(!0) : d.canDrop(!1) } else d.canDrop(!1); this.targetAnchor = f; this.dropPosition = j
                        }
                    }, onMouseMove: function (a) {
                        if (!(this.isDragging && "Disabled" == this.targetState)) {
                            this.inherited(arguments); var b = k.manager(); if (this.isDragging) this._onDragMouse(a); else if (this.mouseDown && this.isSource &&
                            (Math.abs(a.pageX - this._lastX) >= this.dragThreshold || Math.abs(a.pageY - this._lastY) >= this.dragThreshold)) { var c = this.getSelectedTreeNodes(); if (c.length) { if (1 < c.length) { var d = this.selection, e = 0, f = [], h, n; a: for (; h = c[e++];) { for (n = h.getParent() ; n && n !== this.tree; n = n.getParent()) if (d[n.id]) continue a; f.push(h) } c = f } c = j.map(c, function (a) { return a.domNode }); b.startDrag(this, c, this.copyState(m.isCopyKey(a))); this._onDragMouse(a, !0) } }
                        }
                    }, onMouseDown: function (a) {
                        this.mouseDown = !0; this.mouseButton = a.button; this._lastX =
                        a.pageX; this._lastY = a.pageY; this.inherited(arguments)
                    }, onMouseUp: function (a) { if (this.mouseDown) this.mouseDown = !1, this.inherited(arguments) }, onMouseOut: function () { this.inherited(arguments); this._unmarkTargetAnchor() }, checkItemAcceptance: function () { return !0 }, onDndSourceOver: function (a) { this != a ? (this.mouseDown = !1, this._unmarkTargetAnchor()) : this.isDragging && k.manager().canDrop(!1) }, onDndStart: function (a, b, c) {
                        this.isSource && this._changeState("Source", this == a ? c ? "Copied" : "Moved" : ""); this._changeState("Target",
                        this.checkAcceptance(a, b) ? "" : "Disabled"); this == a && k.manager().overSource(this); this.isDragging = !0
                    }, itemCreator: function (a) { return j.map(a, function (a) { return { id: a.id, name: a.textContent || a.innerText || "" } }) }, onDndDrop: function (a, b, c) {
                        if ("Over" == this.containerState) {
                            var d = this.tree, e = d.model, f = this.targetAnchor; this.isDragging = !1; var k, h, m; k = f && f.item || d.item; "Before" == this.dropPosition || "After" == this.dropPosition ? (k = f.getParent() && f.getParent().item || d.item, h = f.getIndexInParent(), "After" == this.dropPosition ?
                            (h = f.getIndexInParent() + 1, m = f.getNextSibling() && f.getNextSibling().item) : m = f.item) : k = f && f.item || d.item; var n; j.forEach(b, function (d, B) { var s = a.getItem(d.id); if (-1 != j.indexOf(s.type, "treeNode")) var w = s.data, y = w.item, C = w.getParent().item; a == this ? ("number" == typeof h && k == C && w.getIndexInParent() < h && (h -= 1), e.pasteItem(y, C, k, c, h, m)) : e.isItem(y) ? e.pasteItem(y, C, k, c, h, m) : (n || (n = this.itemCreator(b, f.rowNode, a)), e.newItem(n[B], k, h, m)) }, this); this.tree._expandNode(f)
                        } this.onDndCancel()
                    }, onDndCancel: function () {
                        this._unmarkTargetAnchor();
                        this.mouseDown = this.isDragging = !1; delete this.mouseButton; this._changeState("Source", ""); this._changeState("Target", "")
                    }, onOverEvent: function () { this.inherited(arguments); k.manager().overSource(this) }, onOutEvent: function () { this._unmarkTargetAnchor(); var a = k.manager(); this.isDragging && a.canDrop(!1); a.outSource(this); this.inherited(arguments) }, _isParentChildDrop: function (a, b) {
                        if (!a.tree || a.tree != this.tree) return !1; for (var c = a.tree.domNode, d = a.selection, e = b.parentNode; e != c && !d[e.id];) e = e.parentNode; return e.id &&
                        d[e.id]
                    }, _unmarkTargetAnchor: function () { if (this.targetAnchor) this._removeItemClass(this.targetAnchor.rowNode, this.dropPosition), this.dropPosition = this.targetBox = this.targetAnchor = null }, _markDndStatus: function (a) { this._changeState("Source", a ? "Copied" : "Moved") }
                })
            })
        }, "dijit/tree/ForestStoreModel": function () {
            define("dijit/tree/ForestStoreModel", ["dojo/_base/array", "dojo/_base/declare", "dojo/_base/kernel", "dojo/_base/lang", "./TreeStoreModel"], function (j, m, h, f, c) {
                return m("dijit.tree.ForestStoreModel",
                c, {
                    rootId: "$root$", rootLabel: "ROOT", query: null, constructor: function (c) { this.root = { store: this, root: !0, id: c.rootId, label: c.rootLabel, children: c.rootChildren } }, mayHaveChildren: function (c) { return c === this.root || this.inherited(arguments) }, getChildren: function (c, d, b) { c === this.root ? this.root.children ? d(this.root.children) : this.store.fetch({ query: this.query, onComplete: f.hitch(this, function (a) { this.root.children = a; d(a) }), onError: b }) : this.inherited(arguments) }, isItem: function (c) { return c === this.root ? !0 : this.inherited(arguments) },
                    fetchItemByIdentity: function (c) { if (c.identity == this.root.id) { var d = c.scope || h.global; c.onItem && c.onItem.call(d, this.root) } else this.inherited(arguments) }, getIdentity: function (c) { return c === this.root ? this.root.id : this.inherited(arguments) }, getLabel: function (c) { return c === this.root ? this.root.label : this.inherited(arguments) }, newItem: function (c, d, b) { return d === this.root ? (this.onNewRootItem(c), this.store.newItem(c)) : this.inherited(arguments) }, onNewRootItem: function () { }, pasteItem: function (c, d, b, a, f) {
                        if (d ===
                        this.root && !a) this.onLeaveRoot(c); this.inherited(arguments, [c, d === this.root ? null : d, b === this.root ? null : b, a, f]); if (b === this.root) this.onAddToRoot(c)
                    }, onAddToRoot: function () { }, onLeaveRoot: function () { }, _requeryTop: function () { var c = this.root.children || []; this.store.fetch({ query: this.query, onComplete: f.hitch(this, function (d) { this.root.children = d; if (c.length != d.length || j.some(c, function (b, a) { return d[a] != b })) this.onChildrenChange(this.root, d) }) }) }, onNewItem: function (c, d) { this._requeryTop(); this.inherited(arguments) },
                    onDeleteItem: function (c) { -1 != j.indexOf(this.root.children, c) && this._requeryTop(); this.inherited(arguments) }, onSetItem: function (c, d, b, a) { this._requeryTop(); this.inherited(arguments) }
                })
            })
        }, "dojo/promise/all": function () {
            define("dojo/promise/all", ["../_base/array", "../Deferred", "../when"], function (j, m, h) {
                var f = j.some; return function (c) {
                    var e, d; c instanceof Array ? d = c : c && "object" === typeof c && (e = c); var b, a = []; if (e) { d = []; for (var k in e) Object.hasOwnProperty.call(e, k) && (a.push(k), d.push(e[k])); b = {} } else d &&
                    (b = []); if (!d || !d.length) return (new m).resolve(b); var j = new m; j.promise.always(function () { b = a = null }); var g = d.length; f(d, function (c, d) { e || a.push(d); h(c, function (c) { j.isFulfilled() || (b[a[d]] = c, 0 === --g && j.resolve(b)) }, j.reject); return j.isFulfilled() }); return j.promise
                }
            })
        }, "cbtree/util/TOC": function () {
            define("cbtree/util/TOC", "module,dojo/_base/declare,dojo/_base/lang,dijit/Destroyable,dijit/registry,dijit/tree/dndSource,../Evented,../Tree,../extensions/TreeStyling,../model/TreeStoreModel,../store/ObjectStore,../store/extensions/Ancestry,../errors/createError!../errors/CBTErrors.json,./QueryEngine,./shim/Array".split(","),
            function (j, m, h, f, c, e, d, b, a, k, n, g, p, q) {
                function o(a, b) { function c(a) { var b = a.getParent(); return b && b != a.tree.rootNode ? c(b) : a } function d(a, b) { return a.getChildren().some(function (a) { return a != b ? d(a, b) : !0 }) } var e = c(a); return d(e, b) } var l = p(j.id); return m([f, d], {
                    checked: !1, model: null, name: "Table Of Content", store: null, tree: null, constructor: function (a, c) {
                        var d = this; m.safeMixin(this, a); this.store = new n({ data: [{ id: "ROOT", name: this.name, type: "ROOT" }] }); this.model = new k({
                            store: this.store, enabledAttr: "enabled",
                            query: { type: "ROOT" }, checkedAll: !1
                        }); this.tree = new b({ model: this.model, checkItemAcceptance: this._acceptEntry, clickEventCheckBox: !1, dndController: e, betweenThreshold: 5, openOnDblClick: this.openOnDblClick || !1, openOnClick: this.openOnClick || !1, valueToIconMap: this.valueToIconMap || null, enableDelete: this.enableDelete || !1, deleteRecursive: this.deleteRecursive || !1, persist: !1, showRoot: !0 }, c); this.own(this.tree.on("checkBoxClick", function () { d.onCheckBoxClick.apply(d, arguments) }), this.tree.on("Dblclick", function () { d.onDblClick.apply(arguments) }),
                        this.tree.on("click", function () { d.onClick.apply(d, arguments) }), this.model.on("pasteItem", function () { d.onMoved(d, arguments) }), this.model.on("delete", function () { d.onDelete.apply(d, arguments) }))
                    }, destroy: function () { this.inherited(arguments); this.store.destroy(); this.model.destroy(); this.tree.destroy() }, _acceptEntry: function (a, b) {
                        var d = c.getEnclosingWidget(a), e = d.tree, f = e.model.store, g; if (b.tree != e || d == e.rootNode) return !1; for (g in b.selection) if (e = b.selection[g], f.getIdentity(e.item), !o(d, e)) return !1;
                        return !0
                    }, _getIdentity: function (a) { if ("[object Object]" == {}.toString.call(a)) return this.store.getIdentity(a); if ("string" == typeof a || "number" == typeof a) return a }, _makeEntry: function (a, b) {
                        if (a && a.name) {
                            if (a.id && "string" != typeof a.id && "number" != typeof a.id) throw new l("InvalidProperty", "_makeEntry", "Property: id"); var c = b && b.checkbox || !0, d = b && b.readOnly || !1, e = this.store.get(b.parent); if (e) { if (c) a.checked = this.checked, a.enabled = !d; b.parent = e; return a } throw new l("NotFound", "_makeEntry", "Parent object not found");
                        } throw new l("InvalidProperty", "_makeEntry", "Property: name");
                    }, addHeader: function (a, b) { if (a && a.id) { var c = this._getIdentity(b && b.parent) || "ROOT", b = h.mixin(b, { parent: c }), a = this._makeEntry(a, b); a.type = "HEADER-" + this.store.getAncestors(b.parent).length; return this.get(this.store.add(a, { parent: b.parent })) } throw new l("PropertyMissing", "addHeader"); }, addEntry: function (a, b) {
                        if (a && a.type) {
                            var c = this._getIdentity(b && b.parent) || null, b = h.mixin(b, { parent: c }), a = this._makeEntry(a, b); return this.get(this.store.add(a,
                            { parent: b.parent }))
                        }
                    }, get: function (a) { return this.store.get(a) }, getChildren: function (a) { return this.store.getChildren(a) }, getChecked: function (a) { return this.model.getChecked(a) }, getDescendants: function (a, b) { var c = this.store.getDescendants(a); c && b && (c = q(b)(c)); return c }, query: function (a, b) { return this.store.query(a, b) }, setChecked: function (a, b) { return this.model.setChecked(a, !!b) }, startup: function () { this.tree.startup() }, toString: function () { return "[object TOC]" }, onCheckBoxClick: function () { }, onClick: function () { },
                    onDblClick: function () { }, onDelete: function () { }, onMoved: function () { }
                })
            })
        }, "dijit/_TemplatedMixin": function () {
            define("dijit/_TemplatedMixin", "dojo/_base/lang,dojo/touch,./_WidgetBase,dojo/string,dojo/cache,dojo/_base/array,dojo/_base/declare,dojo/dom-construct,dojo/sniff,dojo/_base/unload".split(","), function (j, m, h, f, c, e, d, b, a, k) {
                var n = d("dijit._TemplatedMixin", null, {
                    templateString: null, templatePath: null, _skipNodeCache: !1, _earlyTemplatedStartup: !1, constructor: function () {
                        this._attachPoints = []; this._attachEvents =
                        []
                    }, _stringRepl: function (a) { var b = this.declaredClass, c = this; return f.substitute(a, this, function (a, d) { "!" == d.charAt(0) && (a = j.getObject(d.substr(1), !1, c)); if ("undefined" == typeof a) throw Error(b + " template:" + d); return null == a ? "" : "!" == d.charAt(0) ? a : a.toString().replace(/"/g, "&quot;") }, this) }, buildRendering: function () {
                        if (!this.templateString) this.templateString = c(this.templatePath, { sanitize: !0 }); var a = n.getCachedTemplate(this.templateString, this._skipNodeCache, this.ownerDocument), d; if (j.isString(a)) {
                            if (d =
                            b.toDom(this._stringRepl(a), this.ownerDocument), 1 != d.nodeType) throw Error("Invalid template: " + a);
                        } else d = a.cloneNode(!0); this.domNode = d; this.inherited(arguments); this._attachTemplateNodes(d, function (a, b) { return a.getAttribute(b) }); this._beforeFillContent(); this._fillContent(this.srcNodeRef)
                    }, _beforeFillContent: function () { }, _fillContent: function (a) { var b = this.containerNode; if (a && b) for (; a.hasChildNodes() ;) b.appendChild(a.firstChild) }, _attachTemplateNodes: function (a, b) {
                        for (var c = j.isArray(a) ? a : a.all ||
                        a.getElementsByTagName("*"), d = j.isArray(a) ? 0 : -1; 0 > d || c[d]; d++) {
                            var e = -1 == d ? a : c[d]; if (!this.widgetsInTemplate || !b(e, "dojoType") && !b(e, "data-dojo-type")) {
                                var f = b(e, "dojoAttachPoint") || b(e, "data-dojo-attach-point"); if (f) for (var k = f.split(/\s*,\s*/) ; f = k.shift() ;) j.isArray(this[f]) ? this[f].push(e) : this[f] = e, this._attachPoints.push(f); if (f = b(e, "dojoAttachEvent") || b(e, "data-dojo-attach-event")) for (var k = f.split(/\s*,\s*/), h = j.trim; f = k.shift() ;) if (f) {
                                    var n = null; -1 != f.indexOf(":") ? (n = f.split(":"), f = h(n[0]),
                                    n = h(n[1])) : f = h(f); n || (n = f); this._attachEvents.push(this.connect(e, m[f] || f, n))
                                }
                            }
                        }
                    }, destroyRendering: function () { e.forEach(this._attachPoints, function (a) { delete this[a] }, this); this._attachPoints = []; e.forEach(this._attachEvents, this.disconnect, this); this._attachEvents = []; this.inherited(arguments) }
                }); n._templateCache = {}; n.getCachedTemplate = function (a, c, d) {
                    var e = n._templateCache, k = a, h = e[k]; if (h) { try { if (!h.ownerDocument || h.ownerDocument == (d || document)) return h } catch (j) { } b.destroy(h) } a = f.trim(a); if (c || a.match(/\$\{([^\}]+)\}/g)) return e[k] =
                    a; c = b.toDom(a, d); if (1 != c.nodeType) throw Error("Invalid template: " + a); return e[k] = c
                }; a("ie") && k.addOnWindowUnload(function () { var a = n._templateCache, c; for (c in a) { var d = a[c]; "object" == typeof d && b.destroy(d); delete a[c] } }); j.extend(h, { dojoAttachEvent: "", dojoAttachPoint: "" }); return n
            })
        }, "cbtree/store/handlers/ifrsHandler": function () {
            define("cbtree/store/handlers/ifrsHandler", ["dojo/_base/lang", "dojo/date/stamp", "dojo/json", "../../util/shim/Array"], function (j, m, h) {
                function f(c) {
                    return "[object Object]" ==
                    Object.prototype.toString.call(c)
                } function c(c) { return "[object Function]" == Object.prototype.toString.call(c) } var e = "cbtree/store/handlers/ifrsHandler"; return function (d) {
                    this.childProperty = ["children"]; this.parentProperty = "parent"; this.idProperty = "id"; this.referenceToId = !0; this.typeMap = {}; var b = this; this.handler = function (a) {
                        function d(a) {
                            var b = a[l], c; b ? "number" == typeof b && b > t && (t = Math.floor(b + 1)) : b = t++; a[l] = b; u[b] = a; x.push(a); for (c in a) if (-1 != o.indexOf(c)) {
                                var e = a[c]; e && e instanceof Array && e.forEach(function (a) {
                                    f(a) &&
                                    !a._reference && (a[q] = b, d(a))
                                })
                            }
                        } function j(a, b) { var c; f(a) ? c = x.filter(function (b) { for (var c in a) if (b[c] != a[c]) return !1; return !0 })[0] : (c = u[a]) || -1 == z.indexOf(a) && z.push(a); return c && b ? c[l] : c } function g(a, b) {
                            if (r) { var d = r[a]; if (d) { if (c(d)) return new d(b); if (f(d)) { var g = d.deserialize, d = d.type; if (c(g)) return g(b); if (c(d)) return new d(b) } } throw new TypeError(e + "::handler::mapType(): constructor missing for datatype: [" + a + "]"); } throw new TypeError(e + "::handler::mapType(): custom type detected but no mapping table available");
                        } function m(a) { var b = a[l], c; for (c in a) { var d = a[c]; d && (q && -1 != o.indexOf(c) ? (d instanceof Array && d.forEach(function (a) { if (a._reference && (a = a._reference)) if (a = j(a, !1)) { var c = a[q]; c ? c.push(b) : c = [b]; a[q] = c; B = Math.max(c.length, B) } }), delete a[c]) : d instanceof Array ? (d = d.map(function (a) { if (f(a)) { if (a._reference) return j(a._reference, v); if (a._type) return g(a._type, a._value) } return a }), a[c] = d.filter(function (a) { return !!a })) : f(d) && (d._reference ? a[c] = j(d._reference, v) : d._type && (a[c] = g(d._type, d._value)))) } }
                        var q = b.parentProperty, o = b.childProperty, l = b.idProperty, r = b.typeMap, v = b.referenceToId, t = 1, x = [], z = [], u = {}, B = 0; if ((a = h.parse(a.text || a.data)) && a.items) l = a.identifier || l, a.items.forEach(d), x.forEach(m), 1 == B && x.forEach(function (a) { a[q] = a[q] ? a[q][0] : void 0 }), 0 < z.length && console.warn("Undefined references: " + z); else throw new TypeError(e + "::handler(): invalid IFRS file format"); return x
                    }; this.set = function (a, b) {
                        if (a) { if (f(a)) for (var c in a) this.set(c, a[c]); this[a] = b } this.childProperty = this.childProperty instanceof
                        Array ? this.childProperty : [this.childProperty]; this.typeMap = this.typeMap || {}; this.typeMap.Date || (this.typeMap.Date = { type: Date, deserialize: function (a) { return m.fromISOString(a) } })
                    }; d && this.set(d)
                }
            })
        }, "cbtree/model/_base/CheckedStoreModel": function () {
            define("cbtree/model/_base/CheckedStoreModel", "module,dojo/_base/declare,dojo/_base/lang,dojo/Deferred,dojo/when,./BaseStoreModel,../../errors/createError!../../errors/CBTErrors.json".split(","), function (j, m, h, f, c, e, d) {
                var b = d(j.id); return m([e], {
                    checkedAll: !0,
                    checkedAttr: "checked", checkedRoot: !1, checkedState: !1, checkedStrict: !0, enabledAttr: "", multiState: !0, normalize: !0, _validating: 0, _checkedInherit: !0, constructor: function () { if (!this._writeEnabled) throw new b("MethodMissing", "constructor", "Store must be write enabled, no put() supported"); this.set("checkedStrict", this.checkedStrict); if (!0 === this.checkedStrict) this._loadOptions = { all: !0 }; this._validateDefer = new f }, _checkedAttrSetter: function (a) {
                        if ("string" == typeof a) {
                            if (/\./.test(a)) throw new b("InvalidType",
                            "set", "checkedAttr can not be a dot separated string");
                        } else throw new b("InvalidType", "set", "checkedAttr value must be a string"); return this.checkedAttr
                    }, _checkedStrictSetter: function (a) { a = a.toLowerCase ? a.toLowerCase() : !!a; this._checkedInherit = !0; switch (a) { case !1: this._checkedInherit = !1; break; case !0: break; case "inherit": a = !1; break; default: throw new b("InvalidType", "set", "invalid checkedStrict value"); } return this.checkedStrict = a }, _enabledAttrSetter: function (a) {
                        if ("string" === typeof a) {
                            if (this.enabledAttr !==
                            a) throw new b("ReadOnly", "set", "property enabledAttr is read-only");
                        } else throw new b("InvalidType", "set", "enabledAttr value must be a string"); return this.enabledAttr
                    }, getChecked: function (a) { if (a != this.root || this.checkedRoot) { var b = a[this.checkedAttr]; return void 0 == b && this.checkedAll ? (this._setChecked(a, this.checkedState), this.checkedState) : b } }, getEnabled: function (a) { var b = !0; this.enabledAttr && (b = a[this.enabledAttr]); return void 0 == b || !!b }, setChecked: function (a, b) {
                        !this.checkedStrict && !this._checkedInherit ?
                        this._setChecked(a, b) : this._updateCheckedChild(a, b)
                    }, setEnabled: function (a, b) { if (this.enabledAttr) return this._setValue(a, this.enabledAttr, !!b) }, validateData: function () { }, _getCompositeState: function (a) { var b = !1, c = !1, d = !1, e, f; a.some(function (a) { f = this.getChecked(a); d |= "mixed" == f; switch (f) { case !0: b = !0; break; case !1: c = !0 } return d }, this); if (d || b || c) e = (d |= !(b ^ c)) ? "mixed" : b ? !0 : !1; return e }, _normalizeState: function (a, b) { return this.multiState && "mixed" == b ? this.normalize && !this.mayHaveChildren(a) ? !0 : b : !!b },
                    _setChecked: function (a, b) { var c = !1, c = this._normalizeState(a, b), d = a[this.checkedAttr]; return (void 0 !== d || this.checkedAll) && (d != c || c != b) ? (this._setValue(a, this.checkedAttr, c), !0) : !1 }, _updateCheckedChild: function (a, b) { var c = this; this._setChecked(a, b); this.getChildren(a, function (a) { a.forEach(function (a) { c._updateCheckedChild(a, b) }) }, function (a) { console.error(a) }) }, _updateCheckedParent: function (a, b) {
                        if (this.checkedStrict && a) {
                            var c = this.getParents(a), d = this.getChecked(a), e = this, f; c.then(function (a) {
                                a.forEach(function (a) {
                                    (d !==
                                    e.getChecked(a) || b) && e.getChildren(a, function (b) { f = e._getCompositeState(b); void 0 !== f && e._setChecked(a, f) }, e.onError)
                                }, this)
                            })
                        }
                    }, _validateChildren: function (a, b) {
                        var c, d; this._validating += 1; b = b instanceof Array ? b : [b]; b.forEach(function (a) { if (this.mayHaveChildren(a)) this.getChildren(a, h.hitch(this, function (b) { this._validateChildren(a, b) }), function (a) { console.error(a) }); else if (c = this.getChecked(a)) d = this.normalize ? !!c : c, c != d && this._setValue(a, this.checkedAttr, d) }, this); c = this.getChecked(a); d = this._getCompositeState(b);
                        void 0 !== c && void 0 !== d && c != d && this._setChecked(a, d); this._validating--; this._validating || this._onDataValidated()
                    }, _validateStore: function () { var a = this; this._validateDefer = new f; this.checkedStrict ? this.store.isValidated ? this._onDataValidated() : this._validating || this.getRoot(function (b) { a.getChildren(b, function (c) { a._validateChildren(b, c) }, a.onError) }, a.onError) : this._validateDefer.resolve(); return this._validateDefer.promise }, _onChildrenChange: function (a, b) {
                        var c = b[0] || null, d = this; this.checkedStrict &&
                        (c ? this._observable ? setTimeout(function () { d._updateCheckedParent(c, !0) }, 0) : d._updateCheckedParent(c, !0) : this._observable ? setTimeout(function () { d._setChecked(a, a[d.checkedAttr]) }, 0) : this._setChecked(a, a[this.checkedAttr])); this.onChildrenChange(a, b)
                    }, _onDataValidated: function () { this.store.isValidated = !0; this.onDataValidated(); this._validateDefer.resolve() }, _onSetItem: function (a, b, c, d) {
                        var e = this; this.checkedStrict && b === this.checkedAttr && (this._observable ? setTimeout(function () {
                            e._updateCheckedParent(a,
                            !1)
                        }, 0) : e._updateCheckedParent(a, !1)); return this.inherited(arguments)
                    }, _onStoreClosed: function (a, b) { this._resetPending || (a && delete this.store.isValidated, this.inherited(arguments)) }, onDataValidated: function () { }
                })
            })
        }, "cbtree/models/FileStoreModel": function () {
            define("cbtree/models/FileStoreModel", "dojo/_base/array,dojo/_base/declare,dojo/_base/lang,dojo/_base/window,dojo/aspect,./TreeStoreModel".split(","), function (j, m, h, f, c, e) {
                return m([e], {
                    deferItemLoadingUntilExpand: !0, queryOptions: null, sort: null,
                    rootLabel: "ROOT", rootId: "$rootDir$", moduleName: "cbTree/models/FileStoreModel", constructor: function (d) {
                        var b = this.store; this.root = { store: this, root: !0, id: this.rootId, label: this.rootLabel, children: d.rootChildren }; this.root[this.checkedAttr] = this.checkedState; this.hasFakeRoot = !0; this._validateStore = !1; d.queryOptions && this._setQueryOptions(d.queryOptions); d.sort && this._setSortFields(d.sort); if (b.getFeatures()["dojo.data.api.Notification"]) this.connects = this.connects.concat([c.after(b, "onClose", h.hitch(this,
                        "onStoreClose"), !0)]); console.warn("cbTree/models/FileStoreModel has been deprecated and will be removed with dojo 2.0 !!")
                    }, _setQueryOptions: function (c) { if (h.isObject(c)) this.queryOptions = c }, _setSortFields: function (c) { if (h.isArray(c)) { var b = !0; j.forEach(c, function (a) { h.isObject(a) || (b = !1) }); if (b) this.sort = c } }, getChildren: function (c, b, a) {
                        var e = this.store; c === this.root ? this.root.children ? b(this.root.children) : this.store.fetch({
                            query: this.query, queryOptions: this.queryOptions, sort: this.sort, onComplete: h.hitch(this,
                            function (a) { this.root.children = a; b(a) }), onError: a
                        }) : e.fetchChildren({ item: c, query: this.query, queryOptions: this.queryOptions, sort: this.sort, onError: a, scope: this, onComplete: function (a) { b(a) } })
                    }, getParents: function (c) { var b = []; if (c) return c !== this.root && (b = this.store.getParents(c), !b.length) ? [this.root] : b }, mayHaveChildren: function (c) { return c === this.root || this.inherited(arguments) }, fetchItemByIdentity: function (c) { if (c.identity == this.root.id) { var b = c.scope ? c.scope : f.global; c.onItem && c.onItem.call(b, this.root) } else this.inherited(arguments) },
                    getIcon: function (c) { if (this.iconAttr) return c !== this.root ? this.store.getValue(c, this.iconAttr) : this.root[this.iconAttr] }, getIdentity: function (c) { return c === this.root ? this.root.id : this.inherited(arguments) }, getLabel: function (c) { return c === this.root ? this.root.label : this.inherited(arguments) }, isItem: function (c) { return c === this.root ? !0 : this.inherited(arguments) }, isChildOf: function (c, b) { if (c === this.root) { if (-1 !== j.indexOf(this.root.children, b)) return !0 } else return this.inherited(arguments) }, deleteItem: function (c,
                    b, a, e, f) { f = f || window.global; if (c === this.root) { var g = this.root.children || []; if (0 < g.length && (!b || b.call(f, c))) for (c = 0; c < g.length; c++) this.store.deleteItem(g[c], null, a, e, f) } else return this.store.deleteItem(c, b, a, e, f) }, newItem: function () { throw Error(this.moduleName + "::newItem(): Operation not allowed on a File Store."); }, pasteItem: function (c, b, a) {
                        var e = b = ""; this.store.isItem(c) && (e = this.store.getDirectory(c), a !== this.root && (b = a.directory ? this.store.getPath(a) : this.store.getDirectory(a)), e !== b && (a = b +
                        "/" + this.store.getLabel(c), this.store.renameItem(c, a)))
                    }, onDeleteItem: function (c) { -1 != j.indexOf(this.root.children, c) && this._requeryTop(); this.inherited(arguments) }, onNewItem: function (c, b) { b ? (this.getChildren(b.item, h.hitch(this, function (a) { this.onChildrenChange(b.item, a) })), this._updateCheckedParent(c, !0)) : this._requeryTop() }, onSetItem: function (c, b, a, e) { this._queryAttrs.length && -1 != j.indexOf(this._queryAttrs, b) && this._requeryTop(); this.inherited(arguments) }, onStoreClose: function () { }, _requeryTop: function () {
                        var c =
                        this.root.children || []; this.store.fetch({ query: this.query, queryOptions: this.queryOptions, sort: this.sort, onComplete: h.hitch(this, function (b) { this.root.children = b; if (c.length != b.length || j.some(c, function (a, c) { return b[c] != a })) this.onChildrenChange(this.root, b), this._updateCheckedParent(b[0], !0) }) })
                    }
                })
            })
        }, "cbtree/models/ForestStoreModel": function () {
            define("cbtree/models/ForestStoreModel", ["dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/_base/window", "./TreeStoreModel"], function (j, m, h,
            f, c) {
                return m([c], {
                    rootLabel: "ROOT", rootId: "$root$", moduleName: "cbTree/models/ForestStoreModel", constructor: function (c) { this.root = { store: this, root: !0, id: this.rootId, label: this.rootLabel, children: c.rootChildren }; this.root[this.checkedAttr] = this.checkedState; this.hasFakeRoot = !0 }, getChildren: function (c, d, b, a) { c === this.root ? this.root.children ? d(this.root.children) : this.store.fetch(this._mixinFetch({ query: this.query, onComplete: h.hitch(this, function (a) { this.root.children = a; d(a) }), onError: b })) : this.inherited(arguments) },
                    getParents: function (c) { var d = []; if (c) return c !== this.root && (d = this.store.getParents(c), !d.length) ? [this.root] : d }, mayHaveChildren: function (c) { return c === this.root || this.inherited(arguments) }, fetchItemByIdentity: function (c) { if (c.identity == this.root.id) { var d = c.scope ? c.scope : f.global; c.onItem && c.onItem.call(d, this.root) } else this.inherited(arguments) }, getIcon: function (c) { if (this.iconAttr) return c !== this.root ? this.store.getValue(c, this.iconAttr) : this.root[this.iconAttr] }, getIdentity: function (c) {
                        return c ===
                        this.root ? this.root.id : this.inherited(arguments)
                    }, getLabel: function (c) { return c === this.root ? this.root.label : this.inherited(arguments) }, isItem: function (c) { return c === this.root ? !0 : this.inherited(arguments) }, isChildOf: function (c, d) { if (c === this.root) { if (-1 !== j.indexOf(this.root.children, d)) return !0 } else return this.inherited(arguments) }, deleteItem: function (c) { if (c === this.root) { var c = this.root.children || [], d; for (d = 0; d < c.length; d++) this.store.deleteItem(c[d]) } else return this.store.deleteItem(c) }, newItem: function (c,
                    d, b, a) { if (d === this.root) { var f = this.store.newItem(c); this._updateCheckedParent(f); return f } return this.inherited(arguments) }, pasteItem: function (c, d, b, a, f, h) { d === this.root && (a || this.store.detachFromRoot(c)); b === this.root && this.store.attachToRoot(c, f); this.inherited(arguments, [c, d === this.root ? null : d, b === this.root ? null : b, a, f, h]) }, onDeleteItem: function (c) { -1 != j.indexOf(this.root.children, c) && this._requeryTop(); this.inherited(arguments) }, onNewItem: function (c, d) {
                        d ? (this.getChildren(d.item, h.hitch(this,
                        function (b) { this.onChildrenChange(d.item, b) })), this._updateCheckedParent(c, !0)) : this._requeryTop()
                    }, onSetItem: function (c, d, b, a) { this._queryAttrs.length && -1 != j.indexOf(this._queryAttrs, d) && this._requeryTop(); this.inherited(arguments) }, onRootChange: function (c, d) { ("attach" === d || "detach" === d) && this._requeryTop() }, _requeryTop: function () {
                        var c = this.root.children || []; this.store.fetch(this._mixinFetch({
                            query: this.query, onComplete: h.hitch(this, function (d) {
                                this.root.children = d; if (c.length != d.length || j.some(c,
                                function (b, a) { return d[a] != b })) this.onChildrenChange(this.root, d), this._updateCheckedParent(d[0])
                            })
                        }))
                    }
                })
            })
        }, "url:dijit/form/templates/CheckBox.html": '<div class="dijit dijitReset dijitInline" role="presentation"\n\t><input\n\t \t${!nameAttrSetting} type="${type}" ${checkedAttrSetting}\n\t\tclass="dijitReset dijitCheckBoxInput"\n\t\tdata-dojo-attach-point="focusNode"\n\t \tdata-dojo-attach-event="onclick:_onClick"\n/></div>\n', "cbtree/model/FileStoreModel": function () {
            define("cbtree/model/FileStoreModel",
            "module,dojo/_base/declare,dojo/when,./_base/CheckedStoreModel,./_base/Parents,../errors/createError!../errors/CBTErrors.json".split(","), function (j, m, h, f, c, e) {
                var d = e(j.id); return m([f], {
                    constructor: function () { var b = this.store; if (b && b.defaultProperties && "object" == typeof b.defaultProperties) b.defaultProperties[this.checkedAttr] = this.checkedState }, getChildren: function (b, a, c) { this._getChildren(b, function (a) { return this.store.getChildren(a) }, a, c) }, mayHaveChildren: function (b) { return b && !!b.directory },
                    newItem: function () { throw new d("InvalidAccess", "newItem", "Operation not allowed on a FileObjectStore"); }, pasteItem: function (b, a, d) { if (d.directory && d.path != a.path) { new c(b, this.parentAttr); this.getIdentity(a); var e = this; h(this.store.rename(b, d.path + "/" + b.name), function () { e.store.evented || e._childrenChanged([a, d]) }) } }, _onDeleteItem: function (b) {
                        var a = this.getIdentity(b), c = this; h(this.store.get(a, !0), function (b) { b || delete c._objectCache[a] }, function () { delete c._objectCache[a] }); c._deleteCacheEntry(a);
                        c.onDelete(b); this.getParents(b).then(function (a) { c._childrenChanged(a) })
                    }, toString: function () { return "[object FileStoreModel]" }
                })
            })
        }, "cbtree/models/ItemWriteStoreEX": function () {
            define("cbtree/models/ItemWriteStoreEX", ["dojo/_base/array", "dojo/_base/lang", "dojo/data/ItemFileWriteStore"], function (j, m, h) {
                m.extend(h, {
                    _validated: !1, addReference: function (f, c, e, d) {
                        if (!this.isItem(f) || !this.isItem(c)) throw Error("ItemWriteStoreEX::addReference(): refItem and/or parentItem is not a valid store item"); if (f !==
                        c) { var b; c[e] ? (b = c[e], this._addReferenceToMap(f, c, e), "number" === typeof d ? c[e].splice(d, 0, f) : c[e].push(f)) : (this._addReferenceToMap(f, c, e), c[e] = [f]); this.onSet(c, e, b, c[e]); return !0 } throw Error("ItemWriteStoreEX::addReference(): parent and reference items are identical");
                    }, attachToRoot: function (f, c) { this.isRootItem(f) || (f[this._rootItemPropName] = !0, void 0 !== c ? this._arrayOfTopLevelItems.splice(c, 0, f) : this._arrayOfTopLevelItems.push(f), this.onRoot(f, "attach")) }, detachFromRoot: function (f) {
                        this.isRootItem(f) &&
                        (this._removeArrayElement(this._arrayOfTopLevelItems, f), delete f[this._rootItemPropName], this.onRoot(f, "detach"))
                    }, getIdentifierAttr: function () { this._loadFinished || this._forceLoad(); return this._getIdentifierAttribute() }, getParents: function (f) { var c = [], e; if (f) { if (f = f[this._reverseRefMap] || f["backup_" + this._reverseRefMap]) for (e in f) c.push(this._getItemByIdentity(e)); return c } }, isRootItem: function (f) { this._assertIsItem(f); return f[this._rootItemPropName] ? !0 : !1 }, isValidated: function () { return this._validated },
                    itemExist: function (f) { var c, e; if ("object" != typeof f && "undefined" != typeof f) throw Error("ItemWriteStoreEX::itemExist(): argument is not an object"); this._assert(!this._saveInProgress); c = this.getIdentifierAttr(); if (c !== Number && this._itemsByIdentity) { f = f[c]; if ("undefined" === typeof f) throw Error("ItemWriteStoreEX::itemExist(): item has no identity"); if (this._pending._deletedItems[f]) throw Error("ItemWriteStoreEX::itemExist(): item is pending deletion"); e = this._itemsByIdentity[f] } return e }, loadStore: function (f) {
                        function c(a,
                        b) { var c = b.loadArgs || null, e = c.scope; d.onLoad(a); c && c.onComplete && c.onComplete.call(e, a) } var e = f.scope || window.global, d = this; if (this._loadFinished) onComplete && onComplete.call(e, this._allFileItems.length); else { f = { queryOptions: { deep: !0 }, loadArgs: f, onBegin: c, onError: f.onError, scope: this }; try { this.fetch(f) } catch (b) { if (onError) onError.call(e, b); else throw b; } }
                    }, onDelete: function (f) { if (!0 === f[this._rootItemPropName]) this.onRoot(f, "delete") }, onNew: function (f) { if (this.isRootItem(f)) this.onRoot(f, "new") }, onLoad: function () { },
                    onRoot: function () { }, setValidated: function (f) { this._validated = Boolean(f) }, removeReference: function (f, c, e) { if (!this.isItem(f) || !this.isItem(c)) throw Error("ItemWriteStoreEX::removeReference(): refItem and/or parentItem is not a valid store item"); if (c[e]) { this._removeReferenceFromMap(f, c, e); var d = c[e]; if (this._removeArrayElement(c[e], f)) return this._isEmpty(c[e]) && delete c[e], this.onSet(c, e, d, c[e]), !0 } return !1 }
                })
            })
        }, "cbtree/Tree": function () {
            require({ cache: { "url:cbtree/templates/cbtreeNode.html": '<div class="dijitTreeNode" role="presentation">\n\t<div data-dojo-attach-point="rowNode" class="dijitTreeRow" role="presentation">\n\t\t<div data-dojo-attach-point="indentNode" class="dijitInline"></div>\n\t\t<img src="${_blankGif}" alt="" data-dojo-attach-point="expandoNode" class="dijitTreeExpando" role="presentation" />\n\t\t<span data-dojo-attach-point="expandoNodeText" class="dijitExpandoText" role="presentation"></span>\n\t\t<span data-dojo-attach-point="checkBoxNode" class="cbtreeCheckBox" role="presentation"></span>\n\t\t<span data-dojo-attach-point="contentNode" class="dijitTreeContent" role="presentation">\n\t\t\t<img src="${_blankGif}" alt="" data-dojo-attach-point="iconNode" class="dijitIcon dijitTreeIcon" role="presentation"/>\n\t\t\t<span data-dojo-attach-point="labelNode,focusNode" class="dijitTreeLabel" role="treeitem" tabindex="-1" aria-selected="false"></span>\n\t\t</span>\n\t</div>\n\t<div data-dojo-attach-point="containerNode" class="dijitTreeNodeContainer" role="presentation" style="display: none;"></div>\n</div>\n' } });
            define("cbtree/Tree", "module,require,dojo/_base/connect,dojo/_base/declare,dojo/_base/lang,dojo/aspect,dojo/Deferred,dojo/dom-construct,dojo/has,dojo/keys,dojo/on,dojo/topic,dojo/text!./templates/cbtreeNode.html,dijit/registry,dijit/Tree,./CheckBox,./errors/createError!./errors/CBTErrors.json,./util/IE8_Event,./util/shim/Array".split(","), function (j, m, h, f, c, e, d, b, a, k, n, g, p, q, o, l, r, v) {
                var t = r(j.id), x = a("ie"), z = 0, u = f([o._TreeNode], {
                    templateString: p, _checkBox: null, _toggle: !0, _widget: null, constructor: function (a) {
                        var b =
                        { type: l, target: "INPUT", mixin: null, postCreate: null }, d = { multiState: null, checked: void 0, value: "on" }; if (a = a.widget) c.mixin(d, a.args), c.mixin(b, a); b.args = d; this._toggle = "function" == typeof b.type.prototype.toggle; this._widget = b
                    }, _getCheckedAttr: function () { if (this._checkBox) return this.tree.model.getChecked(this.item) }, _getEnabledAttr: function () { return this.tree.model.getEnabled(this.item) }, _set_checked_Attr: function (a) { this._checkBox && this._checkBox.set("checked", a) }, _set_enabled_Attr: function (a) {
                        this._checkBox &&
                        this._checkBox.set("readOnly", !a)
                    }, _setCheckedAttr: function (a) { if (this._checkBox) return this.tree.model.setChecked(this.item, a) }, _setEnabledAttr: function (a) { void 0 === this.tree.model.setEnabled(this.item, a) && this.set("_enabled_", !!a) }, _createCheckBox: function (a) {
                        var d = !0 === this.tree.attachToForm, e = this.tree.model, f = !0, g = e.getChecked(this.item), h = this._widget, j = h.args; "function" == typeof e.getEnabled && (f = e.getEnabled(this.item)); if (void 0 !== g && (j.multiState = a, j.checked = g, j.value = this.label, "function" ==
                        typeof h.mixin && c.hitch(this, h.mixin)(j), this._checkBox = new h.type(j))) { d ? this._checkBox.set("name", this._checkBox.id) : this._checkBox.name = this._checkBox.id; this._checkBox.item = this.item; if (!this.isExpandable && !this.tree.leafCheckBox || this.isExpandable && !this.tree.branchCheckBox) this._checkBox.domNode.style.display = "none"; "function" == typeof this._widget.postCreate && c.hitch(this._checkBox, this._widget.postCreate)(this); b.place(this._checkBox.domNode, this.checkBoxNode, "replace") } this._checkBox && (this.isExpandable ?
                        (this.tree.branchReadOnly || !f) && this._checkBox.set("readOnly", !0) : (this.tree.leafReadOnly || !f) && this._checkBox.set("readOnly", !0))
                    }, _remove: function () {
                        function a(b) { if (!b._destroyed) { var e = d.getIdentity(b.item), f = c._itemNodesMap[e]; 1 == f.length ? delete c._itemNodesMap[e] : (e = f.indexOf(b), -1 != e && f.splice(e, 1)); c.dndController.removeTreeNode(b); b.getChildren().forEach(a); c.persist && b.isExpanded && c._state(b, !1) } } var b = this.getParent(), c = this.tree, d = c.model; a(this); b && this != c.rootNode && b.removeChild(this);
                        this.destroyRecursive()
                    }, _setExpando: function () { this.rowNode.setAttribute("expandable", this.isExpandable.toString()); this.inherited(arguments) }, _toggleCheckBox: function () { var a; this._checkBox && (this._toggle ? a = this._checkBox.toggle() : (a = this._checkBox.get("checked"), a = "mixed" == a ? !0 : !a), this._checkBox.set("checked", a)); return a }, destroy: function () { this._checkbox && (this._checkbox.destroyRecursive(), delete this._checkbox); this.inherited(arguments) }, postCreate: function () {
                        var a = this.tree, b = null; !0 === a.checkBoxes &&
                        this._createCheckBox(a._multiState); a._hasStyling && a._iconAttr && (b = a.get("icon", this.item)) && this.set("_icon_", b); this.set("tooltip", this.title); this.inherited(arguments)
                    }
                }), j = f([o], {
                    attachToForm: !1, branchCheckBox: !0, branchIcons: !0, branchReadOnly: !1, checkBoxes: !0, clickEventCheckBox: !0, closeOnUnchecked: !1, deleteRecursive: !1, enableDelete: !1, leafCheckBox: !0, leafIcons: !0, leafReadOnly: !1, openOnChecked: !1, _multiState: !0, _customWidget: null, _eventAttrMap: null, _dojoRequired: {
                        min: { major: 1, minor: 8 }, max: {
                            major: 1,
                            minor: 99
                        }
                    }, _checkboxBaseClass: l.prototype.baseClass, _assertVersion: function () { if (dojo.version) { var a = 199, b = 0; z = 100 * dojo.version.major + dojo.version.minor; if (this._dojoRequired && (void 0 !== this._dojoRequired.min && (b = 100 * this._dojoRequired.min.major + this._dojoRequired.min.minor), void 0 !== this._dojoRequired.max && (a = 100 * this._dojoRequired.max.major + this._dojoRequired.max.minor), z < b || z > a)) throw new t("InvalidVersion", "_assertVersion"); } else throw new t("UnknownVersion", "_assertVersion"); }, _createTreeNode: function (a) {
                        a.widget =
                        this._customWidget; if (this._hasStyling && this._icon) a.icon = this._icon; return new u(a)
                    }, _onCheckBoxClick: function (a, b) { var c = b._checkBox.get("checked"), d = b.item; this.model.setChecked(d, c); c && this.openOnChecked ? this.expandChecked() : !c && this.closeOnUnchecked && this.collapseUnchecked(); this.onCheckBoxClick(d, b, a); if (this.clickEventCheckBox) this.onClick(d, b, a); this.focusNode(b); g.publish("checkbox", { item: d, node: b, state: c, evt: a }); a.stopPropagation(); return c }, _onClick: function (a, b) {
                        q.getEnclosingWidget(b.target).isInstanceOf(u) &&
                        this.inherited(arguments)
                    }, _onItemChange: function (a, b, d) { if (b = this._eventAttrMap[b]) { var e = this._itemNodesMap[this.model.getIdentity(a)], f = {}; e && (f[b.attribute] = b.value ? "function" == typeof b.value ? c.hitch(this, b.value)(a, b.attribute, d) : b.value : d, e.forEach(function (b) { b.item = a; b.set(f) }, this)) } }, _onItemDelete: function (a) { if (a = this._itemNodesMap[this.model.getIdentity(a)]) a = a.slice(0), a.forEach(function (a) { a._remove() }) }, _onDeleteKey: function (a) {
                        if (109 > z) a = a.evt; h.isCopyKey(a) && this.enableDelete && "function" ==
                        typeof this.model.deleteItem && (a = this.paths.map(function (a) { return a[a.length - 1] }), a.length && this.model.deleteItem(a, this.deleteRecursive))
                    }, _onEnterKey: function (a) { var b = a.node, c = a.evt; !c.altKey && c.keyCode == k.SPACE && this._onSpaceKey(c, b); this.inherited(arguments) }, _onSpaceKey: function (a, b) { b && b._checkBox && !a.altKey && a.keyCode == k.SPACE && (b._toggleCheckBox(), this._onCheckBoxClick(a, b)) }, _onLabelChange: function (a, b) { this.mapEventToAttr(a, b, "label") }, _onModelReset: function () {
                        var a = c.clone(this._openedNodes),
                        b = this.model, e = this; this.onLoadDeferred.always(function () { e.rootNode && !e.rootNode._destroyed && e._onItemDelete(e.rootNode.item); b.ready().then(function () { e.expandChildrenDeferred = new d; e.pendingCommandsDeferred = e.expandChildrenDeferred; if (e.persist) e._openedNodes = a; e._load(); e.onLoadDeferred = e.pendingCommandsPromise; e.onLoadDeferred.then(c.hitch(e, "onLoad")) }, function (a) { throw a; }) })
                    }, _onSubmit: function (a) {
                        var b = a; if (x && 9 > x) b = new v(this.formNode, "submit", { cancelable: !0 }, a), b.defaultPrevented = !!a.returnValue;
                        b.defaultPrevented || !1 === this.onSubmit(this.formNode, this, b) && b.preventDefault(); return !b.defaultPrevented
                    }, _setAttachToFormAttr: function (a) { var b = this; if (a) if ("boolean" === typeof a || "object" === typeof a) "object" === typeof a && !this._hasOnSubmit && m([a.extension || "./extensions/TreeOnSubmit"], function (a) { e.around(b, "onSubmit", function () { return a.prototype.onSubmit }); this._hasOnSubmit = !0 }), this.attachToForm = a; else throw new t("InvalidType", "_setAttachToFormAttr"); else this.attachToForm = !1 }, _setWidgetAttr: function (a) {
                        var b =
                        a, d; if ("string" == typeof a) return this._setWidgetAttr({ type: a }); if (c.isObject(a) && a.hasOwnProperty("type")) if (b = a.type, "function" == typeof b) if (d = b.prototype, this._checkboxBaseClass = b.prototype.baseClass, d && void 0 !== d.checked) { if ("function" == typeof d.get && "function" == typeof d.set) { this._customWidget = a; return } b = "Widget does not support get() and/or set()" } else b = "widget MUST have a 'checked' property"; else {
                            if ("string" == typeof b && ~b.indexOf("/")) {
                                var e = this; m([b], function (b) { a.type = b; e._setWidgetAttr(a) });
                                return
                            } b = "argument is not a valid module id"
                        } else b = "Object is missing required 'type' property"; throw new t("InvalidWidget", "_setWidgetAttr", b);
                    }, collapseUnchecked: function (a) { if ((a = a || this.rootNode) && a.isExpandable && a.isExpanded) a.getChildren(a).forEach(function (a) { this.collapseUnchecked(a) }, this), !1 === this.model.getChecked(a.item) && this._collapseNode(a) }, create: function () { this._assertVersion(); this.inherited(arguments) }, destroy: function () { this.model = null; this.inherited(arguments) }, expandChecked: function (a) {
                        var b =
                        !1; if (!a) a = this.rootNode, b = !a._checkBox; if (a && a.isExpandable && (b || this.model.getChecked(a.item))) a.isExpanded || this._expandNode(a), a.getChildren(a).forEach(function (a) { this.expandChecked(a) }, this)
                    }, getIconStyle: function (a) { var b = this.model.mayHaveChildren(a), c = this.inherited(arguments) || {}; if (b) { if (!this.branchIcons) c.display = "none" } else if (!this.leafIcons) c.display = "none"; return c }, mixinEvent: function (a, b, c) {
                        this.model.isItem(a) && this._eventAttrMap[b] && (this._onItemChange(a, b, c), this.onEvent(a, b,
                        c))
                    }, onCheckBoxClick: function () { }, onEvent: function () { }, onSubmit: function () { }, postMixInProperties: function () { this._eventAttrMap = {}; this.inherited(arguments) }, postCreate: function () {
                        var a = this.domNode.parentNode, b = this.model, d = this; if (this.model) {
                            if (!0 === this.checkBoxes) this._modelOk() ? (this._multiState = b.multiState, this.mapEventToAttr(null, b.get("checkedAttr") || "checked", "_checked_"), b.validateData()) : (console.warn(b.id + "::postCreate(): model does not support getChecked() and/or setChecked()."), this.checkBoxes =
                            !1); e.after(b, "onLabelChange", c.hitch(this, "_onLabelChange"), !0); e.after(b, "onReset", c.hitch(this, "_onModelReset"), !0); this.mapEventToAttr(null, b.get("enabledAttr"), "_enabled_"); this.mapEventToAttr(null, b.get("labelAttr"), "label"); this.inherited(arguments); b = "." + this._checkboxBaseClass; 109 > z ? (this.own(n(this.domNode, n.selector(b, "click"), function (a) { d._onCheckBoxClick(a, q.getEnclosingWidget(this.parentNode)) })), this._onKeyDown(null, {}), this._keyHandlerMap[k.DELETE] = "_onDeleteKey") : (this.own(n(this.containerNode,
                            n.selector(b, "click"), function (a) { d._onCheckBoxClick(a, q.getEnclosingWidget(this.parentNode)) })), this._keyNavCodes[k.DELETE] = c.hitch(this, "_onDeleteKey"), this._keyNavCodes[k.SPACE] = c.hitch(this, "_onSpaceKey")); for (this.on("load", function () { !d.autoExpand && d.openOnChecked && d.expandChecked() }) ; a;) { if ("FORM" === a.nodeName) { n(a, "submit", c.hitch(this, "_onSubmit")); break } a = a.parentNode } this.formNode = a
                        } else throw new t("PropertyMissing", "postCreate", "no model was specified");
                    }, mapEventToAttr: function (a, b,
                    c, d) { "string" == typeof b && "string" == typeof c && b.length && c.length && (a && delete this._eventAttrMap[a], this._eventAttrMap[b] = { attribute: c, value: d }) }, _modelOk: function () { return this.model.getChecked && "function" == typeof this.model.getChecked && this.model.setChecked && "function" == typeof this.model.setChecked ? !0 : !1 }
                }); j._TreeNode = u; return j
            })
        }, "cbtree/util/Mutex": function () {
            define("cbtree/util/Mutex", ["dojo/Deferred"], function (j) {
                return function () {
                    function m() {
                        if (h.length) {
                            var e = h[0]; try { e.cb() } catch (d) {
                                throw c.onError(d),
                                d;
                            } return !0
                        }
                    } var h = [], f = !1, c = this; this.aquire = function (c, d) { return this.then(function () { d ? c.call(d) : c() }) }; this.then = function (c) { c = { cb: c, def: new j }; h.push(c); f || (f = !0, m()); return c.def.promise }; this.release = function (c) { f && (h.shift().def.resolve(c), m() || (f = !1)) }; this.onError = function (c) { f && (h.shift().def.reject(c), m() || (f = !1)) }
                }
            })
        }, "dijit/_WidgetBase": function () {
            define("dijit/_WidgetBase", "require,dojo/_base/array,dojo/aspect,dojo/_base/config,dojo/_base/connect,dojo/_base/declare,dojo/dom,dojo/dom-attr,dojo/dom-class,dojo/dom-construct,dojo/dom-geometry,dojo/dom-style,dojo/has,dojo/_base/kernel,dojo/_base/lang,dojo/on,dojo/ready,dojo/Stateful,dojo/topic,dojo/_base/window,./Destroyable,./registry".split(","),
            function (j, m, h, f, c, e, d, b, a, k, n, g, p, q, o, l, r, v, t, x, z, u) {
                function B(a) { return function (c) { b[c ? "set" : "remove"](this.domNode, a, c); this._set(a, c) } } p.add("dijit-legacy-requires", !q.isAsync); p("dijit-legacy-requires") && r(0, function () { j(["dijit/_base/manager"]) }); var s = {}; return e("dijit._WidgetBase", [v, z], {
                    id: "", _setIdAttr: "domNode", lang: "", _setLangAttr: B("lang"), dir: "", _setDirAttr: B("dir"), textDir: "", "class": "", _setClassAttr: { node: "domNode", type: "class" }, style: "", title: "", tooltip: "", baseClass: "", srcNodeRef: null,
                    domNode: null, containerNode: null, ownerDocument: null, _setOwnerDocumentAttr: function (a) { this._set("ownerDocument", a) }, attributeMap: {}, _blankGif: f.blankGif || j.toUrl("dojo/resources/blank.gif"), postscript: function (a, b) { this.create(a, b) }, create: function (a, b) {
                        this.srcNodeRef = d.byId(b); this._connects = []; this._supportingWidgets = []; if (this.srcNodeRef && "string" == typeof this.srcNodeRef.id) this.id = this.srcNodeRef.id; if (a) this.params = a, o.mixin(this, a); this.postMixInProperties(); if (!this.id) this.id = u.getUniqueId(this.declaredClass.replace(/\./g,
                        "_")), this.params && delete this.params.id; this.ownerDocument = this.ownerDocument || (this.srcNodeRef ? this.srcNodeRef.ownerDocument : x.doc); this.ownerDocumentBody = x.body(this.ownerDocument); u.add(this); this.buildRendering(); var c; if (this.domNode) { this._applyAttributes(); var e = this.srcNodeRef; e && e.parentNode && this.domNode !== e && (e.parentNode.replaceChild(this.domNode, e), c = !0); this.domNode.setAttribute("widgetId", this.id) } this.postCreate(); c && delete this.srcNodeRef; this._created = !0
                    }, _applyAttributes: function () {
                        var a =
                        this.constructor, b = a._setterAttrs; if (!b) { var b = a._setterAttrs = [], c; for (c in this.attributeMap) b.push(c); var a = a.prototype, d; for (d in a) d in this.attributeMap || "_set" + d.replace(/^[a-z]|-[a-zA-Z]/g, function (a) { return a.charAt(a.length - 1).toUpperCase() }) + "Attr" in a && b.push(d) } var e = {}, f; for (f in this.params || {}) e[f] = this[f]; m.forEach(b, function (a) { a in e || this[a] && this.set(a, this[a]) }, this); for (f in e) this.set(f, e[f])
                    }, postMixInProperties: function () { }, buildRendering: function () {
                        if (!this.domNode) this.domNode =
                        this.srcNodeRef || this.ownerDocument.createElement("div"); if (this.baseClass) { var b = this.baseClass.split(" "); this.isLeftToRight() || (b = b.concat(m.map(b, function (a) { return a + "Rtl" }))); a.add(this.domNode, b) }
                    }, postCreate: function () { }, startup: function () { if (!this._started) this._started = !0, m.forEach(this.getChildren(), function (a) { if (!a._started && !a._destroyed && o.isFunction(a.startup)) a.startup(), a._started = !0 }) }, destroyRecursive: function (a) { this._beingDestroyed = !0; this.destroyDescendants(a); this.destroy(a) },
                    destroy: function (a) { function b(c) { c.destroyRecursive ? c.destroyRecursive(a) : c.destroy && c.destroy(a) } this._beingDestroyed = !0; this.uninitialize(); m.forEach(this._connects, o.hitch(this, "disconnect")); m.forEach(this._supportingWidgets, b); this.domNode && m.forEach(u.findWidgets(this.domNode, this.containerNode), b); this.destroyRendering(a); u.remove(this.id); this._destroyed = !0 }, destroyRendering: function (a) {
                        this.bgIframe && (this.bgIframe.destroy(a), delete this.bgIframe); this.domNode && (a ? b.remove(this.domNode,
                        "widgetId") : k.destroy(this.domNode), delete this.domNode); this.srcNodeRef && (a || k.destroy(this.srcNodeRef), delete this.srcNodeRef)
                    }, destroyDescendants: function (a) { m.forEach(this.getChildren(), function (b) { b.destroyRecursive && b.destroyRecursive(a) }) }, uninitialize: function () { return !1 }, _setStyleAttr: function (a) { var b = this.domNode; o.isObject(a) ? g.set(b, a) : b.style.cssText = b.style.cssText ? b.style.cssText + ("; " + a) : a; this._set("style", a) }, _attrToDom: function (c, d, e) {
                        e = 3 <= arguments.length ? e : this.attributeMap[c];
                        m.forEach(o.isArray(e) ? e : [e], function (e) { var f = this[e.node || e || "domNode"]; switch (e.type || "attribute") { case "attribute": o.isFunction(d) && (d = o.hitch(this, d)); e = e.attribute ? e.attribute : /^on[A-Z][a-zA-Z]*$/.test(c) ? c.toLowerCase() : c; f.tagName ? b.set(f, e, d) : f.set(e, d); break; case "innerText": f.innerHTML = ""; f.appendChild(this.ownerDocument.createTextNode(d)); break; case "innerHTML": f.innerHTML = d; break; case "class": a.replace(f, d, this[c]) } }, this)
                    }, get: function (a) {
                        var b = this._getAttrNames(a); return this[b.g] ?
                        this[b.g]() : this[a]
                    }, set: function (a, b) {
                        if ("object" === typeof a) { for (var c in a) this.set(c, a[c]); return this } c = this._getAttrNames(a); var d = this[c.s]; if (o.isFunction(d)) var e = d.apply(this, Array.prototype.slice.call(arguments, 1)); else {
                            var d = this.focusNode && !o.isFunction(this.focusNode) ? "focusNode" : "domNode", f = this[d].tagName, g; if (!(g = s[f])) { g = this[d]; var h = {}, j; for (j in g) h[j.toLowerCase()] = !0; g = s[f] = h } j = a in this.attributeMap ? this.attributeMap[a] : c.s in this ? this[c.s] : c.l in g && "function" != typeof b ||
                            /^aria-|^data-|^role$/.test(a) ? d : null; null != j && this._attrToDom(a, b, j); this._set(a, b)
                        } return e || this
                    }, _attrPairNames: {}, _getAttrNames: function (a) { var b = this._attrPairNames; if (b[a]) return b[a]; var c = a.replace(/^[a-z]|-[a-zA-Z]/g, function (a) { return a.charAt(a.length - 1).toUpperCase() }); return b[a] = { n: a + "Node", s: "_set" + c + "Attr", g: "_get" + c + "Attr", l: c.toLowerCase() } }, _set: function (a, b) {
                        var c = this[a]; this[a] = b; this._created && b !== c && (this._watchCallbacks && this._watchCallbacks(a, c, b), this.emit("attrmodified-" +
                        a, { detail: { prevValue: c, newValue: b } }))
                    }, emit: function (a, b, c) { b = b || {}; if (void 0 === b.bubbles) b.bubbles = !0; if (void 0 === b.cancelable) b.cancelable = !0; if (!b.detail) b.detail = {}; b.detail.widget = this; var d, e = this["on" + a]; e && (d = e.apply(this, c ? c : [b])); this._started && !this._beingDestroyed && l.emit(this.domNode, a.toLowerCase(), b); return d }, on: function (a, b) { var c = this._onMap(a); return c ? h.after(this, c, b, !0) : this.own(l(this.domNode, a, b))[0] }, _onMap: function (a) {
                        var b = this.constructor, c = b._onMap; if (!c) {
                            var c = b._onMap =
                            {}, d; for (d in b.prototype) /^on/.test(d) && (c[d.replace(/^on/, "").toLowerCase()] = d)
                        } return c["string" == typeof a && a.toLowerCase()]
                    }, toString: function () { return "[Widget " + this.declaredClass + ", " + (this.id || "NO ID") + "]" }, getChildren: function () { return this.containerNode ? u.findWidgets(this.containerNode) : [] }, getParent: function () { return u.getEnclosingWidget(this.domNode.parentNode) }, connect: function (a, b, d) { return this.own(c.connect(a, b, this, d))[0] }, disconnect: function (a) { a.remove() }, subscribe: function (a, b) {
                        return this.own(t.subscribe(a,
                        o.hitch(this, b)))[0]
                    }, unsubscribe: function (a) { a.remove() }, isLeftToRight: function () { return this.dir ? "ltr" == this.dir : n.isBodyLtr(this.ownerDocument) }, isFocusable: function () { return this.focus && "none" != g.get(this.domNode, "display") }, placeAt: function (a, b) {
                        var c = !a.tagName && u.byId(a); c && c.addChild && (!b || "number" === typeof b) ? c.addChild(this, b) : (c = c ? c.containerNode && !/after|before|replace/.test(b || "") ? c.containerNode : c.domNode : d.byId(a, this.ownerDocument), k.place(this.domNode, c, b), !this._started && (this.getParent() ||
                        {})._started && this.startup()); return this
                    }, getTextDir: function (a, b) { return b }, applyTextDir: function () { }, defer: function (a, b) { var c = setTimeout(o.hitch(this, function () { c = null; this._destroyed || o.hitch(this, a)() }), b || 0); return { remove: function () { c && (clearTimeout(c), c = null); return null } } }
                })
            })
        }, "cbtree/extensions/TreeOnSubmit": function () {
            define("cbtree/extensions/TreeOnSubmit", ["dojo/json", "dojo/when", "../Tree"], function (j, m, h) {
                function f(c, d) {
                    var b = c.model, a = b.checkedAttr, f = b.store, h = {}; a && void 0 !== d && (h[a] =
                    d); return m(f.query(h), function (c) { c = c.map(function (c) { return { id: f.getIdentity(c), value: b.getLabel(c), checked: a ? c[a] || b.checkedState : void 0 } }); b._forest && c.shift({ id: b.root.id, value: b.rootLabel, checked: b.root[a], virtual: !0 }); return c }, function (a) { throw a; })
                } function c(c, d, b) {
                    var a, h = [], j; if (b = c.model.store ? !!b : !0) for (a in c._itemNodesMap) j = c._itemNodesMap[a], d = j[0], d = { id: a, value: d.label, checked: d._checkBox ? d._checkBox.checked : void 0, count: j.length }, h.push(d); else h = f(c, d).map(function (a) {
                        j = c._itemNodesMap[a.id];
                        a.count = j ? j.length : 0; return a
                    }); return h
                } return h.extend({ _hasOnSubmit: !0, onSubmit: function (e, d, b) { var a = !1, f; if (e && !b.defaultPrevented && this.attachToForm && "object" === typeof this.attachToForm) f = this.attachToForm.checked, a = this.attachToForm.domOnly || !1, d = this.attachToForm.name || "checkedStates", f = c(this, f, a), a = e.children.namedItem(d), a || (a = document.createElement("INPUT"), a.setAttribute("type", "hidden"), a.setAttribute("name", d), e.appendChild(a)), a.setAttribute("value", j.stringify(f)); return !b.defaultPrevented } })
            })
        }
    }
});
define("cbtree/cbtree", [], 1);