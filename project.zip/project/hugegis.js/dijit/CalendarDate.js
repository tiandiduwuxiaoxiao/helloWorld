﻿define([
    'dojo/_base/declare',
    'dojo/_base/lang',
    'dojo/_base/array',
    'dojo/_base/html',
    'dojo/on',
    'dojo/sniff',
    'dojo/touch',
    'dojo/query',
    'dojo/text!./templates/CalendarDate.html',
    'dijit/_WidgetBase',
	'dijit/_TemplatedMixin',
    'dijit/_WidgetsInTemplateMixin',
    'hugegis/dijit/Popup',
    "dojo/_base/connect",
    "dojox/grid/DataGrid",
    "dojo/data/ItemFileWriteStore",
    'dojo/dom',
    "dijit/form/DateTextBox",
    "dijit/form/Button",
    'hugegis/dijit/MessagePopup',
    "dojo/json",
    'hugegis/dijit/LoadingShelter',
    'hugegis/utilToXML',
    "hugegis/dijit/CalendarDateFull",
    "dojo/domReady!"
],
function (declare, lang, array, html, on, has, touch,
query, template, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, Popup, connect, DataGrid, ItemFileWriteStore,
dom, DateTextBox, Button, MessagePopup, json, LoadingShelter, UtilToXML, CalendarDateFull
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,
        dateSet: null,
        parentWidget: null,
        feedback: null,
        eventFeedback: null,
        eventWidget: null,   //事件组件
        haveOrbitDateArr: [],//【拥有数据的日集合】
        radioType: 'byDay',
        currentSelectedPda: null,
        locusPlayer: null,   //【轨迹Component】

        radioTypeSet: null,
        dateDisplaySet: null,
        calendarCommonSet: null,
        calendarMonthSet: null,
        userDefineSet: null,
        sliderDateSet: null,

        CommonServiceURL: null,
        xmlUtil: new UtilToXML(),
        calendarDateFull: null,
        sidebarType: null,   //【sidebar类型：人员-事件】
        workerArr: null,     //【巡检人员】
        eventCurrentData: null,//【事件当前人员数据】
        calendarRadioClicked: false,//【日历状态切换时event表不变】


        constructor: function () {
            this.nls = window.hugegisNls.calendarDateString;
            this.inherited(arguments);
        },

        postCreate: function () {
            this.inherited(arguments);
            this.shelter = new LoadingShelter({
                hidden: true
            });
            this.shelter.placeAt(hugegisConfig.layoutId);
            this.shelter.startup();

            this.dateSet = new Date();
            this.CommonServiceURL = this.parentWidget.appConfig.services.CommonServiceURL;
        },
        startup: function () {
            var that = this;

            this.dateFormatHandler();
            $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatOne));
            this.whichBlockToDisplay();
            $("#calendarDateTimeSetId").text(this.dateSet.Format(this.nls.dateFormatThree));
            $('#calendarDateMainAreaId').draggable({
                containment: [20, 40, $(document).width() - 355, $(document).height() - 300],
                cursor: 'move'
            });
            this.createCalendarDate(new Date());

            $("#CalendarCommonTable tr td").click(lang.hitch(this, function (event) {
                var target = event.target || event.srcElement;
                if (this.calendarDateTdInviableJudge(target)) return;
                $("#CalendarCommonTable tr td").removeClass('calendarDateClickTdClass');

                if (this.radioType == 'byDay') {
                    $(target).addClass('calendarDateClickTdClass');
                    $("#calendarDateTimeSetId").text(this.dateSet.Format(this.nls.dateFormatThree));
                } else if (this.radioType == 'byWeek') {
                    var parentNode = target.parentElement || target.parentNode;
                    $(parentNode.children).addClass('calendarDateClickTdClass');
                    this.calendarDateTdResetDisableClass(parentNode);
                }
                if ($(target).attr('haveorbit') === 'true') {
                    this.accordingRadioTypeQueryOrbit($(target).text());
                }
            }));
            $('#CalendarTableForMonth tr td').click(lang.hitch(this, function (event) {
                var target = event.target || event.srcElement;
                var td = $(target);
                if (!this.currentSelectedPda || td.attr('haveorbit') == 'true') {
                    this.dateSet = new Date(this.dateSet.getFullYear(), td.attr('value'));
                    $('#CalendarTableForMonth tr td').removeClass('calendarDateClickTdClassForMonth');
                    td.addClass('calendarDateClickTdClassForMonth');
                    $("#calendarDateTimeSetId").text(this.dateSet.Format(this.nls.dateFormatThree));
                    if (this.sidebarType) {
                        if (this.currentSelectedPda && td.attr('haveorbit') == 'true')
                            this.accordingRadioTypeQueryOrbit($(target).attr('value'));
                    } else {
                        this.accordingRadioTypeQueryOrbit($(target).attr('value'));
                    }
                }
            }));

            $("#calendarCloseBtnId").click(lang.hitch(this, function (e) {
                $("#xjMainCalendarDateAreaId").fadeOut(500);
            }));
            $("#theDayRadioId").click(lang.hitch(this, function (e) {
                this.radioGroupClickHandler(e);
            }));
            $("#theWeekRadioId").click(lang.hitch(this, function (e) {
                this.radioGroupClickHandler(e);
            }));
            $("#theMonthRadioId").click(lang.hitch(this, function (e) {
                this.radioGroupClickHandler(e);
            }));
            $("#userDefine").click(lang.hitch(this, function (e) {
                this.radioGroupClickHandler(e);
            }));
            $("#calendarDatePrewIconId").click(lang.hitch(this, function (e) {
                this.prewIconClickHandler();
            }));
            $("#calendarDateNextIconId").click(lang.hitch(this, function (e) {
                this.nextIconClickHandler();
            }));
            $("#calendarDateSliderHourId").attr('title', (new Date()).getHours());
            $("#calendarDateSliderHourId").slider({
                range: "min",
                value: (new Date()).getHours(),
                min: 0,
                max: 23,
                slide: function (event, ui) {
                    that.dateSet.setHours(ui.value);
                    $("#calendarDateSliderHourId").attr('title', ui.value);
                    $("#calendarDateTimeSetId").text(that.dateSet.Format(that.nls.dateFormatThree));
                }
            });
            $("#calendarDateSliderMinuteId").attr('title', (new Date()).getMinutes());
            $("#calendarDateSliderMinuteId").slider({
                range: "min",
                value: (new Date()).getMinutes(),
                min: 0,
                max: 59,
                slide: function (event, ui) {
                    that.dateSet.setMinutes(ui.value);
                    $("#calendarDateSliderMinuteId").attr('title', ui.value);
                    $("#calendarDateTimeSetId").text(that.dateSet.Format(that.nls.dateFormatThree));
                }
            });
            $("#sliderDateCommitBtnId").click(lang.hitch(this, function (e) {
                this.sliderDateCommitBtnClick();
            }));
            //【自定义input赋值】
            var inputDate = new Date();
            inputDate.setHours(8, 0, 0);
            $("#calendarDateBeginTimeId").prop('value', inputDate.Format(this.nls.dateFormatThree));
            $("#calendarDateBeginTimeId").attr('dateStr', inputDate.Format(this.nls.dateFormatFour));
            $("#calendarDateBeginTimeId").focusin(lang.hitch(this, function () {
                if (this.calendarDateFull) {
                    $(this.calendarDateFull.domNode).remove();
                }
                this.calendarDateFull = new CalendarDateFull({
                    currentTarget: $("#calendarDateBeginTimeId"),
                    currentValue: $("#calendarDateBeginTimeId").prop('value'),
                    feedback: this.callBack
                });
                $(this.calendarDateFull.domNode).insertAfter('#calendarDateBeginTimeId');
                $('#calendarDateFullMainAreaId').fadeIn(1000);
            }));
            inputDate.setHours(16, 0, 0);
            $("#calendarDateEndTimeId").prop('value', inputDate.Format(this.nls.dateFormatThree));
            $("#calendarDateEndTimeId").attr('dateStr', inputDate.Format(this.nls.dateFormatFour));
            $("#calendarDateEndTimeId").focusin(lang.hitch(this, function () {
                if (this.calendarDateFull) {
                    $(this.calendarDateFull.domNode).remove();
                }
                this.calendarDateFull = new CalendarDateFull({
                    currentTarget: $("#calendarDateEndTimeId"),
                    currentValue: $("#calendarDateEndTimeId").prop('value'),
                    feedback: this.callBack
                });
                $(this.calendarDateFull.domNode).insertAfter('#calendarDateEndTimeId');
                $('#calendarDateFullMainAreaId').fadeIn(1000);
            }));
            $("#calendarDateUserDefineCommitId").click(lang.hitch(this, function () {
                if (this.sidebarType) {
                    if (this.currentSelectedPda) {
                        var begTimeStr = $("#calendarDateBeginTimeId").attr('dateStr');
                        var endTimeStr = $("#calendarDateEndTimeId").attr('dateStr');
                        this.getPDATrackposList(begTimeStr, endTimeStr);
                    } else {
                        new MessagePopup({
                            titleLabel: "提示",
                            message: "请先选择要查询的人员!"
                        });
                    }
                } else {
                    var begTimeStr = $("#calendarDateBeginTimeId").attr('dateStr');
                    var endTimeStr = $("#calendarDateEndTimeId").attr('dateStr');
                    this.eventSidebarHandler([begTimeStr, endTimeStr]);
                }
            }));
        },
        //【回馈事件】【params数组:日期-radio类型】
        eventCallBack: function (params) {
            if (this.eventFeedback) {
                if (params) {
                    this.eventFeedback(null, this.eventWidget, params);
                } else {
                    this.eventFeedback(this.eventCurrentData, this.eventWidget, params, this.calendarRadioClicked);
                }
            }
            this.calendarRadioClicked = false;
        },
        //【the feedback function for input component】
        callBack: function (e, that) {
            var oDate = e;
            var dateString = oDate.Format(this.nls.dateFormatThree);
            that.attr('dateStr', oDate.Format(this.nls.dateFormatFour));
            that.prop('value', dateString);
            var begTimeStr = $("#calendarDateBeginTimeId").val();
            var endTimeStr = $("#calendarDateEndTimeId").val();
            if (begTimeStr > endTimeStr) {
                new MessagePopup({
                    titleLabel: "警告",
                    message: "开始日期大于结束日期!"
                });
            }
        },
        //【查询轨迹日期处理】
        accordingRadioTypeQueryOrbit: function (dayNum) {
            this.locusPlayer.onCloseClick();

            var begTime, endTime;
            var currentDate = new Date(this.dateSet);
            currentDate.setHours(0, 0, 0);
            switch (this.radioType) {
                case 'byDay':
                    currentDate.setDate(dayNum);
                    begTime = currentDate.Format(this.nls.dateFormatFour);
                    currentDate.setDate(currentDate.getDate() + 1);
                    endTime = currentDate.Format(this.nls.dateFormatFour);
                    break;
                case 'byWeek':
                    if (dayNum <= 7) {
                        currentDate.setDate(1);
                        begTime = currentDate.Format(this.nls.dateFormatFour);
                        currentDate.setDate(7 - currentDate.getDay() + 1);
                        endTime = currentDate.Format(this.nls.dateFormatFour);
                    } else {
                        var maxDate = new Date(currentDate);
                        maxDate.setMonth(maxDate.getMonth() + 1);
                        endTime = maxDate.Format(this.nls.dateFormatFour);
                        maxDate.setDate(0);
                        maxDate.setDate(maxDate.getDate() - maxDate.getDay());
                        var maxMonthDay = maxDate.getDate();
                        if (dayNum > maxMonthDay) {
                            begTime = maxDate.Format(this.nls.dateFormatFour);
                        } else {
                            currentDate.setDate(dayNum);
                            var weekDay = currentDate.getDay();
                            currentDate.setDate(currentDate.getDate() - weekDay);
                            begTime = currentDate.Format(this.nls.dateFormatFour);
                            currentDate.setDate(currentDate.getDate() + 7);
                            endTime = currentDate.Format(this.nls.dateFormatFour);
                        }
                    }
                    break;
                case 'byMonth':
                    currentDate.setDate(1);
                    currentDate.setMonth(dayNum);
                    begTime = currentDate.Format(this.nls.dateFormatFour);
                    currentDate.setMonth(currentDate.getMonth() + 1);
                    endTime = currentDate.Format(this.nls.dateFormatFour);
                    break;
                case 'userDefine':

                    break;
            }
            if (this.sidebarType) {
                this.getPDATrackposList(begTime, endTime);
            } else {
                this.eventCallBack([begTime, endTime]);
            }
        },
        //【查询轨迹】
        getPDATrackposList: function (begTime, endTime) {
            var that = this;
            var bodyNode = document.body;
            bodyNode.style.cursor = 'wait';
            this.shelter.show();
            var xmlUtilTemp = this.xmlUtil;
            var pdaId = this.currentSelectedPda.idStr;
            var URL = window.path + this.CommonServiceURL + "/GetPDATrackposList";
            var myname = dojo.toJson({ "PDAID": pdaId, "BeginTime": begTime, "EndTime": endTime, "ConnSection": this.parentWidget.appConfig.orbitConn });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    //跨浏览器，ie和火狐解析xml使用的解析器是不一样的。 
                    var xmlStrDoc = null;
                    if (window.DOMParser) {
                        // Mozilla Explorer  
                        parser = new DOMParser();
                        xmlStrDoc = parser.parseFromString(response.d, "text/xml");
                    } else {
                        // Internet Explorer  
                        xmlStrDoc = new ActiveXObject("Microsoft.XMLDOM");
                        xmlStrDoc.async = "false";
                        xmlStrDoc.loadXML(response.d);
                    }
                    var ar = new Array();
                    var recordNodes = xmlUtilTemp.xmlGetNodes("Result", "Position", xmlStrDoc);
                    recordNodes.forEach(dojo.hitch(this, function (node, idx, arr) {
                        var X = xmlUtilTemp.xmlGetAttribute(node, "X");
                        var Y = xmlUtilTemp.xmlGetAttribute(node, "Y");
                        var Dir = xmlUtilTemp.xmlGetAttribute(node, "Dir");
                        var CurrentTime = xmlUtilTemp.xmlGetAttribute(node, "CurrentTime");
                        var EventType = xmlUtilTemp.xmlGetAttribute(node, "EventType");
                        var EventRecordid = xmlUtilTemp.xmlGetAttribute(node, "EventRecordid");
                        var CurrentLength = xmlUtilTemp.xmlGetAttribute(node, "CurrentLength");
                        ar.push({
                            X: X,
                            Y: Y,
                            Dir: Dir,
                            CurrentTime: CurrentTime,
                            EventType: EventType,
                            EventRecordid: EventRecordid,
                            CurrentLength: CurrentLength
                        });
                    }));
                    if (ar.length > 0) {
                        if (that.parentWidget.pdaWindowOnMap)
                            that.parentWidget.pdaWindowOnMap.destroy();
                        that.locusPlayer.pData = ar;
                        that.locusPlayer.drawAllLocus();
                    } else {
                        var popup = new MessagePopup({
                            titleLabel: "查询提示",
                            message: "此段无轨迹!"
                        });
                    }
                    that.shelter.hide();
                    bodyNode.style.cursor = '';
                },
                error: function (error) {
                    var popup = new MessagePopup({
                        titleLabel: "异常提示",
                        message: "轨迹服务调用异常!"
                    });
                    that.shelter.hide();
                    bodyNode.style.cursor = '';
                }
            };
            dojo.xhrPost(xhrArgs);
        },
        //【根据radio按钮查询拥有数据的日期】【入口函数】
        queryTrackpos: function () {
            if (this.sidebarType) {
                this.peopleSidebarHandler();
            } else {
                this.eventSidebarHandler(null);
            }
        },
        //【sidebar选择事件查询处理】
        eventSidebarHandler: function (dArr) {
            var that = this,
                pdaIdStr = '',
                workers = this.workerArr;
            if (!dArr)
                var dateArr = this.dateHandlerWhenQuery(new Date(this.dateSet));
            else
                var dateArr = dArr;
            for (var i = 0, j = workers.length; i < j; i++) {
                if (workers[i].idStr) {
                    pdaIdStr += pdaIdStr ? "," + "'" + workers[i].idStr + "'" : "'" + workers[i].idStr + "'";
                }
            }
            if (pdaIdStr) {
                this.queryEvent(pdaIdStr, dateArr[0], dateArr[1]);
            }
        },
        //params pdaId【人员】timeBegin【开始时间】timeEnd【结束时间】
        queryEvent: function (pdaId, timeBegin, timeEnd) {
            var that = this;
            var sqlStr = "select * from v_eventinfo where 1=1 ";
            if (pdaId == null || pdaId.trim ? pdaId.trim() : pdaId.replace(/^\s*|\s*$/g, "") == "")
                pdaid = "''";
            sqlStr += " and pdaid in (" + pdaId + ")";
            if (timeBegin != null)
                sqlStr += " and createtime >= to_date('" + timeBegin + "','YYYY-MM-DD hh24:mi:ss')";
            if (timeEnd != null)
                sqlStr += " and createtime <= to_date('" + timeEnd + "','YYYY-MM-DD hh24:mi:ss')";

            var url = window.path + this.CommonServiceURL + "/CommonSelect";
            var tableData = dojo.toJson({ "ConnSection": this.parentWidget.appConfig.xjdbconn, "SQL": sqlStr });
            this.audioArr = [];
            var xhrArgs = {
                url: url,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: tableData,
                load: function (response) {
                    if (!response.d) {
                        that.eventCurrentData = [];
                        that.haveOrbitDateArr = [];
                    } else {
                        that.eventCurrentData = json.parse(response.d);
                        var allArray = that.eventCurrentData;
                        if (that.radioType == 'byDay' || that.radioType == 'byWeek') {
                            allArray.forEach(function (item) {
                                //【dateStr: yyyy-MM-dd hh:mm:ss】
                                var theDay = new Date(item.CREATETIME.split(' ')[0]).getDate();
                                if (that.haveOrbitDateArr.indexOf(theDay) == -1)
                                    that.haveOrbitDateArr.push(theDay);
                            });
                            that.createCalendarDate(new Date(that.dateSet));
                        } else if (that.radioType == 'byMonth') {
                            allArray.forEach(function (item) {
                                var theMonth = new Date(item.CREATETIME.split(' ')[0]).getMonth();
                                if (that.haveOrbitDateArr.indexOf(theMonth) == -1)
                                    that.haveOrbitDateArr.push(theMonth);
                            });
                            that.calendarTableForMonthTrs();
                        } else if (that.radioType == 'userDefine') {
                            that.eventCallBack([timeBegin, timeEnd]);
                            return;
                        }
                        //【回馈事件】
                        that.eventCallBack(null);
                    }
                },
                error: function (error) {
                    new MessagePopup({
                        titleLabel: '提示',
                        message: '服务异常'
                    });
                }
            };
            dojo.xhrPost(xhrArgs);
        },
        //【sidebar选择人员查询处理】
        peopleSidebarHandler: function () {
            var that = this;
            if (!this.currentSelectedPda) {//【事件的做法不同】
                this.haveOrbitDateArr = [];
                switch (this.radioType) {
                    case 'byDay':
                    case 'byWeek':
                        this.createCalendarDate(new Date(that.dateSet));
                        break;
                    case 'byMonth':
                        this.calendarTableForMonthTrs();
                        break;
                }
                return;
            }
            var pdaId = this.currentSelectedPda.idStr;
            //【date handler】
            var dateArr = this.dateHandlerWhenQuery(new Date(this.dateSet));

            var sql = "select pdaid,trackdate,event,tracklength from "
                      + this.parentWidget.appConfig.trackposDB + " where 1=1";
            sql += " and pdaid = '" + pdaId + "'";
            sql += " and trackdate >= to_date('" + dateArr[0] + "','yyyy-mm-dd hh24:mi:ss')";//【oracle 不区分大小写 MM 和 mm 一样，用mi代替mm(分钟)】
            sql += " and trackdate < to_date('" + dateArr[1] + "','yyyy-mm-dd hh24:mi:ss')";
            sql += " order by trackdate";

            var URL = window.path + this.CommonServiceURL + "/CommonSelect";
            var myname = dojo.toJson({ "ConnSection": this.parentWidget.appConfig.connsection, "SQL": sql });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    if (!response.d) {
                        that.haveOrbitDateArr = [];
                        return;
                    } else {
                        var allArray = json.parse(response.d);
                        if (that.radioType == 'byDay' || that.radioType == 'byWeek') {
                            allArray.forEach(function (item) {
                                //【dateStr: yyyy-MM-dd hh:mm:ss】
                                var theDay = new Date(item.TRACKDATE.split(' ')[0]).getDate();
                                if (that.haveOrbitDateArr.indexOf(theDay) == -1)
                                    that.haveOrbitDateArr.push(theDay);
                            });
                            that.createCalendarDate(new Date(that.dateSet));
                        } else if (that.radioType == 'byMonth') {
                            allArray.forEach(function (item) {
                                var theMonth = new Date(item.TRACKDATE.split(' ')[0]).getMonth();
                                if (that.haveOrbitDateArr.indexOf(theMonth) == -1)
                                    that.haveOrbitDateArr.push(theMonth);
                            });
                            that.calendarTableForMonthTrs();
                        }
                    }
                },
                error: function (error) {
                    console.error(error.toString());
                    new MessagePopup({
                        titleLabel: '提示',
                        message: '服务异常!'
                    });
                    console.error('Calendar--webServiceError');
                }
            };
            dojo.xhrPost(xhrArgs);
        },
        //【查询处理中日期处理分离】
        dateHandlerWhenQuery: function (currentDate) {
            var timeBegin, timeEnd, dateArr = [];
            if (this.radioType == 'byDay' || this.radioType == 'byWeek') {
                currentDate.setDate(1);
                timeBegin = currentDate.Format("yyyy-MM-dd 00:00:00");
                currentDate.setMonth(currentDate.getMonth() + 1);
                timeEnd = currentDate.Format("yyyy-MM-dd 00:00:00");
            } else if (this.radioType == 'byMonth') {
                currentDate.setMonth(0, 1);
                timeBegin = currentDate.Format("yyyy-MM-dd 00:00:00");
                currentDate.setFullYear(currentDate.getFullYear() + 1);
                timeEnd = currentDate.Format("yyyy-MM-dd 00:00:00");
            }
            dateArr.push(timeBegin);
            dateArr.push(timeEnd);
            return dateArr;
        },
        sliderDateCommitBtnClick: function () {
            $("#xjMainCalendarDateAreaId").fadeOut(500);
            if (this.feedback) {
                this.feedback(this.dateSet);
            }
        },
        whichBlockToDisplay: function () {
            if (this.radioTypeSet) {
                $('#calendarDateOrbitDecideId').show();
                $('#CalendarCommonTableArea').show();
                $("#calendarDateDispalyId").show();
                $("#CalendarTableForMonthArea").hide();
                $("#calendarDateUserDefine").hide();
                $("#calendarDateSliderIdArea").hide();
            } else {
                $('#CalendarCommonTableArea').hide();
                $("#calendarDateDispalyId").hide();
                $("#CalendarTableForMonthArea").hide();
                $("#calendarDateUserDefine").hide();
                $('#calendarDateOrbitDecideId').hide();
                $("#calendarDateSliderIdArea").hide();
            }
            if (this.dateDisplaySet) {
                $("#calendarDateDispalyId").show();
            }
            if (this.calendarCommonSet) {
                $('#CalendarCommonTableArea').show();
            }
            if (this.calendarMonthSet) {
                this.radioType = 'byMonth';
                $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatTwo));
                $("#calendarDateDispalyId").show();
                $('#calendarDateOrbitDecideId').show();
                $("#calendarDateOrbitDecideId label").css('display', 'none');
                $("#calendarDateOrbitDecideId input").css('display', 'none');
                $("#calendarDateOrbitDecideId span:first-child").text(this.nls.monthSet);
                $("#CalendarTableForMonthArea").show();
                this.calendarTableForMonthTrs();
            }
            if (this.userDefineSet) {
                $("#calendarDateUserDefine").show();
            }
            if (this.sliderDateSet) {
                $("#calendarDateSliderIdArea").show();
            }
        },
        prewIconClickHandler: function () {
            this.calendarRadioClicked = true;
            switch (this.radioType) {
                case "byDay":
                case "byWeek":
                    this.dateSet = new Date(this.dateSet.getFullYear(), this.dateSet.getMonth() - 1);
                    $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatOne));
                    break;
                case "byMonth":
                    this.dateSet = new Date(this.dateSet.getFullYear() - 1, this.dateSet.getMonth());
                    $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatTwo));
                    break;
            }
            $("#calendarDateTimeSetId").text(this.dateSet.Format(this.nls.dateFormatThree));
            this.queryTrackpos();
        },
        nextIconClickHandler: function () {
            this.calendarRadioClicked = true;
            switch (this.radioType) {
                case "byDay":
                case "byWeek":
                    this.dateSet = new Date(this.dateSet.getFullYear(), this.dateSet.getMonth() + 1);
                    $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatOne));
                    break;
                case "byMonth":
                    this.dateSet = new Date(this.dateSet.getFullYear() + 1, this.dateSet.getMonth());
                    $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatTwo));
                    break;
            }
            $("#calendarDateTimeSetId").text(this.dateSet.Format(this.nls.dateFormatThree));
            this.queryTrackpos();
        },
        radioGroupClickHandler: function (e) {
            this.calendarRadioClicked = true;
            var target = e.target || e.srcElement;
            this.radioType = target.value;
            switch (target.value) {
                case "byDay":
                case "byWeek":
                    $('#CalendarCommonTableArea').show();
                    $('#calendarDateOrbitDecideId').show();
                    $("#calendarDateDispalyId").show();
                    $("#CalendarTableForMonthArea").hide();
                    $("#calendarDateUserDefine").hide();
                    $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatOne));
                    break;
                case "byMonth":
                    $('#CalendarCommonTableArea').hide();
                    $('#calendarDateOrbitDecideId').show();
                    $("#calendarDateDispalyId").show();
                    $("#CalendarTableForMonthArea").show();
                    $("#calendarDateUserDefine").hide();
                    $("#calendarDateTextId").text(this.dateSet.Format(this.nls.dateFormatTwo));
                    break;
                case "userDefine":
                    $('#CalendarCommonTableArea').hide();
                    $('#CalendarTableForMonthArea').hide();
                    $("#calendarDateDispalyId").hide();
                    $("#calendarDateUserDefine").show();
                    $('#calendarDateOrbitDecideId').show();
                    return;
                    break;
            }
            this.queryTrackpos();
        },
        calendarTableForMonthTrs: function () {
            //判断当年当月
            var that = this;
            var inviableDays = this.haveOrbitDateArr.sort(function (a, b) {
                return a - b;
            });
            var tds = $('#CalendarTableForMonth tr td');
            tds.removeAttr('haveorbit');
            tds.removeClass();
            tds.addClass(function (idx) {
                if (idx == inviableDays[0]) {
                    inviableDays.shift();
                    $(this).attr('haveorbit', true);
                    return 'calendarDateTdClassForMonth';
                } else {
                    if (that.sidebarType) {//【人员】
                        if (that.currentSelectedPda) {
                            return 'calendarDateInviableTdClassForMonth';
                        } else {
                            return 'calendarDateTdClassForMonth';
                        }
                    } else {//【事件】
                        return 'calendarDateInviableTdClassForMonth';
                    }
                }
            });
            tds.attr('value', function (idx) {
                return idx;
            });
        },
        calendarDateTdInviableJudge: function (target) {
            if (target.className === 'calendarDateTdInviableClass')
                return true;
            else
                return false;
        },
        calendarDateTdResetDisableClass: function (tds) {
            var items = tds.cells;
            for (var i = 0; i < items.length; i++) {
                if (items[i].id == ('calendarDateInviableTdId' + items[i].innerHTML))
                    items[i].setAttribute('class', 'calendarDateTdInviableClass');
                if (items[i].id == ('calendarDateAnotherTdId' + items[i].innerHTML))
                    items[i].setAttribute('class', 'calendarDateTableTdAnotherClass');
            }
        },
        createCalendarDate: function (dateObj) {
            var nowDate = (new Date()).getDate();
            //【判断当年当月】
            var bool = Boolean(dateObj.getMonth() - (new Date()).getMonth());
            if (!bool)
                bool = Boolean(dateObj.getFullYear() - (new Date()).getFullYear());
            var firstDay = new Date(dateObj);
            firstDay.setDate(1);
            var week = firstDay.getDay();
            var pos = week % 7;
            var calendar = $("#CalendarCommonTable")[0].children['0'].children;
            var daysOfMonth = 1;

            dateObj.setMonth(dateObj.getMonth() + 1);
            dateObj.setDate(0);
            var maxDays = dateObj.getDate();
            var inviableDays = this.haveOrbitDateArr.sort(sortByValue);
            var todayHaveOrbit = inviableDays.indexOf(nowDate) > -1 ? true : false;
            //【sort func for array: from small to big】
            function sortByValue(a, b) {
                return a - b;
            }

            var prewNum = 1, nextNum = 1;
            var prew = dateObj;
            prew.setMonth(prew.getMonth());
            prew.setDate(0);
            prewNum = prew.getDate();
            prewNum = prewNum - pos + 1;
            for (var i = 1; i < calendar.length; i++) {
                for (var j = 0; j < calendar[i].cells.length; j++) {
                    var someTd = $(calendar[i].cells[j]);
                    someTd.removeAttr('id');
                    someTd.removeAttr('class');
                    someTd.removeAttr('disabled');
                    someTd.removeAttr('haveOrbit');
                    if (j < pos && i == 1) {
                        someTd.attr('class', 'calendarDateTableTdAnotherClass');
                        someTd.attr('disabled', 'disabled');
                        someTd.attr('id', 'calendarDateAnotherTdId' + prewNum);
                        someTd.text(prewNum);
                        prewNum++;
                    } else {
                        if (daysOfMonth <= maxDays) {
                            if (this.sidebarType) {//【人员】
                                if (this.currentSelectedPda && inviableDays[0] && daysOfMonth == inviableDays[0]) {
                                    inviableDays.shift();
                                    someTd.attr('class', 'calendarDateTableTdClass');
                                    someTd.attr('haveOrbit', true);
                                } else {
                                    if (!this.currentSelectedPda) {
                                        someTd.attr('class', 'calendarDateTableTdClass');
                                    } else {
                                        someTd.attr('class', 'calendarDateTdInviableClass');
                                        someTd.attr('disabled', 'disabled');
                                        someTd.attr('id', 'calendarDateInviableTdId' + daysOfMonth);
                                    }
                                }
                            } else {//【事件】
                                if (inviableDays[0] && daysOfMonth == inviableDays[0]) {
                                    inviableDays.shift();
                                    someTd.attr('class', 'calendarDateTableTdClass');
                                    someTd.attr('haveOrbit', true);
                                } else {
                                    someTd.attr('class', 'calendarDateTdInviableClass');
                                    someTd.attr('disabled', 'disabled');
                                    someTd.attr('id', 'calendarDateInviableTdId' + daysOfMonth);
                                }
                            }
                            someTd.text(daysOfMonth);
                        } else {
                            someTd.attr('class', 'calendarDateTableTdAnotherClass');
                            someTd.text(nextNum);
                            someTd.attr('disabled', 'disabled');
                            someTd.attr('id', 'calendarDateAnotherTdId' + nextNum);
                            nextNum++;
                        }
                        //【to mark today】
                        if (!bool && daysOfMonth == nowDate) {
                            if (todayHaveOrbit) {
                                someTd.attr('class', 'calendarDateMarkTodayHaveOrbit');
                            } else {
                                someTd.attr('class', 'calendarDateMarkToday');
                            }
                        }
                        daysOfMonth++;
                    }
                }
            }
        },
        dateFormatHandler: function () {
            Date.prototype.Format = function (fmt) {
                var o = {
                    "M+": this.getMonth() + 1,
                    "d+": this.getDate(),
                    "h+": this.getHours(),
                    "m+": this.getMinutes(),
                    "s+": this.getSeconds(),
                    "q+": Math.floor((this.getMonth() + 3) / 3),
                    "S": this.getMilliseconds()
                };
                if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
                for (var k in o)
                    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                return fmt;
            }
        }
    })
});