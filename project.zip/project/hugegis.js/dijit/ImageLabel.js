///////////////////////////////////////////////////////////////////////////
// Copyright © 2014 Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////

define(['dojo/_base/declare',
  'dojo/_base/lang',
  'dojo/on',
  'dojo/_base/html',
  'dojo/dom-construct',
  'dojo/aspect',
  "dojo/_base/connect",
  'hugegis/utilToXML',
  'hugegis/dijit/MessagePopup'
], function (declare, lang, on, html, domConstruct, aspect, connect, utilToXML, MessagePopup) {
    return declare(null, {
        _infoData: null,
        _mediaTdNode: null,
        xmlUtil: new utilToXML(),

        constructor: function (params, table, _mediaTdNode) {
            this._infoData = params;
            this._mediaTdNode = _mediaTdNode;
            if (params.supportTable == table) {
                this.setAnalyticalData();
            } else {
                var isBool = false;
                //var isBool = this.xmlUtil.getURL(this._infoData.cover)
                if (!isBool) {
                    var pathUrl = this._infoData.url;
                    var fileName = "";
                    if (pathUrl != null && pathUrl != "") {
                        var ar = pathUrl.split("/");
                        fileName = ar[ar.length - 1];
                        if (table == "YW_FILE") {
                            sql = "select pic from yw_file t where name = '" + fileName + "'";
                        }
                        else {
                            sql = "select media from track_media where filename = '" + fileName + "'";
                        }
                    }
                    if (sql != null && sql != "") {
                        this.getWeb_GetFileWithSQL(sql, fileName);
                    }
                }
            }
        },
        getWeb_GetFileWithSQL: function (sql, fileName) {
            var thisTemp = this;
            var URL = window.path + window._widgetManager.appConfig.services.CommonServiceURL + "/GetFileWithSQL";
            var myname = dojo.toJson({ "ConnSection": "PropDBConn", "SQL": sql, "FileName": fileName });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    thisTemp.setAnalyticalData(response.d);
                },
                error: function (error) {
                    var popup = new MessagePopup({
                        titleLabel: "空间查询2-异常提示",
                        message: "服务调用异常!"
                    });
                }
            };
            dojo.xhrPost(xhrArgs);
        },
        setAnalyticalData: function (res) {
            //绑定数据
            var tmpA = domConstruct.create('a', {
                'href': this._infoData.cover,
                'target': '_blank'
            }, this._mediaTdNode);
            var tmpPic = domConstruct.create('img', {
                'class': 'attributeImg',
                'src': this._infoData.url,
                'alt': this._infoData.label,
                'title': this._infoData.label
            }, tmpA);
        }
    });
});