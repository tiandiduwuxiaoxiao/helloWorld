﻿define(["dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/_base/window",
    "dojo/_base/kernel",
    'dojo/_base/html',
    "dojo/has",
    "dojo/query",
    "dojo/sniff",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dijit/_Widget",
    "dijit/_Templated",
    "dijit/_Container",
    "esri/kernel",
    "esri/domUtils",
    "esri/InfoWindowBase",
    "esri/dijit/_EventedWidget",
    "dojo/text!./templates/InfoWindow.html",
    'hugegis/dijit/AttributeTable',
    'hugegis/dijit/Popup',
    'hugegis/dijit/MessagePopup',
    'hugegis/dijit/LoadingShelter'],
function (n, h, k, p, q, html, l, y, z, m, g, f, r, s, t, u, e, v, w, x, AttributeTable, Popup, MessagePopup, LoadingShelter) {
    var d = n([w, r, s, t, v], {
        declaredClass: "hugegis-InfoWindow",
        isContainer: !0,
        templateString: x,
        anchor: "upperright",
        fixedAnchor: null,
        coords: null,
        isShowing: !0,
        isContentShowing: !0,
        isTitleBarShowing: !0,
        //width: 250,
        //height: 150,
        width: 170,
        height: 237,
        title: "Info Window",
        _infoData: null,

        setMap: function (a) {
            this.inherited(arguments);
            g.place(this.domNode, a.root);
        },
        startup: function () {
            if (!this._started) {
                this.inherited(arguments);
                this._ANCHORS = [d.ANCHOR_UPPERRIGHT, d.ANCHOR_LOWERRIGHT, d.ANCHOR_LOWERLEFT, d.ANCHOR_UPPERLEFT];
                if (7 > l("ie")) {
                    var a = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled\x3d'true', sizingMethod\x3d'crop', src\x3d'" + f.getComputedStyle(this._sprite).backgroundImage.replace(/url\(\"/i, "").replace(/\"\)/, "") + "')",
                    b = g.create("div", null, p.body());
                    f.set(b, {
                        width: "1px",
                        height: "1px",
                        display: "none",
                        backgroundImage: "none",
                        filter: a
                    });
                    var c = setTimeout(function () {
                        g.destroy(b);
                        clearTimeout(c);
                        c = b = null
                    },
                    100);
                    q.query(".sprite", this.domNode).forEach(function (b) {
                        b.style.backgroundImage = "none";
                        b.style.filter = a
                    })
                }
                this.resize(this.width, this.height);
                this.hide();
            }
        },
        destroy: function () {
            this._destroyed || (this.__unregisterMapListeners(), this.destroyDijits(this._title), this.destroyDijits(this._content), this._title.innerHTML = this._content.innerHTML = "", this.inherited(arguments));
        },
        resize: function (a, b) {
            if (a && b) {
                var c = f.set;
                c(this._topleft, {
                    height: b + "px",
                    marginLeft: a + "px"
                });
                c(this._topright, {
                    width: a + "px",
                    height: b + "px"
                });
                c(this._user, "width", a + "px");
                c(this._hide, "marginLeft", a - 22 + "px");
                c(this._title, "width", a - 25 + "px");
                c(this._content, "height", b - 57 + "px");
                c(this._bottomleft, {
                    marginLeft: a + "px",
                    marginTop: b + "px"
                });
                c(this._bottomright, {
                    width: a + "px",
                    marginTop: b + "px"
                });
                this.width = a;
                this.height = b;
                this.coords && this._adjustPosition(this.coords, this.anchor);
                this.onResize(a, b);
            }
        },
        _adjustPosition: function (a, b) {
            var c = f.set;
            c(this._infowindow, {
                left: Math.round(a.x) + "px",
                top: Math.round(a.y) + "px"
            });
            b === d.ANCHOR_UPPERLEFT ? c(this._window, {
                left: null,
                right: this.width + 18 + "px",
                top: null,
                bottom: this.height + 50 + "px"
            }) : b === d.ANCHOR_UPPERRIGHT ? c(this._window, {
                left: "6px",
                right: null,
                top: null,
                bottom: this.height + 50 + "px"
            }) : b === d.ANCHOR_LOWERRIGHT ? c(this._window, {
                left: "6px",
                right: null,
                top: "43px",
                bottom: null
            }) : b === d.ANCHOR_LOWERLEFT && c(this._window, {
                left: null,
                right: this.width + 18 + "px",
                top: "43px",
                bottom: null
            })
        },
        _getAnchor: function (a) {
            var b = this.map;
            return b && a ? (a.y < b.height / 2 ? "lower" : "upper") + (a.x < b.width / 2 ? "right" : "left") : "upperright";
        },
        show: function (a, b, c) {
            if (a) {
                a.spatialReference ? (this.mapCoords = a, a = this.coords = this.map.toScreen(a, !0)) : (this.mapCoords = null, this.coords = a);
                var d = this.map._getFrameWidth();
                if (-1 !== d && (a.x %= d, 0 > a.x && (a.x += d), this.map.width > d)) for (var f = (this.map.width - d) / 2; a.x < f; ) a.x += d;
                if (!b || -1 === k.indexOf(this._ANCHORS, b)) b = this._getAnchor(a);
                m.remove(this._pointer, this.anchor);
                b = this.anchor = this.fixedAnchor || b;
                this._adjustPosition(a, b);
                m.add(this._pointer, b);
                e.show(this.domNode);
                this.isShowing = !0;
                if (!c) this.onShow();
            }
        },
        hide: function (a, b) {
            e.hide(this.domNode);
            this.isShowing = !1;
            if (!b) this.onHide();
        },
        showTitleBar: function () {
            e.show(this._titlebar);
            e.show(this._border);
            this.isTitleBarShowing = !0;
        },
        hideTitleBar: function () {
            e.hide(this._titlebar);
            e.hide(this._border);
            this.isTitleBarShowing = !1;
        },
        showContent: function () {
            e.show(this._content);
            e.show(this._border);
            this.isContentShowing = !0
        },
        hideContent: function () {
            e.hide(this._content);
            e.hide(this._border);
            this.isContentShowing = !1;
        },
        move: function (a, b) {
            b ? a = this.coords.offset(a.x, a.y) : (this.coords = a, this.mapCoords && (this.mapCoords = this.map.toMap(a)));
            f.set(this._infowindow, {
                left: Math.round(a.x) + "px",
                top: Math.round(a.y) + "px"
            })
        },
        setFixedAnchor: function (a) {
            a && -1 === k.indexOf(this._ANCHORS, a) || (this.fixedAnchor = a, this.isShowing && this.show(this.mapCoords || this.coords, a), this.onAnchorChange(a))
        },
        setTitle: function (a) {
            this.destroyDijits(this._title);
            this._title.title = a;
            this.__setValue("_title", a);
            return this;
        },
        setContent: function (a) {
            this.destroyDijits(this._content);
            this.__setValue("_content", a);
            var c = f.set;
            c(this.actionDiv, {
                display: "none"
            });
            this.resize(250, 150);
            return this;
        },

        setInfoParameters: function (ac) {
            g.empty(this.containerNode);
            var tableNode = g.create('table', {
                'class': 'infoWindowTable'
            }, this.containerNode);
            var cCount = 7;
            if (ac.length > cCount) {
                cCount = ac.length;
            }
            for (var i = 0; i < cCount; i++) {
                var field = "";
                var value = "";
                if (ac.length > i) {
                    field = ac[i].field;
                    value = ac[i].value;
                }
                var trNode = g.create('tr', {
                    'class': 'infoWindowTR'
                }, tableNode);
                var tdNode = g.create('td', {
                    'class': 'infoWindowTdtdRight'
                }, trNode);
                tdNode.title = field;
                tdNode.innerHTML = field;

                tdNode = g.create('td', {
                    'class': 'infoWindowTd'
                }, trNode);
                tdNode.title = value;
                tdNode.innerHTML = value;
            }
        },
        setInfoData: function (obj) {
            var c = f.set;
            c(this.actionDiv, {
                display: "block"
            });
            this.resize(170, 237);
            this._infoData = obj;
            this.setTitle(this._infoData.title);
            this.setInfoParameters(this._infoData.property[0].fieldInfo);
            this.show(this._infoData.point);
            return this;
        },
        onShow: function () {
            this.__registerMapListeners();
            this.startupDijits(this._title);
            this.startupDijits(this._content);
        },
        onHide: function () {
            this.__unregisterMapListeners();
        },
        _onShowPopupclick: function () {
            var at = new AttributeTable(this._infoData);
        },
        _onShowStreetViewclick: function () {
            var thisTemp = this;
            window.CommFun.transferXYToWGS84(this._infoData.point.x, this._infoData.point.y);
            setTimeout(function () {
                if (window.CommFun.wgsCoordinate) {
                    var x = window.CommFun.wgsCoordinate.split(',')[0];
                    var y = window.CommFun.wgsCoordinate.split(',')[1];
                    thisTemp._createStreetViewPopup(x, y);
                }
                else {
                    var popup = new MessagePopup({
                        titleLabel: "街景提示",
                        message: "坐标获取超时，请重新定位。"
                    });
                }
            }, 1000);
        },
        _createStreetViewPopup: function (x, y) {
            var thisTemp = this;
            this.streetViewContainer = html.create('div', {
                style: {
                    width: '1050px',
                    height: '550px'
                }
            }, this.domNode);
            this.streetviewPopup = new Popup({
                titleLabel: '街景图',
                content: this.streetViewContainer,
                width: 1050,
                height: 620
            });
            this.shelter = new LoadingShelter({
                hidden: true
            });
            this.shelter.placeAt(this.streetviewPopup);
            this.shelter.startup();
            this.shelter.show();
            var bdPoint = new BMap.Point(x, y);
            var panorama = new BMap.Panorama(this.streetViewContainer);
            var panoramaService = new BMap.PanoramaService();
            //坐标转换完之后的回调函数
            translateCallback = function (data) {
                if (data.status === 0) {
                    panoramaService.getPanoramaByLocation(data.points[0], function (data) {
                        var panoramaInfo = "";
                        if (data == null) {
                            thisTemp.streetviewPopup.close();
                            var popup = new MessagePopup({
                                titleLabel: "街景提示",
                                message: "偏离道路，百度街景无法获取，请重新定位。"
                            });
                            return;
                        }
                        else {
                            panorama.setId(data.id);  //全景ID
                            panorama.show(); //显示全景
                            thisTemp.shelter.hide();
                        }
                    });
                }
                else {
                    convertorPosition();
                }
            }
            convertorPosition = function () {
                var convertor = new BMap.Convertor();
                var pointArr = [];
                pointArr.push(bdPoint);
                convertor.translate(pointArr, 1, 5, translateCallback)
            }
            setTimeout(convertorPosition, 1000);
        },
        onResize: function () { },
        onAnchorChange: function () { }
    });
    h.mixin(d, {
        ANCHOR_UPPERRIGHT: "upperright",
        ANCHOR_LOWERRIGHT: "lowerright",
        ANCHOR_LOWERLEFT: "lowerleft",
        ANCHOR_UPPERLEFT: "upperleft"
    });
    l("extend-esri") && h.setObject("InfoWindow", d, u);
    return d
});