///////////////////////////////////////////////////////////////////////////
// Copyright © 2014 Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////

define(['dojo/_base/declare',
  'dijit/_WidgetBase',
  'dijit/_TemplatedMixin',
  'dijit/_WidgetsInTemplateMixin',
  'dojo/text!./templates/FieldStatistics.html',
  'dojo/_base/lang',
  'dojo/_base/html',
  'dojo/_base/array',
  'dojo/on',
  'dojo/query',
  'dojo/NodeList-manipulate',
  'dojo/when',
  'dijit/form/Select',
  "esri/lang",
  'hugegis/dijit/Popup',
  'hugegis/dijit/LoadingIndicator',
  'hugegis/utils',
  'hugegis/statisticsUtils',
  "dojox/grid/DataGrid",
  "dojo/data/ItemFileReadStore",
  'hugegis/dijit/ViewStack',
  'hugegis/dijit/Pagination',
  'hugegis/dijit/MessagePopup',
   'dojo/store/Memory',
   'hugegis/utilToXML',
    'dojox/charting/Chart2D',
    'dojox/charting/axis2d/Default',
    'dojox/charting/axis2d/Invisible',
    'dojox/charting/plot2d/Columns',
    'dojox/charting/plot2d/Bars',
    'dojox/charting/plot2d/Lines',
    'dojox/charting/plot2d/Pie',
    'dojox/charting/action2d/Tooltip',
    'dojox/charting/action2d/Highlight',
    'dojox/charting/action2d/MoveSlice',
    'dojox/charting/action2d/Magnify',
    'dojox/charting/widget/Legend',
    'dojo/fx/easing',
    'dijit/form/ComboBox',
], function (declare, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, template, lang, html, array, on, query, nlm, when, Select,
  esriLang, Popup, LoadingIndicator, hugegisUtils, statUtils, DataGrid, ItemFileReadStore, ViewStack, Pagination, MessagePopup, Memory
  , utilToXML, Chart, DefaultAxis, InvisibleAxis, Columns, Bars, Lines, Pie, Tooltip, Highlight, MoveSlice, Magnify, Legend
  , easing
  ) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,
        statInfo: null,
        loading: null,
        widgets: null,
        pagination: null,
        viewStack: null,
        tableName: "",
        //resultData: null,
        commonServiceURL: null,
        xmlUtil: new utilToXML(),
        staField: "",
        btnIndex: 0,
        dataArrar:[],
        chartlabels: [],
        dealPieData: [],
        operChartNum: 0,
        operPieNum: 0,
        resultObj: null,
        colorArray:[],
        tempsql: "",
        commonServiceURL: null,
        newqueryDate:[],

        postMixInProperties: function () {
            this.nls = window.hugegisNls.fieldStatistics;
            //lang.mixin(this.nls, window.hugegisNls.common);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.viewStack = new ViewStack({
                viewType: 'dom',
                views: [this.listNode, this.columnNode, this.pieNode]
            });
            html.place(this.viewStack.domNode, this.domNode);

            this.viewStack.switchView(0);

            this.pagination = new Pagination({
                _maxSize: 0,
                defaultPageSize: 13,
                maxPageStep: 10,
                grid: this.gridDiv,
                parentWidget: this,
                option: null
            });
            this.pagination.placeAt(this.dataListPager);
            //颜色数组赋值
            this.colorArray = window._widgetManager.appConfig.pieColor.split(',');
        },

        showCount: function (count, sqlAll, commonservice,titleList) {
            var layout = titleList;
            this.gridDiv.setStructure(layout);
            this.gridDiv.canSort = function () { return false; };

            this.pagination._maxSize = count;
            this.pagination.initPage();

            this.tempsql = sqlAll;
            this.commonServiceURL = commonservice;
            this.commonServiceURL = this.widgets.commonServiceURL;
            this.getDictByTable();
        },

        showContent: function (dataList) {
            var data = {
                identifier: "index",
                items: []
            }
            //this.resultData = dataList;
            for (var i = 0; i < dataList.length; i++) {
                var obj = dataList[i];
                obj["index"] = i;
                data.items.push(obj);
            }
            var store = new ItemFileReadStore({ data: data });
            this.gridDiv.setStore(store);

            if (this.loading) {
                this.loading.hide();
            }
        },

        queryData: function (sIndex, eIndex) {
            if (this.loading) {
                this.loading.show();
            }
            this.widgets._onPaginationQuery(this.statInfo, sIndex, eIndex)
        },

        _onBtnClicked: function () {
            if (this.widgets) {
                this.loading.show();
                this.widgets._onExportClick(this.statInfo);
            }
        },

        _onBtnClick: function (event) {
            var bnt = event.currentTarget;
            html.removeClass(this.tableBnt, 'hugegis-state-disabled');
            html.removeClass(this.columnBnt, 'hugegis-state-disabled');
            html.removeClass(this.pieBnt, 'hugegis-state-disabled');
            this.btnIndex = bnt.id;
            switch (bnt.id) {
                case "1":
                    html.addClass(this.tableBnt, 'hugegis-state-disabled');
                    this.viewStack.switchView(0);
                    this.fieldDiv.style.visibility = "hidden";
                    break;
                case "2":
                    html.addClass(this.columnBnt, 'hugegis-state-disabled');
                    this.viewStack.switchView(1);
                    this.fieldDiv.style.visibility = "visible";
                    if (this.operChartNum == 0) {
                        this.operChartNum++;
                        this.showChart();
                    }
                    break;
                case "3":
                    html.addClass(this.pieBnt, 'hugegis-state-disabled');
                    this.viewStack.switchView(2);
                    this.fieldDiv.style.visibility = "visible";
                    if (this.operPieNum == 0) {
                        this.operPieNum++;
                        this.showPie();
                    }
                    break;
            }
        },

        showContentAsPopup: function (_widgets, statInfo) {
            this.statInfo = statInfo;
            this.widgets = _widgets;
            if (this._statisticsPopup && this._statisticsPopup.domNode) {
                this._statisticsPopup.close();
            }
            this._statisticsPopup = null;

            this._statisticsPopup = new Popup({
                titleLabel: "详细表格：" + statInfo.typeName,
                content: this.domNode,
                width: 750,
                height: 500//,
                //buttons: [{
                //  label: "确定"
                //}]
            });
            //查询数据字典
            this.tableName = statInfo.xwbm;
            if (!statInfo.xwbm) {
                var obj = statInfo.child;
                if (obj) {
                    this.tableName = obj[0].xwbm;
                }
            }
            if (this.tableName.toUpperCase() == "TZ_GXSX") {
                this.unitlabel.innerText = "单位：米";
            }
            else {
                this.unitlabel.innerText = "单位：个";
            }
        
            this.loading = new LoadingIndicator();
            this.loading.placeAt(this.domNode);
            this.loading.show();
        },

        getDictByTable: function () {
            var thisTemp = this;
            var xmlUtilTemp = this.xmlUtil;
            var URL = window.path + this.commonServiceURL + "/GetDictByTableName";
            var myname = dojo.toJson({ "TableName": this.tableName });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    if (response.d === "") {
                        var popup = new MessagePopup({
                            titleLabel: "查询提示",
                            message: "查询可统计字段错误!"
                        });
                        return;
                    }
                    var result = [];
                    //跨浏览器，ie和火狐解析xml使用的解析器是不一样的。 
                    var xmlStrDoc = null;
                    if (window.DOMParser) {
                        // Mozilla Explorer  
                        parser = new DOMParser();
                        xmlStrDoc = parser.parseFromString(response.d, "text/xml");
                    } else {
                        // Internet Explorer  
                        xmlStrDoc = new ActiveXObject("Microsoft.XMLDOM");
                        xmlStrDoc.async = "false";
                        xmlStrDoc.loadXML(response.d);
                    }
                    var fieldNodes = xmlUtilTemp.xmlGetNodes("Result", "Field", xmlStrDoc);
                    fieldNodes.forEach(dojo.hitch(this, function (node, idx, arr) {
                        var name = xmlUtilTemp.xmlGetAttribute(node, "FieldDisName");
                        var value = xmlUtilTemp.xmlGetAttribute(node, "FieldName");
                        var type = xmlUtilTemp.xmlGetAttribute(node, "FieldType");
                        var order = xmlUtilTemp.xmlGetAttribute(node, "FieldOrder");
                        var mappingcode = xmlUtilTemp.xmlGetAttribute(node, "MappingCode");
                        if (mappingcode != "Non-XMLNode passed to GeoRSSConfigWidget.getAttribute") {
                            if (mappingcode != "") {
                                var item = {
                                    name: name,
                                    value: value,
                                    type: type,
                                    mappingcode: mappingcode,
                                    id: order
                                };
                                result.push(item);
                            }
                        }
                    }));
                    var store = new Memory({ data: result });
                    thisTemp.staFieldDiv.store = store;
                    thisTemp.staFieldDiv.textbox.readOnly = true;
                    thisTemp.staFieldDiv.textbox.disabled = true;
                    //thisTemp.ExpressionTile.textbox.readOnly = true;
                    //thisTemp.ExpressionTile.textbox.disabled = true;
                    //thisTemp.codeField.textbox.readOnly = true;
                    //thisTemp.codeField.textbox.disabled = true;
                    thisTemp.chooseFirst(thisTemp.staFieldDiv);
                },
                error: function (error) {
                    alert(error);
                }
            };
            dojo.xhrPost(xhrArgs);
        },

        
        chooseFirst: function (combobox) {
            if (combobox.store.data.length > 0) {
                combobox.item = combobox.store.data[0];
                combobox.setValue(combobox.store.data[0].name);
                combobox.item = combobox.store.data[0];
            }
        },

        onPropertyChange: function () {
            var item = this.staFieldDiv.item;
            this.staField = item.value;
            if (this.tableName.toUpperCase() == "TZ_GXSX") {
                this.onManagerGXData();
            } else {
                this.onManagerSBData();
            }
        },

        onManagerGXData: function () {
            this.resultObj = new Object();
            this.dataArrar = [];
            this.chartlabels = [];
            this.newqueryDate = [];
            //var mIndex = 0;
            //for (var i = 0; i < this.resultData.length; i++) {
            //    var obj = this.resultData[i];
            //    if (obj[this.staField] in this.resultObj) {
            //        var num = Number(this.resultObj[obj[this.staField]]) + Number(obj["LENGTH"]);
            //        this.resultObj[obj[this.staField]] =Number(num.toFixed(2));
            //    } else {
            //        this.resultObj[obj[this.staField]] =Number(Number(obj["LENGTH"]).toFixed(2));
            //    }
            //}
            //for (var obj in this.resultObj) {
            //    mIndex++;
            //    this.dataArrar.push(this.resultObj[obj]);
            //    var labelObj = new Object();
            //    labelObj["value"] = mIndex;
            //    labelObj["text"] = obj;
            //    this.chartlabels.push(labelObj);
            //}
            var thisTemp = this;
            var sql = "select " + this.staField + ",sum(length) as COUNT " + this.tempsql + this.staField;
            var URL = window.path + this.commonServiceURL + "/CommonSelect";
            var myname = dojo.toJson({ "ConnSection": "PropDBConn", "SQL": sql });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    var myData = dojo.fromJson(response.d);
                    thisTemp.newqueryDate = myData;
                    var m_index = 0;
                    for (var i = 0; i < myData.length; i++) {
                        m_index++;
                        var obj = myData[i];
                        var labelObj = new Object();
                        labelObj["value"] = m_index;
                        labelObj["text"] = obj[thisTemp.staField];
                        thisTemp.chartlabels.push(labelObj);
                        thisTemp.dataArrar.push(obj["COUNT"]);
                    }
                    if (thisTemp.btnIndex == 2) {
                        if (thisTemp.operChartNum != 0) {
                            thisTemp.operPieNum = 0;
                            thisTemp.showChart();
                        }
                    } else if (thisTemp.btnIndex == 3) {
                        if (thisTemp.operPieNum != 0) {
                            thisTemp.operChartNum = 0;
                            thisTemp.showPie();
                        }
                    }
                },
                error: function (error) {
                    var popup = new MessagePopup({
                        titleLabel: "空间查询1-异常提示",
                        message: "服务调用异常!"
                    });
                }
            };
            dojo.xhrPost(xhrArgs);
        },

        onManagerSBData: function () {
            this.resultObj = new Object();
            this.dataArrar = [];
            this.chartlabels = [];
            this.newqueryDate = [];
            //var mIndex = 0;
            //for (var i = 0; i < this.resultData.length; i++) {
            //    var obj = this.resultData[i];
            //    if (obj[this.staField] in this.resultObj) {
            //        this.resultObj[obj[this.staField]] = this.resultObj[obj[this.staField]] + 1;
            //    } else {
            //        this.resultObj[obj[this.staField]] = 1;
            //    }
            //}
            //for (var obj in this.resultObj)
            //{
            //    mIndex++;
            //    this.dataArrar.push(this.resultObj[obj]);
            //    var labelObj = new Object();
            //    labelObj["value"] = mIndex;
            //    labelObj["text"] = obj;
            //    this.chartlabels.push(labelObj);
            //}
            var thisTemp = this;
            var sql = "select " + this.staField + ",count(*) as COUNT " + this.tempsql + this.staField;
            var URL = window.path + this.commonServiceURL + "/CommonSelect";
            var myname = dojo.toJson({ "ConnSection": "PropDBConn", "SQL": sql });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    var myData = dojo.fromJson(response.d);
                    thisTemp.newqueryDate = myData;
                    var m_index = 0;
                    for (var i = 0; i < myData.length;i++)
                    {
                        m_index++;
                        var obj = myData[i];
                        var labelObj = new Object();
                        labelObj["value"] = m_index;
                        labelObj["text"] = obj[thisTemp.staField];
                        thisTemp.chartlabels.push(labelObj);
                        thisTemp.dataArrar.push(obj["COUNT"]);
                    }
                    if (thisTemp.btnIndex == 2) {
                        if (thisTemp.operChartNum != 0) {
                            thisTemp.operPieNum = 0;
                            thisTemp.showChart();
                        }
                    } else if (thisTemp.btnIndex == 3) {
                        if (thisTemp.operPieNum != 0) {
                            thisTemp.operChartNum = 0;
                            thisTemp.showPie();
                        }
                    }
                },
                error: function (error) {
                    var popup = new MessagePopup({
                        titleLabel: "空间查询1-异常提示",
                        message: "服务调用异常!"
                    });
                }
            };
            dojo.xhrPost(xhrArgs);
        },

        showChart: function () {
            var div = document.getElementById("chartNodeDiv");
            while (div.hasChildNodes()) {
                div.removeChild(div.firstChild);
            }
            //this.chartNode.innerHTML = "";
            var newChart = new Chart(this.chartNode);
            newChart.addPlot('default', {
                type: Columns,  //图形类型
                //label: true,
                //labelStyle: "outside",
                //labelOffset:25,
                gap: 10,          //柱子之间的间距
             
                //hAxis: "x",
                //vAxus: "y",
                //markers: true,  //是否显示刻度
                //animate: { duration: 1000 },
                minBarSize:10,    //最小值
                maxBarSize:200,    //最大值
                animate: { duration: 1500, easing: easing.bounceInOut }
            }
                );
            newChart.addAxis("x", {
                labels: this.chartlabels,
                stroke: "green",
                font: "normal normal bold 10pt Tahoma",
                fontColor:"black",
                minorLabels: false,//设置小刻度
                //majorLabels:true,//设置大刻度
                majorLabels: true,
                minorTicks: { color: "red", length: 5 },
                labelSizeChange:true,
            });
            newChart.addAxis("y", {
                vertical: true,
                stroke: "green",
                font: "normal normal bold 7pt Tahoma",
                fontColor: "black",
                majorLabels: true,
                minorTicks: {color:"red",length:5},
                minorLabels: true,   //中间label是否显示
                microTicks:false,
                includeZero: true,
                natural: true,
            });


            newChart.addSeries("测试1", this.dataArrar, { stroke: { color: "steelblue" }, fill: "steelblue" });
            var anim1 = new Highlight(newChart, "default", { highlight: "lightskyblue" });
            var anim2 = new Tooltip(newChart, "default");
            //var anim3 = new Magnify(newChart, "default");
            newChart.render();
        },

        showPie: function () {
            var div = document.getElementById("pieNodeDiv");
            while (div.hasChildNodes()) {
                div.removeChild(div.firstChild);
            }
            this.managerPieData();
            var newChart = new Chart(this.pieChartNode);
            //newChart.setTheme(dojox.charting.SimpleTheme);
            newChart.addPlot('default', {
                type: Pie,  //图形类型
                font: "normal normal bold 8pt Tahoma",
                fontColor: "black",
                radius: 120,
                labelOffset: -40,
                }
              );
            newChart.addSeries("Series A", this.dealPieData);
            var anim1 = new Highlight(newChart, "default");
            var anim2 = new Tooltip(newChart, "default");
            var anim3 = new MoveSlice(newChart, "default");
            newChart.render();
        },

        managerPieData: function () {
            this.dealPieData = [];
            var sum = 0;
            for (var i = 0; i < this.newqueryDate.length; i++)
            {
                sum += parseFloat(this.newqueryDate[i]["COUNT"]);
            }
            var mIndex = 0;
            for (var i = 0; i < this.newqueryDate.length; i++) {
                var mObj = this.newqueryDate[i];
                var mPct = Math.round((mObj["COUNT"] / sum) * 100);
                var mPieObj = new Object();
                mPieObj["y"] = mObj["COUNT"];
                mPieObj["text"] = mObj[this.staField];
                mPieObj["color"] = this.getColor(mIndex);
                mPieObj["stroke"] = "black";
                mPieObj["tooltip"] = mObj[this.staField] + ":" + mObj["COUNT"] + "(" + mPct + "%)";
                this.dealPieData.push(mPieObj);
                mIndex++;
            }
            //if (this.resultObj != null) {
            //    for (var obj in this.resultObj) {
            //        sum += parseFloat(this.resultObj[obj]);
            //    }
            //    var mIndex = 0;
            //    for (var obj in this.resultObj) {
            //        var mPct = Math.round((this.resultObj[obj] / sum) * 100);
            //        var mPieObj = new Object();
            //        mPieObj["y"] = this.resultObj[obj];
            //        mPieObj["text"] = obj;
            //        mPieObj["color"] = this.getColor(mIndex);
            //        mPieObj["stroke"] = "black";
            //        mPieObj["tooltip"] = obj + ":" + this.resultObj[obj] + "(" + mPct + "%)";
            //        this.dealPieData.push(mPieObj);
            //        mIndex++;
            //    }
            //}
        },

        getColor: function (colorIndex) {
            //return '#' + ('00000' + (Math.random() * 0x1000000 << 0).toString(16)).slice(-6);
            //var rand = Math.random();
            //var mNumber = Math.round(rand * 9);
            //return this.colorArray[mNumber];
            var mCount = this.colorArray.length;
            var indexMod = colorIndex % mCount;
            return this.colorArray[indexMod];
        }
    });
});