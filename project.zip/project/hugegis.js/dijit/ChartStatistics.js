///////////////////////////////////////////////////////////////////////////
// Copyright © 2014 Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////

define(['dojo/_base/declare',
  'dijit/_WidgetBase',
  'dijit/_TemplatedMixin',
  'dijit/_WidgetsInTemplateMixin',
  'dojo/text!./templates/ChartStatistics.html',
  'dojo/_base/lang',
  'dojo/_base/html',
  'dojo/_base/array',
  'dojo/on',
  'dojo/query',
  'dojo/NodeList-manipulate',
  'dojo/when',
  'dijit/form/Select',
  "esri/lang",
  'hugegis/dijit/Popup',
  'hugegis/dijit/LoadingIndicator',
  'hugegis/utils',
  'hugegis/statisticsUtils',
  "dojox/grid/DataGrid",
  "dojo/data/ItemFileReadStore",
  'hugegis/dijit/ViewStack',
  'hugegis/dijit/Pagination',
   'dojo/store/Memory',
   'hugegis/utilToXML',
    'dojox/charting/Chart2D',
    'dojox/charting/axis2d/Default',
    'dojox/charting/axis2d/Invisible',
    'dojox/charting/plot2d/Columns',
    'dojox/charting/plot2d/Bars',
    'dojox/charting/plot2d/Lines',
    'dojox/charting/plot2d/Pie',
    'dojox/charting/action2d/Tooltip',
    'dojox/charting/action2d/Highlight',
    'dojox/charting/action2d/MoveSlice',
    'dojox/charting/action2d/Magnify',
    'dojox/charting/widget/Legend',
    'dojo/fx/easing',
    'dijit/form/ComboBox',
], function (declare, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, template, lang, html, array, on, query, nlm, when, Select,
  esriLang, Popup, LoadingIndicator, hugegisUtils, statUtils, DataGrid, ItemFileReadStore, ViewStack, Pagination, Memory
  , utilToXML, Chart, DefaultAxis, InvisibleAxis, Columns, Bars, Lines, Pie, Tooltip, Highlight, MoveSlice, Magnify, Legend
  , easing
  ) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,
        loading: null,
        widgets: null,
        pagination: null,
        viewStack: null,
        tableName: "",
        resultData: null,
        commonServiceURL: null,
        xmlUtil: new utilToXML(),
        staField: "",
        btnIndex: 0,
        dataArray:[],
        chartlabels: [],
        dealPieData: [],
        dealColData:[],
        operChartNum: 0,
        operPieNum: 0,
        resultObj: null,
        colorArray:[],
        dataList: [],
        isLine: true,
        totalNum:0,

        postMixInProperties: function () {
            this.nls = window.hugegisNls.fieldStatistics;
            //lang.mixin(this.nls, window.hugegisNls.common);
        },

        postCreate: function () {
            this.inherited(arguments);
            this.viewStack = new ViewStack({
                viewType: 'dom',
                views: [this.allcolumnNode, this.allpieNode]
            });
            html.place(this.viewStack.domNode, this.domNode);
            this.viewStack.switchView(0);
            //this.pagination = new Pagination({
            //    _maxSize: 0,
            //    defaultPageSize: 13,
            //    maxPageStep: 10,
            //    grid: this.gridDiv,
            //    parentWidget: this,
            //    option: null
            //});
            //this.pagination.placeAt(this.dataListPager);
            //颜色数组赋值
            this.btnIndex = 1;
            this.colorArray = window._widgetManager.appConfig.pieColor.split(',');
        },

        showContentAsPopup: function (_widgets) {
            this.widgets = _widgets;
            this.dataList = _widgets.dataList;
            if (this._statisticsPopup && this._statisticsPopup.domNode) {
                this._statisticsPopup.close();
            }
            this._statisticsPopup = null;

            this._statisticsPopup = new Popup({
                titleLabel: "空间查询结果统计",
                content: this.domNode,
                width: 750,
                height: 500//,
            });
            //this.loading = new LoadingIndicator();
            //this.loading.placeAt(this.domNode);
            //this.loading.show();
            this.radioChange();
        },

        _onBtnClick: function (event) {
            var bnt = event.currentTarget;
            html.removeClass(this.columnBnt, 'hugegis-state-disabled');
            html.removeClass(this.pieBnt, 'hugegis-state-disabled');
            if (this.btnIndex == bnt.id) return;
            else {
                this.btnIndex = bnt.id
            }
            switch (bnt.id) {
                case "1":
                    html.addClass(this.columnBnt, 'hugegis-state-disabled');
                    this.viewStack.switchView(0);
                    //if (this.operChartNum == 0) {
                    //    this.operChartNum++;
                    this.showChart();
                    //}
                    break;
                case "2":
                    html.addClass(this.pieBnt, 'hugegis-state-disabled');
                    this.viewStack.switchView(1);
                    //if (this.operPieNum == 0) {
                    //    this.operPieNum++;
                    this.showPie();
                    //}
                    break;
            }
        },

        radioChange: function (event) {
            this.dataArray = [];
            if (this.radio1.checked) {
                this.isLine = true;
                this.unitlabel.innerText = "单位：米";
                this.tableName = this.radio1.value;
            }
            else {
                this.isLine = false;
                this.unitlabel.innerText = "单位：个";
                if(this.radio2.checked)
                    this.tableName = this.radio2.value;
                else
                    this.tableName = this.radio3.value;
            }
            //匹配数据
            for (var i = 0; i < this.dataList.length; i++) {
                if (this.dataList[i].typeName == this.tableName) {
                    this.dataArray = this.dataList[i].child;
                    //求总数
                    var totalStr = this.dataList[i].name;
                    if (this.isLine == true) {
                        var totalList = totalStr.split("总长");
                        var mStr = totalList[1];
                        if (mStr.indexOf("公里") > -1) {
                            this.totalNum = Number(mStr.substring(0, mStr.length - 3)) * 1000;
                        }
                        else {
                            this.totalNum = Number(mStr.substring(0, mStr.length - 2));
                        }
                    }
                    else {
                        var totalList = totalStr.split('(');
                        var mStr = totalList[1];
                        this.totalNum = Number(mStr.substring(1, mStr.length - 2));
                    }
                    break;
                }
            }
            if (this.btnIndex == 1) {
                this.onManagerColData();
                this.showChart();
            }
            else {
                this.showPie();
            }
        },

        onManagerPieData: function () {
            this.dealPieData = [];
            var mIndex = 0;
            for (var j = 0; j < this.dataArray.length; j++) {
                var mPieObj = new Object();
                var mCurNum = 0;
                var obj = this.dataArray[j];
                if (this.isLine == true) {
                    var pieList = obj.name.split("总长");
                    var pieStr = pieList[1];
                    if (pieStr.indexOf("公里") > -1) {
                        mCurNum=Number(pieStr.substring(0, pieStr.length - 3)) * 1000;
                    }
                    else {
                        mCurNum=Number(pieStr.substring(0, pieStr.length - 2));
                    }
                }
                else {
                    var pieList = obj.name.split('(');
                    var pieStr = pieList[1];
                    mCurNum=Number(pieStr.substring(1, pieStr.length - 2));
                }
                var mPct = Math.round((mCurNum / this.totalNum) * 100);
                mPieObj["y"] = mCurNum;
                mPieObj["text"] = obj.typeName;
                mPieObj["color"] = this.getColor(mIndex);
                mPieObj["stroke"] = "black";
                mPieObj["tooltip"] = obj.typeName + ":" + mCurNum + "(" + mPct + "%)";
                this.dealPieData.push(mPieObj);
                mIndex++;
            }
        },

        onManagerColData: function () {
            //this.resultObj = new Object();
            this.chartlabels = [];
            this.dealColData = [];
            var mIndex = 0;
            for (var j = 0; j < this.dataArray.length; j++) {
                var obj = this.dataArray[j];
                mIndex++;
                var labelObj = new Object();
                labelObj["value"] = mIndex;
                labelObj["text"] = obj.typeName;
                this.chartlabels.push(labelObj);
                //截取值
                
                if (this.isLine == true) {
                    var staList = obj.name.split("总长");
                    var staStr = staList[1];
                    if (staStr.indexOf("公里") > -1) {
                        this.dealColData.push(Number(staStr.substring(0, staStr.length - 3))*1000)
                    }
                    else {
                        this.dealColData.push(Number(staStr.substring(0, staStr.length - 2)));
                    }
                }
                else {
                    var staList = obj.name.split('(');
                    var staStr = staList[1];
                    this.dealColData.push(Number(staStr.substring(1, staStr.length-2)));
                }
            }
        },

        showChart: function () {
            var div = document.getElementById("chartNodeDiv");
            while (div.hasChildNodes()) {
                div.removeChild(div.firstChild);
            }
            if (this.dealColData.length == 0) return;
            var newChart = new Chart(this.chartNode);
            newChart.addPlot('default', {
                type: Columns,  //图形类型
                //label: true,
                //labelStyle: "outside",
                //labelOffset:25,
                gap: 10,          //柱子之间的间距        
                //hAxis: "x",
                //vAxus: "y",
                //markers: true,  //是否显示刻度
                //animate: { duration: 1000 },
                minBarSize:10,    //最小值
                maxBarSize:200,    //最大值
                animate: { duration: 1500, easing: easing.bounceInOut }
            }
                );
            newChart.addAxis("x", {
                labels: this.chartlabels,
                stroke: "green",
                font: "normal normal bold 10pt Tahoma",
                fontColor:"black",
                minorLabels: false,//设置小刻度
                //majorLabels:true,//设置大刻度
                majorLabels: true,
                minorTicks: { color: "red", length: 5 },
                labelSizeChange:true,
            });
            newChart.addAxis("y", {
                vertical: true,
                stroke: "green",
                font: "normal normal bold 7pt Tahoma",
                fontColor: "black",
                majorLabels: true,
                minorTicks: {color:"red",length:5},
                minorLabels: true,   //中间label是否显示
                microTicks:false,
                includeZero: true,
                natural: true,
            });


            newChart.addSeries("测试1",this.dealColData, { stroke: { color: "steelblue" }, fill: "steelblue" });
            var anim2 = new Tooltip(newChart, "default");
            //var anim3 = new Magnify(newChart, "default");
            newChart.render();
        },

        showPie: function () {
            var div = document.getElementById("pieNodeDiv");
            while (div.hasChildNodes()) {
                div.removeChild(div.firstChild);
            }
            this.onManagerPieData();
            var newChart = new Chart(this.pieChartNode);
            //newChart.setTheme(dojox.charting.SimpleTheme);
            newChart.addPlot('default', {
                type: Pie,  //图形类型
                font: "normal normal normal 8pt Tahoma",
                fontColor: "black",
                radius: 130,
                labelOffset: -30,
                }
              );
            newChart.addSeries("Series A", this.dealPieData);
            var anim1 = new Highlight(newChart, "default");
            var anim2 = new Tooltip(newChart, "default");
            var anim3 = new MoveSlice(newChart, "default");
            newChart.render();
        },

        getColor: function (colorIndex) {
            var mCount = this.colorArray.length;
            var indexMod = colorIndex % mCount;
            return this.colorArray[indexMod];
        }
    });
});