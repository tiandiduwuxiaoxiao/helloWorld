///////////////////////////////////////////////////////////////////////////
// Copyright © 2014 Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////

define(['dojo/_base/declare',
  'dijit/_WidgetBase',
  'dijit/_TemplatedMixin',
  'dijit/layout/TabContainer',
  "dijit/layout/ContentPane",
  'hugegis/dijit/Popup',
  'dojo/_base/lang',
  'dojo/on', 'dojo/_base/html',
  'dojo/dom-construct',
  'dojo/aspect',
  "dojo/_base/connect",
  'dijit/form/Button',
  'hugegis/HashTable',
  'hugegis/utilToXML',
  'hugegis/dijit/MessagePopup',
  'hugegis/dijit/LoadingShelter',
  'hugegis/dijit/PopupPage',
  'dojox/grid/DataGrid',
  "dojo/data/ItemFileReadStore",
  'hugegis/dijit/ImageLabel',
  'hugegis/dijit/Mp3Play',
  'dojo/text!./templates/AttributeTable.html'
], function (declare, _WidgetBase, _WidgetsInTemplateMixin, TabContainer, ContentPane, Popup, lang, on, html, domConstruct, aspect, connect, Button, HashTable, utilToXML, MessagePopup, LoadingShelter, PopupPage, DataGrid, ItemFileReadStore, ImageLabel, Mp3Play, template) {
    return declare([_WidgetBase, _WidgetsInTemplateMixin], {
        templateString: template,
        commonServiceURL: null,
        shelter: null,
        _infoData: null,
        _tabPagesList: [],
        _tabContainer: null,
        xmlUtil: new utilToXML(),
        mediaBindingHash: null,

        constructor: function (params) {
            this._infoData = params;
        },
        postCreate: function () {
            this.inherited(arguments);
            domConstruct.empty(this.domNode);
            this.commonServiceURL = window._widgetManager.appConfig.services.CommonServiceURL;
            this._tabPagesList = [];
            if (this._tabContainer) {
                this._tabContainer.destroy();
            }
            this.initDiv();
        },
        initDiv: function () {
            var AttributeTableDiv = html.create("div", {}, this.domNode);
            var tabDiv = html.create("div");
            html.place(tabDiv, AttributeTableDiv);
            this._tabContainer = new TabContainer({
                style: "width: 100%;"
            }, tabDiv);

            this.shelter = new LoadingShelter({
                hidden: true
            });
            this.shelter.placeAt(AttributeTableDiv);
            this.shelter.startup();
            this.shelter.show();

            html.setStyle(this._tabContainer.domNode, 'height', '435px');
            var paneJson = {};
            paneJson.selected = true;
            paneJson.paneId = 0;
            paneJson.title = "属性信息";
            paneJson.name = "属性信息";
            paneJson.style = "height: 100%; width: 100%;";
            var cp = new ContentPane(paneJson);
            if (this._infoData && this._infoData.property) {
                this.initPropertyShow(cp.domNode, this._infoData.property, true);
            }
            this._tabPagesList.push(cp);
            this._tabContainer.addChild(cp);
            cp.startup();
            if (this._infoData && this._infoData.affiliated) {
                this.initAffiliatShow(this._infoData.affiliated);
            }
            var _statisticsPopup = new Popup({
                titleLabel: this._infoData.title,
                content: AttributeTableDiv,
                width: 750,
                height: 500
            });
            this._tabContainer.startup();
            this.own(aspect.after(this._tabContainer, "selectChild", lang.hitch(this, this.tabChanged)));
            this.shelter.hide();
        },
        initAffiliatShow: function (affiAc) {
            for (var i = 0; i < affiAc.length; i++) {
                var obj = affiAc[i];
                var paneJson = {};
                paneJson.paneId = this._tabPagesList.length;
                paneJson.title = obj.label + "[" + obj.count + "]";
                paneJson.name = obj.label;
                paneJson.tabName = obj.tabName;
                paneJson.sql = obj.sql;
                paneJson.style = "height: 100%; width: 100%;";
                var cp = new ContentPane(paneJson);
                this._tabPagesList.push(cp);
                this._tabContainer.addChild(cp);
                cp.startup();
            }
        },
        initInputPage: function () {
            var url = "";
            if (this._infoData.sblb) {
                var tmpObj = window.CommFun.sblb_PropDBConn.find(this._infoData.sblb);
                url = window._widgetManager.appConfig.services.MainTableUrl + "?gjz=" + this._infoData.gjz + "&table=" + tmpObj.TABLENAME;
            }
            else {
                url = window._widgetManager.appConfig.services.SubsidiaryTableUrl + "?gjz=" + this._infoData.gjz + "&table=" + this._infoData.tablename;
            }
            var popup = new PopupPage({
                title: "属性编辑",
                url: url
            });
            popup.initPopupPage();
        },
        initPropertyShow: function (cpNode, ac, bool) {
            domConstruct.empty(cpNode);
            var tableNode = domConstruct.create('table', {
                'class': 'attributeTable'
            });
            var cCount = 3;
            var _table = "";
            var mediaAC = [];
            if (this._tabContainer.selectedChildWidget) {
                _table = this._tabContainer.selectedChildWidget.params.tabName;
            }
            for (var i = 0; i < ac.length; i++) {
                var group = ac[i].group;
                if (bool && group == "概要信息") {
                    continue;
                }
                var fieldInfo = ac[i].fieldInfo
                var trNode = domConstruct.create('tr', {
                    'class': 'attributeColspanTR'
                }, tableNode);
                var tdNode = domConstruct.create('td', {
                    'class': 'attributeColspanTD',
                    'colspan': '' + (cCount * 2) + ''
                }, trNode);
                tdNode.innerHTML = group;
                var fieldTdNode = null;
                var valueTdNode = null;
                var tmpMediaFieldArr = [];//多媒体信息项数组，临时存放多媒体信息项
                var tempK = 0;
                for (var j = 0; j < fieldInfo.length; j++) {
                    var tmpField = fieldInfo[j].field;
                    var tmpValue = fieldInfo[j].value;
                    //如果是多媒体数据，则组织多媒体数组
                    var tmpValueType = this.getMediaType(tmpValue);
                    if (tmpValueType != "") {
                        //暂时存放，信息展示界面构建完成后恢复
                        tmpMediaFieldArr.push(fieldInfo[j]);
                        var tmpMHash = this.getMediaBindingHash();
                        if (tmpMHash == null || tmpMHash.size < 1) {
                            continue;
                        }
                        var tmpItem = null;
                        if (!_table) {
                            tmpItem = tmpMHash.find(tmpValueType);
                        } else {
                            tmpItem = tmpMHash.find(_table);
                            if (tmpItem == null) {
                                tmpItem = tmpMHash.find(tmpValueType);
                            }
                        }
                        if (tmpItem == null) {
                            continue;
                        }
                        //封面图片
                        var tmpCover = String(tmpItem.cover);
                        //多媒体信息头部URL
                        var tmpHeaderUrl = String(tmpItem.headerurl);
                        //名称字段
                        var tmpNameField = String(tmpItem.namefield);
                        var tmpNameItem = this.xmlUtil.getAcItem(fieldInfo, "fieldname", tmpNameField);
                        var tmpName = (tmpNameItem == null ? tmpField : tmpNameItem.value);

                        if (String(tmpHeaderUrl) == "") {
                            //Alert("获取图片头部地址失败，请检查配置文件");
                            continue;
                        }
                        tmpHeaderUrl = tmpHeaderUrl.substring(tmpHeaderUrl.length - 1) == "/" ? tmpHeaderUrl : (tmpHeaderUrl + "/");

                        var tmpSeparator = String(tmpItem.separator);
                        var tmpUrlAr = tmpValue.split(tmpSeparator);
                        for (var k = 0; k < tmpUrlAr.length; k++) {
                            if (String(tmpUrlAr[k]) == "")
                                continue;
                            mediaAC.push(
								{
								    label: tmpName,
								    url: tmpHeaderUrl + String(tmpUrlAr[k]),
								    cover: (tmpValueType == "image" ? tmpHeaderUrl + String(tmpUrlAr[k]) : tmpCover),
								    type: tmpValueType,
								    supportTable: tmpItem.supportTable
								});
                        }
                        continue;
                    } else {
                        if ((tempK % cCount) == 0) {
                            trNode = domConstruct.create('tr', {}, tableNode);
                        }
                        fieldTdNode = domConstruct.create('td', {
                            'class': 'attributeTdRight'
                        }, trNode);
                        fieldTdNode.innerHTML = tmpField;
                        valueTdNode = domConstruct.create('td', {
                            'class': 'attributeTd'
                        }, trNode);
                        //valueTdNode.innerHTML = fieldInfo[j].value;
                        valueTdNode.title = tmpValue;
                        var inputNode = domConstruct.create('input', {
                            'class': 'attributeInput',
                            'data-dojo-attach-point': String(fieldInfo[j].fieldname),
                            'value': tmpValue,
                            'type': 'text',
                            'readOnly': 'true'
                        }, valueTdNode);
                    }
                    tempK++;
                }
            }
            //如果有多媒体信息，则增加一个多媒体信息组
            if (mediaAC.length > 0) {
                var mediaDivNode = domConstruct.create('div', {
                    'style': 'width: 100%;padding-top:10px;'
                });
                var mediaTableNode = domConstruct.create('table', {
                    'class': 'attributeTable'
                }, mediaDivNode);
                var mediaTrNode = domConstruct.create('tr', {
                    'class': 'attributeColspanTR'
                }, mediaTableNode);
                var mediaTdNode = domConstruct.create('td', {
                    'class': 'attributeColspanTD'
                }, mediaTrNode);
                mediaTdNode.innerHTML = "多媒体信息";
                var _mediaTrNode = domConstruct.create('tr', {}, mediaTableNode);
                var _mediaTdNode = domConstruct.create('td', {
                    'class': 'attributeTd'
                }, _mediaTrNode);
                for (var l = 0; l < mediaAC.length; l++) {
                    var tempObj = mediaAC[l];
                    var tempType = this.getMediaType(tempObj.cover);
                    if (tempType == "") {
                        tempObj.label = "现场文件";
                        tempObj.url = require.toUrl('hugegis') + "/css/images/media/file.png";
                    }
                    if (tempType == "mp3") {
                        var tmpMp3 = new Mp3Play(tempObj, _table, _mediaTdNode);
                    }
                    else {
                        var tmpPic = new ImageLabel(tempObj, _table, _mediaTdNode);
                    }
                }
                domConstruct.place(mediaDivNode, cpNode);
            }
            if (bool && this._infoData.sblb && window._widgetManager.appConfig.editableSBLB.indexOf(this._infoData.sblb) != -1 && window.CommFun.getPermissions("属性维护")) {
                var trNode = domConstruct.create('tr', {
                    'class': 'attributeColspanTR'
                }, tableNode);
                var tdNode = domConstruct.create('td', {
                    'class': 'attributeColspanTD',
                    'colspan': '' + (cCount * 2) + ''
                }, trNode);
                tdNode.innerHTML = "属性维护";
                trNode = domConstruct.create('tr', {}, tableNode);
                var fieldTdNode = domConstruct.create('td', {
                    'class': 'attributeTd',
                    'colspan': '' + (cCount * 2) + ''
                }, trNode);
                var valueTdNode = new Button({
                    class: 'hugegis-button',
                    iconClass: 'editbutton'
                });
                valueTdNode.containerNode.innerHTML = "属性编辑操作";
                valueTdNode.placeAt(fieldTdNode);
                this.connect(valueTdNode, "onClick", lang.hitch(this, "initInputPage"));
            }
            domConstruct.place(tableNode, cpNode);
        },
        //判断是否为图片
        getMediaType: function (url) {
            var bl = "";
            if (url == "")
                return bl;

            var tmpXMLList = window._widgetManager.appConfig.muiltmediaconfig.media;
            for (var i = 0; i < tmpXMLList.length; i++) {
                var tmpSuffixAr = String(tmpXMLList[i].suffix).split(";");
                for (var j = 0; j < tmpSuffixAr.length; j++) {
                    if (String(tmpSuffixAr[j]) == "")
                        continue;
                    if (url.toLocaleLowerCase().indexOf(String(tmpSuffixAr[j])) >= 0) {
                        bl = String(tmpXMLList[i].type);
                        break;
                    }
                }
            }
            return bl;
        },
        getMediaBindingHash: function () {
            if (this.mediaBindingHash != null) {
                return this.mediaBindingHash;
            }
            this.mediaBindingHash = new HashTable();
            this.mediaBindingHash.clear();
            var mediaList = window._widgetManager.appConfig.muiltmediaconfig.media;
            for (var i = 0; i < mediaList.length; i++) {
                var item = {};
                item["default"] = mediaList[i].defaultMedia;
                item["supportTable"] = String(mediaList[i].supportTable);
                item["type"] = String(mediaList[i].type);
                item["separator"] = String(mediaList[i].separator);
                item["suffix"] = String(mediaList[i].suffix);
                item["headerurl"] = String(mediaList[i].headerurl);
                item["cover"] = String(mediaList[i].cover);
                item["namefield"] = String(mediaList[i].namefield);

                var _supportTable = item["supportTable"];
                var _type = item["type"];
                if (_supportTable != "") {
                    this.mediaBindingHash.add(_supportTable, item);
                } else {
                    this.mediaBindingHash.add(_type, item);
                }
            }
            return this.mediaBindingHash;
        },
        tabChanged: function () {
            if (this._tabContainer && this._tabContainer.selectedChildWidget) {
                var params = this._tabContainer.selectedChildWidget.params;
                if (params.sql && !params["isInit"]) {
                    this.getWeb_AllTableSelect(params);
                }
            }
        },
        getWeb_AllTableSelect: function (params) {
            var thisTemp = this;
            thisTemp.shelter.show();
            var URL = window.path + this.commonServiceURL + "/AllTableSelect";
            //var URL = window.path + "WXWebService.asmx/AllTableSelect";
            var myname = dojo.toJson({ "SQL": params.sql, "TableName": params.tabName });
            var xhrArgs = {
                url: URL,
                handleAs: "json",
                headers: { "Content-Type": "application/json" },
                postData: myname,
                load: function (response) {
                    thisTemp.shelter.hide();
                    //跨浏览器，ie和火狐解析xml使用的解析器是不一样的。 
                    var xmlStrDoc = null;
                    if (window.DOMParser) {
                        // Mozilla Explorer  
                        parser = new DOMParser();
                        xmlStrDoc = parser.parseFromString(response.d, "text/xml");
                    } else {
                        // Internet Explorer  
                        xmlStrDoc = new ActiveXObject("Microsoft.XMLDOM");
                        xmlStrDoc.async = "false";
                        xmlStrDoc.loadXML(response.d);
                    }
                    var propAc = thisTemp.setAnalyticalData(xmlStrDoc);
                    if (propAc && propAc.length > 0) {
                        params["isInit"] = true;
                        thisTemp.addMultiData(propAc);
                    }
                },
                error: function (error) {
                    thisTemp.shelter.hide();
                    var popup = new MessagePopup({
                        titleLabel: "空间查询2-异常提示",
                        message: "服务调用异常!"
                    });
                }
            };
            dojo.xhrPost(xhrArgs);
        },
        setAnalyticalData: function (xmlStrDoc) {
            //解析记录信息
            var gridAc = new Array();
            var recordNodes = this.xmlUtil.xmlGetNodes("Result", "Record", xmlStrDoc);
            recordNodes.forEach(dojo.hitch(this, function (node, idx, arr) {
                var recordInfo = null;
                var fieldNodes = this.xmlUtil.xmlGetChildNodes("Field", node);
                fieldNodes.forEach(dojo.hitch(this, function (node1, idx1, arr1) {
                    if (String(this.xmlUtil.xmlGetAttribute(node1, "Visible")).toLowerCase() != "false") {
                        //分组信息
                        var group = String(this.xmlUtil.xmlGetAttribute(node1, "Group")).replace(/\s+/g, "");
                        if (group == "") {
                            group = "基本信息";
                        }
                        //字段名(描述)
                        var flabel = String(this.xmlUtil.xmlGetAttribute(node1, "Label")).replace(/\s+/g, "");
                        flabel = flabel.substring(0, flabel.indexOf(":"));
                        //字段名
                        var fieldName = this.xmlUtil.xmlGetAttribute(node1, "Name");
                        var fieldType = this.xmlUtil.xmlGetAttribute(node1, "Type");
                        //字段值
                        var value = String(this.xmlUtil.xmlGetAttribute(node1, "Value"));
                        var fieldObj = { field: flabel, value: value, fieldname: fieldName, type: fieldType };
                        if (!recordInfo) {
                            recordInfo = new Array();
                            recordInfo.push({ group: group, fieldInfo: [fieldObj] });
                        }
                        else {
                            var lock = false;
                            for (var j = 0; j < recordInfo.length; j++) {
                                if (group == recordInfo[j].group) {
                                    var ar = recordInfo[j].fieldInfo;
                                    ar.push(fieldObj);
                                    lock = true;
                                }
                            }
                            if (!lock) {
                                recordInfo.push({ group: group, fieldInfo: [fieldObj] });
                            }
                        }
                    }
                }));
                //测试用
                //recordInfo.push({group:"测试1",fieldInfo:[{field:"图片1",value:"videoMap.png"},{field:"文件1",value:"test.xlsx"},{field:"MP3",value:"Nasus.mp3"},{field:"图片2",value:"2.jpg"}]});
                //recordInfo.push({ group: "测试1", fieldInfo: [{ field: "MP3", value: "horse.mp3" }] });
                gridAc.push(recordInfo);
            }));
            return gridAc;
        },
        addMultiData: function (propAc) {
            var cp = this._tabContainer.selectedChildWidget;
            var cpNode = cp.domNode;
            if (propAc.length == 1) {
                this.initPropertyShow(cpNode, propAc[0], false);
            } else {
                var divNode = domConstruct.create('div', {
                    'style': 'width: 100%;'
                }, cpNode);
                var data = {
                    identifier: "index",
                    items: []
                }
                var fCount = 6;
                for (i = 0; i < propAc.length; i++) {
                    var obj = { index: i };
                    for (var j = 0; j < fCount; j++) {
                        var tmpItem = propAc[i][0].fieldInfo[j];
                        if (tmpItem) {
                            obj[tmpItem.fieldname] = tmpItem.value;
                        }
                    }
                    data.items.push(obj);
                }
                var store = new ItemFileReadStore({ data: data });
                var layout = [];
                if (propAc[0][0].fieldInfo.length < fCount)
                    fCount = propAc[0][0].fieldInfo.length;
                for (var i = 0; i < fCount; i++) {
                    if (i == 0) {
                        layout.push({ name: String(propAc[0][0].fieldInfo[i].field), field: String(propAc[0][0].fieldInfo[i].fieldname), width: "112px" });
                    } else {
                        layout.push({ name: String(propAc[0][0].fieldInfo[i].field), field: String(propAc[0][0].fieldInfo[i].fieldname), width: "113px" });
                    }
                }
                var grid = new DataGrid({
                    id: 'grid',
                    store: store,
                    structure: layout,
                    autoHeight: true
                }, divNode);
                grid.canSort = function () { return false; };
                grid.startup();
                var divTableNode = domConstruct.create('div', {
                    'style': 'width: 100%;padding-top:10px;'
                }, cpNode);
                var thisTemp = this;
                connect.connect(grid, "onRowClick", function (evt) {
                    var obj = grid.getItem(evt.rowIndex);
                    thisTemp.initPropertyShow(divTableNode, propAc[obj.index[0]], false);
                });
                this.initPropertyShow(divTableNode, propAc[0], false);
            }
        }
    });
});