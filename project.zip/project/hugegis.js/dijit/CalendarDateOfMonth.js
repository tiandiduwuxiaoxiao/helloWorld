﻿define([
    'dojo/_base/declare',
    'dojo/_base/lang',
    'dojo/_base/array',
    'dojo/_base/html',
    'dojo/on',
    'dojo/sniff',
    'dojo/touch',
    'dojo/query',
    'dojo/text!./templates/CalendarDateOfMonth.html',
    'dijit/_WidgetBase',
	'dijit/_TemplatedMixin',
    'dijit/_WidgetsInTemplateMixin',
    'hugegis/dijit/Popup',
    "dojo/_base/connect",
    "dojox/grid/DataGrid",
    "dojo/data/ItemFileWriteStore",
    'dojo/dom',
    "dijit/form/DateTextBox",
    "dijit/form/Button",
    'hugegis/dijit/MessagePopup',
    "dojo/json",
    'hugegis/dijit/LoadingShelter',
    "dojo/domReady!"
],
function (declare, lang, array, html, on, has, touch,
query, template, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, Popup, connect, DataGrid, ItemFileWriteStore,
dom, DateTextBox, Button, MessagePopup, json, LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,
        dateSet: new Date(),
        parent: null,
        feedback: null,

        constructor: function () {
            this.nls = window.hugegisNls.calendarDateString;
            this.inherited(arguments);
        },

        postCreate: function () {
            this.inherited(arguments);
            this.start();
        },
        start: function () {
            var that = this;
            this.dateFormatHandler();
            $(this.calendarDateOfMonthTextId).text(this.dateSet.Format(this.nls.dateFormatTwo));
            this.createCalendarDate(new Date(this.dateSet));

            $(this.calendarDateOfMonthPrewIconId).click(lang.hitch(this, function (e) {
                this.prewIconClickHandler();
            }));
            $(this.calendarDateOfMonthNextIconId).click(lang.hitch(this, function (e) {
                this.nextIconClickHandler();
            }));

            $(this.CalendarDateOfMonthTableForMonth).find('td').click(lang.hitch(this, function (e) {
                var target = event.target || event.srcElement;
                this.dateSet.setMonth($(target).attr('value'));
                $(this.calendarDateOfMonthTextId).text(this.dateSet.Format(this.nls.dateFormatTwo));
                $(this.CalendarDateOfMonthTableForMonth).find('td').removeClass('calendarDateClickTdClass');
                $(target).addClass('calendarDateClickTdClass');
                if (this.feedback) {//回调之后的this不是widget的this，单独的函数中
                    this.feedback(this.dateSet);
                }
            }));
        },

        prewIconClickHandler: function () {
            this.dateSet.setFullYear(this.dateSet.getFullYear() - 1);
            $(this.calendarDateOfMonthTextId).text(this.dateSet.Format(this.nls.dateFormatTwo));
            $(this.CalendarDateOfMonthTableForMonth).find('td').removeClass('calendarDateClickTdClass');
        },
        nextIconClickHandler: function () {
            this.dateSet.setFullYear(this.dateSet.getFullYear() + 1);
            $(this.calendarDateOfMonthTextId).text(this.dateSet.Format(this.nls.dateFormatTwo));
            $(this.CalendarDateOfMonthTableForMonth).find('td').removeClass('calendarDateClickTdClass');
        },
        createCalendarDate: function (dateObj) {
            var tds = $(this.CalendarDateOfMonthTableForMonth).find('td');
            tds.removeClass();
            tds.addClass('calendarDateTdClassForMonth');
            tds.attr('value', function (idx) {
                return idx;
            });
        },
        dateFormatHandler: function () {
            Date.prototype.Format = function (fmt) {
                var o = {
                    "M+": this.getMonth() + 1,
                    "d+": this.getDate(),
                    "h+": this.getHours(),
                    "m+": this.getMinutes(),
                    "s+": this.getSeconds(),
                    "q+": Math.floor((this.getMonth() + 3) / 3),
                    "S": this.getMilliseconds()
                };
                if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
                for (var k in o)
                    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                return fmt;
            }
        }
    })
});