﻿define([
    'dojo/_base/declare',
    'dojo/_base/lang',
    'dojo/_base/array',
    'dojo/_base/html',
    'dojo/on',
    'dojo/sniff',
    'dojo/touch',
    'dojo/query',
    'dojo/text!./templates/CalendarDateFull.html',
    'dijit/_WidgetBase',
	'dijit/_TemplatedMixin',
    'dijit/_WidgetsInTemplateMixin',
    'hugegis/dijit/Popup',
    "dojo/_base/connect",
    "dojox/grid/DataGrid",
    "dojo/data/ItemFileWriteStore",
    'dojo/dom',
    "dijit/form/DateTextBox",
    "dijit/form/Button",
    'hugegis/dijit/MessagePopup',
    "dojo/json",
    'hugegis/dijit/LoadingShelter',
    "dojo/domReady!"
],
function (declare, lang, array, html, on, has, touch,
query, template, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, Popup, connect, DataGrid, ItemFileWriteStore,
dom, DateTextBox, Button, MessagePopup, json, LoadingShelter
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,
        dateSet: new Date(),
        parent: null,
        feedback: null,
        currentTarget: null,
        currentValue: null,
        currentInputDate: null,

        constructor: function () {
            this.nls = window.hugegisNls.calendarDateString;
            this.inherited(arguments);
        },

        postCreate: function () {
            var that = this;
            this.inherited(arguments);
            this.start();
        },
        start: function () {
            var that = this;
            this.dateFormatHandler();
            if (this.currentValue) {
                var reg = /[^0-9]/g,
                    str = this.currentValue.replace(reg, ' '),
                    arr = str.split(' ');
                this.dateSet.setFullYear(arr[0], arr[1] - 1, arr[2]);
                this.dateSet.setHours(arr[4], arr[5]);
            }
            this.currentInputDate = new Date(this.dateSet);
            $(this.calendarDateFullTextId).text(this.dateSet.Format(this.nls.dateFormatOne));
            $(this.calendarDateFullTimeSetId).text(this.dateSet.Format(this.nls.dateFormatThree));
            this.createCalendarDate(new Date(this.dateSet));
            $(this.calendarDateFullPrewIconId).click(lang.hitch(this, function (e) {
                this.prewIconClickHandler();
            }));
            $(this.calendarDateFullNextIconId).click(lang.hitch(this, function (e) {
                this.nextIconClickHandler();
            }));
            $(this.calendarDateFullSliderHourId).attr('title', this.dateSet.getHours());
            $(this.calendarDateFullSliderHourId).slider({
                range: "min",
                value: that.dateSet.getHours(),
                min: 0,
                max: 23,
                slide: function (event, ui) {
                    that.dateSet.setHours(ui.value);
                    $(that.calendarDateFullSliderHourId).attr('title', ui.value);
                    $(that.calendarDateFullTimeSetId).text(that.dateSet.Format(that.nls.dateFormatThree));
                }
            });
            $(this.calendarDateFullSliderMinuteId).attr('title', this.dateSet.getMinutes());
            $(this.calendarDateFullSliderMinuteId).slider({
                range: "min",
                value: that.dateSet.getMinutes(),
                min: 0,
                max: 59,
                slide: function (event, ui) {
                    that.dateSet.setMinutes(ui.value);
                    $(that.calendarDateFullSliderMinuteId).attr('title', ui.value);
                    $(that.calendarDateFullTimeSetId).text(that.dateSet.Format(that.nls.dateFormatThree));
                }
            });
            $(this.sliderDateFullCommitBtnId).click(lang.hitch(this, function (e) {
                this.sliderDateCommitBtnClick();
            }));
            $(this.CalendarFullCommonTable).find('th').addClass('calendarDateTableThClass')
            $(this.CalendarFullCommonTable).find('td').click(lang.hitch(this, function (e) {
                var target = event.target || event.srcElement;
                this.dateSet.setDate($(target).text());
                $(this.calendarDateFullTimeSetId).text(this.dateSet.Format(this.nls.dateFormatThree));
                $(this.CalendarFullCommonTable).find('td').removeClass('calendarDateClickTdClass');
                $(target).addClass('calendarDateClickTdClass');
            }));
        },
        sliderDateCommitBtnClick: function () {
            $(this.calendarDateFullMainAreaId).remove();
            if (this.feedback) {
                this.feedback(this.dateSet, this.currentTarget);
            }
        },
        prewIconClickHandler: function () {
            this.dateSet.setMonth(this.dateSet.getMonth() - 1);
            $(this.calendarDateFullTextId).text(this.dateSet.Format(this.nls.dateFormatOne));
            $(this.calendarDateFullTimeSetId).text(this.dateSet.Format(this.nls.dateFormatThree));
            this.createCalendarDate(new Date(this.dateSet));
        },
        nextIconClickHandler: function () {
            this.dateSet.setMonth(this.dateSet.getMonth() + 1);
            $(this.calendarDateFullTextId).text(this.dateSet.Format(this.nls.dateFormatOne));
            $(this.calendarDateFullTimeSetId).text(this.dateSet.Format(this.nls.dateFormatThree));
            this.createCalendarDate(new Date(this.dateSet));
        },
        createCalendarDate: function (dateObj) {
            var nowDate = (new Date()).getDate();
            //判断当年当月
            var bool = Boolean(dateObj.getFullYear() - (new Date()).getFullYear());
            if (!bool)
                bool = Boolean(dateObj.getMonth() - (new Date()).getMonth());
            var inputBool = Boolean(dateObj.getFullYear() - this.currentInputDate.getFullYear());
            if (!inputBool)
                inputBool = Boolean(dateObj.getMonth() - this.currentInputDate.getMonth());
            if (!inputBool)
                var selectDay = dateObj.getDate();
            else
                var selectDay = 0;
            var firstDay = new Date(dateObj);
            firstDay.setDate(1);
            var week = firstDay.getDay();
            var pos = week % 7;
            var calendar = $(this.CalendarFullCommonTable)[0].children['0'].children;
            var daysOfMonth = 1;

            dateObj.setMonth(dateObj.getMonth() + 1);
            dateObj.setDate(0);
            var maxDays = dateObj.getDate();

            var prewNum = 1, nextNum = 1;
            var prew = dateObj;
            prew.setMonth(prew.getMonth());
            prew.setDate(0);
            prewNum = prew.getDate();
            prewNum = prewNum - pos + 1;
            for (var i = 1; i < calendar.length; i++) {
                for (var j = 0; j < calendar[i].cells.length; j++) {
                    var someTd = $(calendar[i].cells[j]);
                    someTd.removeAttr('id');
                    someTd.removeAttr('class');
                    someTd.removeAttr('disabled');
                    if (j < pos && i == 1) {
                        someTd.attr('class', 'calendarDateTableTdAnotherClass');
                        someTd.attr('disabled', 'disabled');
                        someTd.attr('id', 'calendarDateAnotherTdId' + prewNum);
                        someTd.text(prewNum);
                        prewNum++;
                    } else {
                        if (daysOfMonth <= maxDays) {
                            if (daysOfMonth == selectDay) {
                                someTd.attr('class', 'calendarDateClickTdClass');
                            } else {
                                someTd.attr('class', 'calendarDateTableTdClass');
                            }
                            someTd.text(daysOfMonth);
                        } else {
                            someTd.attr('class', 'calendarDateTableTdAnotherClass');
                            someTd.text(nextNum);
                            someTd.attr('disabled', 'disabled');
                            someTd.attr('id', 'calendarDateAnotherTdId' + nextNum);
                            nextNum++;
                        }
                        //to mark today
                        if (!bool && daysOfMonth == nowDate) {
                            someTd.addClass('markTodayClass');
                        }
                        daysOfMonth++;
                    }
                }
            }
        },
        dateFormatHandler: function () {
            Date.prototype.Format = function (fmt) {
                var o = {
                    "M+": this.getMonth() + 1,
                    "d+": this.getDate(),
                    "h+": this.getHours(),
                    "m+": this.getMinutes(),
                    "s+": this.getSeconds(),
                    "q+": Math.floor((this.getMonth() + 3) / 3),
                    "S": this.getMilliseconds()
                };
                if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
                for (var k in o)
                    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                return fmt;
            }
        }
    })
});