﻿define([
    'dojo/_base/declare',
    'dojo/_base/lang',
    'dojo/_base/array',
    'dojo/_base/html',
    'dojo/on',
    'dojo/sniff',
    'dojo/touch',
    'dojo/query',
    'dojo/text!./templates/ImageCollapse.html',
    'dijit/_WidgetBase',
	'dijit/_TemplatedMixin',
    'dijit/_WidgetsInTemplateMixin',
    'hugegis/dijit/PopupForCollapse',
    "dojo/_base/connect",
    "dojo/data/ItemFileWriteStore",
    'dojo/dom',
    'hugegis/dijit/MessagePopup',
    "dojo/json"
],
function (declare, lang, array, html, on, has, touch,
query, template, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, PopupForCollapse, connect, ItemFileWriteStore,
dom, MessagePopup, json
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,
        imageUrlArray: [],

        constructor: function (imageArr) {
            this.imageUrlArray = imageArr;
        },
        createImageCollapse: function () {
            var olObj = $(this.imageCollapsebottomBtn);
            var imgObj = $(this.imageCollapseNode);
            var imgDis = $(this.displayImgNode);

            imgObj.css('height', '500');
            imgDis.css({ 'text-align': 'center', 'height': '60', 'padding': '10' });
            var divItem = $('<div></div>');
            divItem.css({ 'margin': '0 auto', 'height': '50', 'width': this.imageUrlArray.length * (40 + 2) });
            imgDis.append(divItem);

            for (var idx in this.imageUrlArray) {
                var divNode = $('<div></div>');
                divNode.css({ 'height': '50', 'cursor': 'pointer', 'width': '40', 'margin': '0 2', 'border': '1px solid #fff', 'float': 'left' });
                divNode.hover(
                    function () {
                        $(this).css('padding', '2');
                    },
                    function () {
                        $(this).css('padding', '0');
                    }
                );
                var divImg = $('<img />');
                divImg.attr('src', this.imageUrlArray[idx].url);
                divImg.css({ 'max-width': '100%', 'max-height': '100%' });
                divImg.click(lang.hitch(this, function (event) {
                    var target = $(event.target || event.srcElement);
                    var theIndex = target.parent().index();
                    $(this.myCarouselOfImage).carousel(theIndex);
                    this.imgDivStyleSet(theIndex);
                }));
                var label = $('<label></label>');
                label.text(this.imageUrlArray[idx].stepType);
                label.css({
                    'position': 'absolute',
                    'left': '300px'
                });
                var labelT = $('<label></label>');
                labelT.text(this.imageUrlArray[idx].rq);
                labelT.css({
                    'position': 'absolute',
                    'left': '300px',
                    'top': '20px'
                });
                divNode.append(divImg);
                divItem.append(divNode);

                if (idx == 0) {
                    divNode.css('border', '2px solid yellow');

                    var olHtml = $('<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>');
                    olHtml.css('background-color', '#486F97');
                    olObj.append(olHtml);

                    var divHtml = $('<div align="center" class="item active"></div>');
                    divHtml.css({ 'height': '500', 'width': '100%' });
                    divHtml.append(label);
                    divHtml.append(labelT);
                    var imgHtml = $('<img />');
                    imgHtml.attr('src', this.imageUrlArray[idx].url);
                    imgHtml.css({ "max-height": "100%", "max-width": "100%" });
                    divHtml.append(imgHtml);
                    imgObj.append(divHtml);
                } else {
                    var olHtml = $('<li data-target="#carousel-example-generic"></li>');
                    olHtml.css('background-color', '#486F97');
                    olHtml.attr('data-slide-to', idx);
                    olObj.append(olHtml);

                    var divHtml = $('<div align="center" class="item"></div>');
                    divHtml.css({ 'height': '500', 'width': '100%' });
                    divHtml.append(label);
                    divHtml.append(labelT);
                    var imgHtml = $('<img />');
                    imgHtml.attr('src', this.imageUrlArray[idx].url);
                    imgHtml.css({ "max-height": "100%", "max-width": "100%" });
                    divHtml.append(imgHtml);
                    imgObj.append(divHtml);
                }
            }
            $(this.myCarouselOfImage).carousel({
                interval: false
            });
        },
        imgDivStyleSet: function (idx) {
            var imgDisNode = $(this.displayImgNode).find('div div');
            imgDisNode.css('border', function () {
                if ($(this).index() == idx) {
                    return '2px solid yellow';
                } else {
                    return '1px solid #fff';
                }
            });
        },
        postCreate: function () {
            this.createImageCollapse();
            new PopupForCollapse({
                titleLabel: "图片展示",
                width: 800,
                height: 625,
                content: this.domNode
            });
            var imgUrl = require.toUrl('hugegis/images/');
            $(this.anticlockwiseBtnNode).css({
                'width': '60',
                'height': '60',
                'cursor': 'pointer',
                'background': 'transparent url(' + imgUrl + 'undo_48.png) no-repeat center'
            });
            $(this.anticlockwiseBtnNode).hover(
                function () {
                    $(this).css({
                        'border-radius': '40px',
                        'background-color': '#486F97'
                    });
                },
                function () {
                    $(this).css({
                        'border-radius': '0',
                        'background-color': ''
                    });
                }
            );
            $(this.anticlockwiseBtnNode).click(lang.hitch(this, function () {
                var activeNode = $(this.imageCollapseNode).find('.active');
                if (!activeNode.attr('rotateValue')) {
                    activeNode.attr('rotateValue', -30);
                } else {
                    activeNode.attr('rotateValue', Number(activeNode.attr('rotateValue')) - 30);
                }
                activeNode.css('transform', 'rotate(' + activeNode.attr('rotateValue') + 'deg)');
            }));
            $(this.clockwiseBtnNode).click(lang.hitch(this, function () {
                var activeNode = $(this.imageCollapseNode).find('.active');
                if (!activeNode.attr('rotateValue')) {
                    activeNode.attr('rotateValue', 30);
                } else {
                    activeNode.attr('rotateValue', Number(activeNode.attr('rotateValue')) + 30);
                }
                activeNode.css('transform', 'rotate(' + activeNode.attr('rotateValue') + 'deg)');
            }));
            $(this.clockwiseBtnNode).css({
                'width': '60',
                'height': '60',
                'cursor': 'pointer',
                'background': 'transparent url(' + imgUrl + 'redo_48.png) no-repeat center'
            });
            $(this.clockwiseBtnNode).hover(
                function () {
                    $(this).css({
                        'border-radius': '40px',
                        'background-color': '#486F97'
                    });
                },
                function () {
                    $(this).css({
                        'border-radius': '0',
                        'background-color': ''
                    });
                }
            );

            $(this.imageCollapsebottomBtn).find('li').click(lang.hitch(this, function (that) {
                var theIndex = $(that.target || that.srcElement).index();
                $(this.myCarouselOfImage).carousel(theIndex);
                this.imgDivStyleSet(theIndex);
            }));
            $(this.prevBtnHandler).click(lang.hitch(this, function () {
                $(this.myCarouselOfImage).carousel('prev');
                var item = $(this.imageCollapseNode).find('.active');
                var idx = item.index() - 1 >= 0 ? item.index() - 1 : item.index() - 1 + this.imageUrlArray.length;
                this.imgDivStyleSet(idx);
            }));
            $(this.nextBtnHandler).click(lang.hitch(this, function () {
                $(this.myCarouselOfImage).carousel('next');
                var item = $(this.imageCollapseNode).find('.active');
                var idx = item.index() + 1 <= this.imageUrlArray.length - 1 ? item.index() + 1 : item.index() + 1 - this.imageUrlArray.length;
                this.imgDivStyleSet(idx);
            }));
        }
    })
});